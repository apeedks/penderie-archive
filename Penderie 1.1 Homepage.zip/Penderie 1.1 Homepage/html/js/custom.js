$(document).ready(function(){
	
	fullSize();
	applyOrientation();
	
	$('input[type="search"]').on('focusout', function(e) {
	  $('form').removeClass('opened');
	});
	
	$('#banner-homeslider').owlCarousel({
		loop:true,
		margin:0,
		nav:true,
		animateOut: 'fadeOut',
		animateIn: 'fadeIn',
		dots:true,
		autoplay:false,
		navText: [
            "<i class='fa fa-angle-left'></i>",
            "<i class='fa fa-angle-right'></i>"
        ],
		responsive:{
			0:{
				items:1
			},
			600:{
				items:1
			},
			1000:{
				items:1
			}
		}
	})
	
	$('#banner-homesliders').owlCarousel({
		loop:true,
		margin:0,
		nav:true,
		animateOut: 'fadeOut',
		animateIn: 'fadeIn',
		dots:false,
		autoplay:false,
		navText: [
            "<i class='fa fa-angle-left'></i>",
            "<i class='fa fa-angle-right'></i>"
        ],
		responsive:{
			0:{
				items:1
			},
			600:{
				items:1
			},
			1000:{
				items:1
			}
		}
	})
	
	$('#testis-homeslider, #testis-right-homeslider').owlCarousel({
		loop:true,
		margin:0,
		nav:true,
		/*animateOut: 'fadeOut',
		animateIn: 'fadeIn',*/
		dots:false,
		autoplay:true,
		navText: [
            "<i class='icon-arrows'></i>",
            "<i class='icon-arrows-1'></i>"
        ],
		responsive:{
			0:{
				items:1
			},
			600:{
				items:1
			},
			1000:{
				items:1
			}
		}
	})
	
	$('#banner-eventLounge').owlCarousel({
		loop:true,
		margin:0,
		nav:true,
		dots:false,
		autoplay:true,
		navText: [
            "<i class=' icon-arrows'></i>",
            "<i class=' icon-arrows-1'></i>"
        ],
		responsive:{
			0:{
				items:1
			},
			600:{
				items:1
			},
			1000:{
				items:1
			}
		}
	})
	
	$('#product-homeslider').owlCarousel({
		loop:true,
		margin:0,
		nav:true,
		/*animateOut: 'fadeOut',
		animateIn: 'fadeIn',*/
		dots:false,
		autoplay:true,
		navText: [
            "<i class='icon-arrows'></i>",
            "<i class='icon-arrows-1'></i>"
        ],
		responsive:{
			0:{
				items:1
			},
			600:{
				items:1
			},
			1000:{
				items:1
			}
		}
	})
	
	$('#client-homeslider').owlCarousel({
		loop:true,
		margin:15,
		nav:true,
		/*animateOut: 'fadeOut',
		animateIn: 'fadeIn',*/
		dots:false,
		autoplay:true,
		navText: [
            "<i class='icon-arrows'></i>",
            "<i class='icon-arrows-1'></i>"
        ],
		responsive:{
			0:{
				items:2
			},
			600:{
				items:5
			},
			1000:{
				items:7
			}
		}
	})	
	
	$('#light-box-sd').owlCarousel({
		loop:true,
		margin:2,
		nav:true,
		dots:false,
		autoplay:true,
		navText: [
            "<i class='icon-arrows'></i>",
            "<i class='icon-arrows-1'></i>"
        ],
		responsive:{
			0:{
				items:2
			},
			600:{
				items:4
			},
			1000:{
				items:5
			}
		}
	})
	
	
	$('#product-homeslid').owlCarousel({
		loop:true,
		margin:0,
		nav:true,
		/*animateOut: 'fadeOut',
		animateIn: 'fadeIn',*/
		dots:false,
		autoplay:true,
		navText: [
            "<i class='fa fa-angle-left'></i>",
            "<i class='fa fa-angle-right'></i>"
        ],
		responsive:{
			0:{
				items:1
			},
			600:{
				items:3
			},
			1000:{
				items:4
			}
		}
	})
	
	
	$('#testimonial-homeslider').owlCarousel({
		loop:true,
		margin:0,
		nav:false,
		/*animateOut: 'fadeOut',
		animateIn: 'fadeIn',*/
		dots:true,
		autoplay:true,
		navText: [
            "<i class='fa fa-angle-left'></i>",
            "<i class='fa fa-angle-right'></i>"
        ],
		responsive:{
			0:{
				items:1
			}
		}
	})
	
	$('#req-storis, #req-storiss').owlCarousel({
		loop:true,
		margin:14,
		nav:true,
		dots:false,
		autoplay:false,
		navText: [
            "<i class='fa fa-angle-left'></i>",
            "<i class='fa fa-angle-right'></i>"
        ],
		responsive:{
			0:{
				items:1
			},
			600:{
				items:2
			},
			1000:{
				items:4
			}
		}
	})
	
	$("#marque-slider,#marque-slider1,#marque-slider2,#marque-slider3,#marque-slider4").owlCarousel({
		navigation : false, // Show next and prev buttons
		slideSpeed : 300,
		paginationSpeed : 400,
		nav:true,
		autoplay:true,
		loop:true,
		navText:[
		  "<i class='fa fa-angle-left'></i>",
		  "<i class='fa fa-angle-right'></i>"],
		dots:false,
		singleItem:true,
		responsive:{
		0:{
			items:1
		}
		}
	});
	
	$('#spot-slide-light').owlCarousel({
		loop:true,
		margin:0,
		nav:true,
		animateOut: 'fadeOut',
		animateIn: 'fadeIn',
		dots:false,
		autoplay:true,
		navText: [
            "<i class='fa fa-angle-left'></i>",
            "<i class='fa fa-angle-right'></i>"
        ],
		responsive:{
			0:{
				items:1
			},
			600:{
				items:1
			},
			1000:{
				items:1
			}
		}
	})
	
	$('#timeline-sliderss').owlCarousel({
		loop:true,
		margin:0,
		nav:true,
		/*animateOut: 'fadeOut',
		animateIn: 'fadeIn',*/
		dots:false,
		autoplay:true,
		navText: [
            "<i class='icon-arrows'></i>",
            "<i class='icon-arrows-1'></i>"
        ],
		responsive:{
			0:{
				items:1
			},
			600:{
				items:1
			},
			1000:{
				items:1
			}
		}
	})
	
	$('#maga-slide').owlCarousel({
		loop:false,
		margin:0,
		nav:true,
		items:1,
		dots:false,
		autoplay:false,
		navText: [
            "<i class='icon-arrows'></i>",
            "<i class='icon-arrows-1'></i>"
        ],
	})

$(function(){
    var pagePositon = 0,
        sectionsSeclector = 'section',
        $scrollItems = $(sectionsSeclector),
        offsetTolorence = 30,
        pageMaxPosition = $scrollItems.length - 1;
    
    //Map the sections:
    $scrollItems.each(function(index,ele) { $(ele).attr("debog",index).data("pos",index); });

    // Bind to scroll
    $(window).bind('scroll',upPos);
    
    //Move on click:
    $('.headerPageControl a').click(function(e){
        if ($(this).hasClass('bot') && pagePositon+1 <= pageMaxPosition) {
            pagePositon++;
            $('html, body').stop().animate({ 
                  scrollTop: $scrollItems.eq(pagePositon).offset().top
            }, 300);
        }
        if ($(this).hasClass('top') && pagePositon-1 >= 0) {
            pagePositon--;
            $('html, body').stop().animate({ 
                  scrollTop: $scrollItems.eq(pagePositon).offset().top
              }, 300);
            return false;
        }
    });
    
    //Update position func:
    function upPos(){
       var fromTop = $(this).scrollTop();
       var $cur = null;
        $scrollItems.each(function(index,ele){
            if ($(ele).offset().top < fromTop + offsetTolorence) $cur = $(ele);
        });
       if ($cur != null && pagePositon != $cur.data('pos')) {
           pagePositon = $cur.data('pos');
       }                   
    }   
});
	
$(function () { 
  $('[data-toggle="tooltip"]').tooltip({trigger: 'manual'}).tooltip('show');
});  

function moved() {
	alert('in');
	var owl = $(".owl-carousel").data('owlCarousel');
	if (owl.currentItem + 1 === owl.itemsAmount) {
		alert('THE END');
	}
}
	
$(document).ready(function () {       
      if ($('html').hasClass('desktop')) {
        new WOW().init();
      }
});

$.scrollIt({
		upKey: 40,             // key code to navigate to the next section
		downKey: 40,           // key code to navigate to the previous section
		easing: 'ease-in-out',      // the easing function for animation
		scrollTime: 1500,       // how long (in ms) the animation takes
		activeClass: 'active', // class given to the active nav element
		onPageChange: null,    // function(pageIndex) that is called when page is changed
		topOffset:0           // offste (in px) for fixed top navigation
	});
});

$(window).load(function(){
	if (window.innerWidth > 1024 ) {
		var s = skrollr.init();
	}
});

$( window ).resize(function() {
	fullSize();
});

$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})

function fullSize() {
    var heights = window.innerHeight;
    jQuery(".fullHt").css('min-height', (heights + 0) + "px");
}

function applyOrientation() {
    if (window.innerHeight > window.innerWidth) {
        $("body").addClass("potrait");
        $("body").removeClass("landscape");
    } else {
        $("body").addClass("landscape");
        $("body").removeClass("potrait");
    }
}

var banner_Ht = window.innerHeight - $('header').innerHeight();	
	$(window).scroll(function(){
	  var sticky = $('body'),
		  scroll = $(window).scrollTop();
	
	  if (scroll >= 300) sticky.addClass('sticky-header');
	  else sticky.removeClass('sticky-header');
});

$('.custo-filter-colap').click(function () {
	$('body').toggleClass('custo-filter-open')
	$(this).toggleClass('custo-filter-onen-close')
});

$('.search-clicker').click(function () {
	$('body').toggleClass('custo-search-open')
	$(this).toggleClass('search-cross')
});


$('.table-in-acordi .accordion-toggle').click(function () {
	$(this).toggleClass('apsule-colaps')
});

$(function(){
	$('a[title]').tooltip();
});


jQuery(".own-tab-cate li").click(function(){
	var colorClass = jQuery(this).attr("color-class");
	jQuery("#own-category-toggle").attr("class","");
	jQuery("#own-category-toggle").attr("class","own-category-sec fullHt "+colorClass+"");
});

$(".showCountry").click(function() {
	if(!$(this).next("ul").is(":visible")){
		$(this).addClass("open");
		$(this).next("ul").slideDown(400);
	}else{
		$(this).removeClass("open");
		$(this).next("ul").slideUp(400);
	}		
});
$(".selectCountry ul li").click(function() {
	var thisValue = $(this).html();
	$(".showCountry").html(thisValue);
	$(".showCountry").removeClass("open");
	$(".selectCountry ul").slideUp(400);
});


/*----------------------------------------------------*/
/*    Accordians FAQ
 /*----------------------------------------------------*/
$('.accordion').on('shown.bs.collapse', function (e) {
	$(e.target).parent().addClass('active_acc');
	$(e.target).prev().find('.switch').removeClass('fa-plus');
	$(e.target).prev().find('.switch').addClass('fa-minus');
});
$('.accordion').on('hidden.bs.collapse', function (e) {
	$(e.target).parent().removeClass('active_acc');
	$(e.target).prev().find('.switch').addClass('fa-plus');
	$(e.target).prev().find('.switch').removeClass('fa-minus');
}); 

$('button').on('click', function(e) {
  e.preventDefault();
  $('form').addClass('opened');
  $('input[type="search"]').focus();
});
	

$(".tab_content").hide();
$(".tab_content:first").show();

/* if in tab mode */
$("ul.tabs li").click(function() {
	
  $(".tab_content").hide();
  var activeTab = $(this).attr("rel"); 
  $("#"+activeTab).fadeIn();		
	
  $("ul.tabs li").removeClass("active");
  $(this).addClass("active");

  $(".tab_drawer_heading").removeClass("d_active");
  $(".tab_drawer_heading[rel^='"+activeTab+"']").addClass("d_active");
  
});
/* if in drawer mode */
$(".tab_drawer_heading").click(function() {
  
  $(".tab_content").hide();
  var d_activeTab = $(this).attr("rel"); 
  $("#"+d_activeTab).fadeIn();
  
  $(".tab_drawer_heading").removeClass("d_active");
  $(this).addClass("d_active");
  
  $("ul.tabs li").removeClass("active");
  $("ul.tabs li[rel^='"+d_activeTab+"']").addClass("active");
});


/* Extra class "tab_last" 
   to add border to right side
   of last tab */
$('ul.tabs li').last().addClass("tab_last");



$('.dash-nav-btn').click(function () {
	$('body').toggleClass('dash-left-pannel')
	$(this).toggleClass('dash-designpannel')
});

$('.lisetre-nav').click(function () {
	$(this).toggleClass('lisetre-nav-toggls')
});

$(document).ready(function(){
	$('.gallery-left-top a').click(function(){
		$(this).parent().toggleClass('active').siblings().removeClass('active');
		$(this).parent().siblings().find("ul").slideUp();
		if($(this).parent().hasClass('active')){
			$(this).parent().find("ul").slideDown();
		}else{
			$(this).parent().find("ul").slideUp();
		}
	});
});


wrapper   = $(".tabss");
tabs      = wrapper.find(".tab");
tabToggle = wrapper.find(".tab-toggle");

// ----------------- Functions

function openTab() {
	var content     = $(this).parent().next(".content"),
		activeItems = wrapper.find(".active");
	
	if(!$(this).hasClass('active')) {
		$(this).add(content).add(activeItems).toggleClass('active');
		wrapper.css('min-height', content.outerHeight());
	}
};

// ----------------- Interactions

tabToggle.on('click', openTab);

// ----------------- Constructor functions

$(window).load(function(){
  tabToggle.first().trigger('click');  
});


$(".k-switch").click(function () {
  // Simple Code
  var self = $(this);
	  if(self.hasClass("on")) {
         self.removeClass("on");
      } else {
        self.addClass("on");
      }
  });