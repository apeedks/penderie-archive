import {Component, OnInit, ElementRef, ViewChild} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {DbserviceService} from '../services/dbservice.service';
import {AuthenticationService} from '../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import {CookieService} from 'ngx-cookie-service';
import $ from 'jquery';

@Component({
  selector: 'app-magazines',
  templateUrl: './magazines.component.html',
  styleUrls: ['./magazines.component.css']
})
export class MagazinesComponent implements OnInit {
	@ViewChild('lnktimelinesharebox') lnktimelinesharebox:ElementRef;
	model = {sortfield:'latest', searchfield:'',themefield:'All', filtercat:[],tag:'',searchcat:0};
	userid = 0;
	loading2 = false;
	searchcat:string="";
	visiblefilter = false;
	parentid: number = 0;
	custo_filter_onen_close = false;
	visittype = '';
	theme:string = '';
	thetrueluxury:any;
	finematerial:any;
	superiorcraftsmanship:any;
	magazineslist:any;
	artofstyling:any;
	balancedliving:any;
	latestlist:any;
	popularlist:any;
	featuredlist:any;
	rootpath = '';
	websiteroot = '';
	currtime:any;
	myitems = [];
	myslider = [];
	options:any;
	pageSize: number;
	linetypes:any;
	totalitems: any;
	page: number = 1;
	last_page: number =1;
	mysharedstoryid: number =1;
	mysharedtype = 'Magazine';
	mysharedurl = '';
	mysharedescription = '';
	mysharedtitle = '';
	mysharedimage = '';
	categories: any;
	loading = false;
	category:any = '';
  	categorytitle:any = '';
	filters:any = {thetrueluxury:[],finematerial:[],superiorcraftsmanship:[],artofstyling:[],balancedliving:[]};
	sortby = '';
	loaded:boolean = false;
	constructor(private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private cookieService: CookieService) { 
		this.rootpath = localStorage.getItem('baseurl');
		this.visittype = localStorage.getItem('visittype');
		this.websiteroot = localStorage.getItem('basewebsiteurl');
		this.route.params.subscribe(params => {
		    this.theme = params['theme'];//params['theme']; // (+) converts string 'id' to a number
			if(!this.theme)
				this.theme = 'All';
			this.loadpage(this.page);
		});
	}
	   filterbycategory(id)
	    {
	        this.model.searchcat = id;
	        
	        this.myitems = [];
	        this.loadpage(1);
	        // this.loadddl();
	    }
	ngOnInit() {
	    //	this.loadddl();
		this.categorytitle = '';
		this.route.queryParamMap.subscribe(params => {
			if(params.keys.length > 0){
				this.category = params.get('category');
				this.model.tag = params.get('tag');
				console.log(params,params.keys.length);
				this.dbserv.getAll("magazinewidget/"+this.visittype+"/"+this.theme+"/latest").subscribe(res => {this.latestlist = res;});	
				this.dbserv.getAll("magazinewidget/"+this.visittype+"/"+this.theme+"/popular").subscribe(res => {this.popularlist = res;});	
				this.dbserv.getAll("magazinewidget/"+this.visittype+"/"+this.theme+"/featured").subscribe(res => {this.featuredlist = res;});
				this.loadpage(1);
				this.loadddl();
				this.dbserv.post("magazineslides/"+this.visittype+"/"+this.theme+"/"+this.page+"/20",this.model)
				.subscribe(res => {
					this.myslider = res.data;
				});
				scroll(0,0);
			}
		});
		this.route.params.subscribe(params => {
		    this.theme = params['theme'];//params['theme']; // (+) converts string 'id' to a number
			if(!this.theme)
				this.theme = 'All';
			this.dbserv.getAll("magazinewidget/"+this.visittype+"/"+this.theme+"/latest").subscribe(res => {this.latestlist = res;});	
			this.dbserv.getAll("magazinewidget/"+this.visittype+"/"+this.theme+"/popular").subscribe(res => {this.popularlist = res;});	
			this.dbserv.getAll("magazinewidget/"+this.visittype+"/"+this.theme+"/featured").subscribe(res => {this.featuredlist = res;});
			this.loadpage(1);
			this.loadddl();
			this.dbserv.post("magazineslides/"+this.visittype+"/"+this.theme+"/"+this.page+"/20",this.model)
			.subscribe(res => {
				this.myslider = res.data;
			});
			scroll(0,0);
		});
		this.dbserv.getAll("magazinewidget/"+this.visittype+"/"+this.theme+"/latest").subscribe(res => {this.latestlist = res;});	
		this.dbserv.getAll("magazinewidget/"+this.visittype+"/"+this.theme+"/popular").subscribe(res => {this.popularlist = res;});	
		this.dbserv.getAll("magazinewidget/"+this.visittype+"/"+this.theme+"/featured").subscribe(res => {this.featuredlist = res;});

		this.dbserv.getAll("sourcebytype/linetypes").subscribe(res => {this.linetypes = res;});
		this.loadpage(this.page);



        
	}

	ngAfterViewInit(){
		let obj=this;

		// Eventos teclado
		$(document).keydown(function(e) {
			switch(e.which) {
		        case 37: // left
		        obj.moveToSelected('prev');
		        break;

		        case 39: // right
		        obj.moveToSelected('next');
		        break;

		        default: return;
		    }
		    e.preventDefault();
		});

		$('#carousel>div').click(function() {
			console.log('div',$(this));
		  obj.moveToSelected($(this));
		});

		$('#prev').click(function() {
		  obj.moveToSelected('prev');
		});

		$('#next').click(function() {
		  obj.moveToSelected('next');
		});
		$('.carousel-indicators>li').click(function() {
			console.log($(this));
		  obj.moveToSelected($('#'+$(this).attr("data-slide-id")));
		  $('.carousel-indicators li').removeClass('active');
		  $(this).addClass("active");
		});

		$(".custo-filter-colap").click(function(e){
            if(!$(this).hasClass('custo_filter_onen_close')){
                $(".utl-filter-box").addClass('visiblefilter');
                $(".custo-filter-colap").addClass('custo_filter_onen_close');
                e.stopPropagation();
            }else{
                $(".utl-filter-box").removeClass('visiblefilter');
                $(".custo-filter-colap").removeClass('custo_filter_onen_close');
                e.stopPropagation();
            }
        });

        $(".utl-filter-box").click(function(e){
        	  e.stopPropagation();
        });

        $(document).click(function(){
        	  $(".utl-filter-box").removeClass('visiblefilter');
            $(".custo-filter-colap").removeClass('custo_filter_onen_close');
            // self.filterby();
        });
	}
	slidechange(inx,id){
		if ($('#slide'+inx).hasClass('selected')) {
			this.router.navigateByUrl('/'+this.visittype.toLowerCase()+'/magazines/show/'+id);
		}else{
			this.moveToSelected($('#slide'+inx));
		}
	}

	moveToSelected(element) {
		  if (element == "next") {
		    var selected = $(".selected").next();
		  } else if (element == "prev") {
		    var selected = $(".selected").prev();
		  } else {
		    var selected = element;
		  }
		  $('.carousel-indicators li').removeClass('active');
		  $('#indicators'+$(selected).prop('id')).addClass("active");

		  var next = $(selected).next();
		  var prev = $(selected).prev();
		  var prevSecond = $(prev).prev();
		  var nextSecond = $(next).next();

		  $(selected).removeClass().addClass("selected");

		  $(prev).removeClass().addClass("prev");
		  $(next).removeClass().addClass("next");

		  $(nextSecond).removeClass().addClass("nextRightSecond");
		  $(prevSecond).removeClass().addClass("prevLeftSecond");

		  $(nextSecond).nextAll().removeClass().addClass('hideRight');
		  $(prevSecond).prevAll().removeClass().addClass('hideLeft');

		}
	filterswitch()
	{
		$('html, body').animate({
        	scrollTop: $("#scrollUp").offset().top - 105
    	}, 2000);
		this.myitems = [];
		this.loadpage(1);
	}
	sortswitch()
	{
		$('html, body').animate({
        	scrollTop: $("#scrollUp").offset().top - 105
    	}, 2000);
		this.myitems = [];
		this.loadpage(1);
	}
	themefilterwitch()
	{
		this.myitems = [];
		this.loadpage(1);
	}
	pageChanged($event)
	{
	  this.loadpage($event) ; 
	}
	selecrmethod()
	{	this.myitems = [];
		this.loadpage(this.page);
	}
	loadpage(cpage)
	{
		if(cpage == 1)
			this.myitems = [];
		this.currtime = Math.random();
		this.loading = true;
		let cararray = [];
		this.filters.thetrueluxury.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.filters.finematerial.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.filters.superiorcraftsmanship.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.filters.artofstyling.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.filters.balancedliving.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		if(cararray.length == 0){
			if(this.category != '' && this.category != null)
				cararray.push(this.category);
		}
		this.model.filtercat = cararray;
		this.currtime = Math.random();
		this.dbserv.post("publicmagazines/"+this.visittype+"/"+this.theme+"/"+cpage+"/6",this.model).subscribe(res => {
																			if(cpage == 1)
																				this.myitems = [];
																			if(res.total>this.myitems.length)
																				this.myitems = [ ...this.myitems, ...res.data]
																			this.loaded = true;
																			this.page = res.current_page; 
																			this.totalitems = res.total;
																			this.pageSize = res.per_page;
																			this.last_page = res.last_page;
																			this.loading = false;
																			
																		}); 
	}
	// likeme(id,type)
	// {
	// 	let params = {magazine_id:id,status:type};
	// 	this.dbserv.post("magazinelike",params).subscribe(res => {
	// 															if(res.type=="success")
	// 															{
	// 																if(type=="like")
	// 																{
	// 																	$("#reclike" + id).css("display","none");
	// 																	$("#recunlike" + id).css("display","block");
	// 																}
	// 																else if(type=="unlike")
	// 																{
	// 																	$("#reclike" + id).css("display","block");
	// 																	$("#recunlike" + id).css("display","none");
	// 																}
	// 																// this.loadpage(this.page);
	// 																/*this._alert.create(res.type,res.message+type);*/
	// 															}
	// 															else if(res.type=="expired")
	// 															{
	// 																this.router.navigateByUrl('/login') ;	
	// 															}
	// 															else
	// 																this._alert.create(res.type,res.message);
	// 													});
	// }
	// saveme(id,type)
	// {
	// 	let params = {magazine_id:id,status:type};
	// 	this.dbserv.post("magazinemysavedlist",params).subscribe(res => {
	// 															if(res.type=="success")
	// 															{
	// 																if(type=="save")
	// 																{
	// 																	$("#recsave" + id).css("display","none");
	// 																	$("#recunsave" + id).css("display","block");
	// 																}
	// 																else if(type=="unsave")
	// 																{
	// 																	$("#recsave" + id).css("display","block");
	// 																	$("#recunsave" + id).css("display","none");
	// 																}
	// 																// this.loadpage(this.page);
	// 																/*this._alert.create(res.type,res.message+type);*/
	// 															}
	// 															else if(res.type=="expired")
	// 															{
	// 																this.router.navigateByUrl('/login') ;	
	// 															}
	// 															else
	// 																this._alert.create(res.type,res.message);
	// 													});
	// }



	likeme(id,type,inx,arraylist)
	{
		let params = {magazine_id:id,status:type};
		this.dbserv.post("magazinelike",params).subscribe(res => {
																if(res.type=="success")
																{
																	if(type=="like")
																	{
																		$("#reclike" + id).css("display","none");
																		$("#recunlike" + id).css("display","block");
																	}
																	else if(type=="unlike")
																	{
																		$("#reclike" + id).css("display","block");
																		$("#recunlike" + id).css("display","none");
																	}
																	// this.loadpage(this.page,false);
																	/*this._alert.create(res.type,res.message+type);*/
																	if(arraylist == 'mi')
																		this.myitems[inx].liked = res.total;
																	if(arraylist == 'sl')
																		this.magazineslist[inx].liked = res.total;
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/login') ;	
																}
																else
																	this._alert.create(res.type,res.message);
														});
	}
		saveme(id,type,inx,arraylist)
		{
			let params = {magazine_id:id,status:type};
			this.dbserv.post("magazinemysavedlist",params).subscribe(res => {
																	if(res.type=="success")
																	{
																		if(type=="save")
																		{
																			$("#recsave" + id).css("display","none");
																			$("#recunsave" + id).css("display","block");
																		}
																		else if(type=="unsave")
																		{
																			$("#recsave" + id).css("display","block");
																			$("#recunsave" + id).css("display","none");
																		}
																		// this.loadpage(this.page,false);
		                                                                   if(arraylist == 'mi')
		                                                                        this.myitems[inx].saved = res.total;
		                                                                    if(arraylist == 'sl')
		                                                                        this.magazineslist[inx].saved = res.total;
																		/*this._alert.create(res.type,res.message+type);*/
																	}
																	else if(res.type=="expired")
																	{
																		this.router.navigateByUrl('/login') ;	
																	}
																	else
																		this._alert.create(res.type,res.message);
															});
		}

	shareme(currrec)
	{
		this.currtime = Math.random();
		this.mysharedurl = this.websiteroot+"magazines/show/"+currrec.id;
		this.mysharedescription = currrec.title;
		this.mysharedtitle = currrec.shortdesc;
		this.mysharedstoryid = currrec.id;
		this.mysharedimage = this.rootpath+'assets/magazines/'+currrec.cover+'?newtime='+this.currtime;
		this.lnktimelinesharebox.nativeElement.click();
		
//		lnktimelinesharebox
	}
	/*shareme(id)
	{
		let params = {magazine_id:id};
		this.dbserv.post("storiesshareme",params).subscribe(res => {
																if(res.type=="success")
																{
																	this._alert.create(res.type,res.message);
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/login') ;	
																}
																else
																	this._alert.create(res.type,res.message);
														});
	}*/
	addnewmagazine()
	{
		this.userid = this.authserv.getUserId();
		if(this.userid>0)
		{
			this.router.navigate(['/magazines/magazine/0']);
		}
		else
			this.router.navigate(['/login']);
	}
	filterby()
	{
		this.visiblefilter = !this.visiblefilter;
		if(this.visiblefilter)
		{
			this.custo_filter_onen_close = true;
		}
		else
		{
			this.custo_filter_onen_close = false;
		}
	}
	    selectAll(event:any){
    	this.thetrueluxury = event.target.checked;
    	this.finematerial = event.target.checked;
    	this.superiorcraftsmanship = event.target.checked;
    	this.artofstyling = event.target.checked;
    	this.balancedliving = event.target.checked;
    	event.target.value = 'thetrueluxury';
    	this.selecfillter(event);
    	event.target.value = 'finematerial';
    	this.selecfillter(event);
    	event.target.value = 'superiorcraftsmanship';
    	this.selecfillter(event);
    	event.target.value = 'artofstyling';
    	this.selecfillter(event);
    	event.target.value = 'balancedliving';
    	this.selecfillter(event);
		this.myitems = [];
		this.loadpage(1);
	}

	    key_down(e) {
	        console.log(e);
	        if(e.target.value == '')
	        {
	            this.loadpage(this.page);
	        }
	            if(e.keyCode === 13) {
	                    this.filterswitch();
	        }
	    }
		loadddl()
	{
		    if(this.theme == '' || this.theme == 'All')
		        {
		this.categories = [];
		this.dbserv.getAll("magazinecatlist/-/"+this.visittype).
		subscribe(res => { 
			this.categories = res;
			if(this.category != '' && this.category != null)
				this.categorytitle = this.categories.find(x=>x.id == this.category).title;
			else
				this.categorytitle = '';
		});
		 this.dbserv.getAll( "magazinecatlist/The True Luxury/" + this.visittype )
         .subscribe( res => {
             this.filters.thetrueluxury = res;
         } );
     this.dbserv.getAll( "magazinecatlist/Fine Material/" + this.visittype )
         .subscribe( res => {
             this.filters.finematerial = res;
         } );
     this.dbserv.getAll( "magazinecatlist/Superior Craftsmanship/" + this.visittype )
         .subscribe( res => {
             this.filters.superiorcraftsmanship = res;
         } );
     this.dbserv.getAll( "magazinecatlist/Art of Styling/" + this.visittype )
         .subscribe( res => {
             this.filters.artofstyling = res;
         } );
     this.dbserv.getAll( "magazinecatlist/Balanced Living/" + this.visittype )
         .subscribe( res => {
             this.filters.balancedliving = res;
         } );
		        }
		if(this.theme =='The True Luxury'){
		    this.categories = [];
		    this.dbserv.getAll("magazinecatlist/The True Luxury/"+this.visittype)
		    .subscribe(res => { 
		        this.categories = res;
		});
		}
		if(this.theme =='Fine Material'){
            this.categories = [];
		this.dbserv.getAll("magazinecatlist/Fine Material/"+this.visittype)
		.subscribe(res => { 
			this.categories = res;
		});
		}
		if(this.theme =='Superior Craftsmanship'){
            this.categories = [];
		this.dbserv.getAll("magazinecatlist/Superior Craftsmanship/"+this.visittype)
		.subscribe(res => { 
		    this.categories = res;
        });
        }
		if(this.theme =='Art of Styling'){
            this.categories = [];
		this.dbserv.getAll("magazinecatlist/Art of Styling/"+this.visittype)
		.subscribe(res => { 
		    this.categories = res;
        });
        }
		if(this.theme =='Balanced Living'){
            this.categories = [];
		this.dbserv.getAll("magazinecatlist/Balanced Living/"+this.visittype)
		.subscribe(res => { 
		    this.categories = res;
        });
        }
	}
	throttle = 510 * 2;
  	scrollDistance = 1;
  	scrollUpDistance = 2;
	onScrollDown() {
		if(this.totalitems>this.myitems.length){
			this.page++
			this.loadpage(this.page);
		}
  	}
	   selecfillterSingle(event:any, id:any = ''){
	        // console.log(event);
	        if(id == '' || id == 0 || id == null || id == undefined){
	            this.categories.forEach(obj=>{
	                obj.checked = event.target.checked;
	            })
	        }
	        this.loadpage(this.page);
	    }

	    selecfillter(event:any, id:any = ''){
		// console.log(event);
		if(id == '' || id == 0 || id == null || id == undefined){
			switch (event.target.value) {
				case "thetrueluxury":
					this.filters.thetrueluxury.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "finematerial":
					this.filters.finematerial.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "superiorcraftsmanship":
					this.filters.superiorcraftsmanship.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "artofstyling":
					this.filters.artofstyling.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "balancedliving":
					this.filters.balancedliving.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
			}
			this.myitems = [];
			this.loadpage(this.page);
		}
	}
}
