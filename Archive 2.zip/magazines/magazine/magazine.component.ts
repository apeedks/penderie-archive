import { Component, OnInit, ElementRef,ViewChild, HostListener} from '@angular/core';
import {DbserviceService} from '../../services/dbservice.service';
import { AuthenticationService } from '../../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import {ImageCropperComponent, CropperSettings, Bounds} from 'ng2-img-cropper';
// import $ from 'jquery';
import * as _ from 'lodash';
declare var carouselObject: any;
declare var $:any;
declare var Modernizr:any;
window['$'] = window['jQuery'] = $;

@Component({
	selector: 'app-magazine',
	templateUrl: './magazine.component.html',
	styleUrls: ['./magazine.component.css']
})
export class MagazineComponent implements OnInit {
	@ViewChild('lnkmagsections') lnkmagsections:ElementRef;
	@ViewChild('lettermodalcancel') lettermodalcancel:ElementRef;
	@ViewChild('quotationmodalcancel') quotationmodalcancel:ElementRef;
	@ViewChild('modalcancel') modalcancel:ElementRef;
	@ViewChild('btnnext') btnnext:ElementRef;
	@ViewChild('btnback') btnback:ElementRef;
	ckeditoroptions = {removePlugins: 'elementspath',resize_enabled: false,toolbarLocation:'bottom',toolbar : [{ name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ], items: [ 'Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript'] },{ name: 'paragraph', groups: ['list'], items:['NumberedList','BulletedList'] }]};
	imagesmodel = {
		id:0,
		media_type:'Image',
		media_url:'',
		media_name:null,
		mediatitle:'',
		mediacredit:'',
		mediadesc:'',
		section:'magazines'
	};
	model = {id:0, title: '',user_id:0,viewed:0,cover:null,media_id:0,volume:'',shortdesc:'',tags:[],gender:"",theme:"",description:"",courtesy:"",courtesyurl:"",letter:"",quotation:"",created_at:"",updated_at:"",active:"",username:"",userimage:"",name:"",category_id:0};
	contributor = {id:0, user_id:0, isnew:0, first_name:"", last_name:"", occupation:"", email:"", image:null};
	contributors = [];
	rootpath:string;
	letter:any;
	quotation:any;
	currtime:any;
	magid:any;
	pagetitle = '';
	uploadedimage = null;
	uploadedimage2 = null;
	tagslist = [];
	slides = [];
	slidesindex = [];
	settings = {};
	columtext = '';
	maxlengthcolumtext = 1800;
	columntitle = '';
	tags:any = '';
	conttype 	= '';
	contsearch 	= '';
	categories: any;
	currslideid = 0;
	currentslideindex = 0;
	currentsectype = 0;
	currentsectionindex = 0;

	currentpreviousestep = 1;
	currentnextstep = 2;
	currentstep = 1;
	totalmagazinesteps = 1;
	
	sectionmodel = {
		id:0,
		media_type:'Image',
		media_url:'',
		media_name:null,
		mediatitle:'',
		mediacredit:'',
		mediadesc:'',
		section:'magazines',
		mediaowner:'',
		mediaownerurl:'',
		media_id:0
	};
	mediatype = 'Image';
	uploadedimagepp = null;
	mediaimage 			= '';
	mediavideo 			= '';
	mediatitle 			= ''; 
	mediatheme 			= ''; 
	mediaowner 			= ''; 
	mediaownerurl 		= ''; 
	mediadescription 	= '';
	
	datalist = [];
	options:any;
	pageSize: number;
	totalitems: any;
	page: number = 1;
	last_page: number = 1;
	loadingarticle = false;
	
	
	section_imagedata:any;
	section_cropperSettings:CropperSettings;
	@ViewChild('section_cropper', undefined) section_cropper:ImageCropperComponent;

	@ViewChild('lnksaveprofilebox') lnksaveprofilebox:ElementRef;
	imagedata:any;
	cropperSettings:CropperSettings;
	croppedWidth:number;
	croppedHeight:number;
	dragAreaClass:string='dragarea';
	uploadedsymbol:any=null;
	symbolimage = '';
	uploadedimagebtn:boolean=false;
	uploadedsymbolbtn:boolean=false;
	imagepreviewurl:string='';
	showimage=false;
	@ViewChild('cropper', undefined) cropper:ImageCropperComponent;

	contributorimagedata:any;
	contributorCropperSettings:CropperSettings;
	@ViewChild('contributorCropper', undefined) contributorCropper:ImageCropperComponent;
	loading:boolean = false;
	coverphotomsg:string = '';

	@ViewChild('lnkmaguploadvidimg') lnkmaguploadvidimg:ElementRef;
	@ViewChild('flipbook') flipbook: ElementRef;
	flipbookobj:any;
	slidespre = [];

	switchimagetvp()
	{
		if(this.sectionmodel.media_type=="Video")
		{
			$("#divsectionimage").css("display","none");
			$("#divectionvideo").css("display","block");
		}
		else
		{
			$("#divsectionimage").css("display","block");
			$("#divectionvideo").css("display","none");
		}	
	}
	savevideoimage()
	{
		this.loading = true;
		if(this.sectionmodel.media_type == 'Image'
			&& this.section_imagedata.image != ''
		  && this.section_imagedata.image != null
		){
			this.sectionmodel.media_name = this.section_imagedata.image;
		}
		let _formData = new FormData();
		_formData.append("magazine_id",this.model.id.toString());
		_formData.append("slideid",this.currslideid.toString());
		_formData.append("sectype",this.currentsectype.toString());
		_formData.append("sectionindex",this.currentsectionindex.toString());
		_formData.append("mediatype",this.sectionmodel.media_type);
		_formData.append("title",this.sectionmodel.mediatitle);
		// _formData.append("theme",this.mediatheme);
		_formData.append("owner",this.sectionmodel.mediaowner);
		_formData.append("ownerurl",this.sectionmodel.mediaownerurl);
		_formData.append("description",this.sectionmodel.mediadesc);
		_formData.append('mediacredit',this.sectionmodel.mediacredit);
		_formData.append('media_name',this.sectionmodel.media_name);
		_formData.append('media_url',this.sectionmodel.media_url);
		_formData.append('mediaId',this.sectionmodel.media_id.toString());
		if(this.sectionmodel.media_name!=null && this.sectionmodel.media_name!=''){
			_formData.append('media_file',this.uploadedimagepp);
		}
		// if(this.sectionmodel.media_type=='Image')
		// {
		// 	if(this.uploadedimagepp!=null && this.uploadedimagepp.name!='')
		// 		_formData.append('image',this.uploadedimagepp, this.uploadedimagepp.name);
		// }
		// else if(this.mediatype=='Video')
		// {
		// 	_formData.append("mediavideo",this.mediavideo);
		// }
		this.dbserv.saveimage("updatemagazineslidesectionmedia",_formData)
			.subscribe(res => {
				if(res.type=="success"){
					let data = res.data;
					this.loadslides(this.model.id);
					this.modalcancel.nativeElement.click();
				}
				else if(res.type=="expired"){
					this.router.navigateByUrl('/login') ;
				}
				else
					$("#lblcolmmessage").html(res.message);
				this.loading = false;
		});
	}
	loadddl()
	{
		this.categories = [];
		if(this.model.gender != ''){
			this.dbserv.getAll("magazinecatlist/"+this.model.theme+'/'+this.model.gender)
			.subscribe(res => {
				this.categories = res;
			});
		}
	}
	movetostepbystep(stepid)
	{
		// console.log(stepid);
		if(stepid>this.totalmagazinesteps)
		{
			/*$("#fieldofstudymessage").dialog({
													dialogClass: "no-close",
													buttons: [
													{
														text: "OK",
														click: function() {
															$(this).dialog( "close" );
														}
													}
													]
												});	*/
		}
		else
		{
			if(stepid>1 && stepid<=this.totalmagazinesteps)
			{
				this.currentpreviousestep = stepid-1;
				this.currentnextstep = stepid+1;
				this.currentstep = stepid;
			}
			else
			{
				this.currentpreviousestep = 1;
				this.currentnextstep = 2;
				this.currentstep = 1;
			}
			if(this.currentstep<2){
				$("#btnstepback").css("display",'none');
				$("#btnstepbacktabs").css("display",'block');
			}
			else{
				$("#btnstepback").css("display",'block');
				$("#btnstepbacktabs").css("display",'none');
			}
			$(".magazinestepdiv").css("display",'none');
			$("#magazinestep" + this.currentstep).css("display",'block');
			/*alert(this.currentstep);*/
		}
		/*if(this.currentstep==this.totalmagazinesteps)
		{
			$("#btnstepnext").css("display",'none');
		}
		else
		{
			$("#btnstepnext").css("display",'block');
		}*/
	}
	
	constructor(private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private cookieService: CookieService) {
		this.rootpath = localStorage.getItem('baseurl');
		this.cropperSettings = new CropperSettings();
		this.cropperSettings.width = 520;
		this.cropperSettings.height = 575;
		this.cropperSettings.croppedWidth = 520;
		this.cropperSettings.croppedHeight = 575;
		this.cropperSettings.canvasWidth = 420;
		this.cropperSettings.noFileInput = true;
		this.cropperSettings.canvasHeight = 300;
		this.cropperSettings.touchRadius = 20;
		this.cropperSettings.rounded = false;
		this.cropperSettings.keepAspect = true;
		this.imagedata = {};

		this.contributorCropperSettings = new CropperSettings();
		this.contributorCropperSettings.width = 400;
		this.contributorCropperSettings.height = 400;
		this.contributorCropperSettings.croppedWidth = 400;
		this.contributorCropperSettings.croppedHeight = 400;
		this.contributorCropperSettings.canvasWidth = 190;
		this.contributorCropperSettings.canvasHeight = 140;
		this.contributorCropperSettings.noFileInput = true;
		this.contributorCropperSettings.touchRadius = 20;
		this.contributorCropperSettings.rounded = true;
		this.contributorCropperSettings.keepAspect = true;
		this.contributorimagedata = {};

		this.section_cropperSettings = new CropperSettings();
		this.section_cropperSettings.width = 560;
		this.section_cropperSettings.height = 420;
		this.section_cropperSettings.croppedWidth = 560;
		this.section_cropperSettings.croppedHeight = 420;
		this.section_cropperSettings.canvasWidth = 360;
		this.section_cropperSettings.noFileInput = true;
		this.section_cropperSettings.canvasHeight = 300;
		this.section_cropperSettings.touchRadius = 20;
		this.section_cropperSettings.rounded = false;
		this.section_cropperSettings.keepAspect = true;
		this.section_imagedata = {};
	}
	editpagetitle(type,title,slideid)
	{
		this.pagetitle = title;
		$("#"+type+"ptitle-"+ slideid).css("display","none");
		$("#"+type+"pfield-"+ slideid).css("display","block");
	}
	cancelpagetitle(type,slideid)
	{
		$("#"+type+"ptitle-"+slideid).css("display","block");
		$("#"+type+"pfield-"+slideid).css("display","none");
	}
	
	savepagetitle(type,slideid)
	{
		let tmodel = {magazine_id:this.model.id,id:slideid,title:this.pagetitle};
		this.dbserv.save("updatemagazineslidetitle",tmodel).subscribe(res => {
															if(res.type=="success")
															{
																$(".slidetitle-"+slideid).html(res.title);
																$("#"+type+"ptitle-"+slideid).css("display","block");
																$("#"+type+"pfield-"+slideid).css("display","none");
															}
															else if(res.type=="expired")
															{
																this.router.navigateByUrl('/login') ;	
															}
															else
															console.log();
																//this._alert.create(res.type,res.message);
													});
	}
	savenewpage()
	{
		let tmodel = {magazine_id:this.model.id};
		this.dbserv.save("addmagazineslide",tmodel)
			.subscribe(res => {
				if(res.type=="success"){
					$("#preloadnewpage").css("display","none");
					$("#newpageoptions").css("display","block");
					this.loadslides(this.model.id);
				}
				else if(res.type=="expired"){
					this.router.navigateByUrl('/login') ;	
				}
				else
					this._alert.create(res.type,res.message);
		});
	}
	addnewmagpage(numofpages)
	{
		// console.log(this.slides.length,numofpages);
		if ((this.slides.length * 2) + numofpages < 21) {
			let tmodel = {magazine_id:this.model.id,newpages:numofpages};
			this.dbserv.save("addmagazineslide",tmodel)
				.subscribe(res => {
					if(res.type=="success"){
						$("#preloadnewpage").css("display","none");
						$("#newpageoptions").css("display","block");
						this.loadslides(this.model.id);
					}
					else if(res.type=="expired"){
						this.router.navigateByUrl('/login') ;	
					}
					else
						this._alert.create(res.type,res.message);
			});
			/*this.generatesectionaraay(1);*/
		}else{
			this._alert.create('error','You add maximum 26 page in magazine.');
		}
	}
	editsection(slideid,idxslide,sectype,sectionindex){
		console.log(slideid+"-"+idxslide+"-"+sectype+"-"+sectionindex);
		this.dbserv.get("getmagazinesection/"+this.model.id+"/"+slideid+"/"+sectionindex)
			.subscribe(res => {
				if(res.type=="success"){
					let recor = res.data;
					if(recor.type=="Image" || recor.type=="Video"){
						this.popuploadvidimg(slideid,idxslide,sectype,sectionindex);
						// if(recor.type=="Image")
						// 	this.mediaimage = recor.image;
						// else if(recor.type=="Video")
						// 	this.mediavideo = recor.image;
						// this.mediatheme 			= recor.theme;
						// if(this.mediatheme=='')
						// 	this.mediatheme = 'All';
						this.sectionmodel.media_type 			= recor.type;
						this.sectionmodel.mediatitle 			= recor.title;
						this.sectionmodel.mediaowner 			= recor.owner;
						this.sectionmodel.mediaownerurl 	= recor.ownerurl;
						this.sectionmodel.mediadesc 			= recor.description;
						this.sectionmodel.media_id 				= recor.media_id;
						this.sectionmodel.mediacredit 				= recor.mediacredit;
						this.sectionmodel.media_url 				= recor.media_url;
						this.sectionmodel.media_name 				= recor.media_name;
						this.switchimagetvp();
					}
					else if(recor.type=="text"){
						this.popwritecolm(slideid,idxslide,sectype,sectionindex);
						this.columntitle = recor.title;
						this.columtext = recor.description;
					}
					else if(recor.type=="Review" || recor.type=="Story" || recor.type=="Article"){
						this.poparticleshr(slideid,idxslide,sectype,sectionindex);
						this.conttype 	= recor.type;
						this.contsearch = recor.keyid;
						this.loadpopupdata();
					}
				}
				else if(res.type=="expired"){
					this.router.navigateByUrl('/login') ;	
				}
				else
					this._alert.create(res.type,res.message);
			});
	}
	popuploadvidimg(slideid,idxslide,sectype,sectionindex)
	{
	  $("#media").trigger("reset");
		this.currslideid = slideid;
		this.currentslideindex = idxslide;
		this.currentsectype = sectype;
		this.currentsectionindex = sectionindex;
		this.showformcontents('mediaitempopup');
		this.lnkmagsections.nativeElement.click();
		this.sectionmodel = {
			id:0,
			media_type:'Image',
			media_url:'',
			media_name:null,
			mediatitle:'',
			mediacredit:'',
			mediadesc:'',
			section:'magazines',
			mediaowner:'',
			mediaownerurl:'',
			media_id:0
		};
		this.section_cropper.reset();
	}
	popwritecolm(slideid,idxslide,sectype,sectionindex)
	{
	    $("#column").trigger("reset"); 
		this.currslideid = slideid;
		this.currentslideindex = idxslide;
		this.currentsectype = sectype;
		this.currentsectionindex = sectionindex;
		this.showformcontents('writecolumpopup');
		this.lnkmagsections.nativeElement.click();
		this.maxlengthcolumtext = 1700;
		if (sectype == 2 || (sectype == 3 && sectionindex == 1)) {
			this.maxlengthcolumtext = 800;
		}
		if (sectype == 4 || (sectype == 3 && sectionindex != 1)) {
			this.maxlengthcolumtext = 350;
		}
		this.columntitle = '';
		this.columtext = '';
	}
	savearticle()
	{
		if(this.conttype == '')
			$("#lblpopupheading").html('Select a content type before clicking on save.');
		else if(this.contsearch == '')
			$("#lblpopupheading").html('Enter a content key before clicking on save.');
		else if(this.datalist.length==0)
			$("#lblpopupheading").html('No record found to add.');
		else
		{
			let tmodel = {magazine_id:this.model.id,slideid:this.currslideid,sectype:this.currentsectype,sectionindex:this.currentsectionindex,articleid:this.contsearch,type:this.conttype};
			this.dbserv.save("updatemagazinesectionarticle",tmodel).subscribe(res => {
															if(res.type=="success")
															{
																let data = res.data;
																this.loadslides(this.model.id);
																this.modalcancel.nativeElement.click();
															}
															else if(res.type=="expired")
															{
																this.router.navigateByUrl('/login') ;	
															}
															else
																$("#lblcolmmessage").html(res.message);
													});
		}
	}
	savecolumntext()
	{
		let tmodel = {magazine_id:this.model.id,slideid:this.currslideid,sectype:this.currentsectype,sectionindex:this.currentsectionindex,columtext:this.columtext,title:this.columntitle};
		this.dbserv.save("updatemagazineslidesection",tmodel).subscribe(res => {
															if(res.type=="success")
															{
																let data = res.data;
																/*$("#content-choice-" + this.currslideid + "-" + this.currentsectype + "-" + this.currentsectionindex).css("display",'none');
																$("#content-outer-" + this.currslideid + "-" + this.currentsectype + "-" + this.currentsectionindex).css("display",'block');
																$("#content-inner-" + this.currslideid + "-" + this.currentsectype + "-" + this.currentsectionindex).html(data.description);*/
																this.loadslides(this.model.id);
																this.modalcancel.nativeElement.click();
															}
															else if(res.type=="expired")
															{
																this.router.navigateByUrl('/login') ;	
															}
															else
																$("#lblcolmmessage").html(res.message);
													});
	}
	poparticleshr(slideid,idxslide,sectype,sectionindex)
	{
		this.currslideid = slideid;
		this.currentslideindex = idxslide;
		this.currentsectype = sectype;
		this.currentsectionindex = sectionindex;
		this.showformcontents('articlelinkspopup');
		this.lnkmagsections.nativeElement.click();
		this.conttype 	= '';
		this.contsearch = '';
	}
	ngOnInit() {
		if(this.authserv.isloggedin())
		{
			this.authserv.session().subscribe(res => {
				if(res.isnew=='Yes')
					this.router.navigate(['/home']);
			});
			this.route.params.subscribe(params => {
				this.magid = params['magid'];
				this.editrecord(this.magid);
			});
		}
		this.loadddl();
		this.dbserv.getAll("magazinetagslist").subscribe(res => { this.tagslist = res;});
	}
	clicktab(tab)
	{
		if (this.model.id > 0) {
			$(".tabs").removeClass("active");
			$(".tab_content").css("display","none");
			$("#hd" + tab).addClass("active");
			$("#" + tab).css("display","block");
			if (tab === 'tab1') {
				this.editrecord(this.model.id);
			}
			if(tab=='tab4'){
				this.loadslides(this.model.id);
			}
			// this.loadslidesindex(this.model.id);
			if(tab=='tab3'){
				this.loadslides(this.model.id);
				this.loadContributor();
			}
		}else{
			this._alert.create('error','Please first complate summary details then change tabs');
		}
	}
	
	editrecord(id)
	{
		this.dbserv.getById("magazine",id)
			.subscribe(res => {
				if(res.type=="success"){
					this.currtime = Math.random();
					this.model = res.data;
					this.letter = this.model.letter;
					this.quotation = this.model.quotation;
					this.loadslidesindex(id);
					this.loadddl();
					// this.loadContributor();
				}
				else if(res.type=="expired"){
					this.router.navigateByUrl('/login') ;
				}
			});
	}
	saveletter()
	{
		let tmodel = {magazine_id:this.model.id,letter:this.letter};
		this.dbserv.save("savemagazineletter",tmodel).subscribe(res => {
															this.editrecord(this.model.id);
																this._alert.create(res.type,res.message);
																this.lettermodalcancel.nativeElement.click();
														 });	
	}
	savequotation(){
		let tmodel = {magazine_id:this.model.id,quotation:this.quotation};
		this.dbserv.save("savemagazinequotation",tmodel).subscribe(res => {
															this.editrecord(this.model.id);
																this._alert.create(res.type,res.message);
																this.quotationmodalcancel.nativeElement.click();
														 });
	}
	loadslidesindex(id)
	{
		this.slidesindex = [];
		this.dbserv.getById("loadslidesindex",id)
			.subscribe(res => {
				if(res.type=="success")
				{
					this.slidesindex = res.data;
				}
			});
	}
	loadpopupdata(){
		this.datalist = [];
		if(this.conttype != '' && this.contsearch != '')
		{
			this.loadingarticle = true;
			this.dbserv.getAll("magazinearticledata/"+this.conttype+"/"+this.contsearch)
				.subscribe(res => {
					if(res.type=="success"){
						this.currtime = Math.random();
						this.datalist = res.records;
						/*this.pageSize = res.records.data;
						this.totalitems = res.records.data;
						this.page = res.records.data;
						this.last_page = res.records.data;*/
					}
					else if(res.type=="expired"){
						this.router.navigateByUrl('/login') ;	
					}
					this.loadingarticle = false;
				});
		}
	}
	
	loadslides(id)
	{
		this.dbserv.getById("slidesforedit",id)
			.subscribe(res => {
				if(res.type=="success")
				{
					this.currtime = Math.random();
					this.slides = res.data;
					$(".magazinestepdiv").css("display",'none');
					if (this.slides.length === 0) {
						this.addnewmagpage(10);
					}
					this.totalmagazinesteps = this.slides.length+1;
					this.loadslidesindex(id);
					let timer = setTimeout(()=>{    //<<<---    using ()=> syntax
						this.movetostepbystep(this.currentstep);
						clearTimeout(timer);
					 },1000);
					//this.movetostepbystep(this.currentstep);
				}
				else if(res.type=="expired")
				{
					this.router.navigateByUrl('/login') ;
				}
			});
	}
	savemagazine()
	{
		if (this.model.media_id > 0) {
			this.coverphotomsg = '';
			let _formData = new FormData();
			_formData.append("id",this.model.id.toString());
			_formData.append("title",this.model.title);
			_formData.append("gender",this.model.gender);
			_formData.append("description",this.model.description);
			let mytags:string = '';
			if(this.model.tags.length>0){
				for(let i=0;i<this.model.tags.length;i++){
					if(mytags=='')
						mytags = '-'+this.model.tags[i].id.toString()+'-';
					else
						mytags += ',-'+this.model.tags[i].id.toString()+'-';
					_formData.append("tags",mytags);
				}
			}
			
			_formData.append("theme",this.model.theme);
			_formData.append("volume",this.model.volume);
			_formData.append("courtesy",this.model.courtesy);
			_formData.append("courtesyurl",this.model.courtesyurl);
			_formData.append("cover",this.model.cover);
			_formData.append("media_id",this.model.media_id.toString());
			_formData.append("category_id",this.model.category_id.toString());
			_formData.append("active",this.model.active);
			// if(this.uploadedimage!=null && this.uploadedimage.name!=''){
			// 	_formData.append('image',this.uploadedimage, this.uploadedimage.name);
			// }
			this.dbserv.saveimage("magazinessave",_formData)
				.subscribe(res => {
					if(res.type=="success"){
						//this._alert.create(res.type,res.message);
						this.editrecord(res.crecid);
						this.router.navigateByUrl('/magazines/magazine/' + res.crecid) ;
					}
					else if(res.type=="expired"){
						this.router.navigateByUrl('/login') ;	
					}
					else
						console.log();
					//this._alert.create(res.type,res.message);
				});
		}else{
			this.coverphotomsg = 'Cover photo is required';
		}
	}
	fileChange($event){
		this.uploadedimage = $event.target.files[0];
	}
	popupfileChange($event){
		this.uploadedimagepp = $event.target.files[0];
	}
	deletepage()
	{
		if(this.slides.length>0)
		{
			if(confirm('Are you sure?'))
			{
				let rec = this.slides[this.currentstep-1];
				let delmodel = {magazineid:this.model.id,id1:rec[0].id,id2:rec[1].id}
				this.dbserv.post("magazineslidedel", delmodel)
					.subscribe(res => {
						if(res.type=="success"){
							this.editrecord(this.model.id);
							this.loadslides(this.model.id);
							this._alert.create(res.type,res.message);
						}
						else if(res.type=="expired"){
							this.router.navigateByUrl('/admin/login') ;
						}
						else{
							this._alert.create(res.type,res.message);
						}
					});
			}
		}
	}
	fileChangeupload($event){
		this.uploadedimage2 = $event.target.files[0];
		let _formData = new FormData();
		_formData.append("magazine_id",this.model.id.toString());
		if(this.uploadedimage2!=null && this.uploadedimage2.name!=''){
			_formData.append('image',this.uploadedimage2, this.uploadedimage2.name);
		}
		this.dbserv.saveimage("magazineimagesave",_formData)
			.subscribe(res => {
				if(res.type=="success"){
					this._alert.create(res.type,res.message);
					this.editrecord(res.crecid);
					/*this.router.navigateByUrl('/myaccount/magazines') ;
					this.loadpage(this.defaultparam);
					this.isshowform = false;*/
				}
				else if(res.type=="expired"){
					this.router.navigateByUrl('/login') ;	
				}
				else{
					this._alert.create(res.type,res.message);
				}
		});
	}
	/*movenext(step:number)
	{
		this.clicktab("tab" + step);
	}*/
	onItemSelect(item:any){
		console.log(item);
		console.log(this.model.tags);
	}
	OnItemDeSelect(item:any){
		console.log(item);
		console.log(this.model.tags);
	}
	onSelectAll(items: any){
		console.log(this.model.tags);
	}
	onDeSelectAll(items: any){
		console.log(this.model.tags);
	}
	showformcontents(type)
	{
		if(type=='mediaitempopup'){
		  $("#media").trigger("reset"); 
			$("#lblpopupheading").html("Upload Media");
			$('#hd-mediaitempopup').addClass('active');
			$('#hd-articlelinkspopup').removeClass('active');
			$('#hd-writecolumpopup').removeClass('active');
			this.sectionmodel.media_type = 'Image';
		}else if(type=='articlelinkspopup'){
		  $("#contributor").trigger("reset"); 
			$("#lblpopupheading").html("Share Content");
			$('#hd-mediaitempopup').removeClass('active');
			$('#hd-articlelinkspopup').addClass('active');
			$('#hd-writecolumpopup').removeClass('active');
		}
		else if(type=='writecolumpopup'){
		  $("#column").trigger("reset"); 
			$("#lblpopupheading").html("Write a Column");
			$('#hd-mediaitempopup').removeClass('active');
			$('#hd-articlelinkspopup').removeClass('active');
			$('#hd-writecolumpopup').addClass('active');
		}
		$(".frmgrpspp").css("display","none");
		$("#hdfrmgrpspp").removeClass("active");

		$("#"+type).css("display","block");
		$("#hd-"+type).addClass("active");
	}
	clickpopuptab(tab)
	{
		$(".tabs").removeClass("active");
		$(".tab_content").css("display","none");
		$("#hd" + tab).addClass("active");
		$("#" + tab).css("display","block");
		if(tab=='tab4'){
			this.loadslides(this.model.id);
		}
	}
	newtag(){
		if(this.tags != ''){
			let model = {
				tag:this.tags,
				active:'Pending'
			}
			this.dbserv.save("magazinetagsave",model).subscribe(res => {
				if(res.type=="success")
				{
					this.tags = '';
					// this.dbserv.getAll("magazinetagslist").subscribe(res => { this.tagslist = res.records;});
					this._alert.create(res.type,res.message);
				}
				else if(res.type=="expired")
				{
					this.router.navigateByUrl('/login') ;	
				}
				else
				{
					this._alert.create(res.type,res.message);
				}
			}); 
		}
	}

	cropped(bounds:Bounds) {
		this.croppedHeight =bounds.bottom-bounds.top;
		this.croppedWidth = bounds.right-bounds.left;
	}
	
	fileChangeListener($event) {
	var image:any = new Image();
	var file:File = $event.target.files[0];
	var myReader:FileReader = new FileReader();
	var that = this;
	myReader.onloadend = function (loadEvent:any) {
		image.src = loadEvent.target.result;
		that.cropper.setImage(image);

	};

	myReader.readAsDataURL(file);
	}

		previewFile(file) {
		console.log(file);
		var request = new XMLHttpRequest();
		request.open('GET', file, true);
		request.responseType = 'blob';
		var image:any = new Image();
		request.onload = () => {
			var reader = new FileReader();
			reader.readAsDataURL(request.response);
			reader.onload = (event:any) => {
				image.src = event.target.result; 
				this.cropper.setImage(image);
			};
			reader.onloadend = (event:any) => {
				image.src = event.target.result; 
				this.cropper.setImage(image);
			};
		};
		request.send();
	}
	readImageUrl() {
		if (this.uploadedimage && this.uploadedimage) {
			var reader = new FileReader();
			var image:any = new Image();
			reader.onload = (event:any) => {
				 image.src = event.target.result; 
				this.cropper.setImage(image);
			}
			reader.onloadend = (event:any) => {
				 image.src = event.target.result; 
				this.cropper.setImage(image);
			};
			reader.readAsDataURL(this.uploadedimage);
		}
	}
	readContributorImageUrl() {
		if (this.uploadedimage && this.uploadedimage) {
			var reader = new FileReader();
			var image:any = new Image();
			reader.onload = (event:any) => {
				 image.src = event.target.result; 
				this.contributorCropper.setImage(image);
			}
			reader.onloadend = (event:any) => {
				 image.src = event.target.result; 
				this.contributorCropper.setImage(image);
			};
			reader.readAsDataURL(this.uploadedimage);
		}
	}
	readSectionImageUrl() {
		if (this.uploadedimagepp && this.uploadedimagepp) {
			var reader = new FileReader();
			var image:any = new Image();
			reader.onload = (event:any) => {
				 image.src = event.target.result; 
				this.section_cropper.setImage(image);
			}
			reader.onloadend = (event:any) => {
				 image.src = event.target.result; 
				this.section_cropper.setImage(image);
			};
			reader.readAsDataURL(this.uploadedimagepp);
		}
	}


	onSymbolChange($event){
		this.uploadedsymbol = $event.target.files[0];
	}
	onFileChange($event){
		 this.uploadedimage = $event.target.files[0];
		 this.imagesmodel.media_name = $event.target.files[0];
		 this.readImageUrl();
		 //this.saveprofileimage( $event.target.files[0]);
	}
	onSectionFileChange($event){
		 this.uploadedimagepp = $event.target.files[0];
		 this.readSectionImageUrl();
		 //this.saveprofileimage( $event.target.files[0]);
	}
	onContributorFileChange($event){
		 this.uploadedimage = $event.target.files[0];
		 this.readContributorImageUrl();
		 //this.saveprofileimage( $event.target.files[0]);
	}
	@HostListener('dragover', ['$event']) onDragOver(event) {
		this.dragAreaClass = "droparea";
		event.preventDefault();
	}
	@HostListener('dragenter', ['$event']) onDragEnter(event) {
		this.dragAreaClass = "droparea";
		event.preventDefault();
	}
	@HostListener('dragend', ['$event']) onDragEnd(event) {
		this.dragAreaClass = "dragarea";
		event.preventDefault();
	}
	@HostListener('dragleave', ['$event']) onDragLeave(event) {
		this.dragAreaClass = "dragarea";
		event.preventDefault();
	}
	@HostListener('drop', ['$event']) onDrop(event) {
		this.dragAreaClass = "dragarea";
		event.preventDefault();
		event.stopPropagation();
		this.uploadedimage = event.dataTransfer.files[0];
		if(event.target.className == 'uplo-drag-profile uplo-drag-contributor'){
			this.readContributorImageUrl();
		}
		else{
			this.readImageUrl();
		}
		//this.saveprofileimage(event.dataTransfer.files[0]);
	}
	saveimage(){
		this.loading = true;
		let _formData = new FormData();
		this.imagesmodel.media_name = this.imagedata.image;
		_formData.append("id",this.imagesmodel.id.toString());
		_formData.append("media_type",this.imagesmodel.media_type);
		_formData.append("mediatitle",this.imagesmodel.mediatitle);
		_formData.append("mediacredit",this.imagesmodel.mediacredit);
		_formData.append("mediadesc",this.imagesmodel.mediadesc);
		_formData.append('media_name',this.imagesmodel.media_name);
		_formData.append('media_url',this.imagesmodel.media_url);
		_formData.append('section',this.imagesmodel.section);
		if(this.imagesmodel.media_name!=null && this.imagesmodel.media_name!=''){
			_formData.append('media_file',this.uploadedimage);
		}
		this.dbserv.saveimage("savemedia",_formData)
		.subscribe(res => {
			console.log(res);
			if (res.type == 'success') {
				this.imagesmodel = res.data;
				this.model.cover = this.imagesmodel.media_name;
				this.model.media_id = this.imagesmodel.id;
				this.lnksaveprofilebox.nativeElement.click();
			}
			this.loading = false;
		});
	}
	saveContributor(){
		this.loading = true;
		let _formData = new FormData();
		this.contributor.image = this.contributorimagedata.image;
		_formData.append("id",this.contributor.id.toString());
		if (this.contributor.isnew == 1) {
			_formData.append("user_id","0");
		}else{
			_formData.append("user_id",this.contributor.user_id.toString());
		}
		_formData.append("magazine_id",this.model.id.toString());
		_formData.append("first_name",this.contributor.first_name);
		_formData.append("last_name",this.contributor.last_name);
		_formData.append("occupation",this.contributor.occupation);
		_formData.append("email",this.contributor.email);
		if(this.contributor.image!=null && this.contributor.image!=''){
			_formData.append("image",this.contributor.image);
			_formData.append('imagesrc',this.uploadedimage);
		}
		this.dbserv.saveimage("createmagazinecontributor",_formData)
		.subscribe(res => {
			if (res.type == 'success') {
				this.contributor = {id:0, user_id:0, isnew:0, first_name:"", last_name:"", occupation:"", email:"", image:null};
				this.loadContributor();
			}
			this.loading = false;
		});
	}
	loadingContributor:boolean=false;
	maxContributor = 18;
	perPageContributor = 6;
	contributorsInx= [];
	loadContributor(){
	    $("#contributor").trigger("reset"); 
		this.contributors = [];
		this.loadingContributor = true;
		if(this.model.id >0){
			this.dbserv.getAll("listmagazinecontributor/"+this.model.id)
			.subscribe(res => {
				this.contributors = res.data;
				this.contributorsInx = Array.from(Array(Math.ceil(this.contributors.length / this.perPageContributor)),(x,i)=>i).reverse();
				this.loadingContributor = false;
				// let html = '';
				// this.contributors.forEach((val,inx)=>{
				// 	if (inx == 0) {
				// 		html += '<div class="item active">';
				// 	}else{
				// 		html += '<div class="item">';
				// 	}
				// 	html += '<span class="close" (click)="removeContributor('+val.id+')" ><i class="fa fa-close"></i></span>'
				//                 html += '<div class="letter-poster">';
				//                 if(val.user_id==0 && val.image != null){
				// 					        html += '<img alt="user profile" src="'+this.rootpath+'assets/magazines/contributor/'+val.image+'">';
				//                 }
				// 					      if(val.user_id>0 && val.image != null){
				// 					        html += '<img alt="user profile" src="'+this.rootpath+val.image+'">';
				// 					      }
				// 					      if(val.image == null){
				// 					        html += '<img alt="user profile" src="assets/img/original.jpg">';
				// 					      }
				// 					        html += '<div class="mt5 user_name">'+val.first_name+' '+val.last_name+'</div>';
				// 					        html += '<div class="user_occ">'+val.occupation+'</div>';
				// 						    html += '</div>';
				// 						  html += '</div>';
				// });
				// if (html != '') {
				// 	setTimeout(()=>{
				// 		carouselObject.contributorCarousel(html);
				//   },1000);
				// }
			});
		}
	}
	removeContributor(id){
		if(confirm('Are you sure?'))
		{
			this.dbserv.getAll("removemagazinecontributor/"+id)
			.subscribe(res => {
				if(res.type == "success"){
					this.loadContributor();
				}
			});
		}
	}
	saveslidesection(){
		let slides = [];
		this.slides.forEach((item)=>{
			item.forEach((slide)=>{
				slides.push({id:slide.id,sectype:slide.sectype});
			});
		});
		this.dbserv.save("saveslidesection",slides).subscribe(res => {
			this._alert.create(res.type,res.message);
		});
	}
	changeSlide(idx,idxslide,sectype){
		this.slides[idx][idxslide].sectype = sectype;
	}
	
	youtubeURLtoID(url){
    if (url != null && url != '') {
      if( url.indexOf("http") == 0 ) {
        return url.substring(url.lastIndexOf("?v=") + 3);
      }else{
        return url;
      }
    }
  }
	resetrigger(){
	    $("#cover").trigger("reset");    
	}
}
