import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MagazinepreComponent } from './magazinepre.component';

describe('MagazinepreComponent', () => {
  let component: MagazinepreComponent;
  let fixture: ComponentFixture<MagazinepreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MagazinepreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MagazinepreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
