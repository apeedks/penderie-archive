import {ViewChild, ElementRef, AfterViewInit,OnInit, Component, Input, DoCheck, KeyValueDiffers, HostListener, Output, EventEmitter} from '@angular/core';
import {DbserviceService} from '../../services/dbservice.service';
import { AuthenticationService } from '../../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';

declare var $:any;
declare var Modernizr:any;
window['$'] = window['jQuery'] = $;

@Component({
  selector: 'app-magazinepre',
  templateUrl: './magazinepre.component.html',
  styleUrls: ['./magazinepre.component.css']
})
export class MagazinepreComponent implements OnInit,AfterViewInit,DoCheck {

	@ViewChild('lnkmaguploadvidimg') lnkmaguploadvidimg:ElementRef;
	@ViewChild('flipbook') flipbook: ElementRef;
	flipbookobj:any;
	record = {id:0, title: '',user_id:0,viewed:0,cover:null,covertitle:'',shortdesc:'',tags:[],gender:"Both",theme:"All",description:"",courtesy:"",letter:"",created_at:"",updated_at:"",active:"",username:"",userimage:"",name:"", quotation:""};
	rootpath:string;
	currtime:any;
	@Input() magid:any = [0];
	pagetitle = '';
	slides = [];
	slidesindex = [];
	mysharedstoryid: number =1;
	mysharedtype = 'Magazine';
	mysharedurl = '';
	loggedin = false;
	mysharedescription = '';
	mysharedtitle = '';
	mysharedimage = '';
	options:any;

	differ: any;

	@Output() loaded = new EventEmitter();
	
	constructor(private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private cookieService: CookieService, private differs: KeyValueDiffers,) {
		this.rootpath = localStorage.getItem('baseurl');
		if(this.authserv.isloggedin()){
			this.loggedin = true;
		}
		this.differ = differs.find({}).create(null);
		// this.route.params.subscribe(params => {
		//     this.magid = params['magid'];
		
			// });
	}
	@HostListener('click') onClick(){
    console.log("User Click using Host Listener");
  }
	ngOnInit() {
		
		
	}
	ngDoCheck(){
		var changes = this.differ.diff(this.magid);
    if (changes) {
			// console.log(this.magid);
			if (this.magid[0] > 0) {
				this.loadslides(this.magid[0]);
				this.dbserv.getByStringId("magazineforfront",this.magid[0])
					.subscribe(res => {
						if(res.type=="success")
							this.record=res.data;
						else
							this.router.navigateByUrl('/magazines') ;	
					});
				this.loadslidesindex(this.magid[0]);
				this.loadContributor(this.magid[0]);
			}
		}
	}
	loadslidesindex(id)
	{
		this.dbserv.getById("loadslidesindex",id).subscribe(res => {
														if(res.type=="success")
														{
															this.slidesindex = res.data;
														}
													});	
	}
	loadingContributor:boolean=false;
	maxContributor = 18;
	perPageContributor = 6;
	contributorsInx= [];
	contributors = [];
	loadContributor(id){
		this.contributors = [];
		this.loadingContributor = true;
		this.dbserv.getAll("listmagazinecontributor/"+id)
		.subscribe(res => {
			this.contributors = res.data;
			this.contributorsInx = Array.from(Array(Math.ceil(this.contributors.length / this.perPageContributor)),(x,i)=>i).reverse();
			this.loadingContributor = false;
		});
	}
	loadslides(id)
	{
		this.dbserv.getById("magazineslidesforfront",id)
			.subscribe(res => {
				if(res.type=="success")
				{
					this.currtime = Math.random();
					this.slides = res.data;
					setTimeout(()=>{    //<<<---    using ()=> syntax
					  this.loadApp();
					},3000);
					// this.dbserv.getById("magazine/increase-view",this.magid[0]).subscribe(res => {});
				}
			});	
	}
	loadApp()
	{
		// this.flipbookobj = $(this.flipbook.nativeElement).turn({
		// 	display: 'single',
		// 	acceleration: true,
		// 	gradients: !$.isTouch,
		// 	autoCenter: true,
		// 	elevation:50,
		// 	width:360,
		// 	height:800,

			
		// 	when: {
		// 		turned: function(e, page) {
		// 			console.log('Current view: ', $(this).turn('view'));
		// 		}
		// 	}
		// });

		this.flipbookobj = $(this.flipbook.nativeElement).turn({
			width:922,
			height:800,
			elevation: 50,
			gradients: true,
			autoCenter: true,
		});

		let obj = this;

    //Initialize the zoom viewport
    $('.flipbook-viewport').zoom({
        flipbook: $('.flipbook')
    });

    //Binds the single tap event to the zoom function
    $('.flipbook-viewport').bind('zoom.tap', obj.zoomTo);

    //Optional, calls the resize function when the window changes, useful when viewing on tablet or mobile phones
    $(window).resize(function() {
        obj.resizeViewport();
    }).bind('orientationchange', function() {
        obj.resizeViewport();
    });

    //Must be called initially to setup the size
    this.resizeViewport();
	}

	nextpage()
	{
		this.flipbookobj.turn("next");	
	}
	prevpage()
	{
		this.flipbookobj.turn("previous");	
	}
	gotopage(inx){
		this.flipbookobj.turn("page", inx);
	}
	zoomin(){
		//this.zoomobj.zoom("zoomIn");
		// this.flipbookobj.turn("center");
		let currentZoom = this.flipbookobj.turn("zoom");
		if (currentZoom < 2) {
			this.flipbookobj.turn("zoom",(currentZoom + 0.5));
		}
	}
	zoomout(){
		let currentZoom = this.flipbookobj.turn("zoom");
		if (currentZoom > 1) {
			this.flipbookobj.turn("zoom",(currentZoom - 0.5));
		}
	}
	
	resizeViewport() {
	    var width = $(window).width(),
	        height = $(window).height(),
	        options = $('.flipbook').turn('options');

	    $('.flipbook-viewport').css({
	        width: width,
	        height: height
	    }).zoom('resize');
	}
	zoomTo(event) {
    setTimeout(function() {
      if ($('.flipbook-viewport').data().regionClicked) {
        $('.flipbook-viewport').data().regionClicked = false;
      } else {
        if ($('.flipbook-viewport').zoom('value')==1) {
            $('.flipbook-viewport').zoom('zoomIn', event);
        } else {
            $('.flipbook-viewport').zoom('zoomOut');
        }
      }
    }, 1);
	}
	
	ngAfterViewInit() {
		
	}
	youtubeURLtoID(url){
    if (url != null && url != '') {
      if( url.indexOf("http") == 0 ) {
        return url.substring(url.lastIndexOf("?v=") + 3);
      }else{
        return url;
      }
    }
  }
}
