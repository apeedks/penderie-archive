import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lounge',
  templateUrl: './lounge.component.html',
  styleUrls: ['./lounge.component.css']
})
export class LoungeComponent implements OnInit {

  visittype = '';
  constructor() { 
      this.visittype = localStorage.getItem('visittype');
  }

  ngOnInit() {
      scroll(0,0);
  }

}
