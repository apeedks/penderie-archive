import { Component, OnInit } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { AuthenticationService } from '../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import {AlertsService} from '@jaspero/ng2-alerts';
import { TranslateService } from '../translate';
import {DbserviceService} from '../services/dbservice.service';
// import { AuthService } from 'ng4-social-login';
// import { SocialUser } from 'ng4-social-login';
// import { GoogleLoginProvider, FacebookLoginProvider,LinkedinLoginProvider} from 'ng4-social-login';
import { AuthService }from "angular2-social-login";
import { FacebookService, LoginResponse, LoginOptions, UIResponse, UIParams, FBVideoComponent, InitParams } from 'ngx-facebook';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
	isuserloggedin:boolean = false;
	model={id:0,username:'',password:'',email:'',confirmemail:'',image:'',registeredby:'Normal',socialid:'',mobilecode:'',mobileno:'',firstname:'',lastname:'',name:'',connectiontype:"Connections",country:'',state:'',city:''}
	options:any;
	userid:number;
	validation_message = '';
	loggedIn: boolean;
	nameforverification:string;
	constructor(private dbserv:DbserviceService,private _translate: TranslateService,private route: ActivatedRoute,private router: Router,private authserv: AuthenticationService,private _alert: AlertsService,private socialLoginAuthService	: AuthService,private cookieService: CookieService, private fb : FacebookService) { 
		this.userid = this.authserv.getUserId();
		if(this.userid>0)
		{
			this.authserv.logout();
		}
		let initParams: InitParams = {
			appId: '1780419275334741',
			xfbml: true,
			version: 'v2.10'
		};

		this.fb.init(initParams);
	}
	
	ngOnInit() {
		this.userid = this.authserv.getUserId();
		if(this.userid>0)
		{
			this.router.navigate(['myaccount']);
		}
		// this.authService.authState.subscribe((user) => {
		// 	console.log('login',user);
		// 	if(user != null){
		// 		this.authserv.loginwithsocialid(user.id)
		// 			.subscribe(
		// 				data => {
		// 					this.loggedIn = true;
		// 					// if (data.type == "error") {
		// 					// 	this.validation_message = 'Oops! Looks like your email or password is incorrect.';
		// 					// }
		// 					if (data && data.token) {
		// 						// store user details and jwt token in local storage to keep user logged in between page refreshes
		// 						localStorage.setItem('currentUser', JSON.stringify(data));
		// 						this.authserv.sessionreq();
		// 						this.authserv.session().subscribe(res => {
		// 							if(res.isnew=='Yes')
		// 								this.router.navigate(['/home']);
		// 							else
		// 								this.router.navigate(['/myaccount']);
		// 						});
		// 					}
		// 				},
		// 				error => {
							
		// 					//this._alert.create('error',this._translate.instant('Invalid login credentials.'));
		// 				}
		// 			);
		// 	}else{
		// 		this.authserv.logout();
		// 	}
		// });
	}

	signInWithGoogle(): void {
		this.socialLoginAuthService.login('google').subscribe((data: any) => {
			this.authserv.loginwithsocialid(data.uid).subscribe(
				res => {
					if (res.type == 'error') {
						let mydate = new Date().getTime() + (60*60*24*1000);
						this.model.socialid = data.uid;
						this.model.registeredby = data.provider;
						this.model.name = data.name;
						this.model.firstname = this.model.name.split(' ').slice(0, -1).join(' ');
						this.model.lastname =  this.model.name.split(' ').slice(-1).join(' ');
						this.model.email = data.email;
						this.model.image = data.image;
						// this.model.lastname = user.firstName;
						// this.model.lastname = user.lastName;	
						this.model.username = mydate + "";
						this.nameforverification = data.name;
						/*this.dbserv.save("register",this.model).subscribe(res => {
							if (res && res.token) {
								// store user details and jwt token in local storage to keep user logged in between page refreshes
								localStorage.setItem('currentUser', JSON.stringify(res));
								this.authserv.sessionreq();
								this.authserv.session().subscribe(res => {
									this.router.navigate(['/myaccount']);
								});
							}
						});*/
					}
					if (res && res.token) {
						// store user details and jwt token in local storage to keep user logged in between page refreshes
						localStorage.setItem('currentUser', JSON.stringify(res));
						this.authserv.sessionreq();
						this.authserv.session().subscribe(res => {
							this.router.navigate(['/myaccount']);
						});
					}
				},
				error => {
					console.log(data);
					let mydate = new Date().getTime() + (60*60*24*1000);
					this.model.socialid = data.uid;
					this.model.registeredby = data.provider;
					this.model.name = data.name;
					this.model.firstname = this.model.name.split(' ').slice(0, -1).join(' ');
					this.model.lastname =  this.model.name.split(' ').slice(-1).join(' ');
					this.model.email = data.email;
					this.model.image = data.image;
					// this.model.lastname = user.firstName;
					// this.model.lastname = user.lastName;	
					this.model.username = mydate + "";
					this.nameforverification = data.name;
					/*this.dbserv.save("register",this.model).subscribe(res => {
						if (res && res.token) {
							// store user details and jwt token in local storage to keep user logged in between page refreshes
							localStorage.setItem('currentUser', JSON.stringify(res));
							this.authserv.sessionreq();
							this.authserv.session().subscribe(res => {
								this.router.navigate(['/myaccount']);
							});
						}
					});*/
				});
			
		});
	}
	
	signInWithFB(): void {
		const loginOptions: LoginOptions = {
			enable_profile_selector: true,
			return_scopes: true,
			scope: 'public_profile,email'
		};

		this.fb.login(loginOptions).then((response: LoginResponse) => {
				if(response.status === "connected"){
					this.fb.api('/me?fields=name,email,picture').then((res: any) => {
							let userDetails = {
									name: res.name,
									email: res.email,
									uid: res.id,
									provider: "facebook",
									image: res.picture.data.url,
									token: response.authResponse.accessToken
							}

							console.log(userDetails);
							this.authserv.loginwithsocialid(userDetails.uid).subscribe(
								res => {
									if (res.type == 'error') {
										let mydate = new Date().getTime() + (60*60*24*1000);
										this.model.socialid = userDetails.uid;
										this.model.registeredby = userDetails.provider;
										this.model.name = userDetails.name;
										this.model.firstname = this.model.name.split(' ').slice(0, -1).join(' ');
										this.model.lastname =  this.model.name.split(' ').slice(-1).join(' ');
										this.model.email = userDetails.email;
										this.model.image = userDetails.image;
										// this.model.lastname = user.firstName;
										// this.model.lastname = user.lastName;	
										this.model.username = userDetails.uid;
										this.nameforverification = userDetails.name;
										/*this.dbserv.save("register",this.model).subscribe(res => {
											if (res && res.token) {
												// store user details and jwt token in local storage to keep user logged in between page refreshes
												localStorage.setItem('currentUser', JSON.stringify(res));
												this.authserv.sessionreq();
												this.authserv.session().subscribe(res => {
													this.router.navigate(['/myaccount']);
												});
											}
										});*/
									}
									if (res && res.token) {
										// store user details and jwt token in local storage to keep user logged in between page refreshes
										localStorage.setItem('currentUser', JSON.stringify(res));
										this.authserv.sessionreq();
										this.authserv.session().subscribe(res => {
											this.router.navigate(['/myaccount']);
										});
									}
								},
								error => {
									let mydate = new Date().getTime() + (60*60*24*1000);
									this.model.socialid = userDetails.uid;
									this.model.registeredby = userDetails.provider;
									this.model.name = userDetails.name;
									this.model.firstname = this.model.name.split(' ').slice(0, -1).join(' ');
									this.model.lastname =  this.model.name.split(' ').slice(-1).join(' ');
									this.model.email = userDetails.email;
									this.model.image = userDetails.image;
									// this.model.lastname = user.firstName;
									// this.model.lastname = user.lastName;	
									this.model.username = mydate + "";
									this.nameforverification = userDetails.name;
									/*this.dbserv.save("register",this.model).subscribe(res => {
										if (res && res.token) {
											// store user details and jwt token in local storage to keep user logged in between page refreshes
											localStorage.setItem('currentUser', JSON.stringify(res));
											this.authserv.sessionreq();
											this.authserv.session().subscribe(res => {
												this.router.navigate(['/myaccount']);
											});
										}
									});*/
								});
					});
				}
			}).catch();
	}

	signInWithLinkedIN(): void {
		this.socialLoginAuthService.login('linkedin').subscribe((data: any) => {
			// console.log(data);
			this.authserv.loginwithsocialid(data.uid).subscribe(
				data => {
					if (data.type == 'error') {
						this.validation_message = 'Oops! Your account is not registered.';
					}else{
						this.isuserloggedin = true;
						this.validation_message = '';
					}
					if (data && data.token) {
						// store user details and jwt token in local storage to keep user logged in between page refreshes
						localStorage.setItem('currentUser', JSON.stringify(data));
						this.authserv.sessionreq();
						this.authserv.session().subscribe(res => {
							this.router.navigate(['/myaccount']);
						});
					}
				},
				error => {
					this._alert.create('error',this._translate.instant('Invalid login credentials.'));
				});
		});
	}
	signOut(): void {
		// this.authService.signOut();
	}
// Over facebook and linkend and google
	login()
	{
		this.authserv.login(this.model.email, this.model.password)
            .subscribe(
                data => {
					this.validation_message = this.authserv.validation_message;
					this.authserv.session().subscribe(res => {
							if(res.isnew=='Yes')
								this.router.navigate(['/home']);
							else
								this.router.navigate(['/myaccount']);
						});
                },
                error => {
                    this.validation_message ='';
					/*this._alert.create('error',this._translate.instant('Invalid login credentials.'));*/
                });
	}
	   resendverification()
	    {
	        if(this.model.email != null){
	            console.log(this.model.email);
	            this.dbserv.getByStringId("resendverifictionbyemail",this.model.email).subscribe(res => {
	                this._alert.create(res.type,res.message);
	            });
	        }
	        else{
	            this._alert.create('error',this._translate.instant('Please, register before clicking on Resend Request button.'));  
	        }
	    }
}
