import { Component, OnInit } from '@angular/core';
import { DbserviceService } from '../services/dbservice.service';
import { Http, Response } from '@angular/http';
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser';
import { AuthenticationService } from '../services/authentication.service';
import '../../assets/js/slider/jquery.slitslider.js';
import '../../assets/js/owl-carousel-custom.js';
import * as Immutable from 'immutable';
import $ from 'jquery';
import { Router, ActivatedRoute } from '@angular/router';

declare var webGlObject: any;
declare var carouselObject: any;

/*import { TranslateService } from '../translate';*/
@Component({
  selector: 'app-men',
  templateUrl: './men.component.html',
  styleUrls: ['./men.component.css']
})
export class MenComponent implements OnInit {
  stringproperty: string = '';
  exampletranslate: string;
  pageno: number = 1;
  showbecomeapenderian: boolean = true;
  loupelist = [];
  storieslist = [];
  basepageurl: string;
  constructor(private dbserv: DbserviceService, private route: ActivatedRoute, private router: Router, private authserv: AuthenticationService, private _sanitizer: DomSanitizer) {
    this.basepageurl = localStorage.getItem('baseurl');
  }   /*,private _translate: TranslateService*/
  options = Immutable.Map({
    showDots: true,         // Shows a dot navigation component 
    height: 458,            // The initial slideshow height 
    showThumbnails: false,   // Optionally include thumbnails a navigation option 
    thumbnailWidth: 150     // Thumbnail individual width for the thumbnail navigation component 
  });
  gotoregister(type: string) {
    this.router.navigate(['register']);
  }
  ngOnInit() {
    carouselObject.logoCarousel();
    /*let currlang = localStorage.getItem('currlang');
		this._translate.use(currlang);
		this.exampletranslate = this._translate.translate('hello world');
		alert(currlang + "=" + this.exampletranslate);*/

    //this.stringproperty = this.mydb.myData();
		/**let obj: any = this.mydb.geturl("persons");
		this.stringproperty = obj.next_page_url;*/
    //console.log('hellow' + this.stringproperty);
    //localStorage.setItem('testsrting','hellow world');

    if (this.authserv.isloggedin()) {
      this.showbecomeapenderian = false;
    }

    this.dbserv.getAll("getslides/" + this.pageno + "/Men").subscribe(res => {
      this.images = [];
      this.pageno = res.current_page;
      for (let result of res.data) {
        //   console.log("assets/photogallery/" + result.url) ;
        //   let newName = {
        //    url:"assets/photogallery/" + result.url
        // };
        this.images.push("assets/photogallery/" + result.url);
        // this.images.push(newName);
      }

      // this.images = Immutable.List(neimages);
      // console.log(this.images);
      webGlObject.init();
    });
    // console.log(this.images);

  }
  ngAfterViewInit() {
    webGlObject.init();
  }

  // images = Immutable.List([
  // 		{url: 'assets/img/banner1.jpg'},
  // 		{url: 'assets/img/banner3.png'},
  // 		{url: 'assets/img/banner4.png'},
  // 	]);

  images = [
    'assets/img/banner1.jpg',
    'assets/img/banner3.png',
    'assets/img/banner4.png',
  ];

  getBackground(image) {
    return this._sanitizer.bypassSecurityTrustStyle(`url(${image})`);
  }
  showByIndex() {
    //getslides/{pageno}/{gender}
  }
  currentuserselect(colorClass: string) {
    $("#own-category-toggle").attr("class", "");
    $("#own-category-toggle").attr("class", "own-category-sec fullHt " + colorClass + "");
  }
}
