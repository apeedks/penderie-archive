import { Component, OnInit, ElementRef, ViewChild} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import { AuthenticationService } from '../../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';
import {PlatformLocation } from '@angular/common';
declare var loupegallaryObject: any;
@Component({
  selector: 'app-review-product',
  templateUrl: './review-product.component.html',
  styleUrls: ['./review-product.component.css']
})
export class ReviewProductComponent implements OnInit {
	@ViewChild('lnktimelinesharebox') lnktimelinesharebox:ElementRef;
	record = {id:0,user_id:0,category_id:0,brand_id:0,shortdesc:'',title:"",type:"",gender:"",productline:"",season:"",overview:"",material:"",materialrate:0,craftsmanship:"",craftsmanshiprate:0,designnstyle:"",designnstylerate:0,usage:"",usagerate:0,exclusivity:"",exclusivityrate:0,conclusions:"",coverphototvp:"",coverphoto:"",mainphoto1tvp:"",mainphoto1:"",mainphoto2tvp:"",mainphoto2:"",mainphoto3tvp:"",mainphoto3:"",mainphoto4tvp:"",mainphoto4:"",mainphoto5tvp:"",mainphoto5:"",mainphoto6tvp:"",mainphoto6:"",created_at:"",updated_at:"",active:"",brand:"",category:"",username:"",image:"",likedbyme:'',savedbyme:'',name:"",coverimagestyle:"",liked:'',saved:''};
	rootpath = '';
	reviewid = 0;
	options:any;
	listofrecommended:any;
	totalitems: any;
	myitems = [];
	visittype = '';
	websiteroot:string;
	currtime:any;
	mysharedtype = 'Review Product';
	page: number = 1;
	mysharedurl = '';
	mysharedescription = '';
	mysharedtitle = '';
	mysharedimage = '';
	markers = [];
	gallery = [];
	pageSize: number;
	loggedin="No";
	last_page: number =1;
	constructor(private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private cookieService: CookieService,private platformLocation: PlatformLocation) {
		this.mysharedurl = (this.platformLocation as any).location.href;
		this.rootpath = localStorage.getItem('baseurl');
		this.websiteroot = localStorage.getItem('basewebsiteurl');
		this.visittype = localStorage.getItem('visittype');
	}
	loadpage()
	{
		this.currtime = Math.random();
		this.dbserv.getById("getproductreview/Product",this.reviewid).subscribe(res => {
													if(res.type=="success")
													{
														this.record=res.data;
														this.markers = res.data.markers;
														this.mysharedescription = this.record.overview;
														this.mysharedtitle = this.record.title;
														this.mysharedimage = this.rootpath+'assets/loupe/' + this.record.coverphoto+'?random+\='+this.currtime;
														this.mysharedurl = this.websiteroot+"loupe/product/"+ this.record.id;
														this.dbserv.getById("/loupe/increase-view",this.reviewid).subscribe(res => {});
														this.dbserv.getAll("getReviewRecommended/Product/"+this.visittype+"/"+this.reviewid).subscribe(res => {
														    if(res.type=="success")
		                                                    {
														    this.listofrecommended = res.data.data;
		                                                    }
														    });
														let images = [];
														if(this.record.mainphoto1tvp=="Image" && this.record.mainphoto1)
														{
															let rec = {type:this.record.mainphoto1tvp,media:this.record.mainphoto1};
															images.push(rec);
														}
														if(this.record.mainphoto2tvp=="Image" && this.record.mainphoto2)
														{
															let rec = {type:this.record.mainphoto2tvp,media:this.record.mainphoto2};
															images.push(rec);
														}
														if(this.record.mainphoto3tvp=="Image" && this.record.mainphoto3)
														{
															let rec = {type:this.record.mainphoto3tvp,media:this.record.mainphoto3};
															images.push(rec);
														}
														if(this.record.mainphoto4tvp=="Image" && this.record.mainphoto4)
														{
															let rec = {type:this.record.mainphoto4tvp,media:this.record.mainphoto4};
															images.push(rec);
														}
														if(this.record.mainphoto5tvp=="Image" && this.record.mainphoto5)
														{
															let rec = {type:this.record.mainphoto5tvp,media:this.record.mainphoto5};
															images.push(rec);
														}
														if(this.record.mainphoto6tvp=="Image" && this.record.mainphoto6)
														{
															let rec = {type:this.record.mainphoto6tvp,media:this.record.mainphoto6};
															images.push(rec);
														}
														if(images.length>1)
														{
															this.mysharedimage = this.rootpath+'assets/loupe/'+images[0].media+'?newtime='+this.currtime;;
														}
														if(this.record.mainphoto1)
															this.gallery.push({type:this.record.mainphoto1tvp,media:this.record.mainphoto1});
														if(this.record.mainphoto2)
															this.gallery.push({type:this.record.mainphoto2tvp,media:this.record.mainphoto2});
														if(this.record.mainphoto3)
															this.gallery.push({type:this.record.mainphoto3tvp,media:this.record.mainphoto3});
														if(this.record.mainphoto4)
															this.gallery.push({type:this.record.mainphoto4tvp,media:this.record.mainphoto4});
														if(this.record.mainphoto5)
															this.gallery.push({type:this.record.mainphoto5tvp,media:this.record.mainphoto5});
														if(this.record.mainphoto6)
															this.gallery.push({type:this.record.mainphoto6tvp,media:this.record.mainphoto6});
														console.log(this.gallery);

													}
												});
	}
	ngOnInit() {
		this.route.params.subscribe(params => {
		    this.reviewid = params['reviewid']; // (+) converts string 'id' to a number
			this.loadpage();
		});
		scroll(0,0);
		if (this.authserv.isloggedin()) {
			this.loggedin = "Yes";
		}
	}
	likeme(id,type,inx)
    {
        let params = {loupeid:id,status:type};
        this.dbserv.post("loupelike",params).subscribe(res => {
                                                                if(res.type=="success")
                                                                {
                                                                    if(type=="like")
                                                                    {
                                                                        $("#reclike" + id).css("display","none");
                                                                        $("#recunlike" + id).css("display","block");
                                                                    }
                                                                    else if(type=="unlike")
                                                                    {
                                                                        $("#reclike" + id).css("display","block");
                                                                        $("#recunlike" + id).css("display","none");
                                                                    }
                                                                    // this.loadpage(1);
                                                                    this.listofrecommended[inx].liked = res.total;
                                                                    /*this._alert.create(res.type,res.message+type);*/
                                                                }
                                                                else if(res.type=="expired")
                                                                {
                                                                    this.router.navigateByUrl('/login') ;
                                                                }
                                                                else
                                                                    this._alert.create(res.type,res.message);
                                                        });
    }
    saveme(id,type,inx)
    {
        let params = {loupeid:id,status:type};
        this.dbserv.post("loupemysavedlist",params).subscribe(res => {
                                                                if(res.type=="success")
                                                                {
                                                                    if(type=="save")
                                                                    {
                                                                        $("#recsave" + id).css("display","none");
                                                                        $("#recunsave" + id).css("display","block");
                                                                    }
                                                                    else if(type=="unsave")
                                                                    {
                                                                        $("#recsave" + id).css("display","block");
                                                                        $("#recunsave" + id).css("display","none");
                                                                    }
                                                                    // this.loadpage(1);
                                                                    this.listofrecommended[inx].saved = res.total;
                                                                    /*this._alert.create(res.type,res.message+type);*/
                                                                }
                                                                else if(res.type=="expired")
                                                                {
                                                                    this.router.navigateByUrl('/login') ;
                                                                }
                                                                else
                                                                    this._alert.create(res.type,res.message);
                                                        });
    }
	opensharebox(id)
	{
		this.lnktimelinesharebox.nativeElement.click();
	}
    add3Dots(string, limit)
    {
    if(string != null && string != undefined){
      var dots = "...";
      if(string.length > limit)
      {
        // you can also use substr instead of substring
        string = string.substring(0,limit) + dots;
      }
        return string;
        }
    }
    openCommentSection(event){
	  
	  	    	// if(event.target.tagName == "I"){
		    		// event.target.parentElement.classList.toggle("active");
		    		// let panel = event.target.parentElement.nextElementSibling;
					$(".pi-socialshare").toggle(200);
		        	$(event.target).toggleClass('fa fa-chevron-down fa fa-chevron-up');
		   //  	}else{
					// event.target.classList.toggle("active");
					// let panel = event.target.nextElementSibling;
					// $(panel).toggle(200);
		   //      	$(event.target).children().toggleClass('fa fa-plus fa fa-minus');
		   //  	}
		    // });
	  }

	   previous(id){
	  	loupegallaryObject.previous(id);
	  }
	  next(id){
	  	loupegallaryObject.next(id);
	  }
	youtubeURLtoID(url){
		if (url != null && url != '') {
			if( url.indexOf("http") == 0 ) {
				return url.substring(url.lastIndexOf("?v=") + 3);
			}else{
				return url;
			}
		}
	}
	throttle = (300 * 3);
	  scrollDistance = 1;
	  scrollUpDistance = 2;
	onScrollDown() {
	        if(this.totalitems>this.myitems.length){
	            this.page++;
	            this.loadpage();
	       }
	 }
}
