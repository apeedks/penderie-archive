import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loupe',
  templateUrl: './loupe.component.html',
  styleUrls: ['./loupe.component.css']
})
export class LoupeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
      scroll(0,0);
  }

}
