import { Component, OnInit, ElementRef, ViewChild} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import { AuthenticationService } from '../../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';
import {PlatformLocation } from '@angular/common';
declare var loupegallaryObject: any;
@Component({
  selector: 'app-review-service',
  templateUrl: './review-service.component.html',
  styleUrls: ['./review-service.component.css']
})
export class ReviewServiceComponent implements OnInit {
	@ViewChild('lnktimelinesharebox') lnktimelinesharebox:ElementRef;
	record = {id:0,user_id:0,category_id:0,brand_id:0,shortdesc:'',title:"",type:"",gender:"",productline:"",season:"",overview:"",material:"",materialrate:0,craftsmanship:"",craftsmanshiprate:0,designnstyle:"",designnstylerate:0,usage:"",usagerate:0,exclusivity:"",exclusivityrate:0,conclusions:"",coverphototvp:"",coverphoto:"",mainphoto1tvp:"",mainphoto1:"",mainphoto2tvp:"",mainphoto2:"",mainphoto3tvp:"",mainphoto3:"",mainphoto4tvp:"",mainphoto4:"",mainphoto5tvp:"",mainphoto5:"",mainphoto6tvp:"",mainphoto6:"",created_at:"",updated_at:"",active:"",brand:"",category:"",username:"",image:"",likedbyme:'',savedbyme:"",tags:[],name:"",storetype:"",coverimagestyle:"",liked:'',saved:''};
	rootpath = '';
	listofrecommended=[];
	storieslist:any;
	websiteroot = '';
	myitems = [];
	reviewid = 0;
	options:any;
	visittype = '';
	currtime:any;
	mysharedtype = 'Review Service';
	mysharedurl = '';
	mysharedescription = '';
	mysharedstoryid: number =1;
	mysharedtitle = '';
	mysharedimage = '';
    visiblefilter = false;
    custo_filter_onen_close = false;
	markers = [];
	gallery = [];
	loggedin="No";
	constructor(private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private cookieService: CookieService,private platformLocation: PlatformLocation) {
		this.mysharedurl = (this.platformLocation as any).location.href;
		this.rootpath = localStorage.getItem('baseurl');
		this.visittype = localStorage.getItem('visittype');
		this.websiteroot = localStorage.getItem('basewebsiteurl');
	}
	likeme(id,type,inx)
    {
        let params = {loupeid:id,status:type};
        this.dbserv.post("loupelike",params).subscribe(res => {
                                                                if(res.type=="success")
                                                                {
                                                                    if(type=="like")
                                                                    {
                                                                        $("#reclike" + id).css("display","none");
                                                                        $("#recunlike" + id).css("display","block");
                                                                    }
                                                                    else if(type=="unlike")
                                                                    {
                                                                        $("#reclike" + id).css("display","block");
                                                                        $("#recunlike" + id).css("display","none");
                                                                    }
                                                                    // this.loadpage(1);
                                                                    this.listofrecommended[inx].liked = res.total;
                                                                    /*this._alert.create(res.type,res.message+type);*/
                                                                }
                                                                else if(res.type=="expired")
                                                                {
                                                                    this.router.navigateByUrl('/login') ;
                                                                }
                                                                else
                                                                    this._alert.create(res.type,res.message);
                                                        });
    }
    saveme(id,type,inx)
    {
        let params = {loupeid:id,status:type};
        this.dbserv.post("loupemysavedlist",params).subscribe(res => {
                                                                if(res.type=="success")
                                                                {
                                                                    if(type=="save")
                                                                    {
                                                                        $("#recsave" + id).css("display","none");
                                                                        $("#recunsave" + id).css("display","block");
                                                                    }
                                                                    else if(type=="unsave")
                                                                    {
                                                                        $("#recsave" + id).css("display","block");
                                                                        $("#recunsave" + id).css("display","none");
                                                                    }
                                                                    // this.loadpage(1);
                                                                    this.listofrecommended[inx].saved = res.total;
                                                                    /*this._alert.create(res.type,res.message+type);*/
                                                                }
                                                                else if(res.type=="expired")
                                                                {
                                                                    this.router.navigateByUrl('/login') ;
                                                                }
                                                                else
                                                                    this._alert.create(res.type,res.message);
                                                        });
    }
    shareme(currrec)
    {
        this.currtime = Math.random();
        this.mysharedurl = this.websiteroot+"story/"+currrec.id;
        this.mysharedescription = currrec.title;
        this.mysharedtitle = currrec.shortdesc;
        this.mysharedstoryid = currrec.id;
        this.mysharedimage = this.rootpath+'assets/stories/'+currrec.image+'?newtime='+this.currtime;
        this.lnktimelinesharebox.nativeElement.click();
        
//      lnktimelinesharebox
    }
	/*likeme(id,type)
	{
		let params = {loupeid:id,status:type};
		this.dbserv.post("loupelike",params).subscribe(res => {
																if(res.type=="success")
																{
																	if(type=="like")
																	{
																		$("#reclike" + id).css("display","none");
																		$("#recunlike" + id).css("display","block");
																	}
																	else if(type=="unlike")
																	{
																		$("#reclike" + id).css("display","block");
																		$("#recunlike" + id).css("display","none");
																	}
																	// this.loadpage();
																	this.record.liked = res.total;
																	this._alert.create(res.type,res.message+type);
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/login') ;	
																}
																else
																	this._alert.create(res.type,res.message);
														});
	}
	saveme(id,type)
	{
		let params = {loupeid:id,status:type};
		this.dbserv.post("loupemysavedlist",params).subscribe(res => {
																if(res.type=="success")
																{
																	if(type=="save")
																	{
																		$("#recsave" + id).css("display","none");
																		$("#recunsave" + id).css("display","block");
																	}
																	else if(type=="unsave")
																	{
																		$("#recsave" + id).css("display","block");
																		$("#recunsave" + id).css("display","none");
																	}
																	// this.loadpage();
																	this.record.saved = res.total;
																	this._alert.create(res.type,res.message+type);
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/login') ;	
																}
																else
																	this._alert.create(res.type,res.message);
														});
	}*/
	loadpage()
	{
		this.currtime = Math.random();
		this.dbserv.getById("getproductreview/Service",this.reviewid)
		.subscribe(res => {
			if(res.type=="success")
				this.record=res.data;
				this.markers = res.data.markers;
				this.mysharedescription = this.record.overview;
				this.mysharedtitle = this.record.title;
				this.mysharedimage = this.rootpath+'assets/loupe/' + this.record.coverphoto;
				this.mysharedurl = this.websiteroot+"loupe/service/"+ this.record.id;
				this.dbserv.getById("/loupe/increase-view",this.reviewid).subscribe(res => {});
				this.dbserv.getAll("getReviewRecommended/Service/"+this.visittype+"/"+this.reviewid).subscribe(res => {
                    if(res.type=="success")
                    {
                    this.listofrecommended = res.data.data;
                    }
                    });
				
				let images = [];
				if(this.record.mainphoto1tvp=="Image" && this.record.mainphoto1)
				{
					let rec = {type:this.record.mainphoto1tvp,media:this.record.mainphoto1};
					images.push(rec);
				}
				if(this.record.mainphoto2tvp=="Image" && this.record.mainphoto2)
				{
					let rec = {type:this.record.mainphoto2tvp,media:this.record.mainphoto2};
					images.push(rec);
				}
				if(this.record.mainphoto3tvp=="Image" && this.record.mainphoto3)
				{
					let rec = {type:this.record.mainphoto3tvp,media:this.record.mainphoto3};
					images.push(rec);
				}
				if(this.record.mainphoto4tvp=="Image" && this.record.mainphoto4)
				{
					let rec = {type:this.record.mainphoto4tvp,media:this.record.mainphoto4};
					images.push(rec);
				}
				if(this.record.mainphoto5tvp=="Image" && this.record.mainphoto5)
				{
					let rec = {type:this.record.mainphoto5tvp,media:this.record.mainphoto5};
					images.push(rec);
				}
				if(this.record.mainphoto6tvp=="Image" && this.record.mainphoto6)
				{
					let rec = {type:this.record.mainphoto6tvp,media:this.record.mainphoto6};
					images.push(rec);
				}
				if(images.length>1)
				{
					this.mysharedimage = this.rootpath+'assets/loupe/'+images[0].media+'?newtime='+this.currtime;;
				}
				if(this.record.mainphoto1)
					this.gallery.push({type:this.record.mainphoto1tvp,media:this.record.mainphoto1});
				if(this.record.mainphoto2)
					this.gallery.push({type:this.record.mainphoto2tvp,media:this.record.mainphoto2});
				if(this.record.mainphoto3)
					this.gallery.push({type:this.record.mainphoto3tvp,media:this.record.mainphoto3});
				if(this.record.mainphoto4)
					this.gallery.push({type:this.record.mainphoto4tvp,media:this.record.mainphoto4});
				if(this.record.mainphoto5)
					this.gallery.push({type:this.record.mainphoto5tvp,media:this.record.mainphoto5});
				if(this.record.mainphoto6)
					this.gallery.push({type:this.record.mainphoto6tvp,media:this.record.mainphoto6});
				console.log(this.gallery);
		});
	}
	ngOnInit() {
		this.route.params.subscribe(params => {
		    this.reviewid = params['reviewid']; // (+) converts string 'id' to a number
			this.loadpage();
                    $(".custo-filter-colap").click(function(e){
            if(!$(this).hasClass('custo_filter_onen_close')){
                $(".utl-filter-box").addClass('visiblefilter');
                $(".custo-filter-colap").addClass('custo_filter_onen_close');
                e.stopPropagation();
            }else{
                $(".utl-filter-box").removeClass('visiblefilter');
                $(".custo-filter-colap").removeClass('custo_filter_onen_close');
                e.stopPropagation();
            }
        });

        $(".utl-filter-box").click(function(e){
            e.stopPropagation();
        });

        $(document).click(function(){
            $(".utl-filter-box").removeClass('visiblefilter');
            $(".custo-filter-colap").removeClass('custo_filter_onen_close');
            // self.filterby();
        });
		});
		
		scroll(0,0);
			if (this.authserv.isloggedin()) {
			this.loggedin = "Yes";
		}
	}
	opensharebox(id)
	{
		this.lnktimelinesharebox.nativeElement.click();
	}
    filterby()
    {
        this.visiblefilter = !this.visiblefilter;
        if(this.visiblefilter)
        {
            this.custo_filter_onen_close = true;
        }
        else
        {
            this.custo_filter_onen_close = false;   
        }
    }
        filterswitch()
    {
        $('html, body').animate({
            scrollTop: $("#scrollUp").offset().top - 95
        }, 2000);
        
        this.loadpage();
    }
        key_down(e) {
        console.log(e);
        if(e.target.value == '')
        {
            this.loadpage();
        }
            if(e.keyCode === 13) {
                    this.filterswitch();
        }
  }
          add3Dots(string, limit)
    {
    if(string != null && string != undefined){
      var dots = "...";
      if(string.length > limit)
      {
        // you can also use substr instead of substring
        string = string.substring(0,limit) + dots;
      }
        return string;
        }
	}
	    openCommentSection(event){
	  
	  	    	// if(event.target.tagName == "I"){
		    		// event.target.parentElement.classList.toggle("active");
		    		// let panel = event.target.parentElement.nextElementSibling;
					$(".pi-socialshare").toggle(200);
		        	$(event.target).toggleClass('fa fa-chevron-down fa fa-chevron-up');
		   //  	}else{
					// event.target.classList.toggle("active");
					// let panel = event.target.nextElementSibling;
					// $(panel).toggle(200);
		   //      	$(event.target).children().toggleClass('fa fa-plus fa fa-minus');
		   //  	}
		    // });
	  }
	  previous(id){
	  	loupegallaryObject.previous(id);
	  }
	  next(id){
	  	loupegallaryObject.next(id);
	  }
	  	street(id){
		$("#ellipsis-"+id).children().toggleClass('fa fa-ellipsis-h fa fa-ellipsis-v');
		$("#street-"+id).toggle();
	} 
	youtubeURLtoID(url){
		if (url != null && url != '') {
			if( url.indexOf("http") == 0 ) {
				return url.substring(url.lastIndexOf("?v=") + 3);
			}else{
				return url;
			}
		}
	}
}
