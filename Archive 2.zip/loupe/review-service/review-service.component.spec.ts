import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewServiceComponent } from './review-service.component';

describe('ReviewServiceComponent', () => {
  let component: ReviewServiceComponent;
  let fixture: ComponentFixture<ReviewServiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReviewServiceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
