import { Component, OnInit, ElementRef, ViewChild} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import { AuthenticationService } from '../../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';
@Component({
  selector: 'app-review-services',
  templateUrl: './review-services.component.html',
  styleUrls: ['./review-services.component.css']
})
export class ReviewServicesComponent implements OnInit {
	@ViewChild('lnktimelinesharebox') lnktimelinesharebox:ElementRef;
	visiblefilter = false;
	custo_filter_onen_close = false;
	rootpath = '';
	websiteroot = '';
	visittype = '';
	currtime:any;
	countrylist:any;
	statelist:any;
	citylist:any;
	myitems = [];
	selectedcats: any = {};
	selectedseasons: any = {};
	selectedlines: any = {};
	selectedbrands: any = {};
	selectedcountry = '';
	selectedstate = '';
	selectedcity = '';
	selectedzipcode = '';
	sortby = '';
	srhfield = '';
	options:any;
	categories:any;
	linetypes:any;
	brands:any;
	pageSize: number;
	totalitems: any;
	page: number = 1;
	last_page: number =1;
	loggedin="No";
	latitude:any;
	longitude:any;
	mysharedurl = '';
	mysharedreviewid = 0;
	mysharedtype = 'Review Service';
	haschild = '';
	mysharedescription = '';
	mysharedtitle = '';
	mysharedimage = '';
	settings = {};
	autoCitytags = [];
	selectedCitytags = [];
	userid:number = 0;
	loading = false;
	constructor(private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private cookieService: CookieService) {
		this.rootpath = localStorage.getItem('baseurl');
		this.visittype = localStorage.getItem('visittype');
		this.websiteroot = localStorage.getItem('basewebsiteurl');
		this.userid = this.authserv.getUserId() > 0 ? this.authserv.getUserId() : 0;
		this.settings = {
          singleSelection: true,
          text:"Search Your City",
          enableSearchFilter: true,
          searchPlaceholderText: 'Search your city',
		  limitSelection:4,
		  groupBy: "category",
		  searchBy: ['itemName'],
		  //noDataLabel: "Search City...",
          classes:"review-city-autocomplete"
        };
	}

	ngOnInit() {
		this.categories = [];
		this.dbserv.getAll("loupeallcatlist/"+this.visittype+"/"+"Service").subscribe(res => {
		    this.categories = res;
		    this.haschild = res.haschild;
		    this.loadbrands();
		    });
		this.dbserv.getAll("sourcebytype/linetypes").subscribe(res => {this.linetypes = res;});
		this.dbserv.getAll("countries").subscribe(res => {this.countrylist = res;});

		if (window.navigator && window.navigator.geolocation) {
	        window.navigator.geolocation.getCurrentPosition(
	            position => {
	                console.log(position);
	                this.latitude = position.coords.latitude;
	                this.longitude = position.coords.longitude;
	            },
	            error => {
	                switch (error.code) {
	                    case 1:
	                        console.log('Permission Denied');
	                        break;
	                    case 2:
	                        console.log('Position Unavailable');
	                        break;
	                    case 3:
	                        console.log('Timeout');
	                        break;
	                }
	            }
	        );
	    };
                $(".custo-filter-colap").click(function(e){
            if(!$(this).hasClass('custo_filter_onen_close')){
                $(".utl-filter-box").addClass('visiblefilter');
                $(".custo-filter-colap").addClass('custo_filter_onen_close');
                e.stopPropagation();
            }else{
                $(".utl-filter-box").removeClass('visiblefilter');
                $(".custo-filter-colap").removeClass('custo_filter_onen_close');
                e.stopPropagation();
            }
        });

        $(".utl-filter-box").click(function(e){
            e.stopPropagation();
        });

        $(document).click(function(){
            $(".utl-filter-box").removeClass('visiblefilter');
            $(".custo-filter-colap").removeClass('custo_filter_onen_close');
            // self.filterby();
        });
		scroll(0,0);
	if (this.authserv.isloggedin()) {
			this.loggedin = "Yes";
		}
	}

	states()
	{
		this.dbserv.getAll("states/" + this.selectedcountry).subscribe(res => {this.statelist = res;});
		this.custo_filter_onen_close = false;
		this.visiblefilter = false;
	}
	cities()
	{
		this.dbserv.getAll("cities/" + this.selectedcountry + "/" + this.selectedstate).subscribe(res => {this.citylist = res;});
		this.custo_filter_onen_close = false;
		this.visiblefilter = false;
	}
	showimages(item)
	{
		let images = [];
		if(item.mainphoto1tvp=="Image" && item.mainphoto1)
		{
			let rec = {type:item.mainphoto1tvp,media:item.mainphoto1};
			images.push(rec);
		}
		if(item.mainphoto2tvp=="Image" && item.mainphoto2)
		{
			let rec = {type:item.mainphoto2tvp,media:item.mainphoto2};
			images.push(rec);
		}
		if(item.mainphoto3tvp=="Image" && item.mainphoto3)
		{
			let rec = {type:item.mainphoto3tvp,media:item.mainphoto3};
			images.push(rec);
		}
		if(item.mainphoto4tvp=="Image" && item.mainphoto4)
		{
			let rec = {type:item.mainphoto4tvp,media:item.mainphoto4};
			images.push(rec);
		}
		if(item.mainphoto5tvp=="Image" && item.mainphoto5)
		{
			let rec = {type:item.mainphoto5tvp,media:item.mainphoto5};
			images.push(rec);
		}
		if(item.mainphoto6tvp=="Image" && item.mainphoto6)
		{
			let rec = {type:item.mainphoto6tvp,media:item.mainphoto6};
			images.push(rec);
		}
		let mediastring = '';
		this.currtime = Math.random();
		/*if(images.length>1)
		{
			if(images.length>1)
			{
				mediastring+='<img class="list-opa-one" src="'+this.rootpath+'assets/loupe/'+images[0].media+'?newtime='+this.currtime+'" alt="porduct-img">';
			}
			if(images.length>2)
			{
				mediastring+='<img class="list-opa-two" src="'+this.rootpath+'assets/loupe/'+images[1].media+'?newtime='+this.currtime+'" alt="porduct-img">';
			}
		}
		else if(images.length==1)
		{
			if(images.length>1)
			{
				mediastring+='<img src="'+this.rootpath+'assets/loupe/'+images[0].media+'?newtime='+this.currtime+'" alt="porduct-img">';
			}
		}*/
		if(images.length>1)
			{
				mediastring+='<img src="'+this.rootpath+'assets/loupe/'+images[0].media+'?newtime='+this.currtime+'" alt="porduct-img">';
			}
		return mediastring;
	}
	pageChanged($event)
	{
	  console.log($event);
	  this.loadpage($event) ;
	}


throttle = (300 * 3);
  scrollDistance = 1;
  scrollUpDistance = 2;
onScrollDown() {
		if(this.totalitems>this.myitems.length){
			this.page++;
			this.loadpage(this.page);
	   }
 }

	loadpage(cpage)
	{
		let srhmodel = {
			selectedcats:this.selectedcats,
			selectedseasons:this.selectedseasons,
			selectedlines:this.selectedlines,
			selectedbrands:this.selectedbrands,
			sortby:this.sortby,
			srhfield:this.srhfield,
			selectedcountry:this.selectedcountry,
			selectedstate:this.selectedstate,
			selectedcity:this.selectedcity,
			selectedzipcode:this.selectedzipcode,
			latitude:this.latitude,
			longitude:this.longitude
		};
		this.currtime = Math.random();
		this.custo_filter_onen_close = false;
		this.visiblefilter = false;
		this.loading = true;
		this.dbserv.post("publicreviews/"+this.visittype+"/Service/"+cpage+"/12",srhmodel)
		.subscribe(res => {
			if(cpage == 1)
				this.myitems = [];
			if(res.total>this.myitems.length)
				this.myitems = [ ...this.myitems, ...res.data]
			//this.myitems = res.data;
			this.page = res.current_page;
			this.totalitems = res.total;
			this.pageSize = res.per_page;
			this.last_page = res.last_page;
		});
		this.loading = false;
	}
	likeme(id,type,inx)
	{
		let params = {loupeid:id,status:type};
		this.dbserv.post("loupelike",params).subscribe(res => {
																if(res.type=="success")
																{
																	if(type=="like")
																	{
																		$("#reclike" + id).css("display","none");
																		$("#recunlike" + id).css("display","block");
																	}
																	else if(type=="unlike")
																	{
																		$("#reclike" + id).css("display","block");
																		$("#recunlike" + id).css("display","none");
																	}
																	// this.loadpage(1);
																	this.myitems[inx].liked = res.total;
																	/*this._alert.create(res.type,res.message+type);*/
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/login') ;
																}
																else
																	this._alert.create(res.type,res.message);
														});
	}
	saveme(id,type,inx)
	{
		let params = {loupeid:id,status:type};
		this.dbserv.post("loupemysavedlist",params).subscribe(res => {
																if(res.type=="success")
																{
																	if(type=="save")
																	{
																		$("#recsave" + id).css("display","none");
																		$("#recunsave" + id).css("display","block");
																	}
																	else if(type=="unsave")
																	{
																		$("#recsave" + id).css("display","block");
																		$("#recunsave" + id).css("display","none");
																	}
																	// this.loadpage(1);
																	this.myitems[inx].saved = res.total;
																	/*this._alert.create(res.type,res.message+type);*/
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/login') ;
																}
																else
																	this._alert.create(res.type,res.message);
														});
	}
	shareme(currrec)
	{
		this.currtime = Math.random();
		this.mysharedurl = this.websiteroot+"loupe/service/"+currrec.id;
		this.mysharedescription = currrec.title;
		this.mysharedtitle = currrec.shortdesc;
		this.mysharedreviewid = currrec.id;
		let images = [];
		if(currrec.mainphoto1tvp=="Image" && currrec.mainphoto1)
		{
			let rec = {type:currrec.mainphoto1tvp,media:currrec.mainphoto1};
			images.push(rec);
		}
		if(currrec.mainphoto2tvp=="Image" && currrec.mainphoto2)
		{
			let rec = {type:currrec.mainphoto2tvp,media:currrec.mainphoto2};
			images.push(rec);
		}
		if(currrec.mainphoto3tvp=="Image" && currrec.mainphoto3)
		{
			let rec = {type:currrec.mainphoto3tvp,media:currrec.mainphoto3};
			images.push(rec);
		}
		if(currrec.mainphoto4tvp=="Image" && currrec.mainphoto4)
		{
			let rec = {type:currrec.mainphoto4tvp,media:currrec.mainphoto4};
			images.push(rec);
		}
		if(currrec.mainphoto5tvp=="Image" && currrec.mainphoto5)
		{
			let rec = {type:currrec.mainphoto5tvp,media:currrec.mainphoto5};
			images.push(rec);
		}
		if(currrec.mainphoto6tvp=="Image" && currrec.mainphoto6)
		{
			let rec = {type:currrec.mainphoto6tvp,media:currrec.mainphoto6};
			images.push(rec);
		}
		if(images.length>1)
		{
			this.mysharedimage = this.rootpath+'assets/loupe/'+images[0].media+'?newtime='+this.currtime;;
		}
		this.lnktimelinesharebox.nativeElement.click();

//		lnktimelinesharebox
	}
	loadbrands()
	{
		this.dbserv.post("loupebrandsalllist/"+this.visittype,{selectedcats:this.selectedcats}).subscribe(res => { this.brands = res;this.loadpage(1);});
	}
	filterby()
	{
		this.visiblefilter = !this.visiblefilter;
		if(this.visiblefilter)
		{
			this.custo_filter_onen_close = true;
		}
		else
		{
			this.custo_filter_onen_close = false;
		}
	}
	getAutoCityTags(){
		let params = {
    		action:"popular",
    		latitude:this.latitude,
			longitude:this.longitude,
			userid: this.authserv.getUserId() > 0 ? this.authserv.getUserId() : 0,
			type:"Service"
    	};
        this.dbserv.post("loupeautocompletecitylist",params).subscribe(res => {
        	this.autoCitytags = res;
        });
	}
	onItemSelect(item: any) {
	    //console.log(item);
	    //console.log(this.selectedCitytags);
	    this.selectedcity = item.itemName;
	    this.loadpage(1);
	}
	OnItemDeSelect(item: any) {
	    //console.log(item);
	    //console.log(this.selectedCitytags);
	    this.selectedcity = "";
	    this.loadpage(1);
	}
	onOpen(evt: any){
		if(this.selectedcity == ""){
			this.getAutoCityTags();
		}
	}
	onSearch(evt: any) {

        //this.autoCitytags = [];
        this.selectedCitytags = [];
        if(evt.target.value != ""){
        	let params = {
        		searchcity:evt.target.value,
        		action:"search",
        		type:"Service"
        	};
	        this.dbserv.post("loupeautocompletecitylist",params).subscribe(res 																												=> {
	        	this.autoCitytags = res;
	        });
        } else {
        	this.getAutoCityTags();												
        }

    }
     filterswitch()
    {
        $('html, body').animate({
            scrollTop: $("#scrollUp").offset().top - 95
        }, 2000);
        
        this.loadpage(1);
    }
        key_down(e) {
        console.log(e);
        if(e.target.value == '')
        {
            this.loadpage(1);
        }
            if(e.keyCode === 13) {
                    this.filterswitch();
        }
  }
     selectfiltervalue()
    {
                 $('html, body').animate({
            scrollTop: $("#scrollUp").offset().top - 95
        }, 2000);
        this.loadpage(1);
        }
    sortvalue()
    {
        $('html, body').animate({
            scrollTop: $("#scrollUp").offset().top - 95
        }, 2000);
        this.loadpage(1);
        }
	street(id){
		$("#ellipsis-"+id).children().toggleClass('fa fa-ellipsis-h fa fa-ellipsis-v');
		$("#street-"+id).toggle();
	} 
	youtubeURLtoID(url){
		if (url != null && url != '') {
			if( url.indexOf("http") == 0 ) {
				return url.substring(url.lastIndexOf("?v=") + 3);
			}else{
				return url;
			}
		}
	}
}
