import { Component, OnInit, ElementRef, ViewChild} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import { AuthenticationService } from '../../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';

@Component({
  selector: 'app-review-products',
  templateUrl: './review-products.component.html',
  styleUrls: ['./review-products.component.css']
})
export class ReviewProductsComponent implements OnInit {
	@ViewChild('lnktimelinesharebox') lnktimelinesharebox:ElementRef;
	filterbrandids1:any = [];
	loggedin="No";
	filterbrandids2:any = [];
	visiblefilter = false;
	custo_filter_onen_close = false;
	rootpath = '';
	websiteroot = '';
	userid:number = 0;
	visittype = '';
	parentid ='';
	currtime:any;
	myitems = [];
	selectedcats: any = {};
	selectedseasons: any = {};
	selectedlines: any = {};
	selectedreleaseyears: any = {};
	selectedbrands: any = {};
    selectedbrands2: any = {};
	sortby = '';
	srhfield = '';
	options:any;
	categories:any;
	linetypes:any;
	brands:any;
    brands2:any;
    releaseyear1:any;
	pageSize: number;
	totalitems: any;
	page: number = 1;
	last_page: number =1;
	filterbrandids:any = [];
	mysharedreviewid = 0;
	mysharedtype = 'Review Product';
	mysharedurl = '';
	mysharedescription = '';
	mysharedtitle = '';
	mysharedimage = '';
	loading = false;
	release_year = [];
	constructor(private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private cookieService: CookieService) {
		this.rootpath = localStorage.getItem('baseurl');
		this.visittype = localStorage.getItem('visittype');
		this.websiteroot = localStorage.getItem('basewebsiteurl');
		this.userid = this.authserv.getUserId() > 0 ? this.authserv.getUserId() : 0;
	}
	
	ngOnInit() {
		let today = new Date();
		let year = today.getFullYear();
		for (var i = 2000; i <= year; i++) {
			this.release_year.push(i);
		}
		this.release_year = this.release_year.reverse();
        $(".custo-filter-colap").click(function(e){
            if(!$(this).hasClass('custo_filter_onen_close')){
                $(".utl-filter-box").addClass('visiblefilter');
                $(".custo-filter-colap").addClass('custo_filter_onen_close');
                e.stopPropagation();
            }else{
                $(".utl-filter-box").removeClass('visiblefilter');
                $(".custo-filter-colap").removeClass('custo_filter_onen_close');
                e.stopPropagation();
            }
        });

        $(".utl-filter-box").click(function(e){
            e.stopPropagation();
        });

        $(document).click(function(){
            $(".utl-filter-box").removeClass('visiblefilter');
            $(".custo-filter-colap").removeClass('custo_filter_onen_close');
            // self.filterby();
        });
		this.categories = [];
		this.dbserv.getAll("loupeallcatlist/"+this.visittype+"/"+"Product").subscribe(res => { 
		    this.categories = res;
		    this.parentid = res.parentid;
		    this.loadbrands();
		    });
		this.dbserv.getAll("sourcebytype/linetypes").subscribe(res => {this.linetypes = res;});
		scroll(0,0);
				if (this.authserv.isloggedin()) {
			this.loggedin = "Yes";
		}
	}
	showimages(item)
	{
		let images = [];
		if(item.mainphoto1tvp=="Image" && item.mainphoto1)
		{
			let rec = {type:item.mainphoto1tvp,media:item.mainphoto1};
			images.push(rec);
		}
		if(item.mainphoto2tvp=="Image" && item.mainphoto2)
		{
			let rec = {type:item.mainphoto2tvp,media:item.mainphoto2};
			images.push(rec);
		}
		if(item.mainphoto3tvp=="Image" && item.mainphoto3)
		{
			let rec = {type:item.mainphoto3tvp,media:item.mainphoto3};
			images.push(rec);
		}
		if(item.mainphoto4tvp=="Image" && item.mainphoto4)
		{
			let rec = {type:item.mainphoto4tvp,media:item.mainphoto4};
			images.push(rec);
		}
		if(item.mainphoto5tvp=="Image" && item.mainphoto5)
		{
			let rec = {type:item.mainphoto5tvp,media:item.mainphoto5};
			images.push(rec);
		}
		if(item.mainphoto6tvp=="Image" && item.mainphoto6)
		{
			let rec = {type:item.mainphoto6tvp,media:item.mainphoto6};
			images.push(rec);
		}
		let mediastring = '';
		this.currtime = Math.random();
		/*if(images.length>1)
		{
			if(images.length>1)
			{
				mediastring+='<img class="list-opa-one" src="'+this.rootpath+'assets/loupe/'+images[0].media+'?newtime='+this.currtime+'" alt="porduct-img">';
			}
			if(images.length>2)
			{
				mediastring+='<img class="list-opa-two" src="'+this.rootpath+'assets/loupe/'+images[1].media+'?newtime='+this.currtime+'" alt="porduct-img">';
			}
		}
		else if(images.length==1)
		{
			if(images.length>1)
			{
				mediastring+='<img src="'+this.rootpath+'assets/loupe/'+images[0].media+'?newtime='+this.currtime+'" alt="porduct-img">';
			}
		}*/
		if(images.length>1)
			{
				mediastring+='<img src="'+this.rootpath+'assets/loupe/'+images[0].media+'?newtime='+this.currtime+'" alt="porduct-img">';
			}
		return mediastring;
	}	
	pageChanged($event)
	{
	  console.log($event);
	  this.loadpage($event) ; 
	}

throttle = (300 * 3);
  scrollDistance = 1;
  scrollUpDistance = 2;
onScrollDown() {
		if(this.totalitems>this.myitems.length){
			this.page++;
			this.loadpage(this.page);
	   }
 }
	loadpage(cpage)
	{
		let srhmodel = {
			selectedcats:this.selectedcats,
			selectedseasons:this.selectedseasons,
			selectedlines:this.selectedlines,
			selectedreleaseyears:this.selectedreleaseyears,
			selectedbrands:this.selectedbrands,
			selectedbrands2:this.selectedbrands2,
			sortby:this.sortby,
			srhfield:this.srhfield
		};
		this.currtime = Math.random();
		this.custo_filter_onen_close = false;
		this.visiblefilter = false;
		this.loading = true;
		this.dbserv.post("publicreviews/"+this.visittype+"/Product/"+cpage+"/12",srhmodel)
			.subscribe(res => {
				if(cpage == 1)
					this.myitems = [];
				if(res.total>this.myitems.length)
					this.myitems = [ ...this.myitems, ...res.data]

				//this.myitems = res.data; 
				this.page = res.current_page; 
				this.totalitems = res.total;
				this.pageSize = res.per_page;
				this.last_page = res.last_page;
			}); 
			this.loading = false;
	}
	likeme(id,type,inx)
	{
		let params = {loupeid:id,status:type};
		this.dbserv.post("loupelike",params).subscribe(res => {
																if(res.type=="success")
																{
																	if(type=="like")
																	{
																		$("#reclike" + id).css("display","none");
																		$("#recunlike" + id).css("display","block");
																	}
																	else if(type=="unlike")
																	{
																		$("#reclike" + id).css("display","block");
																		$("#recunlike" + id).css("display","none");
																	}
																	// this.loadpage(1);
																	this.myitems[inx].liked = res.total;
																	/*this._alert.create(res.type,res.message+type);*/
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/login') ;	
																}
																else
																	this._alert.create(res.type,res.message);
														});
	}
	saveme(id,type,inx)
	{
		let params = {loupeid:id,status:type};
		this.dbserv.post("loupemysavedlist",params).subscribe(res => {
																if(res.type=="success")
																{
																	if(type=="save")
																	{
																		$("#recsave" + id).css("display","none");
																		$("#recunsave" + id).css("display","block");
																	}
																	else if(type=="unsave")
																	{
																		$("#recsave" + id).css("display","block");
																		$("#recunsave" + id).css("display","none");
																	}
																	// this.loadpage(1);
																	/*this._alert.create(res.type,res.message+type);*/
																	this.myitems[inx].saved = res.total;
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/login') ;	
																}
																else
																	this._alert.create(res.type,res.message);
														});
	}
	shareme(currrec)
	{
		this.currtime = Math.random();
		this.mysharedurl = this.websiteroot+"loupe/product/"+currrec.id;
		this.mysharedescription = currrec.title;
		this.mysharedtitle = currrec.shortdesc;
		this.mysharedreviewid = currrec.id;
		let images = [];
		if(currrec.mainphoto1tvp=="Image" && currrec.mainphoto1)
		{
			let rec = {type:currrec.mainphoto1tvp,media:currrec.mainphoto1};
			images.push(rec);
		}
		if(currrec.mainphoto2tvp=="Image" && currrec.mainphoto2)
		{
			let rec = {type:currrec.mainphoto2tvp,media:currrec.mainphoto2};
			images.push(rec);
		}
		if(currrec.mainphoto3tvp=="Image" && currrec.mainphoto3)
		{
			let rec = {type:currrec.mainphoto3tvp,media:currrec.mainphoto3};
			images.push(rec);
		}
		if(currrec.mainphoto4tvp=="Image" && currrec.mainphoto4)
		{
			let rec = {type:currrec.mainphoto4tvp,media:currrec.mainphoto4};
			images.push(rec);
		}
		if(currrec.mainphoto5tvp=="Image" && currrec.mainphoto5)
		{
			let rec = {type:currrec.mainphoto5tvp,media:currrec.mainphoto5};
			images.push(rec);
		}
		if(currrec.mainphoto6tvp=="Image" && currrec.mainphoto6)
		{
			let rec = {type:currrec.mainphoto6tvp,media:currrec.mainphoto6};
			images.push(rec);
		}
		if(images.length>1)
		{
			this.mysharedimage = this.rootpath+'assets/loupe/'+images[0].media+'?newtime='+this.currtime;;
		}
		this.lnktimelinesharebox.nativeElement.click();
		
//		lnktimelinesharebox
	}
	loadbrands()
	{
		this.dbserv.post("loupebrandsalllist/"+this.visittype,{selectedcats:this.selectedcats}).subscribe(res => { this.brands = res;this.loadpage(1);});	
	}
	filterby()
	{
		this.visiblefilter = !this.visiblefilter;
		if(this.visiblefilter)
		{
			this.custo_filter_onen_close = true;
		}
		else
		{
			this.custo_filter_onen_close = false;	
		}
	}
    
    filterswitch()
    {
        $('html, body').animate({
            scrollTop: $("#scrollUp").offset().top - 95
        }, 2000);
        
        this.loadpage(1);
    }
        key_down(e) {
        console.log(e);
        if(e.target.value == '')
        {
            this.loadpage(1);
        }
            if(e.keyCode === 13) {
                    this.filterswitch();
        }
  }
  filtercat(){
        this.filterbrandids = [];
        this.brands.forEach(obj=>{
            if(obj.checked)
                this.filterbrandids.push(obj.id);
        });
        this.loadpage(1);
    }
    selecallcat(event){
      this.filterbrandids = [];
      this.brands.forEach(obj=>{
      	this.selectedbrands[obj.id] = event.target.checked
        obj.checked = event.target.checked;
        if(obj.checked)
          this.filterbrandids.push(obj.id);
        });
      this.loadpage(1);
    }
    selecallcat1(event){
      this.selectedseasons['Spring Summer'] =event.target.checked;
      this.selectedseasons['Fall Winter'] =event.target.checked;
      this.loadpage(1);
    }
    selecallreleaseyear(event){
    	this.release_year.forEach(obj=>{
    		this.selectedreleaseyears[obj] = event.target.checked;
      });
      this.loadpage(1);
    }
    selecallline(event){
    	this.linetypes.forEach(obj=>{
    		this.selectedlines[obj.title] = event.target.checked;
      });
      this.loadpage(1);
    }
    selectAll(event){
    	this.filterbrandids = [];
      this.brands.forEach(obj=>{
	    	this.selectedbrands[obj.id] = event.target.checked
	      obj.checked = event.target.checked;
	      if(obj.checked)
	        this.filterbrandids.push(obj.id);
      });
    	this.selectedseasons['Spring Summer'] =event.target.checked;
      this.selectedseasons['Fall Winter'] =event.target.checked;
    	this.release_year.forEach(obj=>{
    		this.selectedreleaseyears[obj] = event.target.checked;
      });
    	this.linetypes.forEach(obj=>{
    		this.selectedlines[obj.title] = event.target.checked;
      });
      this.loadpage(1);
    }

    releaseyear()
    {
      $('html, body').animate({
        scrollTop: $("#scrollUp").offset().top - 95
      }, 2000);
      this.loadpage(1);
    }
    producline()
    {
         $('html, body').animate({
            scrollTop: $("#scrollUp").offset().top - 95
        }, 2000);
        this.loadpage(1);
    }
    sortfilter()
    {
         $('html, body').animate({
            scrollTop: $("#scrollUp").offset().top - 95
        }, 2000);
        this.loadpage(1);
        }
  add3Dots(string, limit)
	{
	if(string != null && string != undefined){
	  var dots = "...";
	  if(string.length > limit)
	  {
	    // you can also use substr instead of substring
	    string = string.substring(0,limit) + dots;
	  }
	    return string;
	    }
	}  

	filtercat3(){
        this.filterbrandids1 = [];
        this.brands.forEach(obj=>{
            if(obj.checked)
                this.filterbrandids1.push(obj.id);
        });
        this.loadpage(1);
    }
    selecallcat3(event){
         $('html, body').animate({
            scrollTop: $("#scrollUp").offset().top - 95
        }, 2000);
        this.filterbrandids1 = [];
        this.brands.forEach(obj=>{
            this.selectedbrands[obj.id] = event.target.checked
            obj.checked = event.target.checked;
            if(obj.checked)
                this.filterbrandids1.push(obj.id);
        });
        this.loadpage(1);
        
    }
    filtercat2(){
        this.filterbrandids2 = [];
        this.release_year.forEach(obj=>{
            if(obj.checked)
                this.filterbrandids2.push(obj.id);
        });
        this.loadpage(1);
    }
    selecallcat2(event){
         $('html, body').animate({
            scrollTop: $("#scrollUp").offset().top - 95
        }, 2000);
        this.filterbrandids2 = [];
        this.release_year.forEach(obj=>{
            this.selectedbrands2[obj.id] = event.target.checked
            obj.checked = event.target.checked;
            if(obj.checked)
                this.filterbrandids2.push(obj.id);
        });
        this.loadpage(1);
        
	}
	street(id){
		$("#ellipsis-"+id).children().toggleClass('fa fa-ellipsis-h fa fa-ellipsis-v');
		$("#street-"+id).toggle();
	}
	youtubeURLtoID(url){
		if (url != null && url != '') {
			if( url.indexOf("http") == 0 ) {
				return url.substring(url.lastIndexOf("?v=") + 3);
			}else{
				return url;
			}
		}
	}
}
