import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
	
	constructor(private router: Router,private cookieService: CookieService) { }
	
	ngOnInit() {
		let tvp:string = this.cookieService.get('visittype');
		switch(tvp)
		{
			case "Men":
				$(".gndr_male").addClass("current");
				$(".gndr_fmale").removeClass("current");
				this.router.navigate(['/man']);
				break;
			case "Women":
				$(".gndr_fmale").addClass("current");
				$(".gndr_male").removeClass("current");
				this.router.navigate(['/women']);
				break;
		}
	}
	switchmalefemale(type:string)
	{
		switch(type)
		{
			case "Men":
				$(".gndr_male").addClass("current");
				$(".gndr_fmale").removeClass("current");
				this.cookieService.set('visittype',type);
				setTimeout(function() {
					window.location.reload();
				  }, 500);
				break;
			case "Women":
				$(".gndr_fmale").addClass("current");
				$(".gndr_male").removeClass("current");
				this.cookieService.set('visittype',type);
				setTimeout(function() {
					window.location.reload();
				  }, 500);
				break;
		}
	}
	close()
	{
		$('.close').parents('p').fadeOut();
		this.router.navigate(['/women']);
		// localStorage.set('visittype','WOMAN');
		// console.log(this.visittype);
	}
}
