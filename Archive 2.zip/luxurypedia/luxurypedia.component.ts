import { Component, OnInit, HostListener, ElementRef, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../services/dbservice.service';
import { AuthenticationService } from '../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';

@Component({
  selector: 'app-luxurypedia',
  templateUrl: './luxurypedia.component.html',
  styleUrls: ['./luxurypedia.component.css']
})
export class LuxurypediaComponent implements OnInit {
    @ViewChild('lnktimelinesharebox') lnktimelinesharebox:ElementRef;
	model = {alphabet:'',tag:'',sortfield:'latest',searchfield:'',filterfield:'',categoryfield:'',filters:[]};
	visiblefilter = false;
	mysharedurl = '';
	mysharedtype = 'Article';
	mysharedescription = '';
	mysharedtitle = '';
	mysharedimage = '';
	custo_filter_onen_close = false;
    filterfield='';
	valuefilter='';
	articleid:number = 0;
	visittype = '';
	rootpath = '';
	currtime:any;
	tagslist:any;
	latestlist:any;
	popularlist:any;
	featuredlist:any;
	myitems = [];
	options:any;
	pageSize: number;
	totalitems: any;
	page: number = 1;
	last_page: number =1;
	categories: any;
	filters:any = {thetrueluxury:[],finematerial:[],superiorcraftsmanship:[],artofstyling:[],balancedliving:[]};
	lateshtag:boolean = true;
	featuretag:boolean = true;
	moretag:boolean = true;
	loaded:boolean = false;
  thetrueluxury:any;
  finematerial:any;
  superiorcraftsmanship:any;
  artofstyling:any;
  balancedliving:any;
  loading = false;
  category:any = '';
  categorytitle:any = '';
  tag:any = '';
  searchfilter:string = "";
  searchthetrueluxury:string="";
  searchfinematerial:string="";
  searchsuperiorcraftsmanship:string="";
  searchartofstyling:string="";
  searchbalancedliving:string="";
  loggedin="No";
	
	constructor(private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private cookieService: CookieService) {
		this.rootpath = localStorage.getItem('baseurl');
		
		this.visittype = localStorage.getItem('visittype');
	}
	loadddl()
	{
		this.categories = [];
		this.dbserv.getAll("luxurycatlist/-/"+this.visittype).subscribe(res => { 
			this.categories = res;
			if(this.category != '' && this.category != null)
				this.categorytitle = this.categories.find(x=>x.id == this.category).title;
			else
				this.categorytitle = '';
		});
		this.dbserv.getAll("luxurycatlist/The True Luxury/"+this.visittype)
		.subscribe(res => { 
			this.filters.thetrueluxury = res;
		});
		this.dbserv.getAll("luxurycatlist/Fine Material/"+this.visittype)
		.subscribe(res => { 
			this.filters.finematerial = res;
		});
		this.dbserv.getAll("luxurycatlist/Superior Craftsmanship/"+this.visittype)
		.subscribe(res => { 
			this.filters.superiorcraftsmanship = res;
		});
		this.dbserv.getAll("luxurycatlist/Art of Styling/"+this.visittype)
		.subscribe(res => { 
			this.filters.artofstyling = res;
		});
		this.dbserv.getAll("luxurycatlist/Balanced Living/"+this.visittype)
		.subscribe(res => { 
			this.filters.balancedliving = res;
		});
	}
	street(id){
		$("#ellipsis-"+id).children().toggleClass('fa fa-ellipsis-h fa fa-ellipsis-v');
		$("#street-"+id).toggle();
	}
	ngOnInit() {

		$(".custo-filter-colap").click(function(e){
			if(!$(this).hasClass('custo_filter_onen_close')){
		    	$(".utl-filter-box").addClass('visiblefilter');
		    	$(".custo-filter-colap").addClass('custo_filter_onen_close');
		    	e.stopPropagation();
		    }else{
		    	$(".utl-filter-box").removeClass('visiblefilter');
		    	$(".custo-filter-colap").removeClass('custo_filter_onen_close');
		    	e.stopPropagation();
		    }
		});

		$(".utl-filter-box").click(function(e){
		    e.stopPropagation();
		});

		$(document).click(function(){
		    $(".utl-filter-box").removeClass('visiblefilter');
		    $(".custo-filter-colap").removeClass('custo_filter_onen_close');
		    // self.filterby();
		});
		$(window).resize(function() {
			if ($(window).width() < 992) {
				$('.bottom_div').each(function () {
				    if (!$(this).text().match(/^\s*$/)) {
				        $(this).insertBefore($(this).prev('.top_div'));
				    }
				});  
			}
			else{
				$('.top_div').each(function () {
				    if (!$(this).text().match(/^\s*$/)) {
				        $(this).insertBefore($(this).prev('.bottom_div'));
				    }
				});  	
			}
		});
		this.route.queryParamMap.subscribe(params => {
			this.category = params.get('category');
			this.tag = params.get('tag');
			if(params.get('sortfield') != null)
				this.model.sortfield = params.get('sortfield');
			if(this.tag != '' && this.tag != null)
				this.model.tag = this.tag;
			// console.log(params,this.category,this.tag);
			this.loadddl();
			this.dbserv.getAll("luxurytagswidget/"+this.visittype).subscribe(res => {this.tagslist = res;});	
			this.dbserv.getAll("luxurypediawidget/"+this.visittype+"/All/latest").subscribe(res => {this.latestlist = res;});	
			this.dbserv.getAll("luxurypediawidget/"+this.visittype+"/All/popular").subscribe(res => {this.popularlist = res;});	
			this.dbserv.getAll("luxurypediawidget/"+this.visittype+"/All/featured").subscribe(res => {this.featuredlist = res;});
			this.loadpage(this.page);
		});
		if (this.authserv.isloggedin()) {
			this.loggedin = "Yes";
		}
		scroll(0,0);
	}
	alphabetswitch(chr)
	{
		this.model.alphabet = chr;
		this.myitems = [];
		this.loadpage(1);
	}
	tagswitch(tg)
	{
		if($("#tag"+tg).hasClass("active")){
			$("#tag"+tg).removeClass("active");
			this.model.tag = '';
			this.myitems = [];
			this.loadpage(1);
		}else{
			$(".tagList").removeClass("active");
			$("#tag"+tg).addClass("active");
			this.model.tag = tg;
			this.myitems = [];
			this.loadpage(1);
		}
	}
	filterswitch()
	{
		$('html, body').animate({
        	scrollTop: $("#scrollUp").offset().top - 95
    	}, 2000);
    	
		this.myitems = [];
		this.loadpage(1);
	}
	sortswitch()
	{
		$('html, body').animate({
        	scrollTop: $("#scrollUp").offset().top - 95
    	}, 2000);
		this.myitems = [];
		this.loadpage(1);
	}
	loadpage(cpage)
	{
		console.log('load',cpage);
		
		this.currtime = Math.random();
		this.loading = true;
		let cararray = [];
		this.filters.thetrueluxury.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.filters.finematerial.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.filters.superiorcraftsmanship.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.filters.artofstyling.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.filters.balancedliving.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		if(cararray.length == 0){
			if(this.category != '' && this.category != null)
				cararray.push(this.category);
		}
		this.model.filters = cararray;
		this.dbserv.post("luxuryarticles/"+this.visittype+"/All/"+cpage+"/9",this.model)
		.subscribe(res => {
			if(cpage == 1)
				this.myitems = [];
			if(res.total>this.myitems.length)
				this.myitems = [ ...this.myitems, ...res.data]
			this.loaded = true;
			this.page = res.current_page; 
			this.totalitems = res.total;
			this.pageSize = res.per_page;
			this.last_page = res.last_page;
			this.loading = false;
		}); 
	}
	filterby()
	{
		// var self = this;
		$(".custo-filter-colap").click(function(e){
		    $(".utl-filter-box").addClass('visiblefilter');
		    $(".custo-filter-colap").addClass('custo_filter_onen_close');
		     e.stopPropagation();
		});

		$(".utl-filter-box").click(function(e){
		    e.stopPropagation();
		});

		$(document).click(function(){
		    $(".utl-filter-box").removeClass('visiblefilter');
		    $(".custo-filter-colap").removeClass('custo_filter_onen_close');
		    // self.filterby();
		});
		this.visiblefilter = !this.visiblefilter;
		if(this.visiblefilter)
		{
			this.custo_filter_onen_close = true;
		}
		else
		{
			this.custo_filter_onen_close = false;	
		}
	}
	
	selecrmethod()
	{
	this.loadpage(1);
	}
	selecfillter(event:any, id:any = ''){
		// console.log(event);
		if(id == '' || id == 0 || id == null || id == undefined){
			switch (event.target.value) {
				case "thetrueluxury":
					this.filters.thetrueluxury.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					this.searchthetrueluxury="";
					break;
				case "finematerial":
					this.filters.finematerial.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					this.searchfinematerial="";
					break;
				case "superiorcraftsmanship":
					this.filters.superiorcraftsmanship.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					this.searchsuperiorcraftsmanship="";
					break;
				case "artofstyling":
					this.filters.artofstyling.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					this.searchartofstyling="";
					break;
				case "balancedliving":
					this.filters.balancedliving.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					this.searchbalancedliving="";
					break;
			}
      this.myitems = [];
			this.loadpage(1);
		}
	}

  throttle = 380*3;
  scrollDistance = 1;
  scrollUpDistance = 2;
	onScrollDown() {
		if(this.totalitems>this.myitems.length){
			this.page++
			this.loadpage(this.page);
		}
  }
  key_down(e) {
	console.log(e);
	if(e.target.value == '')
	{
		this.loadpage(1);
	}
    	if(e.keyCode === 13) {
      			this.filterswitch();
    }
  }
 key_up(e) {
    console.log(e);
    if(e.target.value == '')
    {
        this.loadpage(1);
//        let filterfield=array.filter(element => element.field == filterValue);
        this.filters.thetrueluxury = this.filterfield; 

    }

  }
    
  add3Dots(string, limit)
	{
	if(string != null && string != undefined){
	  var dots = "...";
	  if(string.length > limit)
	  {
	    // you can also use substr instead of substring
	    string = string.substring(0,limit) + dots;
	  }
	    return string;
	    }
	}
    selectAll(event:any){
      this.thetrueluxury = event.target.checked;
      this.finematerial = event.target.checked;
      this.superiorcraftsmanship = event.target.checked;
      this.artofstyling = event.target.checked;
      this.balancedliving = event.target.checked;
      event.target.value = 'thetrueluxury';
      this.selecfillter(event);
      event.target.value = 'finematerial';
      this.selecfillter(event);
      event.target.value = 'superiorcraftsmanship';
      this.selecfillter(event);
      event.target.value = 'artofstyling';
      this.selecfillter(event);
      event.target.value = 'balancedliving';
      this.selecfillter(event);
    this.myitems = [];
    this.loadpage(1);
  }
	likeme(id,type,inx)
	{
		let params = {luxurypedia_id:id,status:type};
		this.dbserv.post("luxurypedialike",params).subscribe(res => {
																if(res.type=="success")
																{
																	if(type=="like")
																	{
																		$("#reclike" + id).css("display","none");
																		$("#recunlike" + id).css("display","block");
																	}
																	else if(type=="unlike")
																	{
																		$("#reclike" + id).css("display","block");
																		$("#recunlike" + id).css("display","none");
																	}
																	//  this.loadpage(1);
																	this.myitems[inx].liked = res.total;
																	/*this._alert.create(res.type,res.message+type);*/
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/login') ;	
																}
																else
																	this._alert.create(res.type,res.message);
														});
	}
	saveme(id,type,inx)
	{
		let params = {articleid:id,status:type};
		this.dbserv.post("luxurybookmark",params).subscribe(res => {
																if(res.type=="success")
																{
																	if(type=="save")
																	{
																		$("#recsave" + id).css("display","none");
																		$("#recunsave" + id).css("display","block");
																	}
																	else if(type=="unsave")
																	{
																		$("#recsave" + id).css("display","block");
																		$("#recunsave" + id).css("display","none");
																	}
																		// this.loadpage(1);
																			this.myitems[inx].saved = res.total;
																	/*this._alert.create(res.type,res.message+type);*/
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/login') ;	
																}
																else
																	this._alert.create(res.type,res.message);
														});
	}
    opensharebox(id)
    {
        this.lnktimelinesharebox.nativeElement.click();
    }
}
