import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LuxurypediaComponent } from './luxurypedia.component';

describe('LuxurypediaComponent', () => {
  let component: LuxurypediaComponent;
  let fixture: ComponentFixture<LuxurypediaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LuxurypediaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LuxurypediaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
