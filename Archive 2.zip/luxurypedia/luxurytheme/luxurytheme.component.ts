import { Component, OnInit, HostListener, ElementRef, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import { AuthenticationService } from '../../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';

@Component({
  selector: 'app-luxurytheme',
  templateUrl: './luxurytheme.component.html',
  styleUrls: ['./luxurytheme.component.css']
})
export class LuxurythemeComponent implements OnInit {
	@ViewChild('lnktimelinesharebox') lnktimelinesharebox:ElementRef;
	wasClicked:boolean = false;
	custo_filter_onen_close = false;
	visiblefilter = false;
	model = {alphabet:'',tag:'',sortfield:'latest',searchfield:'',searchcat:0,filtercat:[]};
	visittype = '';
	rootpath = '';
	theme = 'The True Luxury';
	currtime:any;
	tagslist:any;
	latestlist:any;
	popularlist:any;
	featuredlist:any;
	myitems = [];
	myslider = [];
	options:any;
	pageSize: number;
	totalitems: any;
	page: number = 1;
	last_page: number =1;
	categories: any;
	parentid: number = 0;
	loaded:boolean = false;
	loggedin="No";
	searchcat:string="";
	loading = false;
	constructor(private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private cookieService: CookieService) {
		this.rootpath = localStorage.getItem('baseurl');
		this.visittype = localStorage.getItem('visittype');
	}
	loadddl()
	{
		this.categories = [];
		this.dbserv.getAll("luxurypediacatsbyparent/"+this.theme+"/"+this.visittype+"/"+this.parentid).subscribe(res => { this.categories = res;});
	}
	filterbycategory(id)
	{
		this.model.searchcat = id;
		this.parentid = this.model.searchcat;
		this.myitems = [];
		this.loadpage(1);
		// this.loadddl();
	}
	ngOnInit() {

			$(".custo-filter-colap").click(function(e){
			if(!$(this).hasClass('custo_filter_onen_close')){
		    	$(".utl-filter-box").addClass('visiblefilter');
		    	$(".custo-filter-colap").addClass('custo_filter_onen_close');
		    	e.stopPropagation();
		    }else{
		    	$(".utl-filter-box").removeClass('visiblefilter');
		    	$(".custo-filter-colap").removeClass('custo_filter_onen_close');
		    	e.stopPropagation();
		    }
		});

		$(".utl-filter-box").click(function(e){
		    e.stopPropagation();
		});

		$(document).click(function(){
		    $(".utl-filter-box").removeClass('visiblefilter');
		    $(".custo-filter-colap").removeClass('custo_filter_onen_close');
		    // self.filterby();
		});
		
		this.route.params.subscribe(params => {
		    this.theme = params['theme'];
			this.dbserv.getAll("luxurytagswidget/"+this.visittype+"/"+this.theme).subscribe(res => {this.tagslist = res;});	
			this.dbserv.getAll("luxurypediawidget/"+this.visittype+"/"+this.theme+"/latest").subscribe(res => {this.latestlist = res;});	
			this.dbserv.getAll("luxurypediawidget/"+this.visittype+"/"+this.theme+"/popular").subscribe(res => {this.popularlist = res;});	
			this.dbserv.getAll("luxurypediawidget/"+this.visittype+"/"+this.theme+"/featured").subscribe(res => {this.featuredlist = res;});
			this.dbserv.post("luxurypediaslider/"+this.visittype+"/"+this.theme+"/"+this.page+"/20",this.model)
			.subscribe(res => {
				this.myslider = res.data;
			});
			this.loadddl();
			this.loadpage(1);
			scroll(0,0);
		});
		if (this.authserv.isloggedin()) {
			this.loggedin = "Yes";
		}
	}
	alphabetswitch(chr)
	{
		this.model.alphabet = chr;
		this.myitems = [];
		this.loadpage(1);
	}
	tagswitch(tg)
	{
		this.model.tag = tg;
		this.myitems = [];
		this.loadpage(1);
	}
	filterswitch()
	{
		this.myitems = [];
		this.loadpage(1);
	}
	sortswitch()
	{
		$('html, body').animate({
        	scrollTop: $("#scrollUp").offset().top - 95
    	}, 2000);
		this.myitems = [];
		this.loadpage(1);
	}
	loadpage(cpage)
	{
			// if(cpage == 1)
			// this.myitems = [];
	    
		this.currtime = Math.random();
		this.loading = true;
		
		let cararray = [];
    this.categories.forEach(obj=>{
      if(obj.checked)
        cararray.push(obj.id);
    })
		this.model.filtercat = cararray;
		// console.log(this.model.filtercat);
		this.currtime = Math.random();
		this.dbserv.post("luxuryarticles/"+this.visittype+"/"+this.theme+"/"+cpage+"/9",this.model).subscribe(res => {
																			if(cpage == 1)
																				this.myitems = [];
																			if(res.total>this.myitems.length)
																				this.myitems = [ ...this.myitems, ...res.data]
																			this.loaded = true;
																			
																			//this.myitems = [ ...this.myitems, ...res.data]
																			this.page = res.current_page; 
																			this.totalitems = res.total;
																			this.pageSize = res.per_page;
																			this.last_page = res.last_page;
																			this.loading = false;
																		}); 
	}
	filterby()
	{
		this.wasClicked = !this.wasClicked;
		if(this.wasClicked)
		{
			this.custo_filter_onen_close = true;
			this.visiblefilter = true;
			
		}
		else
		{
			this.custo_filter_onen_close = false;	
			this.visiblefilter = false;	
		}

	}
	key_down(e) {
	console.log(e);
	if(e.target.value == '')
	{
		this.loadpage(1);
	}
    	if(e.keyCode === 13) {
      			this.sortswitch();
    }
  }
  selecrmethod()
	{	
		this.myitems = [];
		this.loadpage(1);
	}
	
  add3Dots(string, limit)
	{
	if(string != null && string != undefined){
	  var dots = "...";
	  if(string.length > limit)
	  {
	    // you can also use substr instead of substring
	    string = string.substring(0,limit) + dots;
	  }
	    return string;
	    }
	}

  throttle = 380*3;
  scrollDistance = 1;
  scrollUpDistance = 2;
	onScrollDown() {
		if(this.totalitems>this.myitems.length){
			this.page++
			this.loadpage(this.page);
		}
  }
	selecfillter(event:any, id:any = ''){
		// console.log(event);
		if(id == '' || id == 0 || id == null || id == undefined){
			this.categories.forEach(obj=>{
				obj.checked = event.target.checked;
			})
		}
		this.loadpage(1);
	}
	street(id){
		$("#ellipsis-"+id).children().toggleClass('fa fa-ellipsis-h fa fa-ellipsis-v');
		$("#street-"+id).toggle();
	}
	
	likeme(id,type,inx)
	{
		let params = {luxurypedia_id:id,status:type};
		this.dbserv.post("luxurypedialike",params).subscribe(res => {
																if(res.type=="success")
																{
																	if(type=="like")
																	{
																		$("#reclike" + id).css("display","none");
																		$("#recunlike" + id).css("display","block");
																	}
																	else if(type=="unlike")
																	{
																		$("#reclike" + id).css("display","block");
																		$("#recunlike" + id).css("display","none");
																	}
																	// this.loadpage(1);
																	this.myitems[inx].liked = res.total;
																	/*this._alert.create(res.type,res.message+type);*/
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/login') ;	
																}
																else
																	this._alert.create(res.type,res.message);
														});
	}
	saveme(id,type,inx)
	{
		let params = {articleid:id,status:type};
		this.dbserv.post("luxurybookmark",params).subscribe(res => {
																if(res.type=="success")
																{
																	if(type=="save")
																	{
																		$("#recsave" + id).css("display","none");
																		$("#recunsave" + id).css("display","block");
																	}
																	else if(type=="unsave")
																	{
																		$("#recsave" + id).css("display","block");
																		$("#recunsave" + id).css("display","none");
																	}
																	// this.loadpage(1);
																	this.myitems[inx].saved = res.total;
																	/*this._alert.create(res.type,res.message+type);*/
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/login') ;	
																}
																else
																	this._alert.create(res.type,res.message);
														});
	}
	opensharebox(id)
	{
		this.lnktimelinesharebox.nativeElement.click();
	}
			
}
