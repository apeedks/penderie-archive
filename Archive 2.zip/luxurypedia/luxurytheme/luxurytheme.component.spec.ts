import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LuxurythemeComponent } from './luxurytheme.component';

describe('LuxurythemeComponent', () => {
  let component: LuxurythemeComponent;
  let fixture: ComponentFixture<LuxurythemeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LuxurythemeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LuxurythemeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
