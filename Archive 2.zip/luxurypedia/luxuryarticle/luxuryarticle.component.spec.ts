import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LuxuryarticleComponent } from './luxuryarticle.component';

describe('LuxuryarticleComponent', () => {
  let component: LuxuryarticleComponent;
  let fixture: ComponentFixture<LuxuryarticleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LuxuryarticleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LuxuryarticleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
