import { Component, OnInit, ElementRef, ViewChild} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import { AuthenticationService } from '../../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';

@Component({
  selector: 'app-luxuryarticle',
  templateUrl: './luxuryarticle.component.html',
  styleUrls: ['./luxuryarticle.component.css']
})
export class LuxuryarticleComponent implements OnInit {
	@ViewChild('lnktimelinesharebox') lnktimelinesharebox:ElementRef;
	record = {id:0,category_id:0,title:"",gender:"",image:"",summary:"",theme:"",featured:"",tags:[],created_at:"",updated_at:"",viewed:"",active:"",category:"",articles:[],loggedin:'No',coverimage:'',likedbyme:'',savedbyme:'',liked:'',saved:''};
	visittype = '';
	rootpath = '';
	websiteroot = '';
	options:any;
	theme = 'The True Luxury';
	currtime:any;
	tagslist:any;
	latestlist:any;
	popularlist:any;
	featuredlist:any;
	articleid:number = 0;
	mysharedtype = 'Luxurypedia';
	mysharedurl = '';
	mysharedescription = '';
	mysharedtitle = '';
	mysharedimage = '';
	related = [];
	iconimage:string = '';
	iconhover:string = '';
	iconredicon:string = '';
	constructor(private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private cookieService: CookieService) {
		this.rootpath = localStorage.getItem('baseurl');
		this.visittype = localStorage.getItem('visittype');
		this.websiteroot = localStorage.getItem('basewebsiteurl');
	}
	ngOnInit() {
		this.route.params.subscribe(params => {
		    this.theme = params['theme'];
			this.articleid = params['articleid'];
			this.currtime = Math.random();
			this.dbserv.getAll("luxurytagswidget/"+this.visittype).subscribe(res => {this.tagslist = res;});	
			this.dbserv.getAll("luxurypediawidget/"+this.visittype+"/"+this.theme+"/latest").subscribe(res => {this.latestlist = res;});	
			this.dbserv.getAll("luxurypediawidget/"+this.visittype+"/"+this.theme+"/popular").subscribe(res => {this.popularlist = res;});	
			this.dbserv.getAll("luxurypediawidget/"+this.visittype+"/"+this.theme+"/featured").subscribe(res => {this.featuredlist = res;});
			this.loadpage();
		});
		scroll(0,0);
	}

	likeme(id,type)
	{
		let params = {luxurypedia_id:id,status:type};
		this.dbserv.post("luxurypedialike",params).subscribe(res => {
																if(res.type=="success")
																{
																	if(type=="like")
																	{
																		$(".reclike" + id).css("display","none");
																		$(".recunlike" + id).css("display","block");
																	}
																	else if(type=="unlike")
																	{
																		$(".reclike" + id).css("display","block");
																		$(".recunlike" + id).css("display","none");
																	}
																	// this.loadpage();
																	this.record.liked = res.total;
																	/*this._alert.create(res.type,res.message+type);*/
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/login') ;	
																}
																else
																	this._alert.create(res.type,res.message);
														});
	}
	saveme(id,type)
	{
		let params = {articleid:this.articleid,status:type};
		this.dbserv.post("luxurybookmark",params).subscribe(res => {
																if(res.type=="success")
																{
																	if(type=="save")
																	{
																		$(".recsave" + id).css("display","none");
																		$(".recunsave" + id).css("display","block");
																	}
																	else if(type=="unsave")
																	{
																		$(".recsave" + id).css("display","block");
																		$(".recunsave" + id).css("display","none");
																	}
																	this.record.saved = res.total;
																	// this.loadpage();
																	/*this._alert.create(res.type,res.message+type);*/
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/login') ;	
																}
																else
																	this._alert.create(res.type,res.message);
														});
	}
	loadpage()
	{
		this.dbserv.getById("luxurypediaartcilepub",this.articleid).subscribe(res => {
	  	this.record = res.data;
	  	this.related = res.related;
			this.mysharedescription = this.record.summary;
			this.mysharedtitle = this.record.title;
			this.dbserv.getById("luxurypedia/increase-view",this.articleid).subscribe(res => {});
			this.mysharedurl = this.websiteroot+"luxurypedia-article/"+this.theme+"/"+ this.record.id;
			if(this.record.theme != ''){
				switch (this.record.theme) {
          case ('The True Luxury'):
            this.iconimage ='assets/img/head-icon1.png';
            this.iconhover ='assets/img/img-r1.png';
            this.iconredicon ='assets/img/img-inn-4.png';
            break;
          case ('Fine Material'):
            this.iconimage ='assets/img/head-icon1.png';
            this.iconhover ='assets/img/img-r1.png';
            this.iconredicon ='assets/img/img-inn4.png';
            break;
          case ('Superior Craftsmanship'):
            this.iconimage ='assets/img/head-icon2.png';
            this.iconhover ='assets/img/img-r2.png';
            this.iconredicon ='assets/img/img-inn3.png';
            break;
          case ('Art of Styling'):
            this.iconimage ='assets/img/head-icon3.png';
            this.iconhover ='assets/img/img-r3.png';
            this.iconredicon ='assets/img/img-inn2.png';
            break;
          case ('Balanced Living'):
            this.iconimage ='assets/img/head-icon4.png';
            this.iconhover ='assets/img/img-r4.png';
            this.iconredicon ='assets/img/img-inn1.png';
            break;
      	}
	    }
		});	
	}
	opensharebox(id)
	{
		this.lnktimelinesharebox.nativeElement.click();
	}
	alphabetswitch(chr)
	{
			
	}
	tagswitch(tag)
	{
			
	}
	scrollUp(id)
	{
			$('html, body').animate({
        	scrollTop: $("#"+this.slug(id)).offset().top - 95
    	}, 2000);
	}
	  	slug(str) {
	    var $slug = '';
	    var trimmed = $.trim(str);
	    $slug = trimmed.replace(/[^a-z0-9-]/gi, '-').
	    replace(/-+/g, '-').
	    replace(/^-|-$/g, '');
	    return $slug.toLowerCase();
	}
	  add3Dots(string, limit)
	{
	if(string != null && string != undefined){
	  var dots = "...";
	  if(string.length > limit)
	  {
	    // you can also use substr instead of substring
	    string = string.substring(0,limit) + dots;
	  }
	    return string;
	    }
	}
}
