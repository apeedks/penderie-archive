import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../services/dbservice.service';
import { Meta,Title} from '@angular/platform-browser';

@Component({
  selector: 'app-knowledge',
  templateUrl: './knowledge.component.html',
  styleUrls: ['./knowledge.component.css']
})
export class KnowledgeComponent implements OnInit {
	type = 'Member';
	knowledge_slug = '';
	constructor(private dbserv:DbserviceService,private route: ActivatedRoute,private router: Router,private meta: Meta, private titleService: Title) 
	{ 
		this.route.params.subscribe(params => {
			this.type = params['type'];
			this.knowledge_slug = this.type.toLowerCase().replace(' ','_');
		});
	}
	
	ngOnInit() {
		scroll(0,0);
	}

}
