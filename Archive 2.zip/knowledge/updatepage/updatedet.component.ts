import { Component, OnInit, ElementRef, ViewChild} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import { AuthenticationService } from '../../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';

@Component({
  selector: 'app-updatedet',
  templateUrl: './updatedet.component.html',
  styleUrls: ['./updatedet.component.css']
})
export class UpdatedetComponent implements OnInit {
	@ViewChild('lnktimelinesharebox') lnktimelinesharebox:ElementRef;
	record = {id:0,image:"",title:"",content:'',updated_at:''};
	storieslist:any;
	stroyid = 0;
	loggedin="No";
	pageurl = '';
	visittype = '';
	rootpath = '';
    tagslist:any;
	websiteroot = '';
	currtime:any;
	userid = 0;
	userimage = '';
	comment = '';
	options:any;
	pageSize: number;
	totalitems:number;
	last_page:number = 1;
	page: number = 1;
	limit:number = 5;
	public items = [];
	mysharedstoryid: number =1;
	mysharedtype = 'Story';
	mysharedurl = '';
	mysharedescription = '';
	mysharedtitle = '';
	mysharedimage = '';
	type = 'Member';
    knowledge_slug = '';
	constructor(private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private cookieService: CookieService) { 
		this.rootpath = localStorage.getItem('baseurl');
		this.visittype = localStorage.getItem('visittype');
		this.websiteroot = localStorage.getItem('basewebsiteurl');
		if(this.authserv.isloggedin())
		{
			this.userid = +this.authserv.getUserId();
			this.userimage = this.authserv.getUserImage();
		}
		this.route.params.subscribe(params => {
            this.type = params['type'];
            this.knowledge_slug = this.type.toLowerCase().replace(' ','_');
        });
	}

	loadpage()
	{
		this.currtime = Math.random();
		this.dbserv.getById("webupdatedel",this.stroyid).subscribe(res => {
																		if(res.type=="success")
																		{
																			this.record = res.data;
																			this.mysharedstoryid = this.record.id;
																			this.mysharedescription = this.record.content;
																			this.mysharedtitle = this.record.title;
//																			this.mysharedimage = this.rootpath+'assets/stories/' + this.record.image+'?random+\='+this.currtime;
																			this.mysharedurl = this.websiteroot+"story/"+ this.record.id;
																		}
																	});
	}
	ngOnInit() {
//        this.dbserv.getAll("storieswidget/"+this.visittype+"/All").subscribe(res => {this.tagslist = res;});
//		this.dbserv.getAll("storieswidget/"+this.visittype+"/All").subscribe(res => {this.storieslist = res;});	
		this.route.params.subscribe(params => {
		    this.stroyid = params['updateid'];
		this.loadpage();
		});
//		scroll(0,0);
		if (this.authserv.isloggedin()) {
			this.loggedin = "Yes";
		}
	}
        add3Dots(string, limit)
    {
      var dots = "...";
      if(string.length > limit)
      {
        // you can also use substr instead of substring
        string = string.substring(0,limit) + dots;
      }
        return string;
    }
        sortswitch()
    {
        $('html, body').animate({
            scrollTop: $("#scrollUp").offset().top - 95
        }, 2000);
        this.items = [];
        this.loadpage();
	}
}
