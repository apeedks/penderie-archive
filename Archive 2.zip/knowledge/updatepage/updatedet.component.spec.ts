import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatedetComponent } from './updatedet.component';

describe('UpdatedetComponent', () => {
  let component: UpdatedetComponent;
  let fixture: ComponentFixture<UpdatedetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatedetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatedetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
