import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import { Meta,Title} from '@angular/platform-browser';
import $ from 'jquery';

@Component({
  selector: 'app-tutorials',
  templateUrl: './tutorials.component.html',
  styleUrls: ['./tutorials.component.css']
})
export class TutorialsComponent implements OnInit {
	type = 'Member';
	knowledge_slug = '';
	cattitle = '';
	currentgender:string = 'Women';
	public items = [];
	defaultid = 0;
	searchfield = '';
	pageSize: number;
	totalitems: any;
	page: number = 1;
	last_page: number =1;
	categories = [];
	constructor(private dbserv:DbserviceService,private route: ActivatedRoute,private router: Router,private meta: Meta, private titleService: Title) {
		this.currentgender = localStorage.getItem('visittype');
		this.route.params.subscribe(params => {
			this.type = params['type'];
			this.knowledge_slug = this.type.toLowerCase().replace(' ','_');
		});
	}
	showsubmenu(menuid)
	{
		$(".childmenulist").css("display","none");
		$("#submenu" + menuid).css("display","block");
	}
	
	switchcat(id)
	{
		this.defaultid = id;
		this.loadvideos(1);
	}
	loadvideos(pageno)
	{
		let model = {srhfield:this.searchfield};
		
		this.dbserv.getAll("knowledgecat/"+this.defaultid).subscribe(res => { 
																	 if(res.type=='success')
																	 	this.cattitle = res.data.title;
																	});	
		
		this.dbserv.post("publictutorials/"+this.defaultid+"/"+pageno+"/12",model).subscribe(res => {
																			this.items = res.data; 
																			this.page = res.current_page; 
																			this.totalitems = res.total;
																			this.pageSize = res.per_page;
																			this.last_page = res.last_page;
																		}); 
	}
	ngOnInit() {
		this.dbserv.getAll("fronttutcatlist/"+this.currentgender+"/Tutorial/"+this.type).subscribe(res => {this.categories= res.data;this.defaultid=res.defaultid;this.switchcat(this.defaultid);});	
	}

}
