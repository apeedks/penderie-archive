import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import { Meta,Title} from '@angular/platform-browser';
import $ from 'jquery';
@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FaqComponent implements OnInit {
	type = 'Member';
	knowledge_slug = '';
	searchfield = '';
	currentgender:string = 'Women';
	public items = [];
	constructor(private dbserv:DbserviceService,private route: ActivatedRoute,private router: Router,private meta: Meta, private titleService: Title) {
		this.currentgender = localStorage.getItem('visittype');
		this.route.params.subscribe(params => {
			this.type = params['type'];
			this.knowledge_slug = this.type.toLowerCase().replace(' ','_');
		});
	}
	
	ngOnInit() {
		this.loadpage();
	}
	loadpage()
	{
		let model = {srhfield:this.searchfield};
		this.dbserv.post("faqs/"+this.currentgender+"/"+this.type,model).subscribe(res => {
													this.items=res.data;
												});
	}
	showarticle(id)
	{
		if($("#faqcontentitem"+id).css("display") == "block"){
		    $("#faqcontentitem"+id).css("display","none");
		}else{
		    $(".faqcontentitems").css("display","none");
		    $("#faqcontentitem"+id).css("display","block");
		}
	}
}
