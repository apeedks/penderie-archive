import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import { Meta,Title} from '@angular/platform-browser';

import $ from 'jquery';
@Component({
  selector: 'app-updates',
  templateUrl: './updates_changes.component.html',
  styleUrls: ['./updates.component.css']
})
export class UpdatesComponent implements OnInit {
	

	//fiter
	wasClicked:boolean = false;
	custo_filter_onen_close = false;
	visiblefilter = false;
  	type = 'Member';
	knowledge_slug = '';
	monthText:string;
	yearText:number;
	pageSize: number;
	totalitems: any;
	page: number = 1;
	limit: number = 5;
	last_page: number = 1;
	currentgender:string = 'Women';
	apiurl:string;
	public items = [];
	constructor(private dbserv:DbserviceService,private route: ActivatedRoute,private router: Router,private meta: Meta, private titleService: Title) {
		this.currentgender = localStorage.getItem('visittype');
		this.route.params.subscribe(params => {
			this.type = params['type'];
			this.knowledge_slug = this.type.toLowerCase().replace(' ','_');
		});
	}
	showmorerecs()
	{
		this.page = this.page + 1;
		/*alert(this.last_page +"-"+ this.page);*/
		this.loadpage(this.page);	
	}
	loadpage(pageno)
	{
		let model = {
			year:this.yearText,
			month:(this.monthShorNames.indexOf(this.monthText) + 1)
		};
		this.dbserv.post("webupdate/"+this.currentgender+"/"+this.type+"/"+pageno+"/"+this.limit,model)
		.subscribe(res => {
			console.log(res.data);
			// this.items= [ ...this.items, ...res.data];
			this.items= res.data;
			this.page = res.current_page; 
			this.totalitems = res.total;
			this.pageSize = res.per_page;
			this.last_page = res.last_page;
		});	
	}
	monthNames = [
		"January", "February", "March",
		"April", "May", "June",
		"July", "August", "September",
		"October", "November", "December"
	];
	monthShorNames = [
		"Jan", "Feb", "Mar","Apr", "May", "Jun",
		"Jul", "Aug", "Sep","Oct", "Nov", "Dec"
	];

	getMonthName(date) {
		return this.monthNames[date.getMonth()];
	}
	getShortMonthName(date) {
		return this.getMonthName(date).substr(0, 3);
	};

	ngOnInit() {
		this.apiurl = localStorage.getItem('apiurl');
		let today = new Date();
		this.monthText = this.getShortMonthName(today);
		console.log(this.monthText);
		this.yearText = today.getFullYear();
		this.loadpage(this.page);
		scroll(0,0);
	}
	showarticle(id)
	{
		$(".faqcontentitems").css("display","none");
		$("#faqcontentitem"+id).css("display","block");
	}

	filterby()
		{
			this.wasClicked = !this.wasClicked;
			if(this.wasClicked)
			{
				this.custo_filter_onen_close = true;
				this.visiblefilter = true;
				
			}
			else
			{
				this.custo_filter_onen_close = false;	
				this.visiblefilter = false;	
			}

		}
    srting = 'Lorem Ipsum is simply dummy text of the printing and type setting industry. Lorem Ipsum is simply dummy text of the printing and type setting industry.';
	add3Dots(string, limit)
	{
	  var dots = "...";
	  if(string.length > limit)
	  {
	    // you can also use substr instead of substring
	    string = string.substring(0,limit) + dots;
	  }

	    return string;
	}
}

