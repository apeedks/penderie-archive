import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import { Meta,Title} from '@angular/platform-browser';
import $ from 'jquery';

@Component({
  selector: 'app-documentation',
  templateUrl: './documentation.component.html',
  styleUrls: ['./documentation.component.css']
})
export class DocumentationComponent implements OnInit {
	record = {id:0,category_id:0,title:"",content:"",sortorder:0,created_at:"",updated_at:"",active:""};
	type = 'Member';
	knowledge_slug = '';
	currentgender:string = 'Women';
	defaultid = 0;
	searchfield:'';
	public items = [];
	categories = [];
	constructor(private dbserv:DbserviceService,private route: ActivatedRoute,private router: Router,private meta: Meta, private titleService: Title) {
		this.currentgender = localStorage.getItem('visittype');
		this.route.params.subscribe(params => {
			this.type = params['type'];
			this.knowledge_slug = this.type.toLowerCase().replace(' ','_');
		});
	}
	loadarticle(id:number)
	{
		console.log(id);
		this.dbserv.getById("getfrontbyid",id)
		.subscribe(res => {
			console.log(res);
			this.record= res.data;
		});
	}
	loadpage()
	{

	}
	showsubcats(submenuid)
	{
		$(".secondlevelitems").css("display","none");
		$("#secondlevel" + submenuid).css("display","block");	
	}
	showmaincats(id)
	{
		$(".firstlevelitems").css("display","none");
		$("#firstlevel" + id).css("display","block");
	}
	ngOnInit() {
		this.dbserv.getAll("frontdoccatlist/"+this.currentgender+"/Documentation/"+this.type)
		.subscribe(res => {
			this.categories= res.data;
			this.defaultid = res.defaultid;
			this.loadarticle(this.defaultid);
		});	
		scroll(0,0);
	}

}
