import { Component, OnInit } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { AuthenticationService } from '../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import {AlertsService} from '@jaspero/ng2-alerts';
import { TranslateService } from '../translate';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotPasswordComponent implements OnInit {
	model={email:'',active:''};
	options:any;
    userid:number;
  
  successMsg='';
  errorMsg='';
  uploadedimagebtn:boolean=false;
  uploadedimagebtnUsername:boolean=false;
	constructor(private _translate: TranslateService,private route: ActivatedRoute,private router: Router,private authserv: AuthenticationService,private _alert: AlertsService,private cookieService: CookieService) { 
		this.userid = this.authserv.getUserId();
		if(this.userid>0)
		{
			this.authserv.logout();
		}
	}
	
	ngOnInit() {
		this.userid = this.authserv.getUserId();
		if(this.userid>0)
		{
			this.router.navigate(['myaccount']);
		}
	}

  saveforgotaction(active){
    this.model.active = active;
  }

	forgotpassword(){
    if (this.model.active == 'username') {
      this.saveforgotusername();
    } else {
      this.saveforgotpassword();
    }
	}

  saveforgotpassword(){
    this.uploadedimagebtn = true;
    this.authserv.forgotpassword(this.model.email)
      .subscribe(data => {
        if (data.type == "success")
        {
          this._alert.create('success',this._translate.instant(data.message));
          this.successMsg = data.message;
          this.errorMsg = '';
        }else{
          this._alert.create('error',this._translate.instant(data.message));
          this.errorMsg = data.message;
          this.successMsg = '';
        }
        this.uploadedimagebtn = false;
      });
  }

  saveforgotusername()
  {
    this.uploadedimagebtnUsername = true;
    this.authserv.forgotusername(this.model.email)
      .subscribe(data => {
        if (data.type == "success")
        {
          this._alert.create('success',this._translate.instant(data.message));
          this.successMsg = data.message;
          this.errorMsg = '';
        }else{
          this._alert.create('error',this._translate.instant(data.message));
          this.errorMsg = data.message;
          this.successMsg = '';
        }
        this.uploadedimagebtnUsername = false;
      });
  }
}
