import { Component, OnInit } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { AuthenticationService } from '../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import {AlertsService} from '@jaspero/ng2-alerts';
import { TranslateService } from '../translate';

@Component({
  selector: 'app-forgotusername',
  templateUrl: './forgotusername.component.html',
  styleUrls: ['./forgotusername.component.css']
})
export class ForgotUsernameComponent implements OnInit {
	model={email:'',password:''}
	options:any;
  userid:number;
  
  successMsg='';
  errorMsg='';

	constructor(private _translate: TranslateService,private route: ActivatedRoute,private router: Router,private authserv: AuthenticationService,private _alert: AlertsService,private cookieService: CookieService) { 
		this.userid = this.authserv.getUserId();
		if(this.userid>0)
		{
			this.authserv.logout();
		}
	}
	
	ngOnInit() {
		this.userid = this.authserv.getUserId();
		if(this.userid>0)
		{
			this.router.navigate(['myaccount']);
		}
	}
	forgotusername()
	{
    this.authserv.forgotusername(this.model.email)
      .subscribe(data => {
        if (data.type == "success")
        {
          this._alert.create('success',this._translate.instant(data.message));
          this.successMsg = data.message;
          this.errorMsg = '';
        }else{
          this._alert.create('error',this._translate.instant(data.message));
          this.errorMsg = data.message;
          this.successMsg = '';
        }
      },
      error => {
        /*this._alert.create('error',this._translate.instant('Invalid login credentials.'));*/
      });
	}
}
