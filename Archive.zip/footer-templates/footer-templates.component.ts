import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-templates',
  templateUrl: './footer-templates.component.html',
  styleUrls: ['./footer-templates.component.css']
})
export class FooterTemplatesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
