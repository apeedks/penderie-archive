import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fine-material',
  templateUrl: './fine-material.component.html',
  styleUrls: ['./fine-material.component.css']
})
export class FineMaterialComponent implements OnInit {
  visittype = '';
  constructor() { 
      this.visittype = localStorage.getItem('visittype');
  }

  ngOnInit() {
  }

}
