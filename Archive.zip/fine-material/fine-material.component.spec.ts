import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FineMaterialComponent } from './fine-material.component';

describe('FineMaterialComponent', () => {
  let component: FineMaterialComponent;
  let fixture: ComponentFixture<FineMaterialComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FineMaterialComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FineMaterialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
