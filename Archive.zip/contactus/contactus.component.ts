import { Component, OnInit } from '@angular/core';
import {DbserviceService} from '../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styles: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {
	model={name:'',email:'',subject:'',description:''}
	options:any;
	constructor(private dbserv:DbserviceService, private _alert:AlertsService) { }
	
	ngOnInit() {
		
	}
	submitfunc()
	{
		this.dbserv.save("contactus",this.model).subscribe(res => {
										this._alert.create(res.type,res.message);
									 }); 
	}
}
