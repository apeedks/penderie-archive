import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-artofstyleing',
  templateUrl: './artofstyleing.component.html',
  styleUrls: ['./artofstyleing.component.css']
})
export class ArtofstyleingComponent implements OnInit {
    visittype = '';
	constructor() {  this.visittype = localStorage.getItem('visittype');
	}
	
	ngOnInit() {
	}

}
