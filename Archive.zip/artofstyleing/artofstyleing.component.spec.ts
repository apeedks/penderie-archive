import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArtofstyleingComponent } from './artofstyleing.component';

describe('ArtofstyleingComponent', () => {
  let component: ArtofstyleingComponent;
  let fixture: ComponentFixture<ArtofstyleingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArtofstyleingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArtofstyleingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
