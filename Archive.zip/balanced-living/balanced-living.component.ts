import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-balanced-living',
  templateUrl: './balanced-living.component.html',
  styleUrls: ['./balanced-living.component.css']
})
export class BalancedLivingComponent implements OnInit {

    visittype = '';
    constructor() {  this.visittype = localStorage.getItem('visittype');
    }

  ngOnInit() {
  }

}
