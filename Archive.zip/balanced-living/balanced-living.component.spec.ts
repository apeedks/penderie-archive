import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BalancedLivingComponent } from './balanced-living.component';

describe('BalancedLivingComponent', () => {
  let component: BalancedLivingComponent;
  let fixture: ComponentFixture<BalancedLivingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BalancedLivingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BalancedLivingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
