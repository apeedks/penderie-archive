import { Injectable } from '@angular/core';
import {Response} from '@angular/http';
import { Router, CanActivate, CanActivateChild, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from './services/authentication.service';
import { User } from './_models/user';
@Injectable()
export class AdminAuthGuard implements CanActivate,CanActivateChild {
   myuser: User;
  constructor(private router: Router,private authserv: AuthenticationService) { }
  
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | boolean {
	  
		return this.authserv.session().map((response: Response) =>  {
			let user:User;
			user = response.json();
			
			if (user.usertype =='Admin') {
				localStorage.setItem('user', JSON.stringify(user));
                return true;
            }
			else
			{
				return false;
			
			}
        }).catch((err: Response) => {
			this.router.navigateByUrl('/admin/login') ;
			return Observable.throw('Unauthorized');
        });
		
		/*return this.authserv.adminsession().subscribe(response => {
					let user:User;
					user = response;
					if (user.usertype !='Admin') {
						this.router.navigateByUrl('/admin/login') ;
					}
					return true;
				}, (err) => {
					console.log(err);
					if (err === 'Unauthorized') { this.router.navigateByUrl('/admin/login') ; return false;};
				});*/
		
		/**if (localStorage.getItem('currentUser')) {
            // logged in so return true
            return true;
        }

        // not logged in so redirect to login page with the return url
        //this.router.navigate(['/admin/login']);
        return false;*/
  }
  canActivateChild(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
     return this.authserv.session().map((response: Response) =>  {
			let user:User;
			user = response.json();
			
			if (user.usertype =='Admin') {
				localStorage.setItem('user', JSON.stringify(user));
                return true;
            }
			else
			{
				return false;
			
			}
        }).catch((err: Response) => {
			this.router.navigateByUrl('/admin/login') ;
			return Observable.throw('Unauthorized');
        });

  }
}
