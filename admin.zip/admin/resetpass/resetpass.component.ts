import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';

@Component({
  selector: 'app-resetpass',
  templateUrl: './resetpass.component.html',
  styleUrls: ['../nav/adminheader.component.css']
})
export class ResetpassComponent implements OnInit {
	options:any;
	loading:boolean=false;
	constructor(private route: ActivatedRoute,
        private router: Router,private _alert: AlertsService,private dbserv:DbserviceService) { }
	
	ngOnInit() {
		this.route.params.subscribe(params => {
		    this.model.resettoken = params['resettoken']; // (+) converts string 'id' to a number
		});
	}
	
	model = {password: '',resettoken: ""};

	resetpassword()
	{
		this.dbserv.save("resetadminpassword",this.model).subscribe(res => {
															  
															   this._alert.create(res.type,res.message);
															   if(res.type=="success")
															   {
															    	this.model = {password: '',resettoken: ""};
															   }
															 }); 
	}
}
