import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../services/authentication.service';

import { Router, ActivatedRoute } from '@angular/router';
import { User } from '../_models/user';
import { fadeInAnimation } from '../services/animatations';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  animations: [fadeInAnimation],
  styleUrls: ['../nav/adminheader.component.css']
})
export class DashboardComponent implements OnInit {
	 returnUrl: string;
	
  constructor(
		private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService) { }

  ngOnInit() {
	  this.returnUrl = localStorage.getItem('currentUser');
  }

}
