import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
@Component({
  selector: 'app-cms',
  templateUrl: './cms.component.html',
  styleUrls: ['../nav/adminheader.component.css']
})
export class CmsComponent implements OnInit {
	model = {id:0, title: '',content: "",menulink:"",menutext:"",template:"",paccess:"",gender:"",section: "",linkpos: "",currentlist:"",active: ""};
	options:any;
	pageSize: number;
	totalitems: any;
	page: number = 1;
	public items:Object;
	public errormsg = '';
	sections:any;
	isshowform = false;
	currentlist:string = 'Both';
	constructor(private dbserv:DbserviceService,private _alert: AlertsService) { 
	
	}
	loadtemplate()
	{
		this.dbserv.getAll("gettemplates/contents").subscribe(res => {this.sections = res;}); 
	}
	ngOnInit() {
		this.loadpage(this.page);
		this.loadtemplate();
	}
	
	loadpage(pageno)
	{
		this.dbserv.getAll("contents/"+this.currentlist+"/"+pageno).subscribe(res => {this.items = res.data; this.page = res.current_page; this.totalitems = res.total;this.pageSize = res.per_page;}); 
		this.isshowform = false;
	}
	switchcurrentlist(type:string)
	{
		this.currentlist = type;
		this.loadpage(this.page);
	}
	pageChanged($event)
	{
	  this.loadpage($event) ; 
	}
	hideform()
	{
		this.isshowform = false;
	}
	editrecord(id)
	{
		this.isshowform = true;
		this.dbserv.getById("content",id).subscribe(res => {
													if(res.type=="success")
														this.model=res.data;
													else
														this._alert.create(res.type,res.message);
													});
		
	}
	deleterecord(id)
	{
		this.isshowform = false;
		this.dbserv.delete("contentdel", id).subscribe(res => { this._alert.create(res.type,res.message);this.loadpage(this.page);});
		
	}
	templatechanged()
	{
		for(var i = 0;i<this.sections.length;i++) { 
			if(this.model.template==this.sections[i].id)
		     	this.model.content = this.sections[i].content; 
		}
		
	}
	changevalue(type:string)
	{
		this.model.active = type;
	}
	saverecord()
	{

		this.dbserv.save("contentsave",this.model).subscribe(res => {
															  
															   this._alert.create(res.type,res.message);
															   if(res.type=="success")
															   {
															    	this.model = {id:0, title: '',content: "",menulink:"",menutext:"",template:"",paccess:"",gender:"",section: "",linkpos: "",currentlist:"",active: ""};
																	this.loadpage(this.page);
																	this.isshowform = false;
															   }
															 }); 
		
		
		
	}
	addrecord()
	{
		this.model = {id:0, title: '',content: "",menulink:"",menutext:"",template:"",paccess:"",gender:"",section: "",linkpos: "",currentlist:"",active: ""};
		this.isshowform = true;
		
	}
}
