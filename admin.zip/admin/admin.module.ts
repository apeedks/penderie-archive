import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule }    from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppRoutingModule } from './admin-routing';
import {AdminAuthGuard} from './admin.auth.guard';
import { LoginComponent } from './login/login.component';
import { AuthenticationService } from './services/authentication.service';
import { AdminfooterComponent } from './nav/adminfooter.component';
import { AdminheaderComponent } from './nav/adminheader.component';
import { AdminnavComponent } from './nav/adminnav.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UsersComponent } from './users/users.component';
import { CmsComponent } from './cms/cms.component';
import { DbserviceService } from './services/dbservice.service';
import {NgxPaginationModule} from 'ngx-pagination';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PasswordComponent } from './password/password.component';
import { CKEditorModule } from 'ng2-ckeditor';
import { JasperoAlertsModule } from '@jaspero/ng2-alerts';
import { TemplatesComponent } from './templates/templates.component';
import { GalleriesComponent } from './media/galleries/galleries.component';
import { EmailsComponent } from './contents/emails/emails.component';
import { ResetpassComponent } from './resetpass/resetpass.component';
import { CommerceComponent } from './commerce/commerce.component';
import { AdmincommnavComponent } from './commerce/admincommnav/admincommnav.component';
import { DesignercommerceComponent } from './commerce/designercommerce/designercommerce.component';
import { ContentsComponent } from './contents/contents.component';
import { AdmincontnavComponent } from './contents/admincontnav/admincontnav.component';
import { PagesComponent } from './contents/pages/pages.component';
import { PagesTabsComponent } from './contents/pages//pagestabs/pagestabs.component';
import {PagesTabsSectionsComponent} from './contents/pages/pagestabs/pagessection/pagessection.component';
import { DataTableModule } from 'angular-4-data-table/src/index';
import { ThemetemplateComponent } from './contents/pages/themetemplate/themetemplate.component';
import { AdminusernavComponent } from './users/adminusernav/adminusernav.component';
import { AdminmedianavComponent } from './media/adminmedianav/adminmedianav.component';
import { AdmincomunitynavComponent } from './community/admincomunitynav/admincomunitynav.component';
import { CommunityComponent } from './community/community.component';
import { MediaComponent } from './media/media.component';
import { TimelineComponent } from './timeline/timeline.component';
import { AdmintimelinenavComponent } from './timeline/admintimelinenav/admintimelinenav.component';
import { AdsComponent } from './ads/ads.component';

import { SystemComponent } from './system/system.component';
import { Adminsystemnav } from './system/adminsystemnav/adminsystemnav.component';
// import { SystememailComponent } from './system/email/email.component';
// import { SystemchatComponent } from './system/chat/chat.component';
// import { SystemsystemComponent } from './system/system/system.component';

import { CommunicationComponent } from './communication/communication.component';
import { Admincommunicationnav } from './communication/admincommunicationnav/admincommunicationnav.component';
import { SystememailComponent } from './communication/email/email.component';
import { SystemchatComponent } from './communication/chat/chat.component';
import { Com_SystemsystemComponent } from './communication/system/com_system.component';

import { SettingsComponent } from './settings/settings.component';
import { UielementsComponent } from './uielements/uielements.component';
import { TemplatesectionsComponent } from './contents/pages/templatesections/templatesections.component';
import { PagetemplatesComponent } from './contents/pages/pagetemplates/pagetemplates.component';
import { AdminsetngnavComponent } from './settings/adminsetngnav/adminsetngnav.component';
import { GenderswitchComponent } from './nav/genderswitch.component';
import { ProfilepointsComponent } from './settings/profilepoints/profilepoints.component';
import { MembersComponent } from './users/members/members.component';
import {FaqsComponent} from './contents/knowledge/faqs/faqs.component';
import { GroupsnforumsComponent } from './community/groupsnforums/groupsnforums.component';
import { GroupsComponent } from './community/groupsnforums/groups/groups.component';
import { ForumsComponent } from './community/groupsnforums/forums/forums.component';
import { CategoriesComponent } from './commerce/designercommerce/categories/categories.component';
import { BrandsComponent } from './commerce/designercommerce/brands/brands.component';
import { SellercommerceComponent } from './commerce/sellercommerce/sellercommerce.component';
import { TypesComponent } from './commerce/sellercommerce/types/types.component';
import { McategoriesComponent } from './commerce/sellercommerce/mcategories/mcategories.component';
import { SourcesComponent } from './settings/sources/sources.component';
import { KnowledgeComponent } from './contents/knowledge/knowledge.component';
import { DocumentationComponent } from './contents/knowledge/documentation/documentation.component';
import { TutorialsComponent } from './contents/knowledge/tutorials/tutorials.component';
import { UpdatesComponent } from './contents/knowledge/updates/updates.component';
import { SuboptgroupsComponent } from './contents/knowledge/suboptgroups/suboptgroups.component';
import { AdminemailsComponent } from './contents/emails/adminemails/adminemails.component';
import { MemprofileComponent } from './users/members/memprofile/memprofile.component';
import { MemclubsComponent } from './users/members/memclubs/memclubs.component';
import { MemprefsComponent } from './users/members/memprefs/memprefs.component';
import { MeminboxComponent } from './users/members/meminbox/meminbox.component';
import { MemactivityComponent } from './users/members/memactivity/memactivity.component';
import { LuxurypediaComponent } from './contents/luxurypedia/luxurypedia.component';
import { ArticlesComponent } from './contents/luxurypedia/articles/articles.component';
import { ArticledetComponent } from './contents/luxurypedia/articledet/articledet.component';
import { LuxurytagsComponent } from './contents/luxurypedia/luxurytags/luxurytags.component';
import { CatdropdownComponent } from './catdropdown/catdropdown.component';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import { StoriesComponent } from './contents/stories/stories.component';
import { StorycatsComponent } from './contents/stories/storycats/storycats.component';
import { StorytagsComponent } from './contents/stories/storytags/storytags.component';
import { SlidersComponent } from './media/sliders/sliders.component';
import { DefaultfoldersComponent } from './media/defaultfolders/defaultfolders.component';
import { CustomfoldersComponent } from './media/customfolders/customfolders.component';
import { FotodiaryComponent } from './media/fotodiary/fotodiary.component';
import { CollectionComponent } from './media/collection/collection.component';
import { CatalogueComponent } from './media/catalogue/catalogue.component';
import { PortfolioComponent } from './media/portfolio/portfolio.component';
import { TreeModule } from 'angular-tree-component';
import { LoupeComponent } from './contents/loupe/loupe.component';
import { LoupecatsComponent } from './contents/loupe/loupecats/loupecats.component';
import { LoupetagsComponent } from './contents/loupe/loupetags/loupetags.component';
import { LoupebrandsComponent } from './contents/loupe/loupebrands/loupebrands.component';
import { LoupemarkersComponent } from './contents/loupe/loupemarkers/loupemarkers.component';
import { SecureurlPipe } from './secureurl.pipe';
import { ProfileComponent } from './profile/profile.component';
import { ImageCropperModule } from 'ng2-img-cropper';
import { EmployeesComponent } from './users/employees/employees.component';
import { AdminsComponent } from './users/admins/admins.component';
import { MagazinesComponent } from './contents/magazines/magazines.component';
import { MagazinecatsComponent } from './contents/magazines/magazinecats/magazinecats.component';
import { MagazinetagsComponent } from './contents/magazines/magazinetags/magazinetags.component';
import { CkEditorComponent } from './ckeditor.component';
import { ThemeFilterComponent } from './themefilter.component';
import { GenderFilterComponent } from './genderfilter.component';
import { AccountFilterComponent } from './accountfilter.component';
import { StatusFilterComponent } from './statusfilter.component';
import { StatusCategoryFilterComponent } from './statuscategoryfilter.component';
import { FeatureFilterComponent } from './featurefilter.component';
import { StatusStoriesFilterComponent } from './statusstoriesfilter.component';
import { LoupeStatusFilterComponent } from './loupestatusfilter.component';
import { LoupeCatStatusFilterComponent } from './loupecatstatusfilter.component';
import { LoupeServiceFilterComponent } from './loupeservicefilter.component';
import { LoupeCatServiceFilterComponent } from './loupecatservicefilter.component';
import { EmojiPickerModule } from 'angular2-emoji-picker';
import { limitToPipe } from './pipe/limit.pipe';
import { MyDatePickerModule } from 'mydatepicker';
import { UniquePipe } from './unique.pipe';
import { Unique1Pipe } from './unique1.pipe';
import { DateFormatPipe } from './dateformat.pipe';
import { TooltipModule } from "ngx-tooltip";

@NgModule({
  imports: [
    BrowserModule,
	FormsModule,
	HttpModule,
	CommonModule,
	AppRoutingModule,
	ImageCropperModule,
	NgxPaginationModule,
	BrowserAnimationsModule, 
	JasperoAlertsModule,
	CKEditorModule,
	AngularMultiSelectModule,
	DataTableModule,
	TreeModule,
	MyDatePickerModule,
	EmojiPickerModule.forRoot(),
	TooltipModule,
  ],
  declarations: [
				 DashboardComponent,
				 LoginComponent,
				 AdminfooterComponent,
				 AdminheaderComponent,
				 AdminnavComponent, 
				 UsersComponent, 
				 CmsComponent, 
				 PasswordComponent, 
				 TemplatesComponent, 
				 GalleriesComponent, 
				 EmailsComponent, 
				 ResetpassComponent, 
				 CommerceComponent, 
				 AdmincommnavComponent, 
				 DesignercommerceComponent, 
				 ContentsComponent, 
				 AdmincontnavComponent, 
				 PagesComponent, 
				 PagesTabsComponent, 
				 PagesTabsSectionsComponent, 
				 FaqsComponent,
				 McategoriesComponent,
				 ThemetemplateComponent, 
				 AdminusernavComponent, 
				 AdminmedianavComponent, 
				 AdmincomunitynavComponent, 
				 CommunityComponent, 
				 MediaComponent, 
				 TimelineComponent, 
				 AdmintimelinenavComponent, 
				 AdsComponent, 
				 SystemComponent, 
				 CommunicationComponent,
				 Admincommunicationnav,
				 Adminsystemnav,
				 SystememailComponent,
				 SystemchatComponent,
				 Com_SystemsystemComponent,
				 //SystemsystemComponent,
				 SettingsComponent, 
				 UielementsComponent, 
				 TemplatesectionsComponent, 
				 PagetemplatesComponent, 
				 AdminsetngnavComponent, 
				 GenderswitchComponent, 
				 ProfilepointsComponent, 
				 MembersComponent, 
				 GroupsnforumsComponent, 
				 GroupsComponent, 
				 ForumsComponent, 
				 CategoriesComponent, 
				 BrandsComponent, 
				 SellercommerceComponent, 
				 TypesComponent, 
				 SourcesComponent, 
				 KnowledgeComponent, 
				 DocumentationComponent, 
				 TutorialsComponent, 
				 UpdatesComponent, 
				 SuboptgroupsComponent, 
				 AdminemailsComponent, 
				 MemprofileComponent, 
				 MemclubsComponent, 
				 MemprefsComponent, 
				 MeminboxComponent, 
				 MemactivityComponent, 
				 LuxurypediaComponent, 
				 ArticlesComponent, 
				 ArticledetComponent, 
				 LuxurytagsComponent, 
				 CatdropdownComponent, 
				 StoriesComponent, 
				 StorycatsComponent,
				 MagazinecatsComponent,
				 StorytagsComponent, 
				 SlidersComponent, 
				 DefaultfoldersComponent, 
				 CustomfoldersComponent, 
				 FotodiaryComponent, 
				 CollectionComponent, 
				 CatalogueComponent, 
				 PortfolioComponent, 
				 LoupeComponent,
				 LoupecatsComponent,
				 LoupetagsComponent,
				 LoupebrandsComponent,
				 SecureurlPipe,
				 UniquePipe,
				 Unique1Pipe,
				 DateFormatPipe,
				 LoupeStatusFilterComponent,
				 LoupeServiceFilterComponent,
				 LoupeCatStatusFilterComponent,
				 LoupeCatServiceFilterComponent,
				 ProfileComponent, EmployeesComponent, AdminsComponent, MagazinesComponent, MagazinetagsComponent, CkEditorComponent,
	ThemeFilterComponent,GenderFilterComponent,AccountFilterComponent,StatusFilterComponent,StatusCategoryFilterComponent,FeatureFilterComponent,StatusStoriesFilterComponent, limitToPipe, LoupemarkersComponent
			],
  providers: [
			  AdminAuthGuard, 
			  AuthenticationService, 
			  DbserviceService
			],
  bootstrap: []
})
export class AdminModule { }
