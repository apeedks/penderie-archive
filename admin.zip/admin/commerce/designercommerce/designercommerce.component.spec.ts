import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DesignercommerceComponent } from './designercommerce.component';

describe('DesignercommerceComponent', () => {
  let component: DesignercommerceComponent;
  let fixture: ComponentFixture<DesignercommerceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DesignercommerceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DesignercommerceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
