import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-designercommerce',
  templateUrl: './designercommerce.component.html',
  styleUrls: ['../../nav/adminheader.component.css']
})
export class DesignercommerceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
