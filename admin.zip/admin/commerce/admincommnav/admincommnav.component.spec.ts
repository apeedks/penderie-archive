import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmincommnavComponent } from './admincommnav.component';

describe('AdmincommnavComponent', () => {
  let component: AdmincommnavComponent;
  let fixture: ComponentFixture<AdmincommnavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdmincommnavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdmincommnavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
