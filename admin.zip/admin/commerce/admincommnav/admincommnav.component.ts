import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admincommnav',
  templateUrl: './admincommnav.component.html',
  styleUrls:['./admincommnav.component.css']
})
export class AdmincommnavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
