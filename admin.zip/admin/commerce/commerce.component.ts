import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commerce',
  templateUrl: './commerce.component.html',
  styleUrls: ['../nav/adminheader.component.css']
})
export class CommerceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}
