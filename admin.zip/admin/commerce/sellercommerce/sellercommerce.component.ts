import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sellercommerce',
  templateUrl: './sellercommerce.component.html',
  styleUrls: ['../../nav/adminheader.component.css']
})
export class SellercommerceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
