import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SellercommerceComponent } from './sellercommerce.component';

describe('SellercommerceComponent', () => {
  let component: SellercommerceComponent;
  let fixture: ComponentFixture<SellercommerceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SellercommerceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SellercommerceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
