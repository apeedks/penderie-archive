import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import {AdminAuthGuard} from './admin.auth.guard';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { CmsComponent } from './cms/cms.component';
import { UsersComponent } from './users/users.component';
import { PasswordComponent } from './password/password.component';
import { TemplatesComponent } from './templates/templates.component';
import { GalleriesComponent } from './media/galleries/galleries.component';
import { ResetpassComponent } from './resetpass/resetpass.component';
import { CommerceComponent } from './commerce/commerce.component';
import { DesignercommerceComponent } from './commerce/designercommerce/designercommerce.component';
import { CategoriesComponent } from './commerce/designercommerce/categories/categories.component';
import { BrandsComponent } from './commerce/designercommerce/brands/brands.component';
import { EmailsComponent } from './contents/emails/emails.component';
import {ContentsComponent} from './contents/contents.component';
import {PagesComponent} from './contents/pages/pages.component';
import {PagesTabsComponent} from './contents/pages/pagestabs/pagestabs.component';
import {PagesTabsSectionsComponent} from './contents/pages/pagestabs/pagessection/pagessection.component';
import {CommunityComponent} from './community/community.component';
import {UielementsComponent} from './uielements/uielements.component';
import {TimelineComponent} from './timeline/timeline.component';
import {AdsComponent} from './ads/ads.component';
import { SystemComponent } from './system/system.component';
import { CommunicationComponent } from './communication/communication.component';
// import { SystememailComponent } from './system/email/email.component';
// import { SystemchatComponent } from './system/chat/chat.component';
// import { SystemsystemComponent } from './system/system/system.component';

import { SystememailComponent } from './communication/email/email.component';
import { SystemchatComponent } from './communication/chat/chat.component';
import { Com_SystemsystemComponent } from './communication/system/com_system.component';

import {SettingsComponent} from './settings/settings.component';
import {ThemetemplateComponent} from './contents/pages/themetemplate/themetemplate.component';
import {FaqsComponent} from './contents/knowledge/faqs/faqs.component';
import { TemplatesectionsComponent } from './contents/pages/templatesections/templatesections.component';
import {PagetemplatesComponent} from './contents/pages/pagetemplates/pagetemplates.component';
import { ProfilepointsComponent } from './settings/profilepoints/profilepoints.component';
import { MembersComponent } from './users/members/members.component';
import { GroupsnforumsComponent } from './community/groupsnforums/groupsnforums.component';
import { GroupsComponent } from './community/groupsnforums/groups/groups.component';
import { ForumsComponent } from './community/groupsnforums/forums/forums.component';
import { SellercommerceComponent } from './commerce/sellercommerce/sellercommerce.component'; 
import { TypesComponent } from './commerce/sellercommerce/types/types.component';
import { McategoriesComponent } from './commerce/sellercommerce/mcategories/mcategories.component';
import { SourcesComponent } from './settings/sources/sources.component';
import { KnowledgeComponent } from './contents/knowledge/knowledge.component';
import { DocumentationComponent } from './contents/knowledge/documentation/documentation.component';
import { TutorialsComponent } from './contents/knowledge/tutorials/tutorials.component';
import { UpdatesComponent } from './contents/knowledge/updates/updates.component';
import { AdminemailsComponent } from './contents/emails/adminemails/adminemails.component';
import { MemprofileComponent } from './users/members/memprofile/memprofile.component';
import { MemclubsComponent } from './users/members/memclubs/memclubs.component';
import { MemprefsComponent } from './users/members/memprefs/memprefs.component';
import { MeminboxComponent } from './users/members/meminbox/meminbox.component';
import { MemactivityComponent } from './users/members/memactivity/memactivity.component';
import { LuxurypediaComponent } from './contents/luxurypedia/luxurypedia.component';
import { ArticlesComponent } from './contents/luxurypedia/articles/articles.component';
import { ArticledetComponent } from './contents/luxurypedia/articledet/articledet.component';
import { LuxurytagsComponent } from './contents/luxurypedia/luxurytags/luxurytags.component';
import { StoriesComponent } from './contents/stories/stories.component';
import { StorycatsComponent } from './contents/stories/storycats/storycats.component';
import { MagazinecatsComponent } from './contents/magazines/magazinecats/magazinecats.component';
import { StorytagsComponent } from './contents/stories/storytags/storytags.component';
import { LoupeComponent } from './contents/loupe/loupe.component';
import { LoupecatsComponent } from './contents/loupe/loupecats/loupecats.component';
import { LoupetagsComponent } from './contents/loupe/loupetags/loupetags.component';
import { LoupebrandsComponent } from './contents/loupe/loupebrands/loupebrands.component';
import { MediaComponent } from './media/media.component';
import { SlidersComponent } from './media/sliders/sliders.component';
import { DefaultfoldersComponent } from './media/defaultfolders/defaultfolders.component';
import { CustomfoldersComponent } from './media/customfolders/customfolders.component';
import { FotodiaryComponent } from './media/fotodiary/fotodiary.component';
import { CollectionComponent } from './media/collection/collection.component';
import { CatalogueComponent } from './media/catalogue/catalogue.component';
import { PortfolioComponent } from './media/portfolio/portfolio.component';
import { ProfileComponent } from './profile/profile.component';
import { EmployeesComponent } from './users/employees/employees.component';
import { AdminsComponent } from './users/admins/admins.component';
import { MagazinesComponent } from './contents/magazines/magazines.component';
import { MagazinetagsComponent } from './contents/magazines/magazinetags/magazinetags.component';
const routes: Routes = [  
    {path: 'admin', pathMatch: 'full', component: LoginComponent },
	{path: 'admin/login', pathMatch: 'full', component: LoginComponent },
	{path: 'admin/logout', pathMatch: 'full', component: LoginComponent },
    {path: 'admin/dashboard',component: DashboardComponent,canActivate: [AdminAuthGuard]}, 
	{path: 'admin/users',component: UsersComponent,canActivate: [AdminAuthGuard]}, 
	{path: 'admin/users/admins',component: AdminsComponent,canActivate: [AdminAuthGuard]}, 
	{path: 'admin/users/employees',component: EmployeesComponent,canActivate: [AdminAuthGuard]}, 
	{path: 'admin/users/members',component: MembersComponent,canActivate: [AdminAuthGuard]}, 
	{path: 'admin/users/members/profile/:userid',component: MemprofileComponent,canActivate: [AdminAuthGuard]}, 
	{path: 'admin/users/members/prefs/:userid',component: MemprefsComponent,canActivate: [AdminAuthGuard]}, 
	{path: 'admin/users/members/clubs/:userid',component: MemclubsComponent,canActivate: [AdminAuthGuard]}, 
	{path: 'admin/users/members/activity/:userid',component: MemactivityComponent,canActivate: [AdminAuthGuard]}, 
	{path: 'admin/users/members/inbox/:userid',component: MeminboxComponent,canActivate: [AdminAuthGuard]}, 
	
	{path: 'admin/settings/profilepoints',component: ProfilepointsComponent,canActivate: [AdminAuthGuard]}, 
	{path: 'admin/cms',component: CmsComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/templates/:templatetype',component: TemplatesComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/password',component: PasswordComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/profile',component: ProfileComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/resetpass/:resettoken',component: ResetpassComponent},
	{path: 'admin/ads',component: AdsComponent,canActivate: [AdminAuthGuard]},

	{path: 'admin/system',component: SystemComponent,canActivate: [AdminAuthGuard]},
	// {path: 'admin/system/email',component: SystememailComponent,canActivate: [AdminAuthGuard]},
	// {path: 'admin/system/chat',component: SystemchatComponent,canActivate: [AdminAuthGuard]},
	// {path: 'admin/system/system',component: SystemsystemComponent,canActivate: [AdminAuthGuard]},
	// {path: 'admin/system/chat/:selecteduserid',component: SystemchatComponent,canActivate: [AdminAuthGuard]},
	
	{path: 'admin/communication',component: CommunicationComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/communication/email',component: SystememailComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/communication/chat',component: SystemchatComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/communication/system',component: Com_SystemsystemComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/communication/chat/:selecteduserid',component: SystemchatComponent,canActivate: [AdminAuthGuard]},

	{path: 'admin/settings',component: SettingsComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/settings/sources',component: SourcesComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/uielements',component: UielementsComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/contents/page',component: PagesComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/contents/page/tabs/:contentid',component: PagesTabsComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/contents/page/sections/:contentid/:tabid',component: PagesTabsSectionsComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/contents/page/theme',component: ThemetemplateComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/contents/page/theme/sections/:templateid',component: TemplatesectionsComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/contents/page/templates',component: PagetemplatesComponent,canActivate: [AdminAuthGuard]},
	
	{path: 'admin/contents/knowledge/faqs',component: FaqsComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/contents/knowledge/documentation',component: DocumentationComponent,canActivate: [AdminAuthGuard]},	
	{path: 'admin/contents/knowledge/tutorial',component: TutorialsComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/contents/knowledge/updates',component: UpdatesComponent,canActivate: [AdminAuthGuard]},
	
	{path: 'admin/contents/emails',component: EmailsComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/contents/emails/adminemails/:type',component: AdminemailsComponent,canActivate: [AdminAuthGuard]},	
	
	{path: 'admin/contents/knowledge',component: KnowledgeComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/contents/knowledge/:parentid',component: KnowledgeComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/community',component: CommunityComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/community/groupsnforums',component: GroupsnforumsComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/community/groupsnforums/groups',component: GroupsComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/community/groupsnforums/forums',component: ForumsComponent,canActivate: [AdminAuthGuard]},

	{path: 'admin/commerce',component: CommerceComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/commerce/designer',component: DesignercommerceComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/commerce/categories',component: CategoriesComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/commerce/brands',component: BrandsComponent,canActivate: [AdminAuthGuard]},

	{path: 'admin/commerce/seller',component: SellercommerceComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/commerce/seller/categories',component: McategoriesComponent,canActivate: [AdminAuthGuard]},
	{path: 'admin/commerce/seller/types',component: TypesComponent,canActivate: [AdminAuthGuard]},
	
	

	
	{
        path: 'admin/media',canActivate: [AdminAuthGuard],
        children: [
				   	/*{path: '', redirectTo: 'categories'},*/	
					{path: 'analytics',component: MediaComponent,pathMatch: 'prefix'},
					{path: 'sliders',component: SlidersComponent,pathMatch: 'prefix'},
					{path: 'default-folders',component: DefaultfoldersComponent,pathMatch: 'prefix'},
					{path: 'custom-folders',component: CustomfoldersComponent,pathMatch: 'prefix'},	
					{path: 'foto-diary',component: FotodiaryComponent,pathMatch: 'prefix'},
					{path: 'collection',component: CollectionComponent,pathMatch: 'prefix'},
					{path: 'catalog',component: CatalogueComponent,pathMatch: 'prefix'},
					{path: 'portfolio',component: PortfolioComponent,pathMatch: 'prefix'},
					{path: 'gallery',component: GalleriesComponent,pathMatch: 'prefix'},
			]
    },
	{
        path: 'admin/contents/luxurypedia',canActivate: [AdminAuthGuard],
        children: [
				   	/*{path: '', redirectTo: 'categories'},*/	
					{path: 'categories',component: LuxurypediaComponent,pathMatch: 'prefix'},
					{path: 'categories/:parentid',component: LuxurypediaComponent,pathMatch: 'prefix'},
					{path: 'tags',component: LuxurytagsComponent,pathMatch: 'prefix'},
					{path: 'tags/:id',component: LuxurytagsComponent,pathMatch: 'prefix'},
					{path: '',component: ArticlesComponent,pathMatch: 'prefix'},	
					{path: 'article/:type/:id',component: ArticlesComponent,pathMatch: 'prefix'},
					{path: 'articledet/:articleid/:parentid',component: ArticledetComponent,pathMatch: 'prefix'},
					
			]
    },
	{
        path: 'admin/contents/stories',canActivate: [AdminAuthGuard],
        children: [
				   	{path: 'categories',component: StorycatsComponent,pathMatch: 'prefix'},
					{path: 'categories/:parentid',component: StorycatsComponent,pathMatch: 'prefix'},
					{path: 'tags',component: StorytagsComponent,pathMatch: 'prefix'},
					{path: '',component: StoriesComponent,pathMatch: 'prefix'},
					{path: 'stories/:type/:id',component: StoriesComponent,pathMatch: 'prefix'},
				  ]
    },
    {	path: 'admin/contents/loupe',canActivate: [AdminAuthGuard],
    	children: [
		   	{path: 'categories',component: LoupecatsComponent,pathMatch: 'prefix'},
			{path: 'categories/:parentid',component: LoupecatsComponent,pathMatch: 'prefix'},
			{path: 'tags',component: LoupetagsComponent,pathMatch: 'prefix'},
			{path: 'brands',component: LoupebrandsComponent,pathMatch: 'prefix'},
			{path: '',component: LoupeComponent,pathMatch: 'prefix'},	
		]
    },
    
    {
        path: 'admin/contents/magazines',canActivate: [AdminAuthGuard],
        children: [
                    {path: 'categories',component: MagazinecatsComponent,pathMatch: 'prefix'},
                    {path: 'categories/:parentid',component: MagazinecatsComponent,pathMatch: 'prefix'},
                    {path: 'tags',component: MagazinetagsComponent,pathMatch: 'prefix'},
                    {path: '',component: MagazinesComponent,pathMatch: 'prefix'},
                    {path: 'magazines/:type/:id',component: MagazinesComponent,pathMatch: 'prefix'},
                  ]
    },
	{
        path: 'admin/media',
        component: MediaComponent,
        children: []
    },
	{
        path: 'admin/timeline',
        component: TimelineComponent,
        children: []
    },
	{
        path: 'admin/contents',
        component: ContentsComponent,
        children: [
           /* {path: 'pages', component:PagesComponent},*/
			/*{path: 'themepages', component:ThemetemplateComponent}*/
        ]
    },
	
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports:[
	RouterModule	   
  ],
  declarations: [],
  bootstrap: [DashboardComponent]
})
export class AppRoutingModule { }
