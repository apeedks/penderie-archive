import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sliders',
  templateUrl: './sliders.component.html',
  styleUrls: ['../../nav/adminheader.component.css']
})
export class SlidersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
