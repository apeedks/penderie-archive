import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminmedianav',
  templateUrl: './adminmedianav.component.html',
  styleUrls: ['./adminmedianav.component.css']
})
export class AdminmedianavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
