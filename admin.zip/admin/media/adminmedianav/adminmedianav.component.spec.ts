import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminmedianavComponent } from './adminmedianav.component';

describe('AdminmedianavComponent', () => {
  let component: AdminmedianavComponent;
  let fixture: ComponentFixture<AdminmedianavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminmedianavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminmedianavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
