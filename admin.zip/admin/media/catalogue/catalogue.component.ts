import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-catalogue',
  templateUrl: './catalogue.component.html',
  styleUrls: ['../../nav/adminheader.component.css']
})
export class CatalogueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
