import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FotodiaryComponent } from './fotodiary.component';

describe('FotodiaryComponent', () => {
  let component: FotodiaryComponent;
  let fixture: ComponentFixture<FotodiaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FotodiaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FotodiaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
