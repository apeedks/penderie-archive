import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fotodiary',
  templateUrl: './fotodiary.component.html',
  styleUrls: ['../../nav/adminheader.component.css']
})
export class FotodiaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
