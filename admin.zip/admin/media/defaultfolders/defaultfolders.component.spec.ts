import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DefaultfoldersComponent } from './defaultfolders.component';

describe('DefaultfoldersComponent', () => {
  let component: DefaultfoldersComponent;
  let fixture: ComponentFixture<DefaultfoldersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DefaultfoldersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DefaultfoldersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
