import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DbserviceService } from '../../services/dbservice.service';
import { AuthenticationService } from '../../services/authentication.service';
import { AlertsService } from '@jaspero/ng2-alerts';

@Component({
  selector: 'app-galleries',
  templateUrl: './galleries.component.html',
  styleUrls: ['../../nav/adminheader.component.css']
})
export class GalleriesComponent implements OnInit {
  model = { id: 0, title: '', gender: 'Both', image: null, active: "" };
  pageSize: number;
  uploadimage: File;
  options: any;
  templatetype: string;
  totalitems: any;
  page: number = 1;
  public items: Object;
  public errormsg = '';
  isshowform = false;
  basepageurl: string;
  constructor(private dbserv: DbserviceService, private _alert: AlertsService, private route: ActivatedRoute, private authserv: AuthenticationService) {
    this.basepageurl = localStorage.getItem('baseurl');
  }
  fileChange($event) {
    console.log($event);
    this.model.image = $event.target.files[0];
  }

  ngOnInit() {
    this.loadpage(this.page);
  }

  loadpage(pageno) {
    this.dbserv.getAll("galleries/" + pageno).subscribe(res => { this.items = res.data; this.page = res.current_page; this.totalitems = res.total; this.pageSize = res.per_page; });
    this.isshowform = false;
  }

  pageChanged($event) {
    this.loadpage($event);
  }
  hideform() {
    this.isshowform = false;
  }
  editrecord(id) {
    this.isshowform = true;
    this.dbserv.getById("gallery", id).subscribe(res => {
      if (res.type == "success")
        this.model = res.data;
      else
        this._alert.create(res.type, res.message);
    });

  }
  deleterecord(id) {
    this.dbserv.delete("gallerydel", id).subscribe(res => { this._alert.create(res.type, res.message); this.loadpage(this.page); });

  }
  saverecord() {
    let _formData = new FormData();
    _formData.append("userid", this.authserv.getUserId().toString());
    _formData.append("usertype", this.authserv.getUserType());
    if (this.model.image)
      _formData.append('image', this.model.image, this.model.image.name);
    _formData.append("id", this.model.id.toString());
    _formData.append("title", this.model.title);
    _formData.append("active", this.model.active);
    _formData.append("gender", this.model.gender);
    this.dbserv.saveimage("gallerysave", _formData).subscribe(res => {

      this._alert.create(res.type, res.message);
      if (res.type == "success") {
        this.model = { id: 0, title: '', gender: 'Both', image: null, active: "" };
        this.loadpage(this.page);
        this.isshowform = false;
      }
    });

  }
  addrecord() {
    this.model = { id: 0, title: '', gender: 'Both', image: null, active: "" };
    this.isshowform = true;

  }

}
