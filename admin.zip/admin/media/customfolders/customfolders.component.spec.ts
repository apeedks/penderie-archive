import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomfoldersComponent } from './customfolders.component';

describe('CustomfoldersComponent', () => {
  let component: CustomfoldersComponent;
  let fixture: ComponentFixture<CustomfoldersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomfoldersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomfoldersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
