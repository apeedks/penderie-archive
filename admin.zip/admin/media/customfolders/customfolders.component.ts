import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customfolders',
  templateUrl: './customfolders.component.html',
  styleUrls: ['../../nav/adminheader.component.css']
})
export class CustomfoldersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
