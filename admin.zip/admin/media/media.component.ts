import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-media',
  templateUrl: './media.component.html',
  styleUrls: ['../nav/adminheader.component.css','./media.component.css']
})
export class MediaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
