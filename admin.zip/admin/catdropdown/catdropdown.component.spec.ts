import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CatdropdownComponent } from './catdropdown.component';

describe('CatdropdownComponent', () => {
  let component: CatdropdownComponent;
  let fixture: ComponentFixture<CatdropdownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CatdropdownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CatdropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
