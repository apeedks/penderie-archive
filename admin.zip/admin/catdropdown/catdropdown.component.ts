import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-catdropdown',
  templateUrl: './catdropdown.component.html',
  styleUrls: ['./catdropdown.component.css']
})
export class CatdropdownComponent implements OnInit {
	@Input() childMessage: string;
	@Input() ddlcategories = [];
	constructor() { }
	
	ngOnInit() {
	}

}
