import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MemactivityComponent } from './memactivity.component';

describe('MemactivityComponent', () => {
  let component: MemactivityComponent;
  let fixture: ComponentFixture<MemactivityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MemactivityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MemactivityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
