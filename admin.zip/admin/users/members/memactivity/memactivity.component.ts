import {Component, OnInit} from '@angular/core';
import {DbserviceService} from '../../../services/dbservice.service';
import { AuthenticationService } from '../../../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import {AlertsService} from '@jaspero/ng2-alerts';
import $ from 'jquery';
@Component({
  selector: 'app-memactivity',
  templateUrl: './memactivity.component.html',
  styleUrls: ['../../../nav/adminheader.component.css']
})
export class MemactivityComponent implements OnInit {
	options:any;
	lastpage: number;
	totalitems: any;
	page: number = 1;
	limit:number = 3;
	items = [];
	params:any = {};
	userid = 0;
	constructor(private authserv: AuthenticationService,private _alert: AlertsService,private dbserv:DbserviceService,private router: Router,private route: ActivatedRoute)  { 
		this.route.params.subscribe(params => {
		    this.userid = +params['userid']; // (+) converts string 'id' to a number
			this.loadrecs();
		});
	}
	ngOnInit() {
	}
	showmorerecs()
	{
		this.page = this.page + 1;
		this.dbserv.post("adminmemactivity/"+this.userid+"/"+this.page+"/"+this.limit,this.params).subscribe(res => {
																										   this.items = [ ...this.items, ...res.records.data];
																										   this.page = res.records.current_page;
																										   this.lastpage = res.records.last_page; 
																										   this.totalitems = res.records.total;
																										}); 	
	}
	loadrecs()
	{
		/*this.params.searchfield = this.searchfield;*/
		this.dbserv.post("adminmemactivity/"+this.userid+"/"+this.page+"/"+this.limit,this.params).subscribe(res => {this.items = res.records.data; this.page = res.records.current_page;this.lastpage = res.records.last_page; this.totalitems = res.records.total;}); 
	}
}
