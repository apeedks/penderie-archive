import {Component, OnInit} from '@angular/core';
import {DbserviceService} from '../../../services/dbservice.service';
import { AuthenticationService } from '../../../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import {AlertsService} from '@jaspero/ng2-alerts';
import $ from 'jquery';
@Component({
  selector: 'app-memprefs',
  templateUrl: './memprefs.component.html',
  styleUrls: ['../../../nav/adminheader.component.css']
})
export class MemprefsComponent implements OnInit {
	userid:number = 0;
	options:any;
	preflistdefault:string = '';
	prefcatlist = [];
	preftypelist = [];
	selectedprefs = [];

	constructor(private dbserv:DbserviceService,private authserv: AuthenticationService,private _alert: AlertsService,private route: ActivatedRoute,private router: Router) 
	{ 
		this.route.params.subscribe(params => {
		    this.userid = +params['userid']; // (+) converts string 'id' to a number
			this.dbserv.getAll("admincatsbrands/" + this.userid).subscribe(res => {this.prefcatlist = res; });
			this.dbserv.getAll("admincatstypes/" + this.userid).subscribe(res => {this.preftypelist = res;});
		});
	}
	saveprefs()
	{
		this.selectedprefs = [];
		for(let x in this.prefcatlist) {
			if(this.prefcatlist[x].items)
				for(let y in this.prefcatlist[x].items) {
					if(this.prefcatlist[x].items[y].checked)
						this.selectedprefs.push(this.prefcatlist[x].items[y].id);
				}
		}	
		if(this.selectedprefs.length<1 && this.selectedprefs.length>3)
		{
			this._alert.create('error','You must select alteast 1 and atmost 3 Luxury Brands.');
			return false;
		}
		else
		{
			let model = {user:this.userid,prefs:this.selectedprefs,type:'Luxury Brands'}
			this.dbserv.save("savecatsbrandstypesprefs",model).subscribe(res => {
														this._alert.create(res.type,res.message);
													});	
		}
		
		this.selectedprefs = [];
		for(let x in this.preftypelist) {
			if(this.preftypelist[x].items)
				for(let y in this.preftypelist[x].items) {
					if(this.preftypelist[x].items[y].checked)
						this.selectedprefs.push(this.preftypelist[x].items[y].id);
				}
		}	
		if(this.selectedprefs.length<1 && this.selectedprefs.length>3)
		{
			this._alert.create('error','You must select alteast 1 and atmost 3 Luxury Brands.');
			return false;
		}
		else
		{
			let model = {user:this.userid,prefs:this.selectedprefs,type:'Material'}
			this.dbserv.save("savecatsbrandstypesprefs",model).subscribe(res => {
														this._alert.create(res.type,res.message);
													});	
		}
	}
	getselectedprefs()
	{
		/*this.selectedprefs = [];
		for(let x in this.preflist) {
			if(this.preflist[x]) {
				for(let y in this.preflist[x].items) {
					if(this.preflist[x].items[y].items)
						for(let z in this.preflist[x].items[y].items) {
							if(this.preflist[x].items[y].items[z].checked)
								this.selectedprefs.push(this.preflist[x].items[y].items[z].id);
						}
				}
			}
		}	
		if(this.selectedprefs.length<1 && this.selectedprefs.length>3)
		{
			this._alert.create('error','You must select alteast 1 and atmost 3 preference.');
			return false;
		}
		else
		{
			let model = {user:this.userid,prefs:this.selectedprefs,'type':'Luxury Brands'}
			this.dbserv.save("savecatsbrandstypesprefs",model).subscribe(res => {
														this._alert.create(res.type,res.message);
													});	
		}*/
	}
	prefcontent(tab)
	{
		$(".tab_prefcontentjquery").removeClass("active");
		$("#prefmytab"+ tab).addClass("active");
		$(".preftabheaders").removeClass("active");
		$("#preftabhead"+ tab).addClass("active");
	}
	ngOnInit() {
	}
}
