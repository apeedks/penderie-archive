import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MeminboxComponent } from './meminbox.component';

describe('MeminboxComponent', () => {
  let component: MeminboxComponent;
  let fixture: ComponentFixture<MeminboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MeminboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MeminboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
