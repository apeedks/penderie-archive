import {Component, OnInit} from '@angular/core';
import {DbserviceService} from '../../../services/dbservice.service';
import { AuthenticationService } from '../../../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import {AlertsService} from '@jaspero/ng2-alerts';
import $ from 'jquery';
@Component({
  selector: 'app-memclubs',
  templateUrl: './memclubs.component.html',
  styleUrls: ['../../../nav/adminheader.component.css']
})
export class MemclubsComponent implements OnInit {
	userid:number = 0;
	clubslist = [];
	grouplist = [];
	forumlist = [];
	options:any;
	isclubselected = false;
	clubdefault:string = '';
	constructor(private dbserv:DbserviceService,private authserv: AuthenticationService,private _alert: AlertsService,private route: ActivatedRoute,private router: Router) 
	{ 
		this.route.params.subscribe(params => {
		    this.userid = +params['userid']; // (+) converts string 'id' to a number
			this.dbserv.getAll("adminclubs/" + this.userid).subscribe(res => {this.clubslist = res;this.clubdefault = this.clubslist[0].id.toString();});
			
		});
	}
	
	ngOnInit() {
		
	}
	getselectedclubs()
	{
		this.grouplist = [];
		this.forumlist = [];
		this.isclubselected = false;
		for(let x in this.clubslist) {
			if(this.clubslist[x]) {
				for(let y in this.clubslist[x].items) {
					if(this.clubslist[x].items[y].checked)
						this.grouplist.push(this.clubslist[x].items[y].id);
					if(this.clubslist[x].items[y].items)
						for(let z in this.clubslist[x].items[y].items) {
							if(this.clubslist[x].items[y].items[z].checked)
								this.forumlist.push(this.clubslist[x].items[y].items[z].id);
						}
				}
			}
		}	
		if(this.grouplist.length<1 && this.grouplist.length>3)
		{
			this._alert.create('error','You must select alteast 1 and atmost 3 groups.');
			return false;
		}
		else
		{
			let model = {user:this.userid,groups:this.grouplist,forums:this.forumlist}
			this.dbserv.save("saveclubprefs",model).subscribe(res => {
														this._alert.create(res.type,res.message);
													});	
			this.isclubselected = true;

		}
	}
	clubcontent(tab:string)
	{
		$(".tab_contentjquery").removeClass("activeitem");
		$(".tab_contentjquery").addClass("inactiveitem");
		$("#mytab"+ tab).removeClass("inactiveitem");
		$("#mytab"+ tab).addClass("activeitem");
		$(".tabheaders").removeClass("active");
		$("#tabhead"+ tab).addClass("active");
	}
}
