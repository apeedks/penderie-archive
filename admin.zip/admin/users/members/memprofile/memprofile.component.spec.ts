import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MemprofileComponent } from './memprofile.component';

describe('MemprofileComponent', () => {
  let component: MemprofileComponent;
  let fixture: ComponentFixture<MemprofileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MemprofileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MemprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
