import {Component, OnInit} from '@angular/core';
import {DbserviceService} from '../../../services/dbservice.service';
import { AuthenticationService } from '../../../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import {AlertsService} from '@jaspero/ng2-alerts';

@Component({
  selector: 'app-memprofile',
  templateUrl: './memprofile.component.html',
  styleUrls: ['../../../nav/adminheader.component.css']
})
export class MemprofileComponent implements OnInit {
	userid:number = 0;
	record = {id:0,name:"",email:"",usertype:"",verified:"",image:"",updated_at:"",firstname:"",lastname:"",gender:"",maritalstatus:"",occupation:"",birthday:"",mobileno:"",country:"",state:"",city:"",zipcode:"",initials:"",aboutme:"",connectiontype:"",personality:'', facebook: "https://www.facebook.com/",twitter: "https://twitter.com/",linkedin:"https://www.linkedin.com/",instagram: "https://www.instagram.com/",pinterest: "https://www.pinterest.com/",youtube: "https://www.youtube.com/",google: "https://plus.google.com/",website: "",username:"",created_at:"",active:""};
	options:any;
	constructor(private dbserv:DbserviceService,private authserv: AuthenticationService,private _alert: AlertsService,private route: ActivatedRoute,private router: Router) 
	{ 
		this.route.params.subscribe(params => {
		    this.userid = +params['userid']; // (+) converts string 'id' to a number
			this.dbserv.getById("getuserdetail",this.userid).subscribe(res => {
							if(res.type=="success")
								this.record = res.data;
							else
								this._alert.create(res.type,res.message);
								
							
						});
			/*this.dbserv.getAll("mynotifications").subscribe(res => {
															if(res.type=="success")
																this.notifications = res.data;
														});*/
		});
	}
	
	ngOnInit() {
	}

}
