import { Component, OnInit } from '@angular/core';
import $ from 'jquery';
@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['../nav/adminheader.component.css','./users.component.css']
})
export class UsersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
	   /*alert($('#firstdev').html());*/
  }

}
