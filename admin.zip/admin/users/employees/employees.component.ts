import { Component, OnInit, ViewChild} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { DataTable } from 'angular-4-data-table/src/index';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['../../nav/adminheader.component.css']
})
export class EmployeesComponent implements OnInit {
	public items = [];
	model = {id:0, name: '',email:"",image:null,username: "",usertype:"Member",verified:"",active:"",firstname: "",lastname: "",registeredby: "",socialid:"",gender:"",maritalstatus: "",occupation: "",birthday:"",mobileno: "",country: "",state: "",city: "",zipcode: "",initials: "",aboutme: ""};
	emodel = {ids:null, template: '',subject: "",message: ""};
	rootpath = '';
	options:any;
	currtime:any;
	pageSize: number;
	countrylist:any;
	statelist:any;
	citylist:any;
	totalitems: any;
	emailtemplates:any;
	page: number = 1;
	last_page: number =1;
	public defaultparam = {sortBy:"id", sortAsc:true,offset:0,limit:10,sortfield:"All",searchstr:""};
	public errormsg = '';
	filterfield:string='All';
	isshowform = false;
	isshowemailtemplates = false;
	currentlist:string = 'All';
	applybtnval:string = '';
	headerimage:string = '';
	uploadedimage = null;
	sortfield:string = 'All';
	selectedrecs	= [];
	searchfield:string = '';
	summary = {Published:0, Pending:0,Trash:0,Inactive:0,Total:0};
	@ViewChild(DataTable) recTable: DataTable;
	
	constructor(private dbserv:DbserviceService,private _alert: AlertsService) 
	{
		this.currtime = Math.random();
		this.rootpath = localStorage.getItem('baseurl');
	}
	templatechanged()
	{
		for(var i = 0;i<this.emailtemplates.length;i++) { 
			if(this.emodel.template==this.emailtemplates[i].id)
		     	this.emodel.message = this.emailtemplates[i].content; 
				this.emodel.subject = this.emailtemplates[i].subjects;
		}
		
	}
	showmessage(id:number)
	{
		this.isshowemailtemplates = true;	
		this.selectedrecs=[id];
	}
	statusselectedchange()
	{
		if(this.applybtnval!='')
		{
			if(confirm('Are you sure?'))
			{
				if(this.recTable.selectedRows.length>0)
				{
					this.selectedrecs=[];
					for(var i = 0;i<this.recTable.selectedRows.length;i++) 
					{ 
						this.selectedrecs.push(this.recTable.selectedRows[i].item.id);
					}
					if(this.applybtnval!="Message")
					{
						let newmodel = {'action':this.applybtnval,'vals':JSON.stringify(this.selectedrecs)};
						this.dbserv.save("enmployeeperformaction",newmodel).subscribe(res => {
																	  
																	   this._alert.create(res.type,res.message);
																	   if(res.type=="success")
																	   {
																			this.loadpage(this.defaultparam);
																			this.isshowform = false;
																	   }
																	 }); 
					}
					else
					{
						this.isshowemailtemplates = true;	
					}
				}
				else
				{
					this._alert.create('error','Please, select some record first.');
				}
			}
		}
		
	}
	statuschange(id:number,action:string)
	{
		if(confirm('Are you sure?'))
		{
			this.selectedrecs=[id];
			this.applybtnval = action;
			let newmodel = {'action':this.applybtnval,'vals':JSON.stringify(this.selectedrecs)};
			this.dbserv.save("enmployeeperformaction",newmodel).subscribe(res => {
															  
															   this._alert.create(res.type,res.message);
															   if(res.type=="success")
															   {
																	this.loadpage(this.defaultparam);
																	this.isshowform = false;
															   }
															 }); 
		}
	}
	
	fileChange($event){
		console.log($event.target.files[0]);
		this.uploadedimage = $event.target.files[0];
	}
	sortchanged()
	{
		this.defaultparam.sortfield = this.sortfield;	
		this.loadpage(this.defaultparam);
	}
	loadpage(params:any)
	{
		params.searchstr = this.searchfield;
		this.dbserv.post("enmployees/"+this.currentlist,params).subscribe(res => {
																			this.items = res.data; 
																			this.page = res.current_page; 
																			this.totalitems = res.total;
																			this.pageSize = res.per_page;
																			this.last_page = res.last_page;
																			this.dbserv.post("enmployeesummary/"+this.currentlist,params).subscribe(res => {
																				this.summary = res;
																			}); 
																		}); 
		this.defaultparam = params;
		this.isshowform = false;
	}
	ngOnInit() {
		this.dbserv.getAll("countries").subscribe(res => {this.countrylist = res;});
		this.dbserv.getAll("getadminemails/Member").subscribe(res => {this.emailtemplates = res;});
	}
	switchcurrentlist()
	{
		this.currentlist = this.filterfield;
		this.loadpage(this.defaultparam);
	}
	sendemail()
	{
		this.emodel.ids = this.selectedrecs;
		this.dbserv.post("sendadminemails",this.emodel).subscribe(res => {
																			this._alert.create(res.type,res.message);
																			this.loadpage(this.defaultparam);
																		}); 
		
	}
	hideeform()
	{
		this.isshowemailtemplates = false;	
	}
	hideform()
	{
		this.isshowform = false;
	}
	editrecord(id)
	{
		this.currtime = Math.random();
		this.isshowform = true;
		this.dbserv.getById("enmployee",id).subscribe(res => {
													if(res.type=="success")
													{
														this.model=res.data;
														this.headerimage = this.model.image;
													}
													else
														this._alert.create(res.type,res.message);
													});
	}
	deleterecord(id)
	{
		if(confirm('Are you sure?'))
		{
			this.isshowform = false;
			this.dbserv.delete("enmployeedel", id).subscribe(res => { this._alert.create(res.type,res.message);this.loadpage(this.defaultparam);});
		}
		
	}
	changevalue(type:string)
	{
		this.model.active = type;
	}
	states()
	{
		this.dbserv.getAll("states/" + this.model.country).subscribe(res => {this.statelist = res;});
	}
	cities()
	{
		this.dbserv.getAll("cities/" + this.model.country + "/" + this.model.state).subscribe(res => {this.citylist = res;});
	}
	saverecord()
	{

		let _formData = new FormData();
		_formData.append("id",this.model.id.toString());
		_formData.append("name",this.model.name);
		_formData.append("email",this.model.email);
		_formData.append("username",this.model.username.toString());
		_formData.append("usertype",this.model.usertype);
		_formData.append("verified",this.model.verified);
		_formData.append("active",this.model.active);
		_formData.append("firstname",this.model.firstname);
		_formData.append("lastname",this.model.lastname);
		_formData.append("registeredby",this.model.registeredby);
		_formData.append("socialid",this.model.socialid);
		_formData.append("gender",this.model.gender);
		_formData.append("maritalstatus",this.model.maritalstatus);
		_formData.append("occupation",this.model.occupation);
		_formData.append("birthday",this.model.birthday);
		_formData.append("mobileno",this.model.mobileno);
		_formData.append("country",this.model.country);
		_formData.append("state",this.model.state);
		_formData.append("city",this.model.city);
		_formData.append("zipcode",this.model.zipcode);
		_formData.append("initials",this.model.initials);
		_formData.append("aboutme",this.model.aboutme);
		if(this.uploadedimage!=null && this.uploadedimage.name!='')
		{
			_formData.append('image',this.uploadedimage, this.uploadedimage.name);
		}
		this.currtime = Math.random();
		this.dbserv.saveimage("membersave",_formData).subscribe(res => {
															  
															   this._alert.create(res.type,res.message);
															   if(res.type=="success")
															   {
															    	this.model = {id:0, name: '',email:"",image:null,username: "",usertype:"Member",verified:"",active:"",firstname: "",lastname: "",registeredby: "",socialid:"",gender:"",maritalstatus: "",occupation: "",birthday:"",mobileno: "",country: "",state: "",city: "",zipcode: "",initials: "",aboutme: ""};
																	this.loadpage(this.defaultparam);
																	this.isshowform = false;
															   }
															 }); 
	}
	addrecord()
	{
		this.model = {id:0, name: '',email:"",image:null,username: "",usertype:"Member",verified:"",active:"",firstname: "",lastname: "",registeredby: "",socialid:"",gender:"",maritalstatus: "",occupation: "",birthday:"",mobileno: "",country: "",state: "",city: "",zipcode: "",initials: "",aboutme: ""};
		this.isshowform = true;
		
	}

}
