import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminusernavComponent } from './adminusernav.component';

describe('AdminusernavComponent', () => {
  let component: AdminusernavComponent;
  let fixture: ComponentFixture<AdminusernavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminusernavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminusernavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
