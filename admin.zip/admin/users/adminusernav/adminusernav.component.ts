import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminusernav',
  templateUrl: './adminusernav.component.html',
  styleUrls: ['./adminusernav.component.css']
})
export class AdminusernavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
