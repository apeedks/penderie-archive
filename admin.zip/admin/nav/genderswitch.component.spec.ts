import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GenderswitchComponent } from './genderswitch.component';

describe('GenderswitchComponent', () => {
  let component: GenderswitchComponent;
  let fixture: ComponentFixture<GenderswitchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenderswitchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenderswitchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
