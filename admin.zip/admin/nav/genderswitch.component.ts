import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
@Component({
  selector: 'app-genderswitch',
  templateUrl: './genderswitch.component.html',
  styleUrls: ['./adminheader.component.css']
})
export class GenderswitchComponent implements OnInit {
	visittype:string = "";
	constructor(private router: Router,private cookieService: CookieService) { 
		this.visittype = localStorage.getItem('visittype');
		
	}
	
	ngOnInit() {
		
	}
	switchtopgender(type:string)
	{
		
		this.cookieService.set('visittype',type);
		localStorage.setItem('visittype',type);
		setTimeout((router: Router) => {
			document.location.reload();
		}, 500);
	}
}
