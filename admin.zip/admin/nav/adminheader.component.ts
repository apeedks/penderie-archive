import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import { User } from '../_models/user';
import {DbserviceService} from '../services/dbservice.service';
@Component({
  selector: 'app-adminheader',
  templateUrl: './adminheader.component.html',
  styleUrls: ['./adminheader.component.css']
})
export class AdminheaderComponent implements OnInit {
	isadminloggedin:boolean = false;
	record = {id:0,name: '',email: "",username: "",image: "",imagesrc: ""};
	rootpath = '';
	options:any;
	currtime:any;
	notifications = [];
	constructor(private dbserv:DbserviceService,private route: ActivatedRoute,private router: Router,private authserv: AuthenticationService) { 
		this.currtime = Math.random();
		this.rootpath = localStorage.getItem('baseurl');
	}
	
	ngOnInit() {
	  this.authserv.sessionreq();
	  this.isadminloggedin = this.authserv.isloggedin();
	  if(this.isadminloggedin)
	  {
	  		this.dbserv.getAll("getadminprofile").subscribe(res => {
																if(res.type=="success")
																{
																	this.currtime = Math.random();
																	this.record = res.data;
																}
															});
			this.dbserv.getAll("mynotifications").subscribe(res => {
															this.currtime = Math.random();
															if(res.type=="success")
																this.notifications = res.data;
														});
	  }
	}
}
