import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import { User } from '../_models/user';

@Component({
  selector: 'app-footer',
  templateUrl: './adminfooter.component.html',
  styleUrls: ['./adminheader.component.css']
})
export class AdminfooterComponent implements OnInit {
	 
  constructor(
		private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService) { }

  ngOnInit() {
  }
}
