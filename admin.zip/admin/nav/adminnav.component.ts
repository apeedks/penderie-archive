import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import $ from 'jquery';
@Component({
  selector: 'app-adminnav',
  templateUrl: './adminnav.component.html',
  styleUrls: ['./adminheader.component.css']
})
export class AdminnavComponent implements OnInit {
	wasClicked:boolean = false;
	currentmenu:number = 0;
	rotatelftnav = true;
	collapse_ul = true;
	collapse_lftnav = true;
	content_collapse = true;
	
	constructor(router: Router) { 
		switch(router.url)
		{
			case "/admin/templates/contents":
			case "/admin/cms":
				this.currentmenu = 2;
				break;
			case "/admin/users/employee":
			case "/admin/users/members":
			case "/admin/users/supplier":
			case "/admin/users/provider":
			case "/admin/users/designer":
				this.currentmenu = 1;
				break;
			default:
				this.currentmenu = 0;
			
		}
	} 
  	ngOnInit() {
		
		
	}
	expandCollapse()
	{
		this.wasClicked = !this.wasClicked;
		if(this.wasClicked)
		{
			this.rotatelftnav = false;
			this.collapse_ul = false;
			this.collapse_lftnav = false;
			this.content_collapse = false;
			$('.dashboard_right_content').removeClass("active");
		}
		else
		{
			this.rotatelftnav = true;	
			this.collapse_ul = true;
			this.collapse_lftnav = true;
			this.content_collapse = true;
			$('.dashboard_right_content').addClass("active");

		}

	}
	menushowhide(index:number)
	{
		this.currentmenu = index;

	}

}