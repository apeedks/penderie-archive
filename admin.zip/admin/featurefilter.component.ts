import { Component, OnInit, ViewChild ,Input, EventEmitter, Output, OnChanges } from '@angular/core';
import $ from 'jquery';	
@Component({
    selector: 'app-featurefilter',
    template: `<div class="inner-filts-bloger">
                                        <div class="our-checkboxs bigst-s-font" style="margin-top: 1px;height: 23px;">
                                             <p><label for="featured">Featured </label></p>
                                        </div>
                                        <div class="mCustomScrollbar cust-sel-marg">
                                            <div class="our-checkboxs">
                                                <p><input type="checkbox"  class="checkbox4" id="test86"  (change)="current4()" [checked]="active == 'Yes'"   name="check[]" value="Yes" /><label for="test86">Yes</label></p>
                                                <p><input type="checkbox"  class="checkbox4" id="test87"  (change)="current4()" [checked]="active == 'No'"   name="check[]" value="No" /><label for="test87">No</label></p>
                                             </div>
                                        </div>
                                    </div>`,
    providers: []
})
export class FeatureFilterComponent implements OnInit {
	@Output() changed = new EventEmitter();
	@Input() active = '';
	status:any = ['Yes','No'];
	constructor(){}
	
	ngOnInit() {
		
	}
	selectfeatured()
	{
	console.log('dd');
		
		//select all checkboxes
			$("#test85").change(function(){  //"select all" change 
    var status = this.checked; // "select all" checked status
    $('.checkbox4').each(function(){ //iterate all listed checkbox items
        this.checked = status; //change ".checkbox" checked status
    });
});

$('.checkbox4').change(function(){ //".checkbox" change 
    //uncheck "select all", if one of the listed checkbox item is unchecked
    if(this.checked == false){ //if this item is unchecked
        $("#test85")[0].checked = false; //change "select all" checked status to false
    }
    
    //check "select all" if all checkbox items are checked
    if ($('.checkbox4:checked').length == $('.checkbox4').length ){ 
        $("#test85")[0].checked = true; //change "select all" checked status to true
    }
});
			
		if($("#test85").is(":checked"))
			this.changed.emit(this.status);
		else
			this.changed.emit([]);
	}	
	current4(){
		let status = [];
		$('.checkbox4').each(function(){ //iterate all listed checkbox items
			if(this.checked)
				status.push($(this).val()); //change ".checkbox" checked status
    	});
		this.changed.emit(status);
	}
	
}
