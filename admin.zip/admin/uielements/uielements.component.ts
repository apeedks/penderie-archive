import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uielements',
  templateUrl: './uielements.component.html',
  styleUrls: ['../nav/adminheader.component.css']
})
export class UielementsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
