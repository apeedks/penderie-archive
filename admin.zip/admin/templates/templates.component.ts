import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
@Component({
  selector: 'app-templates',
  templateUrl: './templates.component.html',
  styleUrls: ['../nav/adminheader.component.css']
})
export class TemplatesComponent implements OnInit {
	model = {id:0, title: '',content: "",section: "",active: ""};
	pageSize: number;
	options:any;
	templatetype: string;
	totalitems: any;
	page: number = 1;
	public items:Object;
	public errormsg = '';
	isshowform = false;
	constructor(private dbserv:DbserviceService,private _alert: AlertsService,private route: ActivatedRoute) { 
	}

	ngOnInit() {
	    this.route.params.subscribe(params => {
		    this.templatetype = params['templatetype']; // (+) converts string 'id' to a number
		});
		this.loadpage(this.page);
	}
	
	loadpage(pageno)
	{
		this.dbserv.getAll("templates/"+this.templatetype+"/"+pageno).subscribe(res => {this.items = res.data; this.page = res.current_page; this.totalitems = res.total;this.pageSize = res.per_page;}); 
		this.isshowform = false;
	}
	
	pageChanged($event)
	{
	  console.log($event);this.loadpage($event) ; 
	}
	hideform()
	{
		this.isshowform = false;
	}
	editrecord(id)
	{
		this.isshowform = true;
		this.dbserv.getById("template",id).subscribe(res => {
													if(res.type=="success")
														this.model=res.data;
													else
														this._alert.create(res.type,res.message);
													});
		
	}
	deleterecord(id)
	{
		this.isshowform = false;
		this.dbserv.delete("templatedel", id).subscribe(res => { this._alert.create(res.type,res.message);this.loadpage(this.page);});
		
	}
	saverecord()
	{
		this.model.section = this.templatetype;
		this.dbserv.save("templatesave",this.model).subscribe(res => {
															  
															   //this._alert.create(res.type,res.message);
															   if(res.type=="success")
															   {
															    	this.model = {id:0, title: '',content: "",section: "",active: ""};
																	this.loadpage(this.page);
																	this.isshowform = false;
															   }
															 }); 
		
	}
	addrecord()
	{
		this.model = {id:0, title: '',content: "",section: "",active: ""};
		this.isshowform = true;
		
	}

}
