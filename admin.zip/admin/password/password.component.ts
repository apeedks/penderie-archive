import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['../nav/adminheader.component.css']
})
export class PasswordComponent implements OnInit {
	model = {password: '',new_password: ""};
	options:any;
	loading:boolean=false;
	constructor(private dbserv:DbserviceService,private _alert: AlertsService) { 
		
	}
	data:Object;
	ngOnInit() {
		
	}
	
	updatepassword()
	{
		
		this.dbserv.save("adminpassword",this.model).subscribe(res => {
															  
															   this._alert.create(res.type,res.message);
															   if(res.type=="error")
															   this.model = {password: '',new_password: ""};
															 }); 
	}
}
