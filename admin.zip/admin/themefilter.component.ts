import { Component, OnInit, ViewChild ,Input, EventEmitter, Output, OnChanges } from '@angular/core';
import $ from 'jquery';
@Component({
    selector: 'app-themefilter',
    template: `<div class="inner-filts-bloger">
                <div class="our-checkboxs bigst-s-font">
                  <!-- <p><input type="checkbox" id="ts" /><label for="ts">Theme </label></p> -->
                  <p><input type="checkbox" id="test51" name="check" (click)="selectheme()"   /><label for="test51">Theme</label></p>
                </div>
                <ul class="mCustomScrollbar cust-sel-marg">
                  <div class="our-checkboxs" >
                    <p><input type="checkbox" class="checkbox3" id="test53" name="check[]"  (change)="current3()" [checked]="active == 'The True Luxury'"value="The True Luxury"   /><label for="test53">The True Luxury</label></p>
                    <p><input type="checkbox" class="checkbox3" id="test52" name="check[]"  (change)="current3()" [checked]="active == 'Fine Material'" value="Fine Material"  /><label for="test52">Fine Material</label></p>
                    <p><input type="checkbox" class="checkbox3" id="test54" name="check[]"  (change)="current3()" [checked]="active == 'Superior Craftsmanship'"value="Superior Craftsmanship" /><label for="test54">Superior Craftsmanship</label></p>
                    <p><input type="checkbox" class="checkbox3" id="test55" name="check[]"  (change)="current3()" [checked]="active == 'Art of Styling'"value="Art of Styling" /><label for="test55">Art of Styling</label></p>
                    <p><input type="checkbox" class="checkbox3" id="test56" name="check[]"  (change)="current3()" [checked]="active == 'Balanced Living'"value="Balanced Living" /><label for="test56">Balanced Living</label></p>
                  </div>
                </ul>
              </div>`,
    providers: []
})
export class ThemeFilterComponent implements OnInit {
		@Output() changed = new EventEmitter();
		@Input() active = '';
		status:any = ['The True Luxury','Fine Material','Superior Craftsmanship','Art of Styling','Balanced Living'];
	constructor(){}
	
	ngOnInit() {}
	
	selectheme()
	{
	console.log('dd');
		
		//select all checkboxes
			$("#test51").change(function(){  //"select all" change 
    var status = this.checked; // "select all" checked status
    $('.checkbox3').each(function(){ //iterate all listed checkbox items
        this.checked = status; //change ".checkbox" checked status
    });
});

$('.checkbox3').change(function(){ //".checkbox" change 
    //uncheck "select all", if one of the listed checkbox item is unchecked
    if(this.checked == false){ //if this item is unchecked
        $("#test51")[0].checked = false; //change "select all" checked status to false
    }
    
    //check "select all" if all checkbox items are checked
    if ($('.checkbox3:checked').length == $('.checkbox3').length ){ 
        $("#test51")[0].checked = true; //change "select all" checked status to true
    }
});
		
		if($("#test51").is(":checked"))
			this.changed.emit(this.status);
		else
			this.changed.emit([]);
	}
		
	current3(){
		let status = [];
		$('.checkbox3').each(function(){ //iterate all listed checkbox items
			if(this.checked)
				status.push($(this).val()); //change ".checkbox" checked status
    	});
		this.changed.emit(status);
	}
	

}
