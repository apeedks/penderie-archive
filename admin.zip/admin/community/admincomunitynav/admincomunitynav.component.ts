import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admincomunitynav',
  templateUrl: './admincomunitynav.component.html',
  styleUrls: ['./admincomunitynav.component.css']
})
export class AdmincomunitynavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
