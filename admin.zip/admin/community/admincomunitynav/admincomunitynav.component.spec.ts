import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmincomunitynavComponent } from './admincomunitynav.component';

describe('AdmincomunitynavComponent', () => {
  let component: AdmincomunitynavComponent;
  let fixture: ComponentFixture<AdmincomunitynavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdmincomunitynavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdmincomunitynavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
