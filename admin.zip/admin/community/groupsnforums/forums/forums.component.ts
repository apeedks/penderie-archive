import { Component, OnInit, ViewChild} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { DataTable } from 'angular-4-data-table/src/index';
@Component({
  selector: 'app-forums',
  templateUrl: './forums.component.html',
  styleUrls: ['../../../nav/adminheader.component.css']
})
export class ForumsComponent implements OnInit {
	public items = [];
	model = {id:0, title: '',content:"",group_id:"",category_id:"",country:"",state:"",city:"",zipcode:"",gender:"",type:"",active:""};
	options:any;
	pageSize: number;
	totalitems: any;
	page: number = 1;
	last_page: number =1;
	public defaultparam = {sortBy:"id", sortAsc:true,offset:0,limit:10,sortfield:"All",searchstr:""};
	filterfield:string='All';
	isshowform = false;
	currentlist:string = 'All';
	applybtnval:string = '';
	headerimage:string = '';
	uploadedimage = null;
	groupcats:any;
	countrylist:any;
	statelist:any;
	citylist:any;
	groups:any;
	sortfield:string = 'All';
	selectedrecs	= [];
	searchfield:string = '';
	summary = {Published:0,Trash:0,Unpublished:0,Total:0}; 
	searchgender:string = "Both";
	@ViewChild(DataTable) recTable: DataTable;
	
	constructor(private dbserv:DbserviceService,private _alert: AlertsService) 
	{
		this.searchgender = localStorage.getItem('visittype');
	}
	ngOnInit() {
		this.dbserv.getAll("groupcatsddl/"+this.searchgender+"/All").subscribe(res => {this.groupcats = res;this.filltercats();});
		this.dbserv.getAll("countries").subscribe(res => {this.countrylist = res;this.states();});
	}
	states()
	{
		this.dbserv.getAll("states/" + this.model.country).subscribe(res => {this.statelist = res;this.cities();});
	}
	cities()
	{
		this.dbserv.getAll("cities/" + this.model.country + "/" + this.model.state).subscribe(res => {this.citylist = res;});
	}
	filltercats()
	{
		this.dbserv.getAll("groupsbycatid/"+this.searchgender+"/All/"+this.model.category_id).subscribe(res => {this.groups = res;});	
	}
	statusselectedchange()
	{
		
		
		if(this.applybtnval!='')
		{
			if(this.recTable.selectedRows.length>0)
			{
				this.selectedrecs=[];
				for(var i = 0;i<this.recTable.selectedRows.length;i++) 
				{ 
					this.selectedrecs.push(this.recTable.selectedRows[i].item.id);
				}
				let newmodel = {'action':this.applybtnval,'vals':JSON.stringify(this.selectedrecs)};
				this.dbserv.save("forumsperformaction",newmodel).subscribe(res => {
																  
																   this._alert.create(res.type,res.message);
																   if(res.type=="success")
																   {
																		this.loadpage(this.defaultparam);
																		this.isshowform = false;
																   }
																 }); 
			}
			else
			{
				this._alert.create('error','Please, select some record first.');
			}
		}
		
	}
	statuschange(id:number,action:string)
	{
		this.selectedrecs=[id];
		this.applybtnval = action;
		let newmodel = {'action':this.applybtnval,'vals':JSON.stringify(this.selectedrecs)};
		this.dbserv.save("forumsperformaction",newmodel).subscribe(res => {
															   this._alert.create(res.type,res.message);
															   if(res.type=="success")
															   {
																	this.loadpage(this.defaultparam);
																	this.isshowform = false;
															   }
														}); 
	}
	
	fileChange($event){
		console.log($event.target.files[0]);
		this.uploadedimage = $event.target.files[0];
	}
	sortchanged()
	{
		this.defaultparam.sortfield = this.sortfield;
		this.defaultparam.sortBy = '';
		this.loadpage(this.defaultparam);
	}
	loadpage(params:any)
	{
		params.searchstr = this.searchfield;
		this.dbserv.post("forums/"+this.searchgender+"/"+this.currentlist,params).subscribe(res => {
																			this.items = res.data; 
																			this.page = res.current_page; 
																			this.totalitems = res.total;
																			this.pageSize = res.per_page;
																			this.last_page = res.last_page;
																			this.dbserv.post("forumssummary/"+this.searchgender+"/"+this.currentlist,params).subscribe(res => {
																				this.summary = res;
																			}); 
																		}); 
		this.defaultparam = params;
		this.isshowform = false;
	}
	switchcurrentlist()
	{
		this.currentlist = this.filterfield;
		this.loadpage(this.defaultparam);
	}
	hideform()
	{
		this.isshowform = false;
	}
	editrecord(id)
	{
		this.isshowform = true;
		this.dbserv.getById("forum",id).subscribe(res => {
													if(res.type=="success")
													{
														this.model = res.data;
														this.filltercats();
														this.states();
													}
													else
														this._alert.create(res.type,res.message);
													});
	}
	deleterecord(id)
	{
		this.isshowform = false;
		this.dbserv.delete("forumdel", id).subscribe(res => { this._alert.create(res.type,res.message);this.loadpage(this.defaultparam);});
		
	}
	changevalue(type:string)
	{
		this.model.active = type;
	}
	saverecord()
	{
		this.dbserv.save("forumsave",this.model).subscribe(res => {
															  
															   this._alert.create(res.type,res.message);
															   if(res.type=="success")
															   {

															    	this.model = {id:0, title: '',content:"",group_id:"",category_id:"",country:"",state:"",city:"",zipcode:"",gender:"",type:"",active:""};
																	this.loadpage(this.defaultparam);
																	this.isshowform = false;
															   }
															 }); 
	}
	addrecord()
	{
		this.model = {id:0, title: '',content:"",group_id:"",category_id:"",country:"",state:"",city:"",zipcode:"",gender:"",type:"",active:""};
		this.isshowform = true;
		
	}
}