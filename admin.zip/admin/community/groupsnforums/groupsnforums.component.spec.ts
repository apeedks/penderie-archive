import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GroupsnforumsComponent } from './groupsnforums.component';

describe('GroupsnforumsComponent', () => {
  let component: GroupsnforumsComponent;
  let fixture: ComponentFixture<GroupsnforumsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GroupsnforumsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GroupsnforumsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
