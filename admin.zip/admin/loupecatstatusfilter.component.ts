import { Component, OnInit, ViewChild ,Input, EventEmitter, Output, OnChanges } from '@angular/core';
import $ from 'jquery';
@Component({
    selector: 'app-loupecatstatusfilter',
    template: `<div class="inner-filts-bloger">
              <div class="our-checkboxs bigst-s-font">
                  <p><input type="checkbox" id="s-76"   name="check[]" (change)="selectcatloupestatus()"  /><label for="s-76">Status </label></p>
              </div>
              <ul class="mCustomScrollbar cust-sel-marg">
                  <div class="our-checkboxs">
                      <p><input type="checkbox"  class="checkbox9"  id="s-77" (change)="current()"  name="check[]" value="Pending" /><label for="s-77">Pending</label></p>
                      <p><input type="checkbox"  class="checkbox9"  id="s-78" (change)="current()"  name="check[]" value="Draft" /><label for="s-78" >Draft</label></p>
                      <p><input type="checkbox"  class="checkbox9"  id="s-79" (change)="current()"  name="check[]" value="Trash" /><label for="s-79">Trash</label></p>
                   </div>
              </ul>
          </div>`,
    providers: []
})
export class LoupeCatStatusFilterComponent implements OnInit {
    @Output() changed = new EventEmitter();
    status:any = ['Pending','Draft','Trash'];
    constructor(){}
    
    ngOnInit() {
        
    }
    selectcatloupestatus()
    {
        //select all checkboxes
        $("#s-76").change(function(){  //"select all" change 
            var cstatus = this.checked; // "select all" checked status
            $('.checkbox9').each(function(){ //iterate all listed checkbox items
                this.checked = cstatus; //change ".checkbox" checked status
            });
        });

        $('.checkbox9').change(function(){ //".checkbox" change 
            //uncheck "select all", if one of the listed checkbox item is unchecked
            if(this.checked == false){ //if this item is unchecked
                $("#s-76")[0].checked = false; //change "select all" checked status to false
            }
    
            //check "select all" if all checkbox items are checked
            if ($('.checkbox9:checked').length == $('.checkbox9').length ){ 
                $("#s-76")[0].checked = true; //change "select all" checked status to true
            }
        });
        
        if($("#s-76").is(":checked"))
            this.changed.emit(this.status);
        else
            this.changed.emit([]);
    }
    
    current(){
        let status = [];
        $('.checkbox9').each(function(){ //iterate all listed checkbox items
            if(this.checked)
                status.push($(this).val()); //change ".checkbox" checked status
        });
        this.changed.emit(status);
    }
}
