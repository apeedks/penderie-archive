import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admintimelinenav',
  templateUrl: './admintimelinenav.component.html',
  styleUrls: ['./admintimelinenav.component.css']
})
export class AdmintimelinenavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
