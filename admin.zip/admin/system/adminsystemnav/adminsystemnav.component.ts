import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminsystemnav',
  templateUrl: './adminsystemnav.component.html',
  styleUrls:['./adminsystemnav.component.css']
})
export class Adminsystemnav implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
