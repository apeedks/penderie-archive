import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';
import { fadeInAnimation } from '../services/animatations';
import {DbserviceService} from '../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import $ from 'jquery';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['../nav/adminheader.component.css'],
  animations: [fadeInAnimation],
})
export class LoginComponent implements OnInit {
	model: any = {};
	model2: any = {forgetemail:''};
	options:any;
	loading = false;
	validation_message= '';
    returnUrl: string;
	isloginform:boolean;
	forgetemail: string;
	constructor(
        private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService,private _alert: AlertsService,private dbserv:DbserviceService,) { }

    ngOnInit() {
        // reset login status
        this.authenticationService.logout();
		this.isloginform = true;
        // get return url from route parameters or default to '/'
         // this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    }
	forgetpassword()
	{
		$(".myloaderdiv").css('display','block');
		this.dbserv.save("forgetadminpassword",this.model2).subscribe(res => {
															  
															   //this._alert.create(res.type,res.message);
															   if(res.type=="success")
															   {
															    	$(".myloaderdiv").css('display','none');
																	this.model2 = { forgetemail:''};
																	//this.isshowform = false;
															   }
															   $(".myloaderdiv").css('display','none');
															 }); 	
	}
	switchforms()
	{
		if(this.isloginform==true)
			this.isloginform = false;
		else
			this.isloginform = true;
	}
    login() {
        $(".myloaderdiv").css('display','block');
        this.authenticationService.login(this.model.email, this.model.password)
            .subscribe(
                data => {
                    $(".myloaderdiv").css('display','none');
					if(data.type=='error')
					{
						this.validation_message = data.message;
						//this._alert.create(data.type,data.message);
					}
							
					else
						this.router.navigate(['admin/dashboard']);
                },
                error => {
                    $(".myloaderdiv").css('display','none');
					//this._alert.create('error',error);
                });
    }
    logout() {
    	localStorage.removeItem('currentUser');
    	this.router.navigate(['admin/login']);
    }
}
