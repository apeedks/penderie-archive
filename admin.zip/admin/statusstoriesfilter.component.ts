import { Component, OnInit, ViewChild ,Input, EventEmitter, Output, OnChanges } from '@angular/core';
import $ from 'jquery';
@Component({
    selector: 'app-statusstoriesfilter',
    template: `<div class="inner-filts-bloger">
          <div class="our-checkboxs bigst-s-font">
              <p><input type="checkbox" id="s-10"   name="check[]" (change)="selectstatusstories()"  /><label for="s-10">Status </label></p>
          </div>
          <ul class="mCustomScrollbar cust-sel-marg">
              <div class="our-checkboxs">
                  <p><input type="checkbox"  class="checkbox5"  id="s-11" (change)="current5()"  name="check[]" [checked]="active == 'Published'" value="Published" /><label for="s-11" >Published</label></p>
                  <p><input type="checkbox"  class="checkbox5"  id="s-12" (change)="current5()"  name="check[]" [checked]="active == 'Draft'" value="Draft" /><label for="s-12">Draft</label></p>
                  <p><input type="checkbox"  class="checkbox5"  id="s-14" (change)="current5()"  name="check[]" [checked]="active == 'Archived'" value="Archived" /><label for="s-14">Archived</label></p>
                  <p><input type="checkbox"  class="checkbox5"  id="s-13" (change)="current5()"  name="check[]" [checked]="active == 'Trash'" value="Trash" /><label for="s-13">Trash</label></p>
                  <p><input type="checkbox"  class="checkbox5"  id="s-15" (change)="current5()"  name="check[]" [checked]="active == 'Workinprogress'" value="Workinprogress" /><label for="s-15">Workinprogress</label></p>
               </div>
          </ul>
      </div>`,
    providers: []
})
export class StatusStoriesFilterComponent implements OnInit {
  @Output() changed = new EventEmitter();
  @Input() active = '';
  status:any = ['Published','Draft','Trash','Uploaded'];
  constructor(){}
  
  ngOnInit() {
    
  }
  selectstatusstories()
  {
    //select all checkboxes
    $("#s-10").change(function(){  //"select all" change 
        var cstatus = this.checked; // "select all" checked status
        $('.checkbox5').each(function(){ //iterate all listed checkbox items
            this.checked = cstatus; //change ".checkbox" checked status
        });
    });

    $('.checkbox5').change(function(){ //".checkbox" change 
        //uncheck "select all", if one of the listed checkbox item is unchecked
        if(this.checked == false){ //if this item is unchecked
            $("#s-10")[0].checked = false; //change "select all" checked status to false
        }
    
        //check "select all" if all checkbox items are checked
        if ($('.checkbox5:checked').length == $('.checkbox5').length ){ 
            $("#s-10")[0].checked = true; //change "select all" checked status to true
        }
    });
    
    if($("#s-10").is(":checked"))
      this.changed.emit(this.status);
    else
      this.changed.emit([]);
  }
  
  current5(){
    let status = [];
    $('.checkbox5').each(function(){ //iterate all listed checkbox items
      if(this.checked)
        status.push($(this).val()); //change ".checkbox" checked status
      });
    this.changed.emit(status);
  }
}
