import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import {ImageCropperComponent, CropperSettings} from 'ng2-img-cropper';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['../nav/adminheader.component.css']
})
export class ProfileComponent implements OnInit {
	@ViewChild('cropper', undefined) cropper:ImageCropperComponent;
	model = {id:0,name: '',email: "",username: "",image: "",imagesrc: ""};
	rootpath = '';
	websiteroot:string;
	apiurl:string;
	uploadedimage:any;
	options:any;
	currtime:any;
	cropperSettings: CropperSettings;
	imagepreviewurl:string='';
	imagedata: any;
	loading:boolean=false;
	showCrpper:boolean=false;
	showImagePreview:boolean=true;
	uploadedimagebtn = false;
	constructor(private dbserv:DbserviceService,private _alert: AlertsService, private router: Router) { 
		this.currtime = Math.random();
		this.apiurl = localStorage.getItem('apiurl');
		this.rootpath = localStorage.getItem('baseurl');
		this.websiteroot = localStorage.getItem('basewebsiteurl');
		this.cropperSettings = new CropperSettings();
        this.cropperSettings.width = 100;
        this.cropperSettings.height = 100;
        this.cropperSettings.croppedWidth = 100;
        this.cropperSettings.croppedHeight = 100;
        this.cropperSettings.canvasWidth = 420;
		this.cropperSettings.noFileInput = true;
        this.cropperSettings.canvasHeight = 300;
        this.cropperSettings.touchRadius = 20;
		this.cropperSettings.rounded = true;
     	this.cropperSettings.keepAspect = true;
        this.imagedata = {};
	}
	onFileChange($event){
		this.showCrpper = true;
		this.showImagePreview = false;
	   	this.uploadedimage = $event.target.files[0];
	   	this.readImageUrl();
	   	//this.saveprofileimage( $event.target.files[0]);
	}
	cropped($event)
	{
		/*this.imagepreviewurl = this.imagedata.image;
		this.imagepreviewurl2 = this.imagedata.image;*/
	}
	previewFile(file) {
		if(file!="")
		{
			var request = new XMLHttpRequest();
			request.open('GET', file, true);
			request.responseType = 'blob';
			var image:any = new Image();
			request.onload = () => {
				var reader = new FileReader();
				reader.readAsDataURL(request.response);
				/*reader.onload = (event:any) => {
					image.src = event.target.result; 
					this.cropper.setImage(image);
					console.log(event.target.result);
				};*/
				reader.onloadend = (event:any) => {
					image.src = event.target.result; 
					this.cropper.setImage(image);
					
				};
			};
			request.send();
		}
	}
	readImageUrl() {
	  if (this.uploadedimage && this.uploadedimage) {
		var reader = new FileReader();
		var image:any = new Image();
		/*reader.onload = (event:any) => {
		   image.src = event.target.result; 
			this.cropper.setImage(image);
		}*/
		reader.onloadend = (event:any) => {
           image.src = event.target.result;
			this.cropper.setImage(image);
			
        };
		reader.readAsDataURL(this.uploadedimage);
	  }
	}
	ngOnInit() {
		this.dbserv.getAll("getadminprofile").subscribe(res => {
		  	if(res.type=="success")
			{
				this.model = res.data;
				if(this.model.imagesrc!='')
				{
					let imageurl = this.apiurl+this.model.image;
					this.previewFile(imageurl);
				}
				this.imagepreviewurl = this.model.image+"?time="+this.currtime;
			}
			if(res.type=="error")
				this._alert.create(res.type,res.message);
		});
	}
	
	updateprofile()
	{
		this.uploadedimagebtn = true;
		let _formData = new FormData();
		_formData.append('image',this.imagedata.image);
		_formData.append('username',this.model.username);
		_formData.append('email',this.model.email);
		_formData.append('name',this.model.name);
		if (this.uploadedimage && this.uploadedimage) {
			_formData.append('imagesrc',this.uploadedimage, this.uploadedimage.name);
		}
		this.dbserv.saveimage("updateadminprofile",_formData).subscribe(res => {
			this.uploadedimagebtn = false;
			this._alert.create(res.type,res.message);
			if(res.type == "success"){
				this.router.navigate(['admin/dashboard']);
			}
		}); 
	}
}
