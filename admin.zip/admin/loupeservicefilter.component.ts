import { Component, OnInit, ViewChild ,Input, EventEmitter, Output, OnChanges } from '@angular/core';
import $ from 'jquery';
@Component({
    selector: 'app-loupeservicefilter',
    template: `<div class="inner-filts-bloger">
              <div class="our-checkboxs bigst-s-font">
                  <p><input type="checkbox" id="s-64"  name="check[]" (change)="selectloupeservice()"  /><label for="s-64">Review Type</label></p>
              </div>
              <ul class="mCustomScrollbar cust-sel-marg">
                  <div class="our-checkboxs">
                      <p><input type="checkbox"  class="checkbox8"  id="s-65" (change)="current()"  name="check[]"  [checked]="active == 'Product'" value="Product" /><label for="s-65" >Product</label></p>
                      <p><input type="checkbox"  class="checkbox8"  id="s-66" (change)="current()"  name="check[]"  [checked]="active == 'Service'" value="Service" /><label for="s-66">Service</label></p>
                   </div>
              </ul>
          </div>`,
    providers: []
})
export class LoupeServiceFilterComponent implements OnInit {
    @Output() changed = new EventEmitter();
    @Input() active = '';
    status:any = ['Product','Service'];
    constructor(){}
    
    ngOnInit() {
        
    }
    selectloupeservice()
    {
        //select all checkboxes
        $("#s-64").change(function(){  //"select all" change 
            var cstatus = this.checked; // "select all" checked status
            $('.checkbox8').each(function(){ //iterate all listed checkbox items
                this.checked = cstatus; //change ".checkbox" checked status
            });
        });

        $('.checkbox8').change(function(){ //".checkbox" change 
            //uncheck "select all", if one of the listed checkbox item is unchecked
            if(this.checked == false){ //if this item is unchecked
                $("#s-64")[0].checked = false; //change "select all" checked status to false
            }
    
            //check "select all" if all checkbox items are checked
            if ($('.checkbox8:checked').length == $('.checkbox8').length ){ 
                $("#s-64")[0].checked = true; //change "select all" checked status to true
            }
        });
        
        if($("#s-64").is(":checked"))
            this.changed.emit(this.status);
        else
            this.changed.emit([]);
    }
    
    current(){
        let status = [];
        $('.checkbox8').each(function(){ //iterate all listed checkbox items
            if(this.checked)
                status.push($(this).val()); //change ".checkbox" checked status
        });
        this.changed.emit(status);
    }
}
