import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ads',
  templateUrl: './ads.component.html',
  styleUrls: ['../nav/adminheader.component.css']
})
export class AdsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
