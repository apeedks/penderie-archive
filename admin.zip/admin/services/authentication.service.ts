import { Injectable } from '@angular/core';
import { Http, Headers, Response,RequestOptions} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import $ from 'jquery';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import { User } from '../_models/user';
@Injectable()
export class AuthenticationService {
	serviceBase:string = "";
	public token: string;
	constructor(private http: Http) {
		// set token if saved in local storage
        var currentUser = JSON.parse(localStorage.getItem('currentUser'));
		this.serviceBase = localStorage.getItem('apiurl');
        this.token = currentUser && currentUser.token;	
	}
	private handleError(error: Response | any) {
        console.error(error);
        return Observable.throw(error); // <= B
    }
	session() {
		return this.http.get(this.serviceBase + 'user',this.jwt());
    }
	sessionreq()
	{
		return this.session().map((response: Response) =>  {
			let user:User;
			user = response.json();
			if (user.usertype =='Admin') {
				localStorage.setItem('user', JSON.stringify(user));
				return true;
            }
			else
			{
				localStorage.removeItem('currentUser');
				localStorage.removeItem('user');
				return false;
			}
        });

	}
	login(email: string, password: string) {
        return this.http.post(this.serviceBase + 'authenticate', JSON.stringify({ email: email, password: password }))
            .map((response: Response) => {
                // login successful if there's a jwt token in the response
				let user = response.json();
                if (user && user.token) {
                    localStorage.setItem('currentUser', JSON.stringify(user));
                }
				 return response.json(); 
            });
    }
	isloggedin():boolean
	{
		let user = JSON.parse(localStorage.getItem('user'));
		if (user && user.id) {
            return true;
        }
		
		return false;
	}
	getUserId():number
	{
		let user = JSON.parse(localStorage.getItem('user'));
		if (user && user.id) {
            return user.id;
        }
		
		return 0;
	}
	getUserType():string
	{
		let user = JSON.parse(localStorage.getItem('user'));
		if (user && user.usertype) {
            return user.usertype;
        }
		
		return 'gues';
	}
	private jwt() {
        // create authorization header with jwt token
        let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser && currentUser.token) {
            let headers = new Headers({ 'Authorization': 'Bearer ' + currentUser.token });
            return new RequestOptions({ headers: headers });
        }
    }
    logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
		localStorage.removeItem('user');
    }

}
