import { Component, OnInit, ViewChild ,Input, EventEmitter, Output, OnChanges } from '@angular/core';
import $ from 'jquery';
@Component({
    selector: 'app-loupecatservicefilter',
    template: `<div class="inner-filts-bloger">
              <div class="our-checkboxs bigst-s-font">
                  <p><input type="checkbox" id="s-94"  name="check[]" (change)="selectloupecatservice()"  /><label for="s-94">Category Type</label></p>
              </div>
              <ul class="mCustomScrollbar cust-sel-marg">
                  <div class="our-checkboxs">
                      <p><input type="checkbox"  class="checkbox15"  id="s-95" (change)="current()"  name="check[]" [checked]="active == 'Product'"  value="Product" /><label for="s-95" >Product</label></p>
                      <p><input type="checkbox"  class="checkbox15"  id="s-96" (change)="current()"  name="check[]" [checked]="active == 'Service'" value="Service" /><label for="s-96">Service</label></p>
                   </div>
              </ul>
          </div>`,
    providers: []
})
export class LoupeCatServiceFilterComponent implements OnInit {
    @Output() changed = new EventEmitter();
    @Input() active = '';
    status:any = ['Product','Service'];
    constructor(){}
    
    ngOnInit() {
        
    }
    selectloupecatservice()
    {
        //select all checkboxes
        $("#s-94").change(function(){  //"select all" change 
            var cstatus = this.checked; // "select all" checked status
            $('.checkbox15').each(function(){ //iterate all listed checkbox items
                this.checked = cstatus; //change ".checkbox" checked status
            });
        });

        $('.checkbox15').change(function(){ //".checkbox" change 
            //uncheck "select all", if one of the listed checkbox item is unchecked
            if(this.checked == false){ //if this item is unchecked
                $("#s-94")[0].checked = false; //change "select all" checked status to false
            }
    
            //check "select all" if all checkbox items are checked
            if ($('.checkbox15:checked').length == $('.checkbox15').length ){ 
                $("#s-94")[0].checked = true; //change "select all" checked status to true
            }
        });
        
        if($("#s-94").is(":checked"))
            this.changed.emit(this.status);
        else
            this.changed.emit([]);
    }
    
    current(){
        let status = [];
        $('.checkbox15').each(function(){ //iterate all listed checkbox items
            if(this.checked)
                status.push($(this).val()); //change ".checkbox" checked status
        });
        this.changed.emit(status);
    }
}
