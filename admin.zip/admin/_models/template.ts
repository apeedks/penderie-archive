export class Template {
    id: number;
	title: string;
    content: string;
    section: string;
	active: string;
}