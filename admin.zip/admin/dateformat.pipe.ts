import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
  name: 'dateFormat'
})
export class DateFormatPipe extends DatePipe implements PipeTransform {
  transform(value: any, args?: any): any {
      let date = new Date(value);
      let gf = date.toString();
     let n = gf.toLocaleString();
    return super.transform(n, 'dd/MMM/yyyy hh:mm:ss');
  }
}