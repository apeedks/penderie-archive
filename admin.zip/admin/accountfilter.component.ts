import { Component, OnInit, ViewChild ,Input, EventEmitter, Output, OnChanges } from '@angular/core';
import $ from 'jquery'; 
@Component({
    selector: 'app-accountfilter',
    template: `<div class="inner-filts-bloger">
                                        <div class="our-checkboxs bigst-s-font">
                                             <p><input type="checkbox" id="test155"  name="check[]" (click)="selectaccount()"  /><label for="test155">Status </label></p>
                                        </div>
                                        <ul class="mCustomScrollbar cust-sel-marg">
                                            <div class="our-checkboxs">
                                                <p><input type="checkbox"  class="checkbox151" id="test169"  (change)="current151()"  [checked]="active == 'Both'"   name="check[]" value="Approved" /><label for="test169">Approved</label></p>
                                                <p><input type="checkbox"  class="checkbox151" id="test170"  (change)="current151()"  [checked]="active == 'Men'"    name="check[]" value="Not Approved" /><label for="test170">Not Approved</label></p>
                                                <p><input type="checkbox"  class="checkbox151" id="test171"  (change)="current151()"  [checked]="active == 'Women'"  name="check[]" value="Flag" /><label for="test171">Flag</label></p>
                                                <p><input type="checkbox"  class="checkbox151" id="test172"  (change)="current151()"  [checked]="active == 'Women'"  name="check[]" value="Deleted" /><label for="test172">Deleted</label></p>
                                                <p><input type="checkbox"  class="checkbox151" id="test173"  (change)="current151()"  [checked]="active == 'Women'"  name="check[]" value="Archived" /><label for="test173">Archived</label></p>
                                             </div>
                                        </ul>
                                    </div>`,
    providers: []
})
export class AccountFilterComponent implements OnInit {
    @Output() changed = new EventEmitter();
    @Input() active = '';
    status:any = ['Approved','Not Approved','Flag','Deleted','Archived'];
    constructor(){}
    
    ngOnInit() {
        
    }
    selectaccount()
    {
    console.log('account');
        
        //select all checkboxes
            $("#test155").change(function(){  //"select all" change 
    var status = this.checked; // "select all" checked status
    $('.checkbox151').each(function(){ //iterate all listed checkbox items
        this.checked = status; //change ".checkbox" checked status
    });
});

$('.checkbox151').change(function(){ //".checkbox" change 
    //uncheck "select all", if one of the listed checkbox item is unchecked
    if(this.checked == false){ //if this item is unchecked
        $("#test155")[0].checked = false; //change "select all" checked status to false
    }
    
    //check "select all" if all checkbox items are checked
    if ($('.checkbox151:checked').length == $('.checkbox151').length ){ 
        $("#test155")[0].checked = true; //change "select all" checked status to true
    }
});
            
        if($("#test155").is(":checked"))
            this.changed.emit(this.status);
        else
            this.changed.emit([]);
    }   
    current151(){
        let status = [];
        $('.checkbox151').each(function(){ //iterate all listed checkbox items
            if(this.checked)
                status.push($(this).val()); //change ".checkbox" checked status
        });
        this.changed.emit(status);
    }
    
}
