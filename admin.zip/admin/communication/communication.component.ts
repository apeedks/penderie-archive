import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-communication',
  templateUrl: './communication.component.html',
  styleUrls: ['../nav/adminheader.component.css','./communication.component.css']
})
export class CommunicationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
