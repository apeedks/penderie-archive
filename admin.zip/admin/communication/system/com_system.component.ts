import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';

@Component({
    selector: 'app-system',
    templateUrl: './com_system.component.html',
    styleUrls:['../../nav/adminheader.component.css']
  })

  export class Com_SystemsystemComponent implements OnInit {
    model = {id:0, subjects: '',content: "",code: "",parameters: ""};
    pageSize: number;
    options:any;
    templatetype: string;
    totalitems: any;
    page: number = 1;
    public items:Object;
    public errormsg = '';
    isshowform = false;
    
    constructor(private dbserv:DbserviceService,private _alert: AlertsService,private route: ActivatedRoute) { }
    ngOnInit() {
        this.loadpage(this.page);
    }
    
    loadpage(pageno)
    {
        this.dbserv.getAll("emailtemplates/"+pageno).subscribe(res => {this.items = res.data; this.page = res.current_page; this.totalitems = res.total;this.pageSize = res.per_page;}); 
        this.isshowform = false;
    }
    
    pageChanged($event)
    {
      this.loadpage($event) ; 
    }
    hideform()
    {
        this.isshowform = false;
    }
    editrecord(id)
    {
        this.isshowform = true;
        this.dbserv.getById("emailtemplate",id).subscribe(res => {
                                                    if(res.type=="success")
                                                        this.model=res.data;
                                                    else
                                                        this._alert.create(res.type,res.message);
                                                    });
        
    }
    
    saverecord()
    {
        this.dbserv.save("emailtemplatesave",this.model).subscribe(res => {
                                                              
                                                               //this._alert.create(res.type,res.message);
                                                               if(res.type=="success")
                                                               {
                                                                    this.model = {id:0, subjects: '',content: "",code: "",parameters: ""};
                                                                    this.loadpage(this.page);
                                                                    this.isshowform = false;
                                                               }
                                                             }); 
        
    }
    addrecord()
    {
        this.model = {id:0, subjects: '',content: "",code: "",parameters: ""};
        this.isshowform = true;
        
    }
}
