import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admincommunicationnav',
  templateUrl: './admincommunicationnav.component.html',
  styleUrls:['./admincommunicationnav.component.css']
})
export class Admincommunicationnav implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
