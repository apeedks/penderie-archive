import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Admincommunicationnav } from './admincommunicationnav.component';

describe('Admincommunicationnav', () => {
  let component: Admincommunicationnav;
  let fixture: ComponentFixture<Admincommunicationnav>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Admincommunicationnav ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Admincommunicationnav);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
