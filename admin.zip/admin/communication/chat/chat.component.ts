import { Component, OnInit, OnDestroy, trigger, state, style, transition, animate, Input, Output, EventEmitter, HostListener, ElementRef, ViewChild} from '@angular/core';
import { DbserviceService } from '../../services/dbservice.service';
import { AuthenticationService } from '../../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { AlertsService } from '@jaspero/ng2-alerts';
import { CaretEvent, EmojiEvent, EmojiPickerOptions } from 'angular2-emoji-picker';
import $ from 'jquery';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls:['../../nav/adminheader.component.css']
})

export class SystemchatComponent implements OnInit {
	@ViewChild('postmodalcancel') postmodalcancel:ElementRef;
	@ViewChild('imagemodalcancel') imagemodalcancel:ElementRef;
	@ViewChild('msgScrollDiv') msgScrollDiv:ElementRef;
	dragAreaClass:string='dragarea';
	model = {id:0,toid:0,fromid:0,message:''};
	options:any;
	lastpage: number;
	totalitems: any;
	page: number = 1;
	limit:number = 12;
	params:any = {searchfield:""};
	items = [];
	newitems = [];
	currentlist = 'No';
	myusers = [];
	message: any
	selecteduser = 0;
	searchfield = '';
	searchuserfield = '';
	sortfield = '';
	compliments:any;
	complimentselected = "";
	userid = 0;
	rootpath = '';
	uploadedimage:any=null;
	uploadedimagebtn:boolean=false;
	toggled:boolean=false;
	private _lastCaretEvent: CaretEvent;
	constructor(private emojiPickerOptions: EmojiPickerOptions, private _el: ElementRef, private dbserv:DbserviceService,private authserv: AuthenticationService,private _alert: AlertsService,private route: ActivatedRoute,private router: Router, private cookieService: CookieService) 
	{ 
		this.rootpath = localStorage.getItem('baseurl');
		this.route.params.subscribe(params => {
			if(params['selecteduserid'])
			{
			    this.selecteduser = +params['selecteduserid'];
			}

		    let adminuser = JSON.parse(localStorage.getItem('user'));
			if (adminuser && adminuser.id && adminuser.usertype=="Admin") {
	            this.userid = adminuser.id;
	        }
			this.loadfriends();
			this.dbserv.get("emotics/Inbox").subscribe(res => {this.compliments = res;});
		});
	}
	
	ngOnInit() {
	}
	loadfriends()
	{
		let currentsearch = "-";
		if(this.searchuserfield!="")
			currentsearch = this.searchuserfield;
		let currentsort = "-";
		if(this.sortfield!="")
			currentsort = this.sortfield;
		
		this.dbserv.getAll("admingetAllfriends/"+currentsearch+"/"+currentsort).subscribe(res => {
			this.myusers = res.data;
			if(this.myusers.length > 0){
				if(this.selecteduser == 0){
					this.selecteduser = this.myusers[0].id;
				}
				for (let i = 0; i < this.myusers.length; i++) {
					this.myusers[i].lastMessage = "Not Chated Yet";
					this.myusers[i].lastMessageTime = "";
					this.dbserv.get("getlastmeminbox/"+this.currentlist+"/"+this.myusers[i].id).subscribe(resl => {
						if(resl.records != null){
							this.myusers[i].lastMessage = resl.records.filePath != null ? "Image" : resl.records.message;
							this.myusers[i].lastMessageTime = resl.records.dateadded;
						}
					});  
				}
				this.loadinbox(this.selecteduser);
			}
		});	
	}
	loadinbox(user:number)
	{
		this.params.searchfield = this.searchfield;
		this.dbserv.post("adminmeminbox/"+this.userid+"/"+this.currentlist+"/"+user+"/"+this.page+"/"+this.limit,this.params).subscribe(res => {

			if(res.records.data.length > 0){
				this.items = res.records.data.reverse(); 
			} else {
				this.items = [];
			}
			this.page = res.records.current_page;
			this.lastpage = res.records.last_page; 
			this.totalitems = res.records.total;
			
		}); 
	}
	switchuser(user:number)
	{
		$(".friendlist").removeClass("active");
		$("#friend"+this.currentlist+user).addClass("active");
		this.page = 1;
		this.selecteduser = user;
		this.loadinbox(user);
	}
	showrecords(status)
	{
		this.page = 1;
		this.currentlist = status;	
		this.loadfriends();
	}
	archivememmsg(id,action)
	{
		let arcmodel = {userid:this.userid,msgid:id,status:action}; 
		this.dbserv.save("adminstatusmeminbox",arcmodel).subscribe(res => {
													   if(res.type=="success")
													   {
															this.loadinbox(this.selecteduser);
													   }
													   else
															this._alert.create(res.type,res.message);
													 });	
	}
	showmorerecs()
	{
		this.page = this.page + 1;
		this.dbserv.post("adminmeminbox/"+this.userid+"/"+this.currentlist+"/"+this.selecteduser+"/"+this.page+"/"+this.limit,this.params).subscribe(res => {
			this.items = [ ...res.records.data.reverse(), ...this.items];
			this.page = res.records.current_page;
			this.lastpage = res.records.last_page;
			this.totalitems = res.records.total;
		}); 	
	}
	addcompliments()
	{
		this.chatSend(this.complimentselected);
	}
	chatSend(theirMessage: string) {
			$("#message").attr("disable","true");
		  	this.model.message = theirMessage; 
		  	this.model.toid = this.selecteduser; 
		  	this.model.fromid = this.userid;
		  	this.dbserv.save("adminsavememinbox",this.model).subscribe(res => {
		   	if(res.type=="success")
		   	{
				this.page = 1;
				this.loadinbox(this.selecteduser);
				$("#message").val('');
				this.model.message = "";
				let lastMsg = theirMessage.length > 36 ? theirMessage.substring(0, 36) + "..." : theirMessage;
				$("#lastMsgNo"+this.selecteduser).text(lastMsg);
				this.postmodalcancel.nativeElement.click();
		   	}
		   	else {
		   		this._alert.create(res.type,res.message);
		   	}
		   	$("#message").removeAttr("disable");
		 	});
		  
	}
	
	readImageUrl() {
	  if (this.uploadedimage && this.uploadedimage) {
		var reader = new FileReader();
		var image:any = new Image();
		reader.onload = (event:any) => {
		   image.src = event.target.result; 
		}
		reader.onloadend = (event:any) => {
           image.src = event.target.result; 
        };
		reader.readAsDataURL(this.uploadedimage);
		this.sendImage();
	  }
	}
	onFileChange($event){
	   this.uploadedimage = $event.target.files[0];
	   this.readImageUrl();
	}
	@HostListener('dragover', ['$event']) onDragOver(event) {
        this.dragAreaClass = "droparea";
        event.preventDefault();
    }
	@HostListener('dragenter', ['$event']) onDragEnter(event) {
		this.dragAreaClass = "droparea";
		event.preventDefault();
	}
	@HostListener('dragend', ['$event']) onDragEnd(event) {
		this.dragAreaClass = "dragarea";
		event.preventDefault();
	}
	@HostListener('dragleave', ['$event']) onDragLeave(event) {
		this.dragAreaClass = "dragarea";
		event.preventDefault();
	}
	@HostListener('drop', ['$event']) onDrop(event) {   
		this.dragAreaClass = "dragarea";           
		event.preventDefault();
		event.stopPropagation();
		this.uploadedimage = event.dataTransfer.files[0];
		this.readImageUrl();
	}
	sendImage(){
		
		if(this.uploadedimage!=null)
		{
			this.uploadedimagebtn = true;
			let _formData = new FormData();
			_formData.append("toid",this.selecteduser.toString());
			_formData.append('imagesrc',this.uploadedimage, this.uploadedimage.name);
			this.dbserv.saveimage("sendimageinbox",_formData).subscribe(res => {
				if(res.type=="success")
	   			{	
	   				this.page = 1;
					this.loadinbox(this.selecteduser);
					$("#lastMsgNo"+this.selecteduser).text("Image");
	   				this.imagemodalcancel.nativeElement.click();
	   				this.uploadedimagebtn = false;
	   			} else {
					this._alert.create(res.type,res.message);
					this.uploadedimagebtn = false;
				}
			}); 
		}
		else
		{
			this._alert.create('error','Please, select an image first.');
		}
	}
	handleSelection(event: EmojiEvent) {
		if(typeof this.message !== "undefined"){
			this.message = this.message+event.char;
		} else {
			this.message =  event.char;
		}
		console.log("emoji=",this.message);
	}
}
