import { Component, OnInit, AfterViewChecked, ElementRef, ViewChild, HostListener} from '@angular/core';
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { DbserviceService } from '../../services/dbservice.service';
import { AlertsService } from '@jaspero/ng2-alerts';
import { DataTable } from 'angular-4-data-table/src/index';
import { IMyDpOptions,IMyDateModel } from 'mydatepicker';
import { ImageCropperComponent, CropperSettings, Bounds } from 'ng2-img-cropper';
import $ from 'jquery';

@Component({
  selector: 'app-email',
  templateUrl: './email.component.html',
  styleUrls:['../../nav/adminheader.component.css']
})
export class SystememailComponent implements OnInit {

  constructor(private dbserv:DbserviceService,private _alert: AlertsService,private route: ActivatedRoute,private router: Router){ }

  ngOnInit() {
  }

}
