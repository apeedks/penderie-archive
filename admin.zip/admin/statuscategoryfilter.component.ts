import { Component, OnInit, ViewChild ,Input, EventEmitter, Output, OnChanges } from '@angular/core';
import $ from 'jquery';
@Component({
    selector: 'app-statuscategoryfilter',
    template: `<div class="inner-filts-bloger">
              <div class="our-checkboxs bigst-s-font">
                  <p><input type="checkbox" id="s-99"   name="check[]" (change)="selectstatus()"  /><label for="s-99">Status </label></p>
              </div>
              <ul class="mCustomScrollbar cust-sel-marg">
                  <div class="our-checkboxs">
                      <p><input type="checkbox"  class="checkbox88"  id="s-83" (change)="current()"  name="check[]"  [checked]="active == 'Published'"  value="Published" /><label for="s-83" >Published</label></p>
                      <p><input type="checkbox"  class="checkbox88"  id="s-84" (change)="current()"  name="check[]"  [checked]="active == 'Draft'"   value="Draft" /><label for="s-84">Draft</label></p>
                      <p><input type="checkbox"  class="checkbox88"  id="s-85" (change)="current()"  name="check[]"  [checked]="active == 'Archived'"  value="Archived" /><label for="s-85">Archived</label></p>
                      <p><input type="checkbox"  class="checkbox88"  id="s-89" (change)="current()"  name="check[]"  [checked]="active == 'Trash'"  value="Trash" /><label for="s-89">Trash</label></p>
                   </div>
              </ul>
          </div>`,
    providers: []
})
export class StatusCategoryFilterComponent implements OnInit {
	@Output() changed = new EventEmitter();
	@Input() active = '';
	status:any = ['Published','Draft','Archived','Trash'];
	constructor(){}
	
	ngOnInit() {
		
	}
	selectstatus()
	{
		//select all checkboxes
		$("#s-99").change(function(){  //"select all" change 
		    var cstatus = this.checked; // "select all" checked status
    		$('.checkbox88').each(function(){ //iterate all listed checkbox items
        		this.checked = cstatus; //change ".checkbox" checked status
    		});
		});

		$('.checkbox88').change(function(){ //".checkbox" change 
    		//uncheck "select all", if one of the listed checkbox item is unchecked
    		if(this.checked == false){ //if this item is unchecked
        		$("#s-99")[0].checked = false; //change "select all" checked status to false
    		}
    
    		//check "select all" if all checkbox items are checked
    		if ($('.checkbox88:checked').length == $('.checkbox88').length ){ 
        		$("#s-99")[0].checked = true; //change "select all" checked status to true
    		}
		});
		
		if($("#s-99").is(":checked"))
			this.changed.emit(this.status);
		else
			this.changed.emit([]);
	}
	
	current(){
		let status = [];
		$('.checkbox88').each(function(){ //iterate all listed checkbox items
			if(this.checked)
				status.push($(this).val()); //change ".checkbox" checked status
    	});
		this.changed.emit(status);
	}
}
