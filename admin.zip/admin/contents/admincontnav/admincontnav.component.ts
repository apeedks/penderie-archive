import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import $ from 'jquery';
@Component({
  selector: 'app-admincontnav',
  templateUrl: './admincontnav.component.html',
  styleUrls: ['./admincontnav.component.css']
})
export class AdmincontnavComponent implements OnInit {
	currentpage:string = '';
	constructor(router: Router) { 
		switch(router.url)
		{
			case "/admin/contents/page":
				this.currentpage = 'pages';
				break;
			case "/admin/contents/pagetemplates":
				this.currentpage = 'pagetemplates';
				break;
			case "/admin/contents/themepages":
				this.currentpage = 'themepages';
				break;
			case "/admin/contents/faqs":
				this.currentpage = 'faqs';
				break;
			
		}	
	}
	
	ngOnInit() {
	}

}
