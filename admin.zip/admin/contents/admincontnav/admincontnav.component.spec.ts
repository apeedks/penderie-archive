import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmincontnavComponent } from './admincontnav.component';

describe('AdmincontnavComponent', () => {
  let component: AdmincontnavComponent;
  let fixture: ComponentFixture<AdmincontnavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdmincontnavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdmincontnavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
