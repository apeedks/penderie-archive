import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MagazinetagsComponent } from './magazinetags.component';

describe('MagazinetagsComponent', () => {
  let component: MagazinetagsComponent;
  let fixture: ComponentFixture<MagazinetagsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MagazinetagsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MagazinetagsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
