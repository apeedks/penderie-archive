import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MagazinecatsComponent } from './magazinecats.component';

describe('MagazinecatsComponent', () => {
  let component: MagazinecatsComponent;
  let fixture: ComponentFixture<MagazinecatsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MagazinecatsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MagazinecatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
