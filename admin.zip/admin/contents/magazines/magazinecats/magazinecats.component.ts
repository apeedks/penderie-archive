import { Component, OnInit, ViewChild} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import {DataTable} from 'angular-4-data-table/src/index';
import $ from 'jquery';
@Component({
  selector: 'app-magazinecats',
  templateUrl: './magazinecats.component.html',
  styleUrls: ['../../../nav/adminheader.component.css']
})
export class MagazinecatsComponent implements OnInit {
	public items = [];
	model = {id:0, title: '',theme:"",gender:"",parentid:0,active:""};
	options:any;
	parentid:number = 0;
	pageSize: number;
	totalitems: any;
	page: number = 1;
	last_page: number =1;
	public defaultparam = {sortBy:"id", sortAsc:true,offset:0,limit:10,filtertype:"All",sortfield:"All",searchstr:"",status:[],gender:[],theme:[]};
	filterfield:string='All';
	filtertype:string='All';
	isshowform = false;
	currentlist:string = 'All';
	applybtnval:string = '';
	headerimage:string = '';
	uploadedimage = null;
	sortfield:string = 'All';
	selectedrecs	= [];
	searchfield:string = '';
	selecttag:any;
	summary = {Published:0,Trash:0,Unpublished:0,Total:0};
	visiblefilter = false;
	custo_filter_onen_close = false;
	searchgender:string = "Both";
	
	@ViewChild(DataTable) recTable: DataTable;
	
	constructor(private dbserv:DbserviceService,private _alert: AlertsService,private route: ActivatedRoute,private router: Router) 
	{
		this.searchgender = localStorage.getItem('visittype');
		this.route.params.subscribe(params => {
			if(params['parentid'])
			{
			    this.parentid = +params['parentid'];
				this.loadpage(this.defaultparam);
			}
			else
			    this.parentid = 0;
		});
		/*alert('hellow')*/

		
	}
	ngOnInit() {
		
	}
	statusselectedchange()
	{
		if(this.applybtnval!='')
		{
			if(this.recTable.selectedRows.length>0)
			{
				if(confirm('Are you sure?'))
				{
					this.selectedrecs=[];
					for(var i = 0;i<this.recTable.selectedRows.length;i++) 
					{ 
						this.selectedrecs.push(this.recTable.selectedRows[i].item.id);
					}
					let newmodel = {'action':this.applybtnval,'vals':JSON.stringify(this.selectedrecs)};
					this.dbserv.save("magazinecatsperformaction",newmodel).subscribe(res => {
																   this._alert.create(res.type,res.message);
																   if(res.type=="success")
																   {
																		this.loadpage(this.defaultparam);
																		this.isshowform = false;
																   }
																 });
				}
			}
			else
			{
				this._alert.create('error','Please, select some record first.');
			}
		}
		
	}
	statuschange(id:number,action:string)
	{
		if(confirm('Are you sure?'))
		{
			this.selectedrecs=[id];
			this.applybtnval = action;
			let newmodel = {'action':this.applybtnval,'vals':JSON.stringify(this.selectedrecs)};
			this.dbserv.save("magazinecatsperformaction",newmodel).subscribe(res => {
															   this._alert.create(res.type,res.message);
															   if(res.type=="success")
															   {
																	this.loadpage(this.defaultparam);
																	this.isshowform = false;
															   }
														}); 
		}
	}
	
	changetheme(event:any){
		console.log(event);
		this.defaultparam.theme = event;
		this.loadpage(this.defaultparam);
	}
	
	changestatus(event:any){
		console.log(event);
		this.defaultparam.status = event;
	    this.filterfield = 'All';
	    this.currentlist = 'All';
		this.loadpage(this.defaultparam);
	}
	
	changegender(event:any){
		console.log(event);
		this.defaultparam.gender = event;
		this.loadpage(this.defaultparam);
	}
	
	fileChange($event){
		this.uploadedimage = $event.target.files[0];
	}
	sortchanged()
	{
		this.defaultparam.sortfield = this.sortfield;
		this.defaultparam.sortBy = '';
		this.loadpage(this.defaultparam);
	}
	loadpage(params:any)
	{
		params.searchstr = this.searchfield;
		params.filtertype = this.filtertype;
		params.status = this.defaultparam.status;
		params.gender = this.defaultparam.gender;
		params.theme = this.defaultparam.theme;
		this.dbserv.post("magazinecats/"+this.searchgender+"/"+this.currentlist+"/"+this.parentid,params).subscribe(res => {
																			this.items = res.data; 
																			this.page = res.current_page; 
																			this.totalitems = res.total;
																			this.pageSize = res.per_page;
																			this.last_page = res.last_page;
																			this.dbserv.post("magazinecatsummary/"+this.searchgender+"/"+this.currentlist+"/"+this.parentid,params).subscribe(res => {
																				this.summary = res;
																			}); 
																		}); 
		this.defaultparam = params;
		this.isshowform = false;
	}
	switchcurrentlist()
	{
		this.currentlist = this.filterfield;
		this.loadpage(this.defaultparam);
	}
	hideform()
	{
		this.isshowform = false;
	}
	editrecord(id)
	{
		this.isshowform = true;
		this.dbserv.getById("magazinecat",id).subscribe(res => {
													if(res.type=="success")
													{
														this.model = res.data;
													}
													else
														this._alert.create(res.type,res.message);
													});
	}
	deleterecord(id)
	{
		if(confirm('Are you sure?'))
		{
			this.isshowform = false;
			this.dbserv.delete("magazinecatdel", id).subscribe(res => { this._alert.create(res.type,res.message);this.loadpage(this.defaultparam);});
		}
	}
	changevalue(type:string)
	{
		this.model.active = type;
	}
	saverecord()
	{
		this.model.parentid = this.parentid;
		this.dbserv.save("magazinecatsave",this.model).subscribe(res => {
															  
															   this._alert.create(res.type,res.message);
															   if(res.type=="success")
															   {
															    	this.model = {id:0, title: '',theme:"",gender:"",parentid:0,active:""};
																	this.loadpage(this.defaultparam);
																	this.isshowform = false;
															   }
															 }); 
	}
	addrecord()
	{
		this.model = {id:0, title: '',theme:"",gender:"",parentid:0,active:""};
		this.isshowform = true;
		
	}
/*	filterby()
	{
		this.visiblefilter = !this.visiblefilter;
		if(this.visiblefilter)
		{
			this.custo_filter_onen_close = true;
		}
		else
		{
			this.custo_filter_onen_close = false;	
		}
	}*/
	  ngAfterViewInit() {
	      $(".custo-filter-colap").click(function(e){
	        if(!$(this).hasClass('custo_filter_onen_close')){
	          $(this).next(".utl-filter-box").addClass('visiblefilter');
	          $(this).addClass('custo_filter_onen_close');
	          e.stopPropagation();
	        }else{
	          $(".utl-filter-box").removeClass('visiblefilter');
	          $(".custo-filter-colap").removeClass('custo_filter_onen_close');
	          e.stopPropagation();
	        }
	      });

	      $(".utl-filter-box").click(function(e){
	        e.stopPropagation();
	      });

	      $(document).click(function(){
	        $(".utl-filter-box").removeClass('visiblefilter');
	        $(".custo-filter-colap").removeClass('custo_filter_onen_close');
	      });
	    }
	  clickfortotalitem()
	  {      
	      this.filterfield = 'All';
	      this.currentlist = 'All';
	      this.filtertype = 'All';
	      this.defaultparam.status=[];
	      this.defaultparam.theme=[];
	      this.defaultparam.gender=[]; 
	  }
	   key_down(e) {
	       console.log(e);
	       if(e.target.value == '')
	       {
	         this.loadpage(this.defaultparam);
	       }
	           if(e.keyCode === 13) {
	                 this.loadpage(this.defaultparam);
	         }
	       }
}
