import { Component, OnInit, ViewChild} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import {DataTable} from 'angular-4-data-table/src/index';

@Component({
  selector: 'app-loupetags',
  templateUrl: './loupetags.component.html',
  styleUrls: ['../../../nav/adminheader.component.css']
})
export class LoupetagsComponent implements OnInit {
	public items = [];
	model = {id:0, tag: '',active:""};
	options:any;
	parentid:number = 0;
	pageSize: number;
	totalitems: any;
	page: number = 1;
	last_page: number =1;
	public defaultparam = {sortBy:"id", sortAsc:true,offset:0,limit:10,filtertype:"All",searchstr:""};
	filterfield:string='All';
	filtertype:string='All';
	isshowform = false;
	currentlist:string = 'All';
	applybtnval:string = '';
	headerimage:string = '';
	uploadedimage = null;
	selectedrecs	= [];
	searchfield:string = '';
	summary = {Published:0,Trash:0,Workinprogress:0,Total:0}; 
	searchgender:string = "Both";
	@ViewChild(DataTable) recTable: DataTable;
	
	constructor(private dbserv:DbserviceService,private _alert: AlertsService,private route: ActivatedRoute,private router: Router) 
	{
	}
	ngOnInit() {
		
	}
	statusselectedchange()
	{
		if(this.applybtnval!='')
		{
			if(this.recTable.selectedRows.length>0)
			{
				if(confirm('Are you sure?'))
				{
					this.selectedrecs=[];
					for(var i = 0;i<this.recTable.selectedRows.length;i++) 
					{ 
						this.selectedrecs.push(this.recTable.selectedRows[i].item.id);
					}
					let newmodel = {'action':this.applybtnval,'vals':JSON.stringify(this.selectedrecs)};
					this.dbserv.save("loupetagsperformaction",newmodel).subscribe(res => {
																   if(res.type=="success")
																	{
                                                                        this._alert.create(res.type,res.message);
																		this.loadpage(this.defaultparam);
																		this.isshowform = false;
																	}
																	else if(res.type=="expired")
																	{
																		this.router.navigateByUrl('/admin/login') ;	
																	}
																	else
																	{
																		this._alert.create(res.type,res.message);
																	}
															}); 
				}
			}
			else
			{
				this._alert.create('error','Please, select some record first.');
			}
		}
		
	}
	statuschange(id:number,action:string)
	{
		if(confirm('Are you sure?'))
		{
			this.selectedrecs=[id];
			this.applybtnval = action;
			let newmodel = {'action':this.applybtnval,'vals':JSON.stringify(this.selectedrecs)};
			this.dbserv.save("loupetagsperformaction",newmodel).subscribe(res => {
															   if(res.type=="success")
																{
                                                                    this._alert.create(res.type,res.message);
																	this.loadpage(this.defaultparam);
																	this.isshowform = false;
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/admin/login') ;	
																}
																else
																{
																	this._alert.create(res.type,res.message);
																}
														}); 
		}
	}
	
	fileChange($event){
		this.uploadedimage = $event.target.files[0];
	}
	loadpage(params:any)
	{
		params.searchstr = this.searchfield;
		params.filtertype = this.filtertype;
		this.dbserv.post("loupetags/"+this.currentlist,params).subscribe(res => {
																			if(res.type=="success")
																			{
																				this.items = res.records.data; 
																				this.page = res.records.current_page; 
																				this.totalitems = res.records.total;
																				this.pageSize = res.records.per_page;
																				this.last_page = res.records.last_page;
																				this.dbserv.post("loupetagssummary/"+this.currentlist,params).subscribe(res => {
																					this.summary = res.records;
																				});
																			}
																			else if(res.type=="expired")
																			{
																				this.router.navigateByUrl('/admin/login') ;	
																			}
																			else
																			{
																				this._alert.create(res.type,res.message);
																			}
																}); 
		this.defaultparam = params;
		this.isshowform = false;
	}
	switchcurrentlist()
	{
		this.currentlist = this.filterfield;
		this.loadpage(this.defaultparam);
	}
	hideform()
	{
		this.isshowform = false;
	}
	editrecord(id)
	{
		this.isshowform = true;
		this.dbserv.getById("loupetag",id).subscribe(res => {
													if(res.type=="success")
													{
														this.model = res.data;
													}
													else if(res.type=="expired")
													{
														this.router.navigateByUrl('/admin/login') ;	
													}
													else
													{
														this._alert.create(res.type,res.message);
													}
											});
	}
	deleterecord(id)
	{
		if(confirm('Are you sure?'))
		{
			this.isshowform = false;
			this.dbserv.delete("loupetagsdel", id).subscribe(res => { 
														if(res.type=="success")
														{
															this.loadpage(this.defaultparam);
														}
														else if(res.type=="expired")
														{
															this.router.navigateByUrl('/admin/login') ;	
														}
														else
														{
															this._alert.create(res.type,res.message);
														}
													});
		}
	}
	changevalue(type:string)
	{
		this.model.active = type;
	}
	saverecord()
	{
		this.dbserv.save("loupetagssave",this.model).subscribe(res => {
															    if(res.type=="success")
																{
																	this.model = {id:0, tag: '',active:""};
																	this.loadpage(this.defaultparam);
																	this.isshowform = false;
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/admin/login') ;	
																}
																else
																{
																	this._alert.create(res.type,res.message);
																}
														}); 
	}
	addrecord()
	{
		this.model = {id:0, tag: '',active:""};
		this.isshowform = true;
	}
    key_down(e) {
    console.log(e);
  if(e.target.value == '')
  {
    this.loadpage(this.defaultparam);
  }
      if(e.keyCode === 13) {
            this.loadpage(this.defaultparam);
    }
  }   
}
