import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminemailsComponent } from './adminemails.component';

describe('AdminemailsComponent', () => {
  let component: AdminemailsComponent;
  let fixture: ComponentFixture<AdminemailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminemailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminemailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
