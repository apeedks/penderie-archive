import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StorytagsComponent } from './storytags.component';

describe('StorytagsComponent', () => {
  let component: StorytagsComponent;
  let fixture: ComponentFixture<StorytagsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StorytagsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StorytagsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
