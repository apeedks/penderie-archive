import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StorycatsComponent } from './storycats.component';

describe('StorycatsComponent', () => {
  let component: StorycatsComponent;
  let fixture: ComponentFixture<StorycatsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StorycatsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StorycatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
