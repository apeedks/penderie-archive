import { Component, OnInit, ElementRef,ViewChild, HostListener} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import {DataTable} from 'angular-4-data-table/src/index';
import {ImageCropperComponent, CropperSettings, Bounds} from 'ng2-img-cropper';
import $ from 'jquery';

@Component({
  selector: 'app-stories',
  templateUrl: './stories.component.html',
  styleUrls: ['../../nav/adminheader.component.css']
})
export class StoriesComponent implements OnInit {
	parentMessage = "message from parent";
	public items = [];
	model = {id:0, title: '',category_id:"",user_id:0,credits:"",description:"",image:null,tags:[],gender:"",theme:"",imagetitle:"",active:"",shortdesc:"",mediatitle:"",mediacredit:"",mediadesc:""};
	options:any;
	pageSize: number;
	totalitems: any;
	categories: any;
	page: number = 1;
	last_page: number =1;
	public defaultparam = {sortBy:"id", sortAsc:true,offset:0,limit:10,filtertype:"All",sortfield:"All",searchstr:"", tagid:0, catid:0,status:[],gender:[],theme:[],featured:[]};
	filterfield:string='All';
	filtertype:string='All';
	isshowform = false;
	currentlist:string = 'All';
	applybtnval:string = '';
	headerimage:string = '';
	uploadedimage = null;
	sortfield:string = 'All';
	selectedrecs	= [];
	filtercatids:any = [];
	searchfield:string = '';
	selecttag:any;
	selectcat:any;
	summary = {Published:0,Draft:0,Trash:0,Unpublished:0,Total:0}; 
	searchgender:string = "Both";
	@ViewChild(DataTable) recTable: DataTable;
	@ViewChild('theme') theme:ElementRef;
	currtime:any;
	rootpath:string;
	tagslist:any;
    visiblefilter = false;
    custo_filter_onen_close = false;
	settings = {};
	showimage=false;

	// for image uploader

	@ViewChild('lnksaveprofilebox') lnksaveprofilebox:ElementRef;
	imagedata:any;
	cropperSettings:CropperSettings;
	croppedWidth:number;
	croppedHeight:number;
	dragAreaClass:string='dragarea';
	uploadedsymbol:any=null;
	symbolimage = '';
	uploadedimagebtn:boolean=false;
	uploadedsymbolbtn:boolean=false;
	imagepreviewurl:string='';

	@ViewChild('cropper', undefined) cropper:ImageCropperComponent;

	constructor(private dbserv:DbserviceService,private _alert: AlertsService,private route: ActivatedRoute,private router: Router) 
	{
		this.searchgender = localStorage.getItem('visittype');
		this.rootpath = localStorage.getItem('baseurl');
		this.model.tags = [];
		this.dbserv.getAll("storytagslist").subscribe(res => { this.tagslist = res.records;});
		
		this.settings = { 
								  singleSelection: false, 
								  text:"Select Tags",
								  selectAllText:'Select All',
								  unSelectAllText:'UnSelect All',
								  enableSearchFilter: true,
								  limitSelection:10,
								  enableCheckAll:false,
								  classes:"myclass custom-class"
								};  

		// for image 
		this.rootpath = localStorage.getItem('baseurl');
		this.cropperSettings = new CropperSettings();
		this.cropperSettings.width = 1920;
		this.cropperSettings.height = 1280;
		this.cropperSettings.croppedWidth = 1920;
		this.cropperSettings.croppedHeight = 1280;
		this.cropperSettings.canvasWidth = 420;
		this.cropperSettings.noFileInput = true;
		this.cropperSettings.canvasHeight = 300;
		this.cropperSettings.touchRadius = 20;
		this.cropperSettings.rounded = false;
		this.cropperSettings.keepAspect = true;
		this.imagedata = {};
			
	  this.route.params.subscribe(params => {
			if(params['type'] == 'cat'){
				if(params['id']){
					this.selectcat = +params['id'];
				}
				else{
					this.selectcat = 0;
				}
			}else{
				if(params['id']){
					this.selecttag = +params['id'];
				}
				else{
					this.selecttag = 0;
				}
			}
			this.defaultparam.tagid = this.selecttag;
			this.defaultparam.catid = this.selectcat;
			this.loadpage(this.defaultparam);

		});

	}


// for image
	  cropped(bounds:Bounds) {
	this.croppedHeight =bounds.bottom-bounds.top;
	this.croppedWidth = bounds.right-bounds.left;
  }
  
  fileChangeListener($event) {
	var image:any = new Image();
	var file:File = $event.target.files[0];
	var myReader:FileReader = new FileReader();
	var that = this;
	myReader.onloadend = function (loadEvent:any) {
		image.src = loadEvent.target.result;
		that.cropper.setImage(image);

	};

	myReader.readAsDataURL(file);
	}

		previewFile(file) {
		console.log(file);
		var request = new XMLHttpRequest();
		request.open('GET', file, true);
		request.responseType = 'blob';
		var image:any = new Image();
		request.onload = () => {
			var reader = new FileReader();
			reader.readAsDataURL(request.response);
			reader.onload = (event:any) => {
				image.src = event.target.result; 
				this.cropper.setImage(image);
			};
			reader.onloadend = (event:any) => {
				image.src = event.target.result; 
				this.cropper.setImage(image);
			};
		};
		request.send();
	}
	readImageUrl() {
	  if (this.uploadedimage && this.uploadedimage) {
		var reader = new FileReader();
		var image:any = new Image();
		reader.onload = (event:any) => {
		   image.src = event.target.result; 
			this.cropper.setImage(image);
		}
		reader.onloadend = (event:any) => {
		   image.src = event.target.result; 
			this.cropper.setImage(image);
		};
		reader.readAsDataURL(this.uploadedimage);
	  }
	}


	onSymbolChange($event){
		this.uploadedsymbol = $event.target.files[0];
	}
	onFileChange($event){
	   this.uploadedimage = $event.target.files[0];
	   this.readImageUrl();
	   //this.saveprofileimage( $event.target.files[0]);
	}
	@HostListener('dragover', ['$event']) onDragOver(event) {
		this.dragAreaClass = "droparea";
		event.preventDefault();
	}
	@HostListener('dragenter', ['$event']) onDragEnter(event) {
		this.dragAreaClass = "droparea";
		event.preventDefault();
	}
	@HostListener('dragend', ['$event']) onDragEnd(event) {
		this.dragAreaClass = "dragarea";
		event.preventDefault();
	}
	@HostListener('dragleave', ['$event']) onDragLeave(event) {
		this.dragAreaClass = "dragarea";
		event.preventDefault();
	}
	@HostListener('drop', ['$event']) onDrop(event) {   
		this.dragAreaClass = "dragarea";           
		event.preventDefault();
		event.stopPropagation();
		this.uploadedimage = event.dataTransfer.files[0];
		this.readImageUrl();
		//this.saveprofileimage(event.dataTransfer.files[0]);
	}



	saveprofileimage(){
		this.lnksaveprofilebox.nativeElement.click();
		this.showimage = true;
	}


 // *************************************************************



	loadddl()
	{
		this.categories = [];
		this.dbserv.getAll("storycatlist/"+this.model.theme+'/'+this.searchgender)
		.subscribe(res => {
			this.categories = res;
		});
	}
	ngOnInit() {
		this.model.theme = '-';
		this.loadddl();
	}
	statusselectedchange()
	{
		if(this.applybtnval!='')
		{
			if(this.recTable.selectedRows.length>0)
			{
				if(confirm('Are you sure?'))
				{
					this.selectedrecs=[];
					for(var i = 0;i<this.recTable.selectedRows.length;i++) 
					{ 
						this.selectedrecs.push(this.recTable.selectedRows[i].item.id);
					}
					let newmodel = {'action':this.applybtnval,'vals':JSON.stringify(this.selectedrecs)};
					this.dbserv.save("storiesperformaction",newmodel).subscribe(res => {
																	if(res.type=="success")
																{
																	this._alert.create(res.type,res.message);
																	this.loadpage(this.defaultparam);
																	this.isshowform = false;
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/admin/login') ;	
																}
																else
																{
																	this._alert.create(res.type,res.message);
																}																 
															}); 
				}
			}
			else
			{
				this._alert.create('error','Please, select some record first.');
			}
		}
		
	}
	statuschange(id:number,action:string)
	{
		if(confirm('Are you sure?'))
		{
			this.selectedrecs=[id];
			this.applybtnval = action;
			let newmodel = {'action':this.applybtnval,'vals':JSON.stringify(this.selectedrecs)};
			this.dbserv.save("storiesperformaction",newmodel).subscribe(res => {
																if(res.type=="success")
																{
																	this._alert.create(res.type,res.message);
																	this.loadpage(this.defaultparam);
																	this.isshowform = false;
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/admin/login') ;	
																}
																else
																{
																	this._alert.create(res.type,res.message);
																}
														}); 
		}
	}
	
	sortchanged()
	{
		this.defaultparam.sortfield = this.sortfield;
		this.defaultparam.sortBy = '';
		this.loadpage(this.defaultparam);
	}
	
	loadpage(params:any)
	{
		params.searchstr = this.searchfield;
		params.filtertype = this.filtertype;
		params.catid = this.selectcat;
		params.tagid = this.selecttag;
		params.filtercat = this.filtercatids;
		params.status = this.defaultparam.status;
		params.gender = this.defaultparam.gender;
		params.theme = this.defaultparam.theme;
		params.featured = this.defaultparam.featured;
		this.currtime = Math.random();
		this.dbserv.post("stories/"+this.searchgender+"/"+this.currentlist,params).subscribe(res => {
																			if(res.type=="success")
																			{
																				this.items = res.records.data; 
																				this.page = res.records.current_page; 
																				this.totalitems = res.records.total;
																				this.pageSize = res.records.per_page;
																				this.last_page = res.records.last_page;
																				this.dbserv.post("storiessummary/"+this.searchgender+"/"+this.currentlist,params).subscribe(res => {
																					this.summary = res.records;
																				});
																			}
																			else if(res.type=="expired")
																			{
																				this.router.navigateByUrl('/admin/login') ;	
																			}
																			else
																			{
																				this._alert.create(res.type,res.message);
																			}
																		}); 
		this.defaultparam = params;
		this.isshowform = false;
	}
	switchcurrentlist()
	{
		this.currentlist = this.filterfield;
		this.loadpage(this.defaultparam);
	}
	hideform()
	{
		this.isshowform = false;
		this.cropper.reset();
		this.uploadedimagebtn = false;
	}
	editrecord(id)
	{
		this.isshowform = true;
		this.showimage = false;
		this.dbserv.getById("story",id).subscribe(res => {
													if(res.type=="success")
													{
														this.model = res.data;
														this.loadddl();
													}
													else if(res.type=="expired")
													{
														this.router.navigateByUrl('/admin/login') ;	
													}
													else
														this._alert.create(res.type,res.message);
													});
	}
	deleterecord(id)
	{
		if(confirm('Are you sure?'))
		{
			this.isshowform = false;
			this.dbserv.delete("storiesdel", id).subscribe(res => { 
																if(res.type=="success")
																{
																	this.loadpage(this.defaultparam);
																	this._alert.create(res.type,res.message);
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/admin/login') ;	
																}
																else
																	this._alert.create(res.type,res.message);
														   });
		}
	}
	changevalue(type:string)
	{
		this.model.active = type;
	}
	fileChange($event){
		console.log($event.target.files[0]);
		this.uploadedimage = $event.target.files[0];
	}
	saverecord()
	{

		this.uploadedimagebtn = true;
		let _formData = new FormData();
		_formData.append("id",this.model.id.toString());
		_formData.append("title",this.model.title);
        _formData.append("shortdesc",this.model.shortdesc);
		_formData.append("category_id",this.model.category_id.toString());
        _formData.append("gender",this.model.gender);
		_formData.append("gender",this.searchgender);
		let mytags:string = '';
		if(this.model.tags.length>0)
		{
			for(let i=0;i<this.model.tags.length;i++)
			{
				if(mytags=='')
					mytags = '-'+this.model.tags[i].id.toString()+'-';
				else
					mytags += ',-'+this.model.tags[i].id.toString()+'-';
				_formData.append("tags",mytags);
			}
		}
		
		_formData.append("theme",this.model.theme);
		_formData.append("credits",this.model.credits);
		_formData.append("description",this.model.description);
		_formData.append("imagetitle",this.model.imagetitle);
            _formData.append("mediatitle",this.model.mediatitle);
            _formData.append("mediacredit",this.model.mediacredit);
            _formData.append("mediadesc",this.model.mediadesc);
		_formData.append("active",this.model.active);
		
	// Image 

		if(this.uploadedimage!=null && this.uploadedimage.name!='')
		{
			_formData.append('image',this.uploadedimage, this.uploadedimage.name);
			_formData.append('imagesrc',this.uploadedimage, this.uploadedimage.name);
		}
		if(this.imagedata.image != '' && this.imagedata.image != null)
		{
			_formData.append('image',this.imagedata.image);
		}

		// *****************


		this.dbserv.saveimage("storiessave",_formData).subscribe(res => {
																if(res.type=="success")
																{
																	this._alert.create(res.type,res.message);
																	this.model = {id:0, title: '',category_id:"",user_id:0,credits:"",description:"",image:null,tags:[],gender:"",theme:"",imagetitle:"",active:"",shortdesc:"",mediatitle:"",mediacredit:"",mediadesc:""};
																	this.loadpage(this.defaultparam);
																	this.isshowform = false;

																	this.imagedata={};
																	this.uploadedimage=null;
																	this.cropper.reset();
																	this.uploadedimagebtn = false;
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/admin/login') ;	
																}
																else
																console.log();
																	this._alert.create(res.type,res.message);
																			
														}); 
	}
   changetheme(event:any){
	console.log(event);
	this.defaultparam.theme = event;
	this.loadpage(this.defaultparam);
  }
  
  changestatus(event:any){
	console.log(event);
	this.defaultparam.status = event;
	this.filterfield = 'All';
    this.currentlist = 'All';
	this.loadpage(this.defaultparam);
  }
  changegender(event:any){
        console.log(event);
        this.defaultparam.gender = event;
        this.loadpage(this.defaultparam);
    }
    changefeatured(event:any){
        console.log(event);
        this.defaultparam.featured = event;
        this.loadpage(this.defaultparam);
    }
	addrecord()
	{
	    this.showimage = false;
		this.uploadedimagebtn = true;
		this.model = {id:0, title: '',category_id:"",user_id:0,credits:"",description:"",image:null,tags:[],gender:"",theme:"",imagetitle:"",active:"",shortdesc:'',mediatitle:"",mediacredit:"",mediadesc:""};
		this.isshowform = true;
		this.imagedata={};
		this.uploadedimage=null;
		this.cropper.reset();
		this.uploadedimagebtn = false;
		
	}
	onItemSelect(item:any){
		console.log(item);
		console.log(this.model.tags);
	}
	OnItemDeSelect(item:any){
		console.log(item);
		console.log(this.model.tags);
	}
	onSelectAll(items: any){
		console.log(this.model.tags);
	}
	onDeSelectAll(items: any){
		console.log(this.model.tags);
	}
/*	filterby()
	{
	  this.visiblefilter = !this.visiblefilter;
	  if(this.visiblefilter)
	{
	  this.custo_filter_onen_close = true;
	}
	else
	{
	  this.custo_filter_onen_close = false; 
	}
  }*/
  filtercat(){
		this.filtercatids = [];
		this.categories.forEach(obj=>{
			if(obj.checked)
				this.filtercatids.push(obj.id);
		});
		this.loadpage(this.defaultparam);
	}
	selecallcat(event){
		this.filtercatids = [];
		this.categories.forEach(obj=>{
			obj.checked = event.target.checked;
			if(obj.checked)
				this.filtercatids.push(obj.id);
		});
		this.loadpage(this.defaultparam);
	}
	publishvalue(id:number,type:string)
	{
		if(confirm('Are you sure?'))
		{
			this.selectedrecs=[id];
			if(type == 'Yes'){
				type = 'No';
			}else{
				type = 'Yes';
			}
			
			let newmodel = {'action':type,'vals':JSON.stringify(this.selectedrecs)};
			this.dbserv.save("storiesfeaturedupdate",newmodel)
			.subscribe(res => {
					if(res.type=="success")
					{
						this._alert.create(res.type,res.message);
						this.loadpage(this.defaultparam);
						this.isshowform = false;
					}
					else if(res.type=="expired")
					{
						this.router.navigateByUrl('/admin/login') ;	
					}
					else
					{
						this._alert.create(res.type,res.message);
					}
			}); 
		}
	}
    ngAfterViewInit() {
        $(".custo-filter-colap").click(function(e){
          if(!$(this).hasClass('custo_filter_onen_close')){
            $(this).next(".utl-filter-box").addClass('visiblefilter');
            $(this).addClass('custo_filter_onen_close');
            e.stopPropagation();
          }else{
            $(".utl-filter-box").removeClass('visiblefilter');
            $(".custo-filter-colap").removeClass('custo_filter_onen_close');
            e.stopPropagation();
          }
        });

        $(".utl-filter-box").click(function(e){
          e.stopPropagation();
        });

        $(document).click(function(){
          $(".utl-filter-box").removeClass('visiblefilter');
          $(".custo-filter-colap").removeClass('custo_filter_onen_close');
        });
      }
    clickfortotalitem()
    {      
        this.filterfield = 'All';
        this.currentlist = 'All';
        this.filtertype = 'All';
        this.defaultparam.featured=[];
        this.defaultparam.status=[];
        this.defaultparam.theme=[];
        this.defaultparam.gender=[];
        this.filtercatids=[];
        this.selectcat = 0;
        this.categories.forEach(obj=>{
            obj.checked = false;
        });
        
    }

}
