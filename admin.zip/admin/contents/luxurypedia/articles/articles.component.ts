import { Component, OnInit, ElementRef, ViewChild, HostListener} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import {DataTable} from 'angular-4-data-table/src/index';
import {ImageCropperComponent, CropperSettings, Bounds} from 'ng2-img-cropper';




import $ from 'jquery';
@Component({
    selector: 'app-articles',
    templateUrl: './articles.component.html',
    styleUrls: ['../../../nav/adminheader.component.css']
})
export class ArticlesComponent implements OnInit {

    parentMessage = "message from parent";
    public items = [];
    visiblefilter = false;
    wasClicked:boolean = false;
    custo_filter_onen_close = false;
    model = {id:0, title: '',category_id:"",image:null,coverimage:null,tags:[],gender:"",theme:"",summary:"",featured:"No",active:"",mediatitle:"",mediacredit:"",mediadesc:""};
    options:any;
    pageSize: number;
    totalitems: any;
    categories: any;
    tags: any;
    newtags: any = '';
    page: number = 1;
    last_page: number =1;
    public defaultparam = {sortBy:"id", sortAsc:true,offset:0,limit:10,filtertype:"All",sortfield:"All",searchstr:"", tagid:0, catid:0,status:[],gender:[],theme:[],featured:[]};
    filterfield:string='All';
    filtertype:string='All';
    isshowform = false;
    currentlist:string = 'All';
    applybtnval:string = '';
    headerimage:string = '';
    uploadedimage = null;
    sortfield:string = 'All';
    selectedrecs    = [];
    searchfield:string = '';
    summary = {Published:0,Draft:0,Trash:0,Featured:0,Total:0};
    searchgender:string = "Both";
    @ViewChild(DataTable) recTable: DataTable;
    @ViewChild('theme') theme:ElementRef;
    currtime:any;
    rootpath:string;
    tagslist:any;
    selecttag:any;
    selectcat:any;
    filtercatids:any = [];
    filtertagids:any = [];
    settings = {};


// for image uploader
    @ViewChild('lnksaveprofilebox') lnksaveprofilebox:ElementRef;
    coverimagedata:any;
    homeimagedata:any;
    coverCropperSettings:CropperSettings;
    homeCropperSettings:CropperSettings;
    croppedWidth:number;
    croppedHeight:number;
    dragAreaClass:string='dragarea';
    uploadedsymbol:any=null;
    symbolimage = '';
    uploadedimagebtn:boolean=false;
    uploadedsymbolbtn:boolean=false;
    showimage=false;
    imagepreviewurl:string='';

    @ViewChild('homecropper', undefined) homecropper:ImageCropperComponent;
    @ViewChild('covercropper', undefined) covercropper:ImageCropperComponent;


    constructor(private dbserv:DbserviceService,private _alert: AlertsService,private route: ActivatedRoute,private router: Router)
    {
        this.searchgender = localStorage.getItem('visittype');
        this.rootpath = localStorage.getItem('baseurl');
        this.model.tags = [];
        this.dbserv.getAll("luxurytagslist").subscribe(res => { this.tagslist = res;});

        this.settings = {
                                    singleSelection: false,
                                    text:"Select Tags",
                                    selectAllText:'Select All',
                                    unSelectAllText:'UnSelect All',
                                    enableSearchFilter: true,
                                    limitSelection:10,
                                    enableCheckAll:false,
                                    classes:"myclass custom-class"
                                };





        // for image
        this.homeCropperSettings = new CropperSettings();
        this.homeCropperSettings.width = 645;
        this.homeCropperSettings.height = 560;
        this.homeCropperSettings.croppedWidth = 645;
        this.homeCropperSettings.croppedHeight = 560;
        this.homeCropperSettings.canvasWidth = 420;
        this.homeCropperSettings.noFileInput = true;
        this.homeCropperSettings.canvasHeight = 300;
        this.homeCropperSettings.touchRadius = 20;
        this.homeCropperSettings.rounded = false;
        this.homeCropperSettings.keepAspect = true;
        this.homeimagedata = {};

        this.coverCropperSettings = new CropperSettings();
        this.coverCropperSettings.width = 1280;
        this.coverCropperSettings.height = 560;
        this.coverCropperSettings.croppedWidth = 1280;
        this.coverCropperSettings.croppedHeight = 560;
        this.coverCropperSettings.canvasWidth = 420;
        this.coverCropperSettings.noFileInput = true;
        this.coverCropperSettings.canvasHeight = 300;
        this.coverCropperSettings.touchRadius = 20;
        this.coverCropperSettings.rounded = false;
        this.coverCropperSettings.keepAspect = true;
        this.coverimagedata = {};

        this.route.params.subscribe(params => {
            if(params['type'] == 'cat'){
                if(params['id']){
                    this.selectcat = +params['id'];
                }
                else{
                    this.selectcat = 0;
                }
                }
                else if(params['type'] == 'tag')
                {
                if(params['id']){
                    this.selecttag = +params['id'];
                }
                else{
                    this.selecttag = 0;
                    }
                }
            else{
                if(params['id']){
                    this.selecttag = +params['id'];
                }
                else{
                    this.selecttag = 0;
                }
            }
            this.defaultparam.tagid = this.selecttag;
            this.defaultparam.catid = this.selectcat;
            this.loadpage(this.defaultparam);

        });

    }


// for image
        cropped(bounds:Bounds) {
    this.croppedHeight =bounds.bottom-bounds.top;
    this.croppedWidth = bounds.right-bounds.left;
    }

    fileChangeListener($event) {
    var image:any = new Image();
    var file:File = $event.target.files[0];
    var myReader:FileReader = new FileReader();
    var that = this;
    myReader.onloadend = function (loadEvent:any) {
        image.src = loadEvent.target.result;
        that.homecropper.setImage(image);
        that.covercropper.setImage(image);
    };

    myReader.readAsDataURL(file);
    }

        previewFile(file) {
        console.log(file);
        var request = new XMLHttpRequest();
        request.open('GET', file, true);
        request.responseType = 'blob';
        var image:any = new Image();
        request.onload = () => {
            var reader = new FileReader();
            reader.readAsDataURL(request.response);
            reader.onload = (event:any) => {
                image.src = event.target.result;
                this.homecropper.setImage(image);
                this.covercropper.setImage(image);
            };
            reader.onloadend = (event:any) => {
                image.src = event.target.result;
                this.covercropper.setImage(image);
                this.homecropper.setImage(image);
            };
        };
        request.send();
    }
    readImageUrl() {
        if (this.uploadedimage && this.uploadedimage) {
        var reader = new FileReader();
        var image:any = new Image();
        reader.onload = (event:any) => {
             image.src = event.target.result;
            this.homecropper.setImage(image);
            this.covercropper.setImage(image);
        }
        reader.onloadend = (event:any) => {
             image.src = event.target.result;
            this.homecropper.setImage(image);
            this.covercropper.setImage(image);
        };
        reader.readAsDataURL(this.uploadedimage);
        }
    }


    onSymbolChange($event){
        this.uploadedsymbol = $event.target.files[0];
    }
    onFileChange($event){
         this.uploadedimage = $event.target.files[0];
         this.readImageUrl();
         //this.saveprofileimage( $event.target.files[0]);
    }
    @HostListener('dragover', ['$event']) onDragOver(event) {
        this.dragAreaClass = "droparea";
        event.preventDefault();
    }
    @HostListener('dragenter', ['$event']) onDragEnter(event) {
        this.dragAreaClass = "droparea";
        event.preventDefault();
    }
    @HostListener('dragend', ['$event']) onDragEnd(event) {
        this.dragAreaClass = "dragarea";
        event.preventDefault();
    }
    @HostListener('dragleave', ['$event']) onDragLeave(event) {
        this.dragAreaClass = "dragarea";
        event.preventDefault();
    }
    @HostListener('drop', ['$event']) onDrop(event) {
        this.dragAreaClass = "dragarea";
        event.preventDefault();
        event.stopPropagation();
        this.uploadedimage = event.dataTransfer.files[0];
        this.readImageUrl();
        //this.saveprofileimage(event.dataTransfer.files[0]);
    }


    saveprofileimage(){
        this.lnksaveprofilebox.nativeElement.click();
        this.showimage = true;
    }


 // *************************************************************



    loadddl()
    {
        this.categories = [];
        this.dbserv.getAll("luxurycatlist/"+this.model.theme+'/'+this.searchgender)
        .subscribe(res => {
            this.categories = res;
        });
    }
    loadddl1()
    {
        this.tags = [];
        this.dbserv.getAll("luxurytagslist/")
        .subscribe(res => {
            this.tags = res;
        });
        
    }
    
    ngOnInit() {
        this.model.theme = '-';
        this.loadddl();
        this.loadddl1();




          
    }
    statusselectedchange()
    {
        console.log(this.defaultparam);
        if(this.applybtnval!='')
        {
            if(this.recTable.selectedRows.length>0)
            {
                if(confirm('Are you sure?'))
                {
                    this.selectedrecs=[];
                    for(var i = 0;i<this.recTable.selectedRows.length;i++)
                    {
                        this.selectedrecs.push(this.recTable.selectedRows[i].item.id);
                    }
                    let newmodel = {'action':this.applybtnval,'vals':JSON.stringify(this.selectedrecs)};
                    this.dbserv.save("luxurypediaperformaction",newmodel).subscribe(res => {
                                                                    if(res.type=="success")
                                                                    {
                                                                        this._alert.create(res.type,res.message);
                                                                        this.loadpage(this.defaultparam);
                                                                        this.isshowform = false;
                                                                    }
                                                                    else if(res.type=="expired")
                                                                    {
                                                                        this.router.navigateByUrl('/admin/login') ;
                                                                    }
                                                                    else
                                                                    {
                                                                        this._alert.create(res.type,res.message);
                                                                    }
                                                                });
                }
            }
            else
            {
                this._alert.create('error','Please, select some record first.');
            }
        }

    }
    statuschange(id:number,action:string)
    {
        if(confirm('Are you sure?'))
        {
            this.selectedrecs=[id];
            this.applybtnval = action;
            let newmodel = {'action':this.applybtnval,'vals':JSON.stringify(this.selectedrecs)};
            this.dbserv.save("luxurypediaperformaction",newmodel).subscribe(res => {
                                                                if(res.type=="success")
                                                                {
                                                                    this._alert.create(res.type,res.message);
                                                                    this.loadpage(this.defaultparam);
                                                                    this.isshowform = false;
                                                                }
                                                                else if(res.type=="expired")
                                                                {
                                                                    this.router.navigateByUrl('/admin/login') ;
                                                                }
                                                                else
                                                                {
                                                                    this._alert.create(res.type,res.message);
                                                                }
                                                        });
        }
    }

    sortchanged()
    {
        console.log(this.defaultparam);
        this.defaultparam.sortfield = this.sortfield;
        this.defaultparam.sortBy = '';
        this.loadpage(this.defaultparam);
    }

    loadpage(params:any)
    {
        console.log(params);
        params.searchstr = this.searchfield;
        params.filtertype = this.filtertype;
        params.catid = this.selectcat;
        params.tagid = this.selecttag;
        params.filtercat = this.filtercatids;
        params.filtertag = this.filtertagids;
        params.status = this.defaultparam.status;
        params.gender = this.defaultparam.gender;
        params.theme = this.defaultparam.theme;
        params.featured = this.defaultparam.featured;
        
        this.currtime = Math.random();
        this.dbserv.post("luxurypedia/"+this.searchgender+"/"+this.currentlist,params).subscribe(res => {
                                                                            if(res.type=="success")
                                                                            {
                                                                                this.items = res.records.data;
                                                                                this.page = res.records.current_page;
                                                                                this.totalitems = res.records.total;
                                                                                this.pageSize = res.records.per_page;
                                                                                this.last_page = res.records.last_page;
                                                                                this.dbserv.post("luxurypediasummary/"+this.searchgender+"/"+this.currentlist,params).subscribe(res => {
                                                                                    this.summary = res.records;
                                                                                });
                                                                            }
                                                                            else if(res.type=="expired")
                                                                            {
                                                                                this.router.navigateByUrl('/admin/login') ;
                                                                            }
                                                                            else
                                                                            {
                                                                                this._alert.create(res.type,res.message);
                                                                            }
                                                                        });
        this.defaultparam = params;
        this.isshowform = false;
    }
    changetheme(event:any){
        console.log(event);
        // event.forEach((obj,inx)=>{
        //  this.model.theme = obj;
        //  this.loadddl();
        // })
        this.defaultparam.theme = event;
        this.loadpage(this.defaultparam);
    }

    changestatus(event:any){
        console.log(event);
        this.defaultparam.status = event;
        this.filterfield = 'All';
        this.currentlist = 'All';
        this.loadpage(this.defaultparam);
    }

    changegender(event:any){
        console.log(event);
        this.defaultparam.gender = event;
        this.filterfield = 'All';
        this.currentlist = 'All';
        this.loadpage(this.defaultparam);
    }
    changefeatured(event:any){
        console.log(event);
        this.defaultparam.featured = event;
        this.filterfield = 'All';
        this.currentlist = 'All';
        this.loadpage(this.defaultparam);
    }


    switchcurrentlist()
    {
        console.log(this.defaultparam);
        this.currentlist = this.filterfield;
        this.loadpage(this.defaultparam);
    }
    switchtype()
    {
        console.log(this.defaultparam);
        this.currentlist = this.filtertype;
        this.loadpage(this.defaultparam);
    }
    hideform()
    {
        this.isshowform = false;
        this.homecropper.reset();
        this.covercropper.reset();
        this.uploadedimagebtn = false;
    }
    editrecord(id)
    {
        this.isshowform = true;
        this.showimage = false;
        this.dbserv.getById("luxurypedia",id).subscribe(res => {
                                                    if(res.type=="success")
                                                    {
                                                        this.model = res.data;
                                                        // this.coverimagedata.image = res.data.coverimage;
                                                        this.loadddl();
                                                        this.loadddl1();
                                                    }
                                                    else if(res.type=="expired")
                                                    {
                                                        this.router.navigateByUrl('/admin/login') ;
                                                    }
                                                    else
                                                        this._alert.create(res.type,res.message);
                                                    });
    }
    deleterecord(id)
    {
        if(confirm('Are you sure?'))
        {
            this.isshowform = false;
            this.dbserv.delete("luxurypediadel", id).subscribe(res => {
                                                                if(res.type=="success")
                                                                {
                                                                    this.loadpage(this.defaultparam);
                                                                    this._alert.create(res.type,res.message);
                                                                }
                                                                else if(res.type=="expired")
                                                                {
                                                                    this.router.navigateByUrl('/admin/login') ;
                                                                }
                                                                else
                                                                    this._alert.create(res.type,res.message);
                                                             });
        }
    }
    changevalue(type:string)
    {
        this.model.active = type;
    }

    publishvalue(id:number,type:string)
    {
        if(confirm('Are you sure?'))
        {
            this.selectedrecs=[id];
            if(type == 'Yes'){
                type = 'No';
            }else{
                type = 'Yes';
            }

            let newmodel = {'action':type,'vals':JSON.stringify(this.selectedrecs)};
            this.dbserv.save("luxurypediafeaturedupdate",newmodel).subscribe(res => {
                                                                if(res.type=="success")
                                                                {
                                                                    this._alert.create(res.type,res.message);
                                                                    this.loadpage(this.defaultparam);
                                                                    this.isshowform = false;
                                                                }
                                                                else if(res.type=="expired")
                                                                {
                                                                    this.router.navigateByUrl('/admin/login') ;
                                                                }
                                                                else
                                                                {
                                                                    this._alert.create(res.type,res.message);
                                                                }
                                                        });
        }
    }

    sliderupdate(id:number,type:string)
    {
        if(confirm('Are you sure?'))
        {
            this.selectedrecs=[id];
            if(type == 'Yes'){
                type = 'No';
            }else{
                type = 'Yes';
            }

            let newmodel = {'action':type,'vals':JSON.stringify(this.selectedrecs)};
            this.dbserv.save("sliderupdate",newmodel).subscribe(res => {
                    if(res.type=="success")
                    {
                        this._alert.create(res.type,res.message);
                        this.loadpage(this.defaultparam);
                        this.isshowform = false;
                    }
                    else if(res.type=="expired")
                    {
                        this.router.navigateByUrl('/admin/login') ;
                    }
                    else
                    {
                        this._alert.create(res.type,res.message);
                    }
            });
        }
    }


    fileChange($event){
        console.log($event.target.files[0]);
        this.uploadedimage = $event.target.files[0];
    }
    saverecord()
    {
        if(this.coverimagedata.image != undefined || this.model.image != null){
            console.log(this.model);
            let _formData = new FormData();
            _formData.append("id",this.model.id.toString());
            _formData.append("title",this.model.title);
            _formData.append("category_id",this.model.category_id.toString());
            _formData.append("gender",this.searchgender);
            let mytags:string = '';
            if(this.model.tags.length>0)
            {
                for(let i=0;i<this.model.tags.length;i++)
                {
                    if(mytags=='')
                        mytags = '-'+this.model.tags[i].id.toString()+'-';
                    else
                        mytags += ',-'+this.model.tags[i].id.toString()+'-';
                }
            }
            _formData.append("tags",mytags);
    
            _formData.append("theme",this.model.theme);
            _formData.append("mediatitle",this.model.mediatitle);
            _formData.append("mediacredit",this.model.mediacredit);
            _formData.append("mediadesc",this.model.mediadesc);
                
            _formData.append("featured",this.model.featured);
            _formData.append("active",this.model.active);
    
            // Image
    
            if(this.uploadedimage!=null && this.uploadedimage.name!='')
            {
                _formData.append('image',this.uploadedimage, this.uploadedimage.name);
                _formData.append('imagesrc',this.uploadedimage, this.uploadedimage.name);
            }
            if(this.homeimagedata.image != '' && this.homeimagedata.image != null)
            {
                _formData.append('image',this.homeimagedata.image);
            }
            if(this.coverimagedata.image != '' && this.coverimagedata.image != null)
            {
                _formData.append('coverimage',this.coverimagedata.image);
            }
            _formData.append("summary",this.model.summary);
    
            // *****************
            console.log(this.model);
            this.uploadedimagebtn = true;
            this.dbserv.saveimage("luxurypediasave",_formData).subscribe(res => {
                                                                    if(res.type=="success")
                                                                    {
    
                                                                        this._alert.create(res.type,res.message);
                                                                        this.model = {id:0, title: '',category_id:"",image:null,coverimage:null,tags:[],gender:"",theme:"",summary:"",featured:"No",active:"",mediatitle:"",mediacredit:"",mediadesc:""};
                                                                        this.loadpage(this.defaultparam);
                                                                        this.uploadedimagebtn = false;
                                                                        this.isshowform = false;
                                                                        this.homeimagedata={};
                                                                        this.coverimagedata={};
                                                                        this.uploadedimage=null;
                                                                        this.homecropper.reset();
                                                                        this.covercropper.reset();
    
                                                                    }
                                                                    else if(res.type=="expired")
                                                                    {
                                                                        this.router.navigateByUrl('/admin/login') ;
                                                                    }
                                                                    
    
                                                            });
        }
    }
    addrecord()
    {
        this.showimage = false;
        this.model = {id:0, title: '',category_id:"",image:null,coverimage:null,tags:[],gender:"",theme:"",summary:"",featured:"No",active:"",mediatitle:"",mediacredit:"",mediadesc:""};
        this.isshowform = true;
        this.uploadedimagebtn = true;
        this.homeimagedata={};
        this.coverimagedata={};
        this.uploadedimage=null;
        this.homecropper.reset();
        this.covercropper.reset();
        this.uploadedimagebtn = false;
    }
    onItemSelect(item:any){
        console.log(item);
        console.log(this.model.tags);
    }
    OnItemDeSelect(item:any){
        console.log(item);
        console.log(this.model.tags);
    }
    onSelectAll(items: any){
        console.log(this.model.tags);
    }
    onDeSelectAll(items: any){
        console.log(this.model.tags);
    }
    filtercat(){
        this.filtercatids = [];
        this.categories.forEach(obj=>{
            if(obj.checked)
                this.filtercatids.push(obj.id);
        });
        this.loadpage(this.defaultparam);
    }
    selecallcat(event){
        this.filtercatids = [];
        this.categories.forEach(obj=>{
            obj.checked = event.target.checked;
            if(obj.checked)
                this.filtercatids.push(obj.id);
        });
        this.loadpage(this.defaultparam);
    }
    
    filtertag(){
        this.filtertagids = [];
        this.tags.forEach(obj=>{
            if(obj.checked)
                this.filtertagids.push(obj.id);
        });
        this.loadpage(this.defaultparam);
    }
    selecalltag(event){
        this.filtertagids = [];
        this.tags.forEach(obj=>{
            obj.checked = event.target.checked;
            if(obj.checked)
                this.filtertagids.push(obj.id);
        });
        this.loadpage(this.defaultparam);
    }
    
    
  key_down(e) {
  console.log(e);
  if(e.target.value == '')
  {
    this.loadpage(this.defaultparam);
  }
      if(e.keyCode === 13) {
            this.loadpage(this.defaultparam);
    }
  }
  savenewtag(){
    if(this.newtags != ''){
        let model = {
            tag:this.newtags,
            active:'Published'
        }
        this.dbserv.save("luxurypediatagsave",model).subscribe(res => {
            if(res.type=="success")
            {
                this.newtags = '';
                this.dbserv.getAll("luxurytagslist").subscribe(res => { this.tagslist = res;});
            }
            else if(res.type=="expired")
            {
                this.router.navigateByUrl('/admin/login') ; 
            }
            this._alert.create(res.type,res.message);
        }); 
    }
  }
  ngAfterViewInit() {
      $(".custo-filter-colap").click(function(e){
        if(!$(this).hasClass('custo_filter_onen_close')){
          $(this).next(".utl-filter-box").addClass('visiblefilter');
          $(this).addClass('custo_filter_onen_close');
          e.stopPropagation();
        }else{
          $(".utl-filter-box").removeClass('visiblefilter');
          $(".custo-filter-colap").removeClass('custo_filter_onen_close');
          e.stopPropagation();
        }
      });

      $(".utl-filter-box").click(function(e){
        e.stopPropagation();
      });

      $(document).click(function(){
        $(".utl-filter-box").removeClass('visiblefilter');
        $(".custo-filter-colap").removeClass('custo_filter_onen_close');
      });
    }
  clickfortotalitem()
  {      
      this.filterfield = 'All';
      this.currentlist = 'All';
      this.filtertype = 'All';
      this.defaultparam.featured=[];
      this.defaultparam.status=[];
      this.defaultparam.theme=[];
      this.defaultparam.gender=[];
      this.filtercatids=[];
      this.filtertagids=[];
      this.selecttag = 0;
      this.selectcat = 0;
      this.tags.forEach(obj=>{
          obj.checked = false;
      });
      this.categories.forEach(obj=>{
          obj.checked = false;
      });
      
  }
}
