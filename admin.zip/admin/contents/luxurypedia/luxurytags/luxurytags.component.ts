import { Component, OnInit, ViewChild} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import {DataTable} from 'angular-4-data-table/src/index';

@Component({
  selector: 'app-luxurytags',
  templateUrl: './luxurytags.component.html',
  styleUrls: ['../../../nav/adminheader.component.css']
})
export class LuxurytagsComponent implements OnInit {
	public items = [];
	model = {id:0, tag: '',active:""};
	options:any;
	parentid:number = 0;
	pageSize: number;
	totalitems: any;
	page: number = 1;
	last_page: number =1;
	public defaultparam = {sortBy:"id", sortAsc:true,offset:0,limit:10,filtertype:"All",searchstr:""};
	filterfield:string='All';
	filtertype:string='All';
	isshowform = false;
	currentlist:string = 'All';
	applybtnval:string = '';
	headerimage:string = '';
	uploadedimage = null;
	selectedrecs	= [];
	searchfield:string = '';
	msgvariable = '';
	summary = {Published:0,Trash:0,Unpublished:0,Total:0}; 
	searchgender:string = "Both";
	@ViewChild(DataTable) recTable: DataTable;
	
	constructor(private dbserv:DbserviceService,private _alert: AlertsService,private route: ActivatedRoute,private router: Router) 
	{
	    
	    this.route.params.subscribe(params => {
            if(params['id'] != undefined){
                this.editrecord(params['id']);
            }
          });
	}
	ngOnInit() {
		
	}
	
	nospaces(){
		
		let checkSpe = false;	
			for (let ​i = 0; i<this.model.tag.length; i++) 
			{
    if (this.model.tag[i] === this.model.tag[i].toUpperCase() && this.model.tag[i] !== this.model.tag[i].toLowerCase()) {
        		console.log(this.model.tag[i] + ": " + true);
        	checkSpe = true;	
    }
								}​
		if(this.model.tag.match(/\s/g) || checkSpe){
		this.msgvariable = "Capital and space are not allowed";
		
		//	this.model.tag=this.model.tag.replace(/\s/g,'');
				}
				else{
				this.msgvariable = "";
				}
			}

	statusselectedchange()
	{
		if(this.applybtnval!='')
		{
			if(this.recTable.selectedRows.length>0)
			{
				if(confirm('Are you sure?'))
				{
					this.selectedrecs=[];
					for(var i = 0;i<this.recTable.selectedRows.length;i++) 
					{ 
						this.selectedrecs.push(this.recTable.selectedRows[i].item.id);
					}
					let newmodel = {'action':this.applybtnval,'vals':JSON.stringify(this.selectedrecs)};
					this.dbserv.save("luxurypediatagsperformaction",newmodel)
						.subscribe(res => {
						  this._alert.create(res.type,res.message);
							if(res.type=="success"){
								this.loadpage(1);
								this.isshowform = false;
							}
						});
				}
			}
			else
			{
				this._alert.create('error','Please, select some record first.');
			}
		}
		
	}
	statuschange(id:number,action:string)
	{
		this.selectedrecs=[id];
		this.applybtnval = action;
		let newmodel = {'action':this.applybtnval,'vals':JSON.stringify(this.selectedrecs)};
		this.dbserv.save("luxurypediatagsperformaction",newmodel)
			.subscribe(res => {
			  this._alert.create(res.type,res.message);
			  if(res.type=="success"){
					this.loadpage(1);
					this.isshowform = false;
			  }
		});
	}
	
	fileChange($event){
		this.uploadedimage = $event.target.files[0];
	}
	loadpage(page:any){
		console.log(page.offset);
		this.defaultparam.searchstr = this.searchfield;
		this.defaultparam.filtertype = this.filtertype;
		if (page.offset != undefined) {
			this.defaultparam.offset = page.offset;
		}else{
			this.defaultparam.offset = 0;
		}
		this.dbserv.post("luxurypediatags/"+this.searchgender+"/"+this.currentlist,this.defaultparam)
			.subscribe(res => {
				console.log('api',res.data);
				this.items = res.data;
				this.page = res.current_page;
				this.totalitems = res.total;
				this.pageSize = res.per_page;
				this.last_page = res.last_page;
				this.dbserv.post("luxurypediatagssummary/"+this.searchgender+"/"+this.currentlist,this.defaultparam)
					.subscribe(res => {
						this.summary = res;
					});
			});
		this.isshowform = false;
	}
	switchcurrentlist()
	{
		this.currentlist = this.filterfield;
		this.loadpage(1);
		
	}
	hideform()
	{
		this.isshowform = false;
	}
	editrecord(id)
	{
		this.isshowform = true;
		this.dbserv.getById("luxurypediatag",id)
			.subscribe(res => {
				if(res.type=="success")
				{
					this.model = res.data;
				}
				else
					this._alert.create(res.type,res.message);
				});
	}
	deleterecord(id)
	{
		if(confirm('Are you sure?')){
			this.isshowform = false;
			this.dbserv.delete("luxurypediatagdel", id)
				.subscribe(res => {
					this._alert.create(res.type,res.message);
					this.loadpage(1);
				});
		}
	}
	changevalue(type:string)
	{
		this.model.active = type;
	}
	saverecord()
	{ 
		
	if(this.msgvariable == "")
	{ 
		this.dbserv.save("luxurypediatagsave",this.model)
			.subscribe(res => {
				this._alert.create(res.type,res.message);
				if(res.type=="success")
				{
					this.model = {id:0, tag: '',active:""};
					this.loadpage(1);
					this.isshowform = false;
				}
			});
		}
	}
	addrecord()
	{
		this.model = {id:0, tag: '',active:""};
		this.isshowform = true;
	}
  key_down(e) {
  	if(e.target.value == ''){
    	this.loadpage(1);
  	}
    if(e.keyCode === 13) {
      this.loadpage(1);
    }
  }
  
  datechange(created_at){
      var date = new Date(created_at);
      var gf = date.toString();
      var n = gf.toLocaleString();
         return n; 
  }
}