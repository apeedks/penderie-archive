import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LuxurytagsComponent } from './luxurytags.component';

describe('LuxurytagsComponent', () => {
  let component: LuxurytagsComponent;
  let fixture: ComponentFixture<LuxurytagsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LuxurytagsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LuxurytagsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
