import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArticledetComponent } from './articledet.component';

describe('ArticledetComponent', () => {
  let component: ArticledetComponent;
  let fixture: ComponentFixture<ArticledetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArticledetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArticledetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
