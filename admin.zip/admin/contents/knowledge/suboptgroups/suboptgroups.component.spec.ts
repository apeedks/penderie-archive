import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuboptgroupsComponent } from './suboptgroups.component';

describe('SuboptgroupsComponent', () => {
  let component: SuboptgroupsComponent;
  let fixture: ComponentFixture<SuboptgroupsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuboptgroupsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuboptgroupsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
