import {Component, Input} from  '@angular/core';

@Component({
  selector: '[suboptgroups]',
  template: `
	<!--<optgroup *ngFor="let dropdownitem of dropdownitems" label="{{dropdownitem.title}}">
		<option *ngIf="dropdownitem.haschild=='No'" value="{{dropdownitem.id}}">{{dropdownitem.title}}</option>
		<suboptgroups *ngIf="dropdownitem.haschild=='Yes'" [dropdownitems]="dropdownitem.items"></suboptgroups>
	</optgroup>-->
  `
  ,styleUrls: ['./suboptgroups.component.css']
})
export class SuboptgroupsComponent {
	/*@Input() dropdownitems: [];*/
}
