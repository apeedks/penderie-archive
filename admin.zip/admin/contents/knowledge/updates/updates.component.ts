import { Component, OnInit, ElementRef, ViewChild, HostListener} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { DataTable } from 'angular-4-data-table/src/index';
import {ImageCropperComponent, CropperSettings, Bounds} from 'ng2-img-cropper';

@Component({
  selector: 'app-updates',
  templateUrl: './updates.component.html',
  styleUrls: ['../../../nav/adminheader.component.css']
})
export class UpdatesComponent implements OnInit {
	public items = [];
	model = {id:0, title: '',image: null,gender:"",type:"",content: "",active:""};
	options:any;
	uploadedimage = null;
	pageSize: number;
	totalitems: any;
	page: number = 1;
	last_page: number = 1;
	public defaultparam = {sortBy:"id", sortAsc:true,offset:0,limit:10,searchfield:""};
	public errormsg = '';
	headerimage: string = '';
	sections:any;
	filterfield:string = 'All';
	isshowform = false;
	currentlist:string = 'All';
	searchgender:string = 'Both';
	applybtnval:string = '';
	selectedrecs	= [];
	searchfield:string = '';
	apiurl:string='';
	summary = {Published:0,Trash:0,Draft:0,Total:0};
	@ViewChild(DataTable) recTable: DataTable;


	// for image uploader

	currtime:any;
	rootpath:string;
	@ViewChild('lnksaveprofilebox') lnksaveprofilebox:ElementRef;
	imagedata:any;
    cropperSettings:CropperSettings;
    croppedWidth:number;
    croppedHeight:number;
    dragAreaClass:string='dragarea';
	uploadedsymbol:any=null;
	symbolimage = '';
	uploadedimagebtn:boolean=false;
	uploadedsymbolbtn:boolean=false;
	imagepreviewurl:string='';

    @ViewChild('cropper', undefined) cropper:ImageCropperComponent;


	
	constructor(private dbserv:DbserviceService,private _alert: AlertsService) 
	{
		this.searchgender = localStorage.getItem('visittype');
		this.apiurl = localStorage.getItem('apiurl');


		    // for image 
this.rootpath = localStorage.getItem('baseurl');
	   this.cropperSettings = new CropperSettings();
        this.cropperSettings.width = 645;
        this.cropperSettings.height = 560;
        this.cropperSettings.croppedWidth = 600;
        this.cropperSettings.croppedHeight = 400;
        this.cropperSettings.canvasWidth = 380;
		this.cropperSettings.noFileInput = true;
        this.cropperSettings.canvasHeight = 300;
        this.cropperSettings.touchRadius = 20;
		this.cropperSettings.rounded = false;
     	this.cropperSettings.keepAspect = true;
        this.imagedata = {};

	}



// for image
	  cropped(bounds:Bounds) {
    this.croppedHeight =bounds.bottom-bounds.top;
    this.croppedWidth = bounds.right-bounds.left;
  }
  
  fileChangeListener($event) {
    var image:any = new Image();
    var file:File = $event.target.files[0];
    var myReader:FileReader = new FileReader();
    var that = this;
    myReader.onloadend = function (loadEvent:any) {
        image.src = loadEvent.target.result;
        that.cropper.setImage(image);

    };

    myReader.readAsDataURL(file);
    }

    	previewFile(file) {
		console.log(file);
		var request = new XMLHttpRequest();
		request.open('GET', file, true);
		request.responseType = 'blob';
		var image:any = new Image();
		request.onload = () => {
			var reader = new FileReader();
			reader.readAsDataURL(request.response);
			reader.onload = (event:any) => {
				image.src = event.target.result; 
				this.cropper.setImage(image);
			};
			reader.onloadend = (event:any) => {
				image.src = event.target.result; 
				this.cropper.setImage(image);
			};
		};
		request.send();
	}
	readImageUrl() {
	  if (this.uploadedimage && this.uploadedimage) {
		var reader = new FileReader();
		var image:any = new Image();
		reader.onload = (event:any) => {
		   image.src = event.target.result; 
			this.cropper.setImage(image);
		}
		reader.onloadend = (event:any) => {
           image.src = event.target.result; 
			this.cropper.setImage(image);
        };
		reader.readAsDataURL(this.uploadedimage);
	  }
	}


	onSymbolChange($event){
		this.uploadedsymbol = $event.target.files[0];
	}
	onFileChange($event){
	   this.uploadedimage = $event.target.files[0];
	   this.readImageUrl();
	   //this.saveprofileimage( $event.target.files[0]);
	}
	@HostListener('dragover', ['$event']) onDragOver(event) {
        this.dragAreaClass = "droparea";
        event.preventDefault();
    }
	@HostListener('dragenter', ['$event']) onDragEnter(event) {
		this.dragAreaClass = "droparea";
		event.preventDefault();
	}
	@HostListener('dragend', ['$event']) onDragEnd(event) {
		this.dragAreaClass = "dragarea";
		event.preventDefault();
	}
	@HostListener('dragleave', ['$event']) onDragLeave(event) {
		this.dragAreaClass = "dragarea";
		event.preventDefault();
	}
	@HostListener('drop', ['$event']) onDrop(event) {   
		this.dragAreaClass = "dragarea";           
		event.preventDefault();
		event.stopPropagation();
		this.uploadedimage = event.dataTransfer.files[0];
		this.readImageUrl();
		//this.saveprofileimage(event.dataTransfer.files[0]);
	}



	saveprofileimage(){
		this.lnksaveprofilebox.nativeElement.click();
	}


 // *************************************************************




	loadpage(params:any)
	{
		params.searchstr = this.searchfield;
		this.currtime = Math.random();
		this.dbserv.post("knowledgeupdates/"+this.searchgender+"/"+this.currentlist,params).subscribe(res => {
			this.items = res.data;
			this.last_page = res.last_page; 
			this.page = res.current_page; 
			this.totalitems = res.total; 
			this.pageSize = res.per_page; 
			this.dbserv.post("knowledgeupdatessummary/"+this.searchgender+"/"+this.currentlist,params).subscribe(resu => { 
				this.summary = resu; 
			});																				
		}); 
		this.isshowform = false;
	}
	searchfilter($event)
	{
		console.log(this.model.title);	
	}
	ngOnInit() {
		this.loadpage(this.defaultparam);
	}
	statusselectedchange()
	{
		if(this.applybtnval!='')
		{
			if(this.recTable.selectedRows.length>0)
			{
				if(confirm('Are you sure?'))
				{
					this.selectedrecs=[];
					for(var i = 0;i<this.recTable.selectedRows.length;i++) 
					{ 
						this.selectedrecs.push(this.recTable.selectedRows[i].item.id);
					}
					let newmodel = {'action':this.applybtnval,'vals':JSON.stringify(this.selectedrecs)};
					this.dbserv.save("knowledgeupdatesperformaction",newmodel).subscribe(res => {
																  
																   this._alert.create(res.type,res.message);
																   if(res.type=="success")
																   {
																		this.loadpage(this.defaultparam);
																		this.isshowform = false;
																   }
																 }); 
				}
			}
			else
			{
				this._alert.create('error','Please, select some record first.');
			}
		}
	}
	statuschange(id:number,action:string)
	{
		if(confirm('Are you sure?'))
		{
			this.applybtnval = action;
			this.selectedrecs=[id];
			let newmodel = {'action':this.applybtnval,'vals':JSON.stringify(this.selectedrecs)};
			this.dbserv.save("knowledgeupdatesperformaction",newmodel).subscribe(res => {
															  
				   this._alert.create(res.type,res.message);
				   if(res.type=="success")
				   {
						this.loadpage(this.defaultparam);
						this.isshowform = false;
				   }
			}); 
		}
	}
	switchcurrentlist(type:string)
	{
		this.currentlist = type;
		this.loadpage(this.defaultparam);
	}
	hideform()
	{
		this.isshowform = false;
		this.cropper.reset();
		this.uploadedimagebtn = false;
	}
	editrecord(id)
	{
		this.isshowform = true;
		this.dbserv.getById("knowledgeupdate",id).subscribe(res => {
													if(res.type=="success")
													{
														this.model=res.data;
														this.headerimage = this.apiurl+ "assets/knowledgeupdate/" + this.model.image;
													}
													else
														this._alert.create(res.type,res.message);
													});
	}
	changevalue(type:string)
	{
		this.model.active = type;
	}
	deleterecord(id)
	{
		if(confirm('Are you sure?'))
		{
			this.isshowform = false;
			this.dbserv.delete("knowledgeupdatedel", id).subscribe(res => { this._alert.create(res.type,res.message);this.loadpage(this.defaultparam);});
		}
	}
	saverecord(){

    let _formData = new FormData();
    _formData.append("id", this.model.id.toString());
    _formData.append("title", this.model.title);
    _formData.append("type", this.model.type);
    _formData.append("gender", this.model.gender);
    _formData.append("content", this.model.content);
    _formData.append("active", this.model.active);
    if (this.uploadedimage != null && this.uploadedimage.name != '') {
      _formData.append('image', this.uploadedimage, this.uploadedimage.name);
    }

    // Image 

		if(this.uploadedimage!=null && this.uploadedimage.name!='')
		{
			_formData.append('image',this.uploadedimage, this.uploadedimage.name);
			_formData.append('imagesrc',this.uploadedimage, this.uploadedimage.name);
		}
		if(this.imagedata.image != '' && this.imagedata.image != null)
		{
			_formData.append('image',this.imagedata.image);
		}

		// *****************


    this.dbserv.saveimage("knowledgeupdatesave", _formData).subscribe(res => {
      this._alert.create(res.type, res.message);
      if (res.type == "success") {
      	this.uploadedimagebtn = true;
        this.model = { id: 0, title: '',image: null, type: "", gender: "", content: "", active: "" };
        this.loadpage(this.defaultparam);
        this.uploadedimagebtn = false;

        this.isshowform = false;
        this._alert.create(res.type, res.message);

        this.imagedata={};
		this.uploadedimage=null;
		this.cropper.reset();



      }
	});	


}
	addrecord()
	{
		this.uploadedimagebtn = true;
		this.model = {id:0, title: '',image: null,gender:"",type:"",content: "",active:""};
		this.headerimage = '';
		this.isshowform = true;
		this.imagedata={};
		this.uploadedimage=null;
		this.cropper.reset();
		this.uploadedimagebtn = false;
		
	}
	  fileChange($event) {
    console.log($event.target.files[0]);
    this.uploadedimage = $event.target.files[0];
  }
}