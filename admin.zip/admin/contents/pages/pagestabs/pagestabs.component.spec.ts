import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PagesTabsComponent } from './pagestabs.component';

describe('PagesTabsComponent', () => {
  let component: PagesTabsComponent;
  let fixture: ComponentFixture<PagesTabsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PagesTabsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PagesTabsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
