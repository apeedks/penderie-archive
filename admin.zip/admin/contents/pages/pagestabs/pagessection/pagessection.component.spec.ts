import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PagesTabsSectionsComponent } from './pagessection.component';

describe('PagesTabsSectionsComponent', () => {
  let component: PagesTabsSectionsComponent;
  let fixture: ComponentFixture<PagesTabsSectionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PagesTabsSectionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PagesTabsSectionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
