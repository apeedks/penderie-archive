import { Component, OnInit, ViewChild} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import {DataTable} from 'angular-4-data-table/src/index';

@Component({
  selector: 'app-pagessection',
  templateUrl: './pagessection.component.html',
  styleUrls: ['../../../../nav/adminheader.component.css']
})
export class PagesTabsSectionsComponent implements OnInit {
	public items = [];
	model = {
		id:0,
		contents_tabs_id:0,
		contents_sections_heading: 0,
		section_type:'content',
		title: '',
		content:"",
		link:"",
		sortorder:0
	};
	tabsmodel = {
		id:0,
		contents_id:0,
		template:0,
		content_type: 'template',
		content_section: '',
		title: '',
		content:"",
		sortorder:0,
		sections_heading:[{
			id:0,
			content_section:'',
			title:'',
			sortorder:0
		}],
		remove_sections_heading:[]
	};
	options:any;
	tabid:number = 0;
	contentid:number = 0;
	pageSize: number;
	totalitems: any;
	page: number = 1;
	last_page: number =1;
	sections: any;
	public defaultparam = {sortBy:"id", sortAsc:true,offset:0,limit:10};
	isshowform = false;
	@ViewChild(DataTable) recTable: DataTable;
	sortingddl = [];
	constructor(private dbserv:DbserviceService,private _alert: AlertsService,private route: ActivatedRoute,private router: Router) 
	{
		for (var i = 1; i <= 100; i++) {
		   this.sortingddl.push(i);
		}
		this.route.params.subscribe(params => {
			if(params['contentid']){
			  this.contentid = +params['contentid'];
			}
			else
			  this.contentid = 0;
			if(params['tabid']){
			  this.tabid = +params['tabid'];
			}
			else
			  this.tabid = 0;
			this.loadpage(this.defaultparam);
		});
	}
	ngOnInit() {
		this.dbserv.getById("contentstabs",this.tabid)
			.subscribe(res => {
				if(res.type=="success"){
					this.tabsmodel = res.data;
				}
			});
	}
	loadpage(params:any)
	{
		this.dbserv.post("contentssectionslist/"+this.tabid,params)
			.subscribe(res => {
				if(res.type=="success")
				{
					this.items = res.records.data; 
					this.page = res.records.current_page; 
					this.totalitems = res.records.total;
					this.pageSize = res.records.per_page;
					this.last_page = res.records.last_page;
				}
				else if(res.type=="expired")
				{
					this.router.navigateByUrl('/admin/login') ;	
				}
				else
				{
					this._alert.create(res.type,res.message);
				}
			});
		this.defaultparam = params;
		this.isshowform = false;
	}
	hideform()
	{
		this.isshowform = false;
	}
	editrecord(id)
	{
		this.isshowform = true;
		this.dbserv.getById("contentssections",id)
			.subscribe(res => {
				if(res.type=="success"){
					this.model = res.data;
				}
				else if(res.type=="expired"){
					this.router.navigateByUrl('/admin/login') ;	
				}
				else{
					this._alert.create(res.type,res.message);
				}
			});
	}
	deleterecord(id)
	{
		if(confirm('Are you sure?')){
			this.isshowform = false;
			this.dbserv.delete("contentssectionsdel", id)
				.subscribe(res => {
				  if(res.type=="success"){
						this.loadpage(this.defaultparam);
					}
					else if(res.type=="expired"){
						this.router.navigateByUrl('/admin/login') ;	
					}
					else{
						this._alert.create(res.type,res.message);
					}
			});
		}
	}
	saverecord()
	{
		this.model.contents_tabs_id = this.tabid;
		// if (this.tabsmodel.content_section != 'both') {
		// 	this.model.content_section = this.tabsmodel.content_section;
		// }
		this.dbserv.save("contentssectionssave",this.model)
			.subscribe(res => {
				if(res.type=="success"){
					this.model = {
						id:0,
						contents_tabs_id:0,
						contents_sections_heading: 0,
						section_type:'content',
						title: '',
						content:"",
						link:"",
						sortorder:0
					};
					this.loadpage(this.defaultparam);
					this.isshowform = false;
				}
				else if(res.type=="expired"){
					this.router.navigateByUrl('/admin/login') ;	
				}
				else{
					this._alert.create(res.type,res.message);
				}
		});
	}
	addrecord(){
		this.model = {
			id:0,
			contents_tabs_id:0,
			contents_sections_heading: 0,
			section_type:'content',
			title: '',
			content:"",
			link:"",
			sortorder:0
		};
		this.isshowform = true;
	}
}
