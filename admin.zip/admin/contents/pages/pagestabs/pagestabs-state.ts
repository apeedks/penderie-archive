export interface PagesTabsState {
    id:number,
	contents_id:number,
	template:number,
	content_type: string,
	content_section: string,
	title: string,
	content:string,
	sortorder:number
}

export const INITIAL_PAGESTABS_STATE: PagesTabsState = {
	id:0,
	contents_id:0,
	template:0,
	content_type: 'template',
	content_section: '',
	title: '',
	content:"",
	sortorder:0
};
