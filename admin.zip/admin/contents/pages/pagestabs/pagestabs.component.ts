import { Component, OnInit, ViewChild} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import {DataTable} from 'angular-4-data-table/src/index';
import { PagesState,INITIAL_PAGESSTATE_STATE } from '../pages-state'

@Component({
  selector: 'app-pagestabs',
  templateUrl: './pagestabs.component.html',
  styleUrls: ['../../../nav/adminheader.component.css']
})
export class PagesTabsComponent implements OnInit {
	public items = [];
	model = {
		id:0,
		contents_id:0,
		template:0,
		content_type: 'fix',
		content_section: '',
		title: '',
		content:"",
		sortorder:0,
		sections_heading:[{
			id:0,
			content_section:'',
			title:'',
			sortorder:0
		}],
		remove_sections_heading:[]
	};
	selectedrecs = [];
	applybtnval: string = '';
	pagemodel = INITIAL_PAGESSTATE_STATE;
	options:any;
	contentid:number = 0;
	pageSize: number;
	totalitems: any;
	page: number = 1;
	last_page: number =1;
	sections: any;
	public defaultparam = {sortBy:"id", sortAsc:true,offset:0,limit:10};
	isshowform = false;
	@ViewChild(DataTable) recTable: DataTable;
	sortingddl = [];
	constructor(private dbserv:DbserviceService,private _alert: AlertsService,private route: ActivatedRoute,private router: Router) 
	{
		for (var i = 1; i <= 100; i++) {
		   this.sortingddl.push(i);
		}
		this.route.params.subscribe(params => {
			if(params['contentid']){
			  this.contentid = +params['contentid'];
			}
			else
			  this.contentid = 0;
			this.loadpage(this.defaultparam);
		});
	}
	ngOnInit() {
		this.dbserv.getAll("gettemplates/Contents").subscribe(res => { 
      this.sections = res;
    });
	}
	loadpage(params:any)
	{
		this.dbserv.getById("content", this.contentid).subscribe(res => {
      if (res.type == "success") {
        this.pagemodel = res.data;
      }
      else
        this._alert.create(res.type, res.message);
    });
		this.dbserv.post("contentstabslist/"+this.contentid,params)
			.subscribe(res => {
				if(res.type=="success")
				{
					this.items = res.records.data; 
					this.page = res.records.current_page; 
					this.totalitems = res.records.total;
					this.pageSize = res.records.per_page;
					this.last_page = res.records.last_page;
				}
				else if(res.type=="expired")
				{
					this.router.navigateByUrl('/admin/login') ;	
				}
				else
				{
					this._alert.create(res.type,res.message);
				}
			});
		this.defaultparam = params;
		this.isshowform = false;
	}
	hideform()
	{
		this.isshowform = false;
	}
	editrecord(id)
	{
		this.isshowform = true;
		this.dbserv.getById("contentstabs",id)
			.subscribe(res => {
				if(res.type=="success"){
					this.model = res.data;
					if(this.model.sections_heading.length == 0){
						this.model.sections_heading.push({ id:0,content_section:'',title:'',sortorder:0 });
					}
				}
				else if(res.type=="expired"){
					this.router.navigateByUrl('/admin/login') ;	
				}
				else{
					this._alert.create(res.type,res.message);
				}
			});
	}
	deleterecord(id)
	{
		if(confirm('Are you sure?')){
			this.isshowform = false;
			this.dbserv.delete("contentstabsdel", id)
				.subscribe(res => {
				  if(res.type=="success"){
						this.loadpage(this.defaultparam);
					}
					else if(res.type=="expired"){
						this.router.navigateByUrl('/admin/login') ;	
					}
					else{
						this._alert.create(res.type,res.message);
					}
			});
		}
	}
	saverecord()
	{
		this.model.contents_id = this.contentid;
		if (this.model.content_section != 'both') {
			this.model.sections_heading.forEach((obj)=>{
				obj.content_section = this.model.content_section;
			})
		}
		// console.log(this.model);
		this.dbserv.save("contentstabssave",this.model)
			.subscribe(res => {
				if(res.type=="success"){
					this.model = {
						id:0,
						contents_id:0,
						template:0,
						content_type: 'fix',
						content_section: '',
						title: '',
						content:"",
						sortorder:0,
						sections_heading:[{
							id:0,
							content_section:'',
							title:'',
							sortorder:0
						}],
						remove_sections_heading:[]
					};
					this.loadpage(this.defaultparam);
					this.isshowform = false;
				}
				else if(res.type=="expired"){
					this.router.navigateByUrl('/admin/login') ;	
				}
				else{
					this._alert.create(res.type,res.message);
				}
		});
	}
	addrecord(){
		this.model = {
			id:0,
			contents_id:0,
			template:0,
			content_type: 'fix',
			content_section: '',
			title: '',
			content:"",
			sortorder:0,
			sections_heading:[{
				id:0,
				content_section:'',
				title:'',
				sortorder:0
			}],
			remove_sections_heading:[]
		};
		this.isshowform = true;
	}
	templatechanged() {
    for (var i = 0; i < this.sections.length; i++) {
      if (this.model.template == this.sections[i].id){
        this.model.content = this.sections[i].content;
      }
    }

  }
  contenttypechanged(){
  	this.model.template = 0;
  	this.model.content = '';
  	this.model.content_section = 'full';
  }
  newHeading(){
  	this.model.sections_heading.push({ id:0,content_section:'',title:'', sortorder:0 });
  	console.log(this.model.sections_heading);
  }
  removeHeading(inx){
  	if (this.model.remove_sections_heading == undefined) {
  		this.model.remove_sections_heading = [];
  	}
  	if(this.model.sections_heading[inx].id > 0)
  		this.model.remove_sections_heading.push(this.model.sections_heading[inx].id);
  	this.model.sections_heading.splice(inx,1);
  }
  statuschange(id: number, action: string) {
    if (confirm('Are you sure?')) {
      this.selectedrecs = [id];
      this.applybtnval = action;
      let newmodel = { 'action': this.applybtnval, 'vals': JSON.stringify(this.selectedrecs) };
      this.dbserv.save("contentstabsperformaction", newmodel).subscribe(res => {

        this._alert.create(res.type, res.message);
        if (res.type == "success") {
          this.loadpage(this.defaultparam);
          this.isshowform = false;
        }
      });
    }
  }
}
