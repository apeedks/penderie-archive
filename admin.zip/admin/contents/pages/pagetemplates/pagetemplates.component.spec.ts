import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PagetemplatesComponent } from './pagetemplates.component';

describe('PagetemplatesComponent', () => {
  let component: PagetemplatesComponent;
  let fixture: ComponentFixture<PagetemplatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PagetemplatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PagetemplatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
