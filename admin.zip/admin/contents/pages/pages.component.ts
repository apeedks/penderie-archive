import { Component, OnInit , ViewChild, ElementRef} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DbserviceService } from '../../services/dbservice.service';
import { AlertsService } from '@jaspero/ng2-alerts';
import { DataTable } from 'angular-4-data-table/src/index';
import { PagesState,INITIAL_PAGESSTATE_STATE } from './pages-state'
import {ImageCropperComponent, CropperSettings, Bounds} from 'ng2-img-cropper';
import $ from 'jquery';
declare var ckTabsObject: any;
//declare var ckTabsObject1: any;
@Component({
  selector: 'app-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['../../nav/adminheader.component.css']
})
export class PagesComponent implements OnInit {
  public items = [];
  visiblefilter = false;
  wasClicked:boolean = false;
  rootpath:string;
  custo_filter_onen_close = false;
  model = {
          id: 0,
          title: '',
          content_type: 'tab',
          template: "",
          tabs:1,
          image: null,
          sortorder: "",
          content: "",
          summary: "",
          menulink: "",
          menutext: "",
          metatitle: "",
          metakeyword: "",
          metadescr: "",
          paccess: "",
          gender: "",
          section: "All",
          linkpos: "",
          currentlist: "",
          active: "",
          templateContent: ""
        };
  options: any;
  pageSize: number;
  totalitems: any;
  page: number = 1;
  last_page: number = 1;
  showimage=false;
  public defaultparam = {
    sortBy: "id",
    sortAsc: true,
    offset: 0,
    limit: 10,
    sortfield: "All",
    searchstr: "",
    status:[],
    gender:[]
  };
  public errormsg = '';
  sections: any;
  filterfield: string = 'All';
  isshowform = false;
  currentlist: string = 'All';
  applybtnval: string = '';
  headerimage: string = '';
  uploadedimage = null;
  sortfield: string = 'All';
  selectedrecs = [];
  loading:boolean=false;
  searchfield: string = '';
  summary = { Published: 0, Archived: 0, Trash: 0, Draft: 0, Total: 0 };
  searchgender:string = "Both";
  @ViewChild(DataTable) recTable: DataTable;
  @ViewChild('lnksaveprofilebox') lnksaveprofilebox:ElementRef;
  @ViewChild('cropper', undefined) cropper:ImageCropperComponent;
  imagedata:any;
  cropperSettings:CropperSettings;
  croppedWidth:number;
  croppedHeight:number;
  dragAreaClass:string='dragarea';
  uploadedsymbol:any=null;
  symbolimage = '';
  uploadedimagebtn:boolean=false;
  uploadedsymbolbtn:boolean=false;
  imagepreviewurl:string='';
  sortingddl = [];
  constructor(private dbserv: DbserviceService, private _alert: AlertsService) {
    this.rootpath = localStorage.getItem('baseurl');
    this.searchgender = localStorage.getItem('visittype');
    this.cropperSettings = new CropperSettings();
    this.cropperSettings.width = 1920;
    this.cropperSettings.height = 1280;
    this.cropperSettings.croppedWidth = 1920;
    this.cropperSettings.croppedHeight = 1280;
    this.cropperSettings.canvasWidth = 420;
    this.cropperSettings.noFileInput = true;
    this.cropperSettings.canvasHeight = 300;
    this.cropperSettings.touchRadius = 20;
    this.cropperSettings.rounded = false;
    this.cropperSettings.keepAspect = true;
    this.imagedata = {};
    for (var i = 1; i <= 100; i++) {
      this.sortingddl.push(i);
    }
  }
  statusselectedchange() {
    if (this.applybtnval != '') {
      if (this.recTable.selectedRows.length > 0) {
        if (confirm('Are you sure?')) {
          this.selectedrecs = [];
          for (var i = 0; i < this.recTable.selectedRows.length; i++) {
            this.selectedrecs.push(this.recTable.selectedRows[i].item.id);
          }
          let newmodel = { 'action': this.applybtnval, 'vals': JSON.stringify(this.selectedrecs) };
          this.dbserv.save("performaction", newmodel).subscribe(res => {
            //this._alert.create(res.type, res.message);
            if (res.type == "success") {
              this.loadpage(this.defaultparam);
              this.isshowform = false;
            }
          });
        }
      }
      else {
        this._alert.create('error', 'Please, select some record first.');
      }
    }

  }
  statuschange(id: number, action: string) {
    if (confirm('Are you sure?')) {
      this.selectedrecs = [id];
      this.applybtnval = action;
      let newmodel = { 'action': this.applybtnval, 'vals': JSON.stringify(this.selectedrecs) };
      this.dbserv.save("performaction", newmodel).subscribe(res => {

        this._alert.create(res.type, res.message);
        if (res.type == "success") {
          this.loadpage(this.defaultparam);
          this.isshowform = false;
        }
      });
    }
  }
  templatechanged() {
    for (var i = 0; i < this.sections.length; i++) {
      if (this.model.template == this.sections[i].id){
        this.model.content = this.sections[i].content;
        this.model.templateContent = this.sections[i].content;
        this.model.tabs = 0;
      }
    }
  }
  fileChange($event) {
    console.log($event.target.files[0]);
    this.uploadedimage = $event.target.files[0];
  }
  sortchanged() {
    this.defaultparam.sortfield = this.sortfield;
    this.loadpage(this.defaultparam);
  }
  loadpage(params: any) {
    params.searchstr = this.searchfield;
    params.status = this.defaultparam.status;
    params.gender = this.defaultparam.gender;
    this.dbserv.post("contents/"+this.searchgender+"/"+ this.currentlist, params).subscribe(res => {
      this.items = res.data;
      this.page = res.current_page;
      this.totalitems = res.total;
      this.pageSize = res.per_page;
      this.last_page = res.last_page;
      this.dbserv.post("contentsummary/" + this.currentlist, params).subscribe(res => {
        this.summary = res;
      });
    });

    this.defaultparam = params;
    this.isshowform = false;
  }
  searchfilter($event) {
    console.log(this.model.title);
  }
  	slug(str) {
	    var $slug = '';
	    var trimmed = $.trim(str);
	    $slug = trimmed.replace(/[^a-z0-9-]/gi, '-').
	    replace(/-+/g, '-').
	    replace(/^-|-$/g, '');
	    this.model.menulink = $slug.toLowerCase();
	}
  ngOnInit() {
    /*this.loadpage(this.defaultparam);*/
    this.dbserv.getAll("gettemplates/Contents").subscribe(res => { 
      this.sections = res;
    });

    //ckTabsObject.eventCkTabs();
    //ckTabsObject.eventCkTabs1();

  }
  switchcurrentlist() {
    this.currentlist = this.filterfield;
    this.loadpage(this.defaultparam);
  }
  hideform() {
    this.isshowform = false;
  }
  editrecord(id) {
    this.isshowform = true;
    this.showimage = false;
    this.dbserv.getById("content", id).subscribe(res => {
      if (res.type == "success") {
        this.model = res.data;
        // this.getTabsCount();
        this.headerimage = "assets/pageheaders/" + this.model.image;
      }
      else
        this._alert.create(res.type, res.message);
    });
  }
  deleterecord(id) {
    if (confirm('Are you sure?')) {
      this.isshowform = false;
      this.dbserv.delete("contentdel", id).subscribe(res => { this._alert.create(res.type, res.message); this.loadpage(this.defaultparam); });
    }

  }
  changevalue(type: string) {
    this.model.active = type;
  }
  saverecord() {
      this.loading = true;
    let _formData = new FormData();
    _formData.append("id", this.model.id.toString());
    _formData.append("title", this.model.title);
    _formData.append("content", this.model.content);
    _formData.append("content_type", this.model.content_type);
    _formData.append("template", this.model.template.toString());
    _formData.append("tabs", this.model.tabs.toString());
    _formData.append("menulink", this.model.menulink);
    _formData.append("menutext", this.model.menutext);
    _formData.append("summary", this.model.summary);
    _formData.append("paccess", this.model.paccess);
    _formData.append("metatitle", this.model.metatitle);
    _formData.append("metakeyword", this.model.metakeyword);
    _formData.append("metadescr", this.model.metadescr);
    _formData.append("gender", this.model.gender);
    _formData.append("section", this.model.section);
    _formData.append("sortorder", this.model.sortorder.toString());
    _formData.append("linkpos", this.model.linkpos);
    _formData.append("currentlist", this.model.currentlist);
    _formData.append("active", this.model.active);
    
    if(this.imagedata.image != '' && this.imagedata.image != null)
    {
        _formData.append('image',this.imagedata.image);
        
    }
    
    if(this.uploadedimage!=null && this.uploadedimage.name!='')
    {
        _formData.append('image',this.uploadedimage, this.uploadedimage.name);
        _formData.append('imagesrc',this.uploadedimage, this.uploadedimage.name);
    }
    
    this.dbserv.saveimage("contentsave", _formData).subscribe(res => {

      this._alert.create(res.type, res.message);
      if (res.type == "success") {
        this.model = {
                id: 0,
                title: '',
                content_type: 'tab',
                template: "",
                tabs:1,
                image: null,
                sortorder: "",
                content: "",
                summary: "",
                menulink: "",
                menutext: "",
                metatitle: "",
                metakeyword: "",
                metadescr: "",
                paccess: "",
                gender: "",
                section: "All",
                linkpos: "",
                currentlist: "",
                active: "",
                templateContent: ""
              };
        this.loadpage(this.defaultparam);
        this.imagedata={};
        this.isshowform = false;
        this._alert.create(res.type, res.message);
      }
      this.loading = false;
    });



  }
  addrecord() {
    this.model = {
            id: 0,
            title: '',
            content_type: 'tab',
            template: "",
            tabs:1,
            image: null,
            sortorder: "",
            content: "",
            summary: "",
            menulink: "",
            menutext: "",
            metatitle: "",
            metakeyword: "",
            metadescr: "",
            paccess: "",
            gender: "",
            section: "All",
            linkpos: "",
            currentlist: "",
            active: "",
            templateContent: ""
          };
    this.isshowform = true;
    this.showimage = false;
    this.imagedata={};

  }

  changeTabs(event){
    let value = event;
    if(event.target != undefined){
      value = event.target.value;
      if(value > 0){
        this.model.content = '';

        let templateVal = "Content";

        if(this.model.templateContent !==""){
            templateVal = this.model.templateContent;
        }

        // if(value - this.model.tabs == 0){
          // this.getTabsCount();
          let tabs = '<tabs><div class="tabs_contents col-md-12 col-sm-12 col-xs-12"><div class="bootstrap-tabs statictabbing" data-number-of-tabs="5" data-tab-set-title="sample">';
          tabs += '<ul class="nav nav-tabs" role="tablist">';
          for (var i = 1; i <= value; i++) {
            if(value < this.model.tabs)
              continue;
            if(i==1){
              tabs += '<li class="active" role="presentation"><a aria-controls="sample-tab-'+i+'" data-target="#sample-tab-'+i+'" class="tab-link" data-toggle="tab" href="#sample-tab-'+i+'" role="tab">Tab Name '+i+'</a></li>';
            }else{
            tabs += '<li role="presentation"><a aria-controls="sample-tab-'+i+'" class="tab-link" data-toggle="tab" data-target="#sample-tab-'+i+'" href="#sample-tab-'+i+'" role="tab">Tab Name '+i+'</a></li>';
            }
          }
          tabs += '</ul>';
          tabs += '</div></tabs>';

          tabs += '<div class="tab-content">';
          for (var i = 1; i <= value; i++) {
            if(value < this.model.tabs)
              continue;
            if(i==1){
              tabs += '<div class="tab-pane active" id="sample-tab-'+i+'" role="tabpanel"><div class="tab-pane-content">'+templateVal+'</div></div>';
            }else{
            tabs += '<div class="tab-pane" id="sample-tab-'+i+'" role="tabpanel"><div class="tab-pane-content">'+templateVal+'</div></div>';
            }
          }

          tabs += '</div>';
          tabs += '</div>';

          this.model.content = this.model.content.substring(this.model.content.indexOf('<div class="container">'));
          this.model.content = tabs + this.model.content;
        // }else{
        //   this.model.content = this.model.content.substring(this.model.content.indexOf('<div class="container">'));
        // }
      }else{
        this.model.content = this.model.content.substring(this.model.content.indexOf('<div class="container">'));
      }
    }
  }


changeTabsOld(event){
    let value = event;
    if(event.target != undefined){
      value = event.target.value;
      if(value > 0){
        // if(value - this.model.tabs == 0){
          // this.getTabsCount();
          let tabs = '<tabs><div class="tabs_contents col-md-12 col-sm-12 col-xs-12">';
          tabs += '<div class="statictabbing">';
          tabs += '<ul>';
          for (var i = 1; i <= value; i++) {
            if(value < this.model.tabs)
              continue;
            tabs += '<li><a href="/">Link '+i+'</a></li>';
          }
          tabs += '</ul>';
          tabs += '</div>';
          tabs += '</div></tabs>';
          this.model.content = this.model.content.substring(this.model.content.indexOf('<div class="container">'));
          this.model.content = tabs + this.model.content;
        // }else{
        //   this.model.content = this.model.content.substring(this.model.content.indexOf('<div class="container">'));
        // }
      }else{
        this.model.content = this.model.content.substring(this.model.content.indexOf('<div class="container">'));
      }
    }
  }


  getTabsCount(){
    this.model.content = this.model.content.replace(/<p>&nbsp;<\/p>/gi, '');
    this.model.content = this.model.content.replace(/<p><\/p>/gi, '');
    let tabPoint = this.model.content.indexOf("<tabs>");
    if(tabPoint != -1){
      let tabString = this.model.content.substring(tabPoint,this.model.content.indexOf("</tabs>"));
      let tabsItems = tabString.substring(this.model.content.indexOf("<ul>"),this.model.content.indexOf("</ul>")).split("<li>");
      this.model.tabs = tabsItems.length - 1;
    }
  }
  changestatus(event:any){
      console.log(event);
      this.defaultparam.status = event;
      this.loadpage(this.defaultparam);
  }
  
  changegender(event:any){
      console.log(event);
      this.defaultparam.gender = event;
      this.loadpage(this.defaultparam);
  }

  ngAfterViewInit() {
    $(".custo-filter-colap").click(function(e){
      if(!$(this).hasClass('custo_filter_onen_close')){
        $(this).next(".utl-filter-box").addClass('visiblefilter');
        $(this).addClass('custo_filter_onen_close');
        e.stopPropagation();
      }else{
        $(".utl-filter-box").removeClass('visiblefilter');
        $(".custo-filter-colap").removeClass('custo_filter_onen_close');
        e.stopPropagation();
      }
    });

    $(".utl-filter-box").click(function(e){
      e.stopPropagation();
    });

    $(document).click(function(){
      $(".utl-filter-box").removeClass('visiblefilter');
      $(".custo-filter-colap").removeClass('custo_filter_onen_close');
    });
  }
  cropped(bounds:Bounds) {
      this.croppedHeight =bounds.bottom-bounds.top;
      this.croppedWidth = bounds.right-bounds.left;
}
  
  fileChangeListener($event) {
      var image:any = new Image();
      var file:File = $event.target.files[0];
      var myReader:FileReader = new FileReader();
      var that = this;
      myReader.onloadend = function (loadEvent:any) {
          image.src = loadEvent.target.result;
          that.cropper.setImage(image);

      };

      myReader.readAsDataURL(file);
      }
      previewFile(file) {
         console.log(file);
         var request = new XMLHttpRequest();
         request.open('GET', file, true);
         request.responseType = 'blob';
         var image:any = new Image();
         request.onload = () => {
             var reader = new FileReader();
             reader.readAsDataURL(request.response);
             reader.onload = (event:any) => {
                 image.src = event.target.result; 
                 this.cropper.setImage(image);
             };
             reader.onloadend = (event:any) => {
                 image.src = event.target.result; 
                 this.cropper.setImage(image);
             };
         };
         request.send();
     }
     readImageUrl() {
       if (this.uploadedimage && this.uploadedimage) {
         var reader = new FileReader();
         var image:any = new Image();
         reader.onload = (event:any) => {
            image.src = event.target.result; 
             this.cropper.setImage(image);
         }
         reader.onloadend = (event:any) => {
            image.src = event.target.result; 
             this.cropper.setImage(image);
         };
         reader.readAsDataURL(this.uploadedimage);
       }
     }
     saveprofileimage(){
         this.lnksaveprofilebox.nativeElement.click();
         this.showimage = true;
     }
     onFileChange($event){
         this.uploadedimage = $event.target.files[0];
         this.readImageUrl();
         //this.saveprofileimage( $event.target.files[0]);
      }
     clickfortotalitem()
     {      
         this.filterfield = 'All';
         this.currentlist = 'All';
         this.defaultparam.status=[];
         this.defaultparam.gender=[];
     }
}
