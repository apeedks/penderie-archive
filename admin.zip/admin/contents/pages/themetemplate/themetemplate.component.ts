import { Component, OnInit , ViewChild, ElementRef} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { DataTable } from 'angular-4-data-table/src/index';
import {ImageCropperComponent, CropperSettings, Bounds} from 'ng2-img-cropper';
import $ from 'jquery';

@Component({
  selector: 'app-themetemplate',
  templateUrl: './themetemplate.component.html',
	styleUrls: ['../../../nav/adminheader.component.css', './themetemplate.component.css']
})
export class ThemetemplateComponent implements OnInit {
	model = {id:0, title: '',image:null,menulink:"",menutext:"",paccess:"",gender:"",section: "All",metatitle: "",metakeyword: "",metadescr: "",linkpos: "",active: ""};
	pageSize: number;
	last_page:number =0;
	options:any;
	@ViewChild('lnksaveprofilebox') lnksaveprofilebox:ElementRef;
	templatetype: string;
	loading:boolean=false;
	totalitems: any;
	showimage=false;
	page: number = 1;
	uploadedimage = null;
	public defaultparam = {sortBy:"id", sortAsc:true,offset:0,limit:10,sortfield:"All",searchstr:""};
	public items:Object;
	public errormsg = '';
	headerimage:string = '';
	isshowform = false;
	currtime:any;
	rootpath:string;
	filterfield:string='All';
	applybtnval:string = '';
	sortfield:string = 'All';
	selectedrecs	= [];
	searchfield:string = '';
	summary = {Published:0, Archived:0,Trash:0,Draft:0,Total:0};
	@ViewChild(DataTable) recTable: DataTable;
	@ViewChild('cropper', undefined) cropper:ImageCropperComponent;
	imagedata:any;
    cropperSettings:CropperSettings;
    croppedWidth:number;
    croppedHeight:number;
    dragAreaClass:string='dragarea';
    uploadedsymbol:any=null;
    symbolimage = '';
    uploadedimagebtn:boolean=false;
    uploadedsymbolbtn:boolean=false;
    imagepreviewurl:string='';
	constructor(private dbserv:DbserviceService,private _alert: AlertsService,private route: ActivatedRoute) { 
		    this.rootpath = localStorage.getItem('baseurl');
	        this.cropperSettings = new CropperSettings();
	        this.cropperSettings.width = 1920;
	        this.cropperSettings.height = 1280;
	        this.cropperSettings.croppedWidth = 1920;
	        this.cropperSettings.croppedHeight = 1280;
	        this.cropperSettings.canvasWidth = 420;
	        this.cropperSettings.noFileInput = true;
	        this.cropperSettings.canvasHeight = 300;
	        this.cropperSettings.touchRadius = 20;
	        this.cropperSettings.rounded = false;
	        this.cropperSettings.keepAspect = true;
	        this.imagedata = {};
	}
	fileChange($event){
		console.log($event.target.files[0]);
		this.uploadedimage = $event.target.files[0];
	}
	ngOnInit() {
	    this.route.params.subscribe(params => {
		    this.templatetype = params['templatetype']; // (+) converts string 'id' to a number
		});
		/*this.loadpage(this.defaultparam);*/
	}
	statusselectedchange()
	{
		if(this.applybtnval!='')
		{
			if(this.recTable.selectedRows.length>0)
			{
				if(confirm('Are you sure?'))
				{
					this.selectedrecs=[];
					for(var i = 0;i<this.recTable.selectedRows.length;i++) 
					{ 
						this.selectedrecs.push(this.recTable.selectedRows[i].item.id);
					}
					let newmodel = {'action':this.applybtnval,'vals':JSON.stringify(this.selectedrecs)};
					this.dbserv.save("templateperformaction",newmodel).subscribe(res => {
																  
																   this._alert.create(res.type,res.message);
																   if(res.type=="success")
																   {
																		this.loadpage(this.defaultparam);
																		this.isshowform = false;
																   }
																 }); 
				}
			}
			else
			{
				this._alert.create('error','Please, select some record first.');
			}
		}
	}
	statuschange(id:number,action:string)
	{
		if(confirm('Are you sure?'))
		{
			this.selectedrecs=[id];
			this.applybtnval = action;
			let newmodel = {'action':this.applybtnval,'vals':JSON.stringify(this.selectedrecs)};
			this.dbserv.save("templateperformaction",newmodel).subscribe(res => {
															  
															   this._alert.create(res.type,res.message);
															   if(res.type=="success")
															   {
																	this.loadpage(this.defaultparam);
																	this.isshowform = false;
															   }
															 }); 
		}
	}

	loadpage(params)
	{
		params.searchstr = this.searchfield;
		params.sortfield = this.sortfield;
		this.currtime = Math.random();
		this.dbserv.post("templates/"+this.filterfield,params).subscribe(res => {
													  	this.items = res.data; 
														this.page = res.current_page; 
														this.totalitems = res.total;
														this.pageSize = res.per_page;
														this.last_page = res.last_page;
														this.dbserv.post("templatesummary/"+this.filterfield,params).subscribe(res => {
																this.summary = res;
															}); 
													}); 
		this.isshowform = false;
	}
	
	hideform()
	{
		this.isshowform = false;
	}
	editrecord(id)
	{
		this.isshowform = true;
		this.currtime = Math.random();
		this.showimage = false;
		this.uploadedimage = null;
		this.cropper.reset();
		this.dbserv.getById("template",id).subscribe(res => {
													if(res.type=="success")
														this.model=res.data;
													else
														this._alert.create(res.type,res.message);
													});
		
	}
	deleterecord(id)
	{
		if(confirm('Are you sure?'))
		{
			this.isshowform = false;
			this.dbserv.delete("templatedel", id).subscribe(res => { this._alert.create(res.type,res.message);this.loadpage(this.defaultparam);});
		}
		
	}
	saverecord(){
		this.loading = true;
		let _formData = new FormData();
		_formData.append("id",this.model.id.toString());
		_formData.append("title",this.model.title);
		_formData.append("menulink",this.model.menulink);
		_formData.append("menutext",this.model.menutext);
		_formData.append("gender",this.model.gender);
		_formData.append("section",this.model.section);
		_formData.append("linkpos",this.model.linkpos);
		_formData.append("paccess",this.model.paccess);
		_formData.append("metatitle",this.model.metatitle);
		_formData.append("metakeyword",this.model.metakeyword);
		_formData.append("metadescr",this.model.metadescr);
		if (this.model.active == 'Preview') {
			_formData.append("active",'Draft');
		}else{
			_formData.append("active",this.model.active);
		}
		if(this.imagedata.image != '' && this.imagedata.image != null){
			_formData.append('image',this.imagedata.image);
		}
		if(this.uploadedimage!=null && this.uploadedimage.name!=''){
			_formData.append('image',this.uploadedimage, this.uploadedimage.name);
			_formData.append('imagesrc',this.uploadedimage, this.uploadedimage.name);
		}
		
		this.dbserv.saveimage("templatesave",_formData).subscribe(res => {
															  
															   this._alert.create(res.type,res.message);
															   if(res.type=="success")
															   {
															    	this.model = {id:0, title: '',image:null,menulink:"",menutext:"",paccess:"",gender:"",section: "All",metatitle: "",metakeyword: "",metadescr: "",linkpos: "",active: ""};
																	this.loadpage(this.defaultparam);
																	   this.imagedata={};
																	this.isshowform = false;
															   }
															   this.loading = false;
															 }); 
		
	}
	addrecord(){
		this.model = {id:0, title: '',image:null,menulink:"",menutext:"",paccess:"",gender:"",section: "All",metatitle: "",metakeyword: "",metadescr: "",linkpos: "",active: ""};
		this.isshowform = true;
		this.showimage = false;
		this.imagedata={};
	}

	changevalue(type:string){
		this.model.active = type;
	}
	slug(str) {
	    var $slug = '';
	    var trimmed = $.trim(str);
	    $slug = trimmed.replace(/[^a-z0-9-]/gi, '-').
	    replace(/-+/g, '-').
	    replace(/^-|-$/g, '');
	    this.model.menulink = $slug.toLowerCase();
	}
	// for image
    cropped(bounds:Bounds) {
            this.croppedHeight =bounds.bottom-bounds.top;
            this.croppedWidth = bounds.right-bounds.left;
}
	  fileChangeListener($event) {
	      var image:any = new Image();
	      var file:File = $event.target.files[0];
	      var myReader:FileReader = new FileReader();
	      var that = this;
	      myReader.onloadend = function (loadEvent:any) {
	          image.src = loadEvent.target.result;
	          that.cropper.setImage(image);

	      };

	      myReader.readAsDataURL(file);
	      }
	     previewFile(file) {
	         console.log(file);
	         var request = new XMLHttpRequest();
	         request.open('GET', file, true);
	         request.responseType = 'blob';
	         var image:any = new Image();
	         request.onload = () => {
	             var reader = new FileReader();
	             reader.readAsDataURL(request.response);
	             reader.onload = (event:any) => {
	                 image.src = event.target.result; 
	                 this.cropper.setImage(image);
	             };
	             reader.onloadend = (event:any) => {
	                 image.src = event.target.result; 
	                 this.cropper.setImage(image);
	             };
	         };
	         request.send();
	     }
	     readImageUrl() {
	       if (this.uploadedimage && this.uploadedimage) {
	         var reader = new FileReader();
	         var image:any = new Image();
	         reader.onload = (event:any) => {
	            image.src = event.target.result; 
	             this.cropper.setImage(image);
	         }
	         reader.onloadend = (event:any) => {
	            image.src = event.target.result; 
	             this.cropper.setImage(image);
	         };
	         reader.readAsDataURL(this.uploadedimage);
	       }
	     }
	     saveprofileimage(){
	         this.lnksaveprofilebox.nativeElement.click();
	         this.showimage = true;
	     }
	     onFileChange($event){
	         this.uploadedimage = $event.target.files[0];
	         this.readImageUrl();
	         //this.saveprofileimage( $event.target.files[0]);
	      }

}
