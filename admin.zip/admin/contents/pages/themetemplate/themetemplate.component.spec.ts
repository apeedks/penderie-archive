import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThemetemplateComponent } from './themetemplate.component';

describe('ThemetemplateComponent', () => {
  let component: ThemetemplateComponent;
  let fixture: ComponentFixture<ThemetemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThemetemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThemetemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
