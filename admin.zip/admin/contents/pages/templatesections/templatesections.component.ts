import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
@Component({
  selector: 'app-templatesections',
  templateUrl: './templatesections.component.html',
  styleUrls: ['../../../nav/adminheader.component.css']
})
export class TemplatesectionsComponent implements OnInit {
	model = {
		id:0,
		image:"",
		background_image:"about_img1-1510166163.jpg",
		title: '',
		content: "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis par turient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque, pretium quis,.",
		page:0,
		page_url:"",
		page_title:"",
		page_summary:"",
		template:0,
		sorting:0,
		templateid:0,
		pageid:0,
		active: "",
		heading_box_background_color:"",
		heading_box_body_text_color:"",
		heading_box_text_color:"",
		background_color:"",
		text_color:"red",
		body_text_color:"red",
		background_box_transparency:"",
		heading:false
	};
	pageSize: number;
	options:any;
	templateid: number;
	headerimage:string = '';
	uploadedimage = null;
	totalitems: any;
	page: number = 1;
	public items:Object;
	sections:any;
	public errormsg = '';
	isshowform = false;
	totalsortnums = [];
	sortingddl = [];
	pages=[];
	loading:boolean=false;

	corporate_colors = ['red', 'blue', 'green', 'orange'];
	heading_box_background_colors = ['silver', 'red', 'blue', 'green', 'orange'];
	heading_box_text_colors = ['red', 'blue', 'green', 'orange', 'gray', 'white'];
	heading_box_body_text_colors = ['red', 'blue', 'green', 'orange', 'gray', 'white'];
	background_colors =  ['red', 'blue', 'green', 'orange', 'gray', 'white'];
	text_colors = ['red', 'blue', 'green', 'orange', 'gray', 'white'];
	body_text_colors = ['red', 'blue', 'green', 'orange', 'gray', 'white'];
	background_box_transparencys = ['red', 'blue', 'green', 'orange', 'gray', 'white'];
	templates = [
		{
			id:1,
			content:"",
			heading:false
		},
		{
			id:2,
			content:"",
			heading:true
		},
		{
			id:3,
			content:"",
			heading:true
		},
		{
			id:4,
			content:"",
			heading:true
		},
		{
			id:5,
			content:"",
			heading:true
		},
		{
			id:6,
			content:"",
			heading:false
		},
		{
			id:7,
			content:"",
			heading:false
		},
		{
			id:8,
			content:"",
			heading:false
		}
	];
	rootpath = "";

	constructor(private dbserv:DbserviceService,private _alert: AlertsService,private route: ActivatedRoute) { 
		this.rootpath = localStorage.getItem('baseurl');
		if(this.uploadedimage==null || this.uploadedimage.name=='')
		{
			if (this.model.background_image == '' || this.model.background_image == null) {
				this.model.background_image = this.rootpath + 'assets/themes/' + "about_img1-1510166163.jpg";
			}
			else{
				this.model.background_image = this.rootpath + 'assets/themes/' + this.model.background_image;
			}
		}
		for (var i = 1; i <= 100; i++) {
		   this.sortingddl.push(i);
		}
	}
	templatechanged()
	{
		// for(var i = 0;i<this.sections.length;i++) { 
		// 	if(this.model.template==this.sections[i].id)
		//     this.model.content = this.sections[i].content; 
		// }
		this.corporate_colors = ['red', 'blue', 'green', 'orange'];
		this.heading_box_background_colors = [];
		this.heading_box_text_colors = [];
		this.background_colors =  [];
		this.text_colors = [];
		this.background_box_transparencys = [];
		this.templates.forEach((cnt)=>{
			if(cnt.id == this.model.template){
				this.model.heading = cnt.heading;
			}
		});
		if (this.model.template == 1) {
			this.text_colors = Array.from(this.corporate_colors);
			this.model.text_color = "blue";
			this.model.body_text_color = "gray";
		}
		if (this.model.template == 6 || this.model.template == 7) {
			this.text_colors = Array.from(this.corporate_colors);
			this.text_colors.push('white');
			this.text_colors.push('gray');
			this.model.text_color = "white";
			this.model.body_text_color = "white";
		}
		if (this.model.template == 8) {
			this.text_colors = Array.from(this.corporate_colors);
			this.background_colors = Array.from(this.corporate_colors);
			this.text_colors.push('white');
			this.text_colors.push('gray');
			this.background_colors.push('white');
			this.background_colors.push('gray');
			this.model.text_color = "white";
			this.model.background_color = "red";
			this.model.body_text_color = "white";
		}
		if (this.model.template == 2 || this.model.template == 3) {
			this.heading_box_background_colors = Array.from(this.corporate_colors);
			this.text_colors = Array.from(this.corporate_colors);
			this.text_colors.push('white');
			this.text_colors.push('gray');
			this.model.heading_box_background_color = "red";
			this.model.text_color = "white";
			this.model.heading_box_text_color = "white";
			this.model.heading_box_body_text_color = "white";
			this.model.body_text_color = "white";
		}
		if (this.model.template == 4 || this.model.template == 5) {
			this.heading_box_text_colors = Array.from(this.corporate_colors);
			this.text_colors = Array.from(this.corporate_colors);
			this.heading_box_text_colors.push('gray');
			this.text_colors.push('white');
			this.text_colors.push('gray');
			this.model.heading_box_background_color = "silver";
			this.model.text_color = "white";
			this.model.heading_box_text_color = "red";
			this.model.heading_box_body_text_color = "red";
			this.model.body_text_color = "white";
		}
	}
	pagechanged(){
		this.model.page_url = '';
		this.model.page_title = '';
		this.model.page_summary = '';
		this.pages.forEach((cnt)=>{
			if(cnt.id == this.model.page){
				this.model.page_url = cnt.menulink;
				this.model.page_title = cnt.title;
				this.model.page_summary = cnt.summary;
			}
		});
	}
	fileChange(event){
		console.log(event.target.files[0]);
		this.uploadedimage = event.target.files[0];
		if (event.target.files && event.target.files[0]) {
	    var reader = new FileReader();

	    reader.onload = (event: ProgressEvent) => {
	      this.model.background_image = (<FileReader>event.target).result.toString();
	    }

	    reader.readAsDataURL(event.target.files[0]);
	  }
	}
	ngOnInit() {
	    scroll(0,0);
	    this.route.params.subscribe(params => {
		    this.templateid = +params['templateid']; // (+) converts string 'id' to a number
		    this.dbserv.getById("template",this.templateid)
		    	.subscribe(res => {
		    		if (res.type == "success") {
		    			this.dbserv.getById("getcontentlinkpos",res.data.linkpos)
		    				.subscribe(resc => {
		    					if (res.type == "success") {
		    						this.pages = resc.data;
		    					}
		    				});
		    		}
		    	});
		});
		this.loadpage(this.page);
		this.dbserv.getAll("gettemplates/Themes").subscribe(res => {this.sections = res;});
	}
	
	loadpage(pageno)
	{
		this.dbserv.getAll("templatesections/"+this.templateid+"/"+pageno).subscribe(res => {
		
		this.items = res.data; 
		this.page = res.current_page; 
		this.totalitems = res.total;
		this.pageSize = res.per_page;}); 
		this.isshowform = false;
	}
	pageChanged($event)
	{
	  console.log($event);this.loadpage($event) ; 
	}
	hideform()
	{
		this.isshowform = false;
	}
	editrecord(id)
	{
		this.isshowform = true;
		this.uploadedimage=null;
		this.dbserv.getById("templatesection",id)
			.subscribe(res => {
				if(res.type=="success")
				{
					this.model=res.data.content_obj;
					this.model.id = res.data.id;
					this.headerimage = "assets/themes/" + this.model.image;
					if(this.uploadedimage==null || this.uploadedimage.name==''){
						if (this.model.background_image == '' || this.model.background_image == null) {
							this.model.background_image = this.rootpath + 'assets/themes/' + "about_img1-1510166163.jpg";
						}
						else{
							this.model.background_image = this.rootpath + 'assets/themes/' + this.model.background_image;
						}
					}
					// this.model.background_image = this.rootpath + "assets/themes/" + this.model.image;
				}
				else
					this._alert.create(res.type,res.message);
				});
		
	}
	deleterecord(id)
	{
		if(confirm('Are you sure?'))
		{
			this.isshowform = false;
			this.dbserv.delete("deltemplatesection", id).subscribe(res => { this._alert.create(res.type,res.message);this.loadpage(this.page);});
		}
	}
	saverecord()
	{
		this.model.templateid = this.templateid;
		this.loading = true;
		let _formData = new FormData();
		_formData.append("id",this.model.id.toString());
		_formData.append("title",this.model.title);
		_formData.append("content",this.model.content);
		_formData.append("templateid",this.model.templateid.toString());
		_formData.append("template",this.model.template.toString());
		_formData.append("pageid",this.model.pageid.toString());
		_formData.append("sorting",this.model.sorting.toString());
		_formData.append("active",this.model.active);
		if(this.uploadedimage!=null && this.uploadedimage.name!='')
		{
			_formData.append('image',this.uploadedimage, this.uploadedimage.name);
		}
		_formData.append("model",JSON.stringify(this.model));
		this.dbserv.saveimage("templatesavesection",_formData)
			.subscribe(res => {
		    this._alert.create(res.type,res.message);
		    if(res.type=="success"){
		    	this.model = {
						id:0,
						image:"",
						background_image:"about_img1-1510166163.jpg",
						title: '',
						content: "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis par turient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque, pretium quis,.",
						page:0,
						page_url:"",
						page_title:"",
						page_summary:"",
						template:0,
						sorting:0,
						templateid:0,
						pageid:0,
						active: "",
						heading_box_background_color:"",
						heading_box_text_color:"",
						heading_box_body_text_color:"",
						background_color:"",
						text_color:"red",
						body_text_color:"red",
						background_box_transparency:"",
						heading:false
					};
					this.loadpage(this.page);
					this.isshowform = false;
		    }
				this.loading = false;
		 });
		
	}
	addrecord()
	{
		this.model = {
			id:0,
			image:"",
			background_image:"about_img1-1510166163.jpg",
			title: '',
			content: "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis par turient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque, pretium quis,.",
			page:0,
			page_url:"",
			page_title:"",
			page_summary:"",
			template:0,
			sorting:0,
			templateid:0,
			pageid:0,
			active: "",
			heading_box_background_color:"",
			heading_box_text_color:"",
			heading_box_body_text_color:"",
			background_color:"",
			text_color:"red",
			body_text_color:"red",
			background_box_transparency:"",
			heading:false
		};
		if(this.uploadedimage==null || this.uploadedimage.name=='')
		{
			if (this.model.background_image == '' || this.model.background_image == null) {
				this.model.background_image = this.rootpath + 'assets/themes/' + "about_img1-1510166163.jpg";
			}
			else{
				this.model.background_image = this.rootpath + 'assets/themes/' + this.model.background_image;
			}
		}
		this.isshowform = true;
		
	}

}
