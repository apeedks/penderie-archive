import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplatesectionsComponent } from './templatesections.component';

describe('TemplatesectionsComponent', () => {
  let component: TemplatesectionsComponent;
  let fixture: ComponentFixture<TemplatesectionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplatesectionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplatesectionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
