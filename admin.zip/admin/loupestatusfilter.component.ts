import { Component, OnInit, ViewChild ,Input, EventEmitter, Output, OnChanges } from '@angular/core';
import $ from 'jquery';
@Component({
    selector: 'app-loupestatusfilter',
    template: `<div class="inner-filts-bloger">
              <div class="our-checkboxs bigst-s-font">
                  <p><input type="checkbox" id="s-54"   name="check[]" (change)="selectloupestatus()"  /><label for="s-54">Status </label></p>
              </div>
              <ul class="mCustomScrollbar cust-sel-marg">
                  <div class="our-checkboxs">
                      <p><input type="checkbox" [checked]="active == 'Published'" class="checkbox8"  id="s-55" (change)="current()"   [checked]="active == 'Published'"    name="check[]" value="Published" /><label for="s-55" >Published</label></p>
                      <p><input type="checkbox" [checked]="active == 'Draft'" class="checkbox8"  id="s-56" (change)="current()"    [checked]="active == 'Draft'"  name="check[]" value="Draft" /><label for="s-56">Draft</label></p>
                      <p><input type="checkbox" [checked]="active == 'Archived'" class="checkbox8"  id="s-59" (change)="current()"   [checked]="active == 'Archived'"   name="check[]" value="Archived" /><label for="s-59">Archived</label></p>
                      <p><input type="checkbox" [checked]="active == 'Trash'" class="checkbox8"  id="s-57" (change)="current()"    [checked]="active == 'Trash'"  name="check[]" value="Trash" /><label for="s-57">Trash</label></p>
                      <p><input type="checkbox" [checked]="active == 'Workinprogress'" class="checkbox8"  id="s-60"   [checked]="active == 'Workinprogress'"   (change)="current()"  name="check[]" value="Workinprogress" /><label for="s-60">Workinprogress</label></p>
                   </div>
              </ul>
          </div>`,
    providers: []
})
export class LoupeStatusFilterComponent implements OnInit {
    @Output() changed = new EventEmitter();
    @Input() active = '';
    status:any = ['Published','Draft','Trash','Archived','Workinprogress'];
    constructor(){}
    
    ngOnInit() {
        
    }
    selectloupestatus()
    {
        //select all checkboxes
        $("#s-54").change(function(){  //"select all" change 
            var cstatus = this.checked; // "select all" checked status
            $('.checkbox8').each(function(){ //iterate all listed checkbox items
                this.checked = cstatus; //change ".checkbox" checked status
            });
        });

        $('.checkbox8').change(function(){ //".checkbox" change 
            //uncheck "select all", if one of the listed checkbox item is unchecked
            if(this.checked == false){ //if this item is unchecked
                $("#s-54")[0].checked = false; //change "select all" checked status to false
            }
    
            //check "select all" if all checkbox items are checked
            if ($('.checkbox8:checked').length == $('.checkbox8').length ){ 
                $("#s-54")[0].checked = true; //change "select all" checked status to true
            }
        });
        
        if($("#s-54").is(":checked"))
            this.changed.emit(this.status);
        else
            this.changed.emit([]);
    }
    
    current(){
        let status = [];
        $('.checkbox8').each(function(){ //iterate all listed checkbox items
            if(this.checked)
                status.push($(this).val()); //change ".checkbox" checked status
        });
        this.changed.emit(status);
    }
}
