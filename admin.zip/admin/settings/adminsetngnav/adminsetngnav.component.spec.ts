import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminsetngnavComponent } from './adminsetngnav.component';

describe('AdminsetngnavComponent', () => {
  let component: AdminsetngnavComponent;
  let fixture: ComponentFixture<AdminsetngnavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminsetngnavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminsetngnavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
