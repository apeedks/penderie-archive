import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminsetngnav',
  templateUrl: './adminsetngnav.component.html',
  styleUrls: ['./adminsetngnav.component.css']
})
export class AdminsetngnavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
