import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
@Component({
  selector: 'app-profilepoints',
  templateUrl: './profilepoints.component.html',
  styleUrls: ['../../nav/adminheader.component.css','./profilepoints.component.css']
})
export class ProfilepointsComponent implements OnInit {
	items:any;
	options:any;
	constructor(private route: ActivatedRoute,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService) { 
		
	}
	
	ngOnInit() {
		this.dbserv.getAll("profilepoints").subscribe(res => {this.items = res;});
	}
	updateclick()
	{
		this.dbserv.save("saveprofilepoints",this.items).subscribe(res => {
															   this._alert.create(res.type,res.message);
															 }); 
	}
}
