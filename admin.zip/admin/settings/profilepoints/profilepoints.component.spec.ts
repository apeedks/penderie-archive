import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfilepointsComponent } from './profilepoints.component';

describe('ProfilepointsComponent', () => {
  let component: ProfilepointsComponent;
  let fixture: ComponentFixture<ProfilepointsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfilepointsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfilepointsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
