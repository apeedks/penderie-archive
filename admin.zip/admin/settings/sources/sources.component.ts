import { Component, OnInit, ViewChild} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { DataTable } from 'angular-4-data-table/src/index';
@Component({
  selector: 'app-sources',
  templateUrl: './sources.component.html',
  styleUrls: ['../../nav/adminheader.component.css']
})
export class SourcesComponent implements OnInit {
	public items = [];
	model = {id:0, title: '',gender:"",type:""};
	options:any;
	pageSize: number;
	totalitems: any;
	page: number = 1;
	last_page: number =1;
	public defaultparam = {sortBy:"id", sortAsc:true,offset:0,limit:10,searchstr:""};
	filterfield:string='All';
	isshowform = false;
	currentlist:string = 'All';
	applybtnval:string = '';
	headerimage:string = '';
	uploadedimage = null;
	selectedrecs	= [];
	commercecats:any;
	searchfield:string = '';
	searchgender:string = "Both";
	@ViewChild(DataTable) recTable: DataTable;
	
	constructor(private dbserv:DbserviceService,private _alert: AlertsService) 
	{
		this.searchgender = localStorage.getItem('visittype');
	}
	ngOnInit() {
	}
	statusselectedchange()
	{
		if(this.applybtnval!='')
		{
			if(this.recTable.selectedRows.length>0)
			{
				this.selectedrecs=[];
				for(var i = 0;i<this.recTable.selectedRows.length;i++) 
				{ 
					this.selectedrecs.push(this.recTable.selectedRows[i].item.id);
				}
				let newmodel = {'action':this.applybtnval,'vals':JSON.stringify(this.selectedrecs)};
				this.dbserv.save("sourcesperformaction",newmodel).subscribe(res => {
																  
																   this._alert.create(res.type,res.message);
																   if(res.type=="success")
																   {
																		this.loadpage(this.defaultparam);
																		this.isshowform = false;
																   }
																 }); 
			}
			else
			{
				this._alert.create('error','Please, select some record first.');
			}
		}
	}
	statuschange(id:number,action:string)
	{
		this.selectedrecs=[id];
		this.applybtnval = action;
		let newmodel = {'action':this.applybtnval,'vals':JSON.stringify(this.selectedrecs)};
		this.dbserv.save("sourcesperformaction",newmodel).subscribe(res => {
															   this._alert.create(res.type,res.message);
															   if(res.type=="success")
															   {
																	this.loadpage(this.defaultparam);
																	this.isshowform = false;
															   }
														}); 
	}
	loadpage(params:any)
	{
		params.searchstr = this.searchfield;
		this.dbserv.post("sources/"+this.searchgender+"/"+this.filterfield,params).subscribe(res => {
																			if(res.type=="success")
																		    {
																				this.items = res.records.data; 
																				this.page = res.records.current_page; 
																				this.totalitems = res.records.total;
																				this.pageSize = res.records.per_page;
																				this.last_page = res.records.last_page;
																			}
																			else
																				this._alert.create(res.type,res.message);
																		}); 
		this.defaultparam = params;
		this.isshowform = false;
	}
	hideform()
	{
		this.isshowform = false;
	}
	editrecord(id)
	{
		this.isshowform = true;
		this.dbserv.getById("source",id).subscribe(res => {
													if(res.type=="success")
													{
														this.model = res.data;
													}
													else
														this._alert.create(res.type,res.message);
													});
	}
	deleterecord(id)
	{
		this.isshowform = false;
		this.dbserv.delete("sourcesdel", id).subscribe(res => { this._alert.create(res.type,res.message);this.loadpage(this.defaultparam);});
	}
	saverecord()
	{
		this.dbserv.save("sourcessave",this.model).subscribe(res => {
															   this._alert.create(res.type,res.message);
															   if(res.type=="success")
															   {
															    	this.model = {id:0, title: '',gender:"",type:""};
																	this.loadpage(this.defaultparam);
																	this.isshowform = false;
															   }
															 }); 
	}
	addrecord()
	{
		this.model = {id:0, title: '',gender:"",type:""};
		this.isshowform = true;
	}
}
