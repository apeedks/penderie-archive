import {ViewChild, ElementRef, AfterViewInit,OnInit, Component} from '@angular/core';
declare var $:any;
declare var Modernizr:any;
window['$'] = window['jQuery'] = $;
/*require('jquery.slim');*/
@Component({
  selector: 'app-testing',
  templateUrl: './testing.component.html',
  styles: [``]
})
export class TestingComponent implements OnInit,AfterViewInit {
	@ViewChild('flipbook') flipbook: ElementRef;
	flipbookobj:any;
	constructor(){
		
	}
	ngOnInit() {
		
	}
	loadApp()
	{
		this.flipbookobj = $(this.flipbook.nativeElement).turn({
			width:922,
			height:600,
			elevation: 50,
			gradients: true,
			autoCenter: true

		});
	}
	
	nextpage()
	{
		this.flipbookobj.turn("next");	
	}
	prevpage()
	{
		 this.flipbookobj.turn("previous");	
	}
	
	ngAfterViewInit() {
		this.loadApp()
	}
}