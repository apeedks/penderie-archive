import { Component, OnInit, ChangeDetectionStrategy, ViewEncapsulation, ElementRef, Inject, AfterViewInit, Input } from '@angular/core';
import {ScriptService} from "../services/script.service";
import * as $ from 'jquery';
//import 'modernizr.custom.79639';
import 'jquery.ba-cond.min';
import 'jquery.slitslider';
@Component({
  selector: 'app-template',
  templateUrl: './template.component.html',
  styleUrls: ['./template.component.css'],
  changeDetection: ChangeDetectionStrategy.Default,
  encapsulation: ViewEncapsulation.Emulated,
})
export class TemplateComponent implements OnInit {

	constructor() { 
		
	}
	
	ngOnInit() {

		
	}
	
	ngAfterViewInit() {
		//$('#slider').slitslider({});
	  }

}
