import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StoriessliderComponent } from './storiesslider.component';

describe('StoriessliderComponent', () => {
  let component: StoriessliderComponent;
  let fixture: ComponentFixture<StoriessliderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StoriessliderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StoriessliderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
