import { Component,OnInit,Input} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import { AuthenticationService } from '../../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';

@Component({
  selector: 'app-storiesslider',
  templateUrl: './storiesslider.component.html',
  styleUrls: ['./storiesslider.component.css']
})
export class StoriessliderComponent implements OnInit {
	@Input() gender: string;
	pageno:number = 1;
	storieslist = [];
	rootpath = '';
	currtime:any;
	constructor(private dbserv:DbserviceService,private route: ActivatedRoute,private router: Router,private authserv: AuthenticationService) {
		this.rootpath = localStorage.getItem('baseurl');
	}
	ngOnInit() {
		this.currtime = Math.random();
		this.dbserv.getAll("getstoriesforhome/"+this.pageno+"/" + this.gender).subscribe(res => {
																	  	this.storieslist = res.data;
																	});
	}
	add3Dots(string, limit)
	{
	if(string != null && string != undefined){
	  var dots = "...";
	  if(string.length > limit)
	  {
	    // you can also use substr instead of substring
	    string = string.substring(0,limit) + dots;
	  }
	    return string;
	    }
	}
}