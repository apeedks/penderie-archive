import { Component,OnInit,Input} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import { AuthenticationService } from '../../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';

@Component({
  selector: 'app-luxurypediaslider',
  templateUrl: './luxurypediaslider.component.html',
  styleUrls: ['./luxurypediaslider.component.css']
})
export class LuxurypediasliderComponent implements OnInit {
	@Input() gender: string;
	pageno:number = 1;
	luxurylist = [];
	rootpath = '';
	currtime:any;
	constructor(private dbserv:DbserviceService,private route: ActivatedRoute,private router: Router,private authserv: AuthenticationService) {
		this.rootpath = localStorage.getItem('baseurl');
	}
	ngOnInit() {
		this.currtime = Math.random();
		this.dbserv.getAll("getluxurypediaforhome/"+this.pageno+"/" + this.gender).subscribe(res => {
																	  	this.luxurylist = res.data;
																	});
	}

}
