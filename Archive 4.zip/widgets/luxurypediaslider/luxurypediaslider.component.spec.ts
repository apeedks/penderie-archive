import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LuxurypediasliderComponent } from './luxurypediaslider.component';

describe('LuxurypediasliderComponent', () => {
  let component: LuxurypediasliderComponent;
  let fixture: ComponentFixture<LuxurypediasliderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LuxurypediasliderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LuxurypediasliderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
