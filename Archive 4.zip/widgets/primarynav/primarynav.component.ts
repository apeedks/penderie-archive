import { Component, OnInit, OnDestroy, AfterViewChecked } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationService } from '../../services/authentication.service';
import { TranslateService } from '../../translate';
import {AlertsService} from '@jaspero/ng2-alerts';
// import { AuthService } from 'ng4-social-login';
// import { SocialUser } from 'ng4-social-login';
import { CookieService } from 'ngx-cookie-service';
import {DbserviceService} from '../../services/dbservice.service';
// import {GoogleLoginProvider, FacebookLoginProvider,LinkedinLoginProvider} from 'ng4-social-login';
import { AuthService }from "angular2-social-login";
import { FacebookService, LoginResponse, LoginOptions, UIResponse, UIParams, FBVideoComponent, InitParams } from 'ngx-facebook';
import $ from 'jquery';
//import { Observable } from "rxjs";
//import { IntervalObservable } from "rxjs/observable/IntervalObservable";
//import 'rxjs/add/operator/takeWhile';

import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/observable/interval';
import 'rxjs/add/operator/takeUntil';

@Component({
  selector: 'app-primarynav',
  templateUrl: './primarynav.component.html',
    styleUrls: ['./primarynav.component.css']
})
export class PrimarynavComponent implements OnInit,OnDestroy,AfterViewChecked {
	isuserloggedin:boolean = false;
	rootpath = '';
	currtime:any;
	userid:number = 0;
	nameforverification:string;
	userfullname:string='';
	options:any;
	model: any = {id:0,username:'',password:'',email:'',confirmemail:'',image:'',registeredby:'Normal',socialid:'',mobilecode:'',mobileno:'',firstname:'',lastname:'',name:'',connectiontype:"Connections",country:'',state:'',city:''};
    loading = false;
    returnUrl: string;
  	ismobile:boolean = false;
	notifications:any;
	userprofileimage:string="";
    isnew:string="";
	noticount:number = 0;
	validation_message = '';
	//notificationSetInterval: any;
	destroy$: Subject<boolean> = new Subject<boolean>();
	constructor(private _translate: TranslateService,private dbserv:DbserviceService,private route: ActivatedRoute,private router: Router,private authserv: AuthenticationService,private _alert: AlertsService,private cookieService: CookieService,private socialLoginAuthService	: AuthService, private fb : FacebookService) {
		let initParams: InitParams = {
			appId: '1780419275334741',
			xfbml: true,
			version: 'v2.10'
		};

		this.fb.init(initParams);
		this.rootpath = localStorage.getItem('baseurl'); 
		this.currtime = Math.random();
	}
	
	ngOnInit() {
	    $(window).resize(()=>{
	      if($(window).width() < 992){
	        this.ismobile = true;
	      }else{
	        this.ismobile = false;
	      }
	      // console.log(this.ismobile);
	    });
	    if($(window).width() < 992){
	      this.ismobile = true;
	    }else{
	      this.ismobile = false;
	    }
		this.userid = this.authserv.getUserId();
		if(this.userid>0)
		{
			this.isuserloggedin = true;
			this.userfullname = this.authserv.getUserName();
			this.dbserv.getById("getuserdetail",this.userid).subscribe(res => {
				if(res.type=="success")
				{
					this.userprofileimage = res.data.image;
					this.isnew = res.data.isnew;
				}
			});
			
			// get our data every subsequent 5 seconds
		    Observable.interval(5000).takeUntil(this.destroy$).subscribe(val => {
		    	this.dbserv.getAll("mynotifications",false)
		    	.subscribe(res => {
					if(res.type=="success"){
						this.notifications = res.data;
						this.noticount = res.count;
					}
				},error => {
					console.log(error);
					this.authserv.logout();
					this.router.navigate(['/login']);
					// this._alert.create('error',this._translate.instant('Invalid login credentials.'));
				});
		    });
		}
		else
		{
			// this.authService.authState.subscribe((user) => {
			// 	console.log('prim',this.isuserloggedin,user);
			// 	if(user != null){
			// 		if(user.id != undefined){
			// 			this.authserv.loginwithsocialid(user.id)
			// 				.subscribe(
			// 					data => {
			// 						this.isuserloggedin = true;
			// 						// if (data.type == 'error') {
			// 						// 	this.validation_message = 'Oops! Looks like your email or password is incorrect.';
			// 						// }
			// 						if (data && data.token) {
			// 							// store user details and jwt token in local storage to keep user logged in between page refreshes
			// 							localStorage.setItem('currentUser', JSON.stringify(data));
			// 							this.authserv.sessionreq();
			// 							this.authserv.session().subscribe(res => {
			// 								this.router.navigate(['/myaccount']);
			// 							});
			// 						}
			// 					},
			// 					error => {
			// 						this._alert.create('error',this._translate.instant('Invalid login credentials.'));
			// 					}
			// 				);
			// 		}
			// 	}else{
			// 		this.authserv.logout();
			// 	}
			// });
		}
	}
	login() {
        this.loading = true;
        this.authserv.login(this.model.email, this.model.password)
            .subscribe(
                data => {
                  this.validation_message = this.authserv.validation_message;
                  this.authserv.session().subscribe(res => {
							      this.router.navigate(['/myaccount']);
						      });
					        this.loading = false;
                },
                error => {
					this.validation_message ='';
                    //this._alert.create('error',this._translate.instant('Invalid login credentials.'));
                    this.loading = false;
                });
    }

	signInWithLinkedIN(): void {
		this.socialLoginAuthService.login('linkedin').subscribe((data: any) => {
			// console.log(data);
			this.authserv.loginwithsocialid(data.uid).subscribe(
				data => {
					if (data.type == 'error') {
						this.validation_message = 'Oops! Your account is not registered.';
					}else{
						this.isuserloggedin = true;
						this.validation_message = '';
					}
					if (data && data.token) {
						// store user details and jwt token in local storage to keep user logged in between page refreshes
						localStorage.setItem('currentUser', JSON.stringify(data));
						this.authserv.sessionreq();
						this.authserv.session().subscribe(res => {
							this.router.navigate(['/myaccount']);
						});
					}
				},
				error => {
					this._alert.create('error',this._translate.instant('Invalid login credentials.'));
				});
		});
	}
signInWithGoogle(): void {
		this.socialLoginAuthService.login('google').subscribe((data: any) => {
			this.authserv.loginwithsocialid(data.uid).subscribe(
				res => {
					if (res.type == 'error') {
						let mydate = new Date().getTime() + (60*60*24*1000);
						this.model.socialid = data.uid;
						this.model.registeredby = data.provider;
						this.model.name = data.name;
						this.model.firstname = this.model.name.split(' ').slice(0, -1).join(' ');
						this.model.lastname =  this.model.name.split(' ').slice(-1).join(' ');
						this.model.email = data.email;
						this.model.image = data.image;
						// this.model.lastname = user.firstName;
						// this.model.lastname = user.lastName;	
						this.model.username = mydate + "";
						this.nameforverification = data.name;
						/*this.dbserv.save("register",this.model).subscribe(res => {
							if (res && res.token) {
								// store user details and jwt token in local storage to keep user logged in between page refreshes
								localStorage.setItem('currentUser', JSON.stringify(res));
								this.authserv.sessionreq();
								this.authserv.session().subscribe(res => {
									this.router.navigate(['/myaccount']);
								});
							}
						});*/
					}
					if (res && res.token) {
						// store user details and jwt token in local storage to keep user logged in between page refreshes
						localStorage.setItem('currentUser', JSON.stringify(res));
						this.authserv.sessionreq();
						this.authserv.session().subscribe(res => {
							this.router.navigate(['/myaccount']);
						});
					}
				},
				error => {
					console.log(data);
					let mydate = new Date().getTime() + (60*60*24*1000);
					this.model.socialid = data.uid;
					this.model.registeredby = data.provider;
					this.model.name = data.name;
					this.model.firstname = this.model.name.split(' ').slice(0, -1).join(' ');
					this.model.lastname =  this.model.name.split(' ').slice(-1).join(' ');
					this.model.email = data.email;
					this.model.image = data.image;
					// this.model.lastname = user.firstName;
					// this.model.lastname = user.lastName;	
					this.model.username = mydate + "";
					this.nameforverification = data.name;
					/*this.dbserv.save("register",this.model).subscribe(res => {
						if (res && res.token) {
							// store user details and jwt token in local storage to keep user logged in between page refreshes
							localStorage.setItem('currentUser', JSON.stringify(res));
							this.authserv.sessionreq();
							this.authserv.session().subscribe(res => {
								this.router.navigate(['/myaccount']);
							});
						}
					});*/
				});
			
		});
	}
	
	signInWithFB(): void {
		const loginOptions: LoginOptions = {
			enable_profile_selector: true,
			return_scopes: true,
			scope: 'public_profile,email'
		};

		this.fb.login(loginOptions).then((response: LoginResponse) => {
				if(response.status === "connected"){
					this.fb.api('/me?fields=name,email,picture').then((res: any) => {
							let userDetails = {
									name: res.name,
									email: res.email,
									uid: res.id,
									provider: "facebook",
									image: res.picture.data.url,
									token: response.authResponse.accessToken
							}

							console.log(userDetails);
							this.authserv.loginwithsocialid(userDetails.uid).subscribe(
								res => {
									if (res.type == 'error') {
										let mydate = new Date().getTime() + (60*60*24*1000);
										this.model.socialid = userDetails.uid;
										this.model.registeredby = userDetails.provider;
										this.model.name = userDetails.name;
										this.model.firstname = this.model.name.split(' ').slice(0, -1).join(' ');
										this.model.lastname =  this.model.name.split(' ').slice(-1).join(' ');
										this.model.email = userDetails.email;
										this.model.image = userDetails.image;
										// this.model.lastname = user.firstName;
										// this.model.lastname = user.lastName;	
										this.model.username = userDetails.uid;
										this.nameforverification = userDetails.name;
										/*this.dbserv.save("register",this.model).subscribe(res => {
											if (res && res.token) {
												// store user details and jwt token in local storage to keep user logged in between page refreshes
												localStorage.setItem('currentUser', JSON.stringify(res));
												this.authserv.sessionreq();
												this.authserv.session().subscribe(res => {
													this.router.navigate(['/myaccount']);
												});
											}
										});*/
									}
									if (res && res.token) {
										// store user details and jwt token in local storage to keep user logged in between page refreshes
										localStorage.setItem('currentUser', JSON.stringify(res));
										this.authserv.sessionreq();
										this.authserv.session().subscribe(res => {
											this.router.navigate(['/myaccount']);
										});
									}
								},
								error => {
									let mydate = new Date().getTime() + (60*60*24*1000);
									this.model.socialid = userDetails.uid;
									this.model.registeredby = userDetails.provider;
									this.model.name = userDetails.name;
									this.model.firstname = this.model.name.split(' ').slice(0, -1).join(' ');
									this.model.lastname =  this.model.name.split(' ').slice(-1).join(' ');
									this.model.email = userDetails.email;
									this.model.image = userDetails.image;
									// this.model.lastname = user.firstName;
									// this.model.lastname = user.lastName;	
									this.model.username = mydate + "";
									this.nameforverification = userDetails.name;
									/*this.dbserv.save("register",this.model).subscribe(res => {
										if (res && res.token) {
											// store user details and jwt token in local storage to keep user logged in between page refreshes
											localStorage.setItem('currentUser', JSON.stringify(res));
											this.authserv.sessionreq();
											this.authserv.session().subscribe(res => {
												this.router.navigate(['/myaccount']);
											});
										}
									});*/
								});
					});
				}
			}).catch();
	}
	funcsearchclicked()
	{
		$('body').toggleClass('custo-search-open')
		$('.search-clicker').toggleClass('search-cross')
	}
	logout() {
    this.authserv.logout();
		if(this.isuserloggedin){
			this.isuserloggedin = false;
		}
		this.router.navigate(['/home']);
  }
  ngOnDestroy() {
	  this.destroy$.next(true);
	  // Now let's also unsubscribe from the subject itself:
    this.destroy$.unsubscribe();
	}

		
	ngAfterViewChecked()
    {
	    let obj = this;
        $(".my-pend-relative").hover(
		    function() {
                obj.validation_message ='';
		        // Called when the mouse enters the element
        		$('.log-form-pop form').trigger("reset");
        		
		    },
		    function() {
		        // Called when the mouse leaves the element
		    }
		);
    }
	resendverification()
    {
        if(this.model.email != null){
            console.log(this.model.email);
            this.dbserv.getByStringId("resendverifictionbyemail",this.model.email).subscribe(res => {
                this._alert.create(res.type,res.message);
            });
        }
        else{
            this._alert.create('error',this._translate.instant('Please, register before clicking on Resend Request button.'));  
        }
    }
}
