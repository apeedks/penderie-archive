import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';

@Component({
  selector: 'app-themenav',
  templateUrl: './themenav.component.html',
  styleUrls: ['./themenav.component.css']
})
export class ThemenavComponent implements OnInit {

    visittype = '';
    constructor(private router: Router,private cookieService: CookieService,private route: ActivatedRoute) {  this.visittype = localStorage.getItem('visittype');
    }
	
	ngOnInit() {
	}
	switchsections(type:string)
	{
		this.cookieService.set('sectiontheme',type);
		switch(type)
		{
			case "Fine Material":
				this.router.navigate(['fine-material']);
				break;
			case "Superiar Craftmanship":
				this.router.navigate(['superiar-craftmanship']);
				break;
			case "Art of Styling":
				this.router.navigate(['art-of-styling']);
				break;
			case "Balanced Living":
				this.router.navigate(['balanced-living']);
				break;
		}
	}
}
