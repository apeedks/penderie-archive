import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThemenavComponent } from './themenav.component';

describe('ThemenavComponent', () => {
  let component: ThemenavComponent;
  let fixture: ComponentFixture<ThemenavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThemenavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThemenavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
