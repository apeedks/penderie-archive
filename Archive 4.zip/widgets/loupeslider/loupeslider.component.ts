import { Component, OnInit, HostListener, ElementRef, ViewChild,Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import { AuthenticationService } from '../../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import '../../../assets/js/owl-carousel-custom.js';
import $ from 'jquery';

declare var carouselObject: any;

@Component({
  selector: 'app-loupeslider',
  templateUrl: './loupeslider.component.html',
  styleUrls: ['./loupeslider.component.css']
})
export class LoupesliderComponent implements OnInit {
	@ViewChild('lnktimelinesharebox') lnktimelinesharebox:ElementRef;
	@Input() gender: string;
	pageno:number = 1;
	loupelist = [];
	rootpath = '';
	currtime:any;
	loggedin="No";
	gender1:string="";
	constructor(private dbserv:DbserviceService,private route: ActivatedRoute,private router: Router,private authserv: AuthenticationService,private _alert: AlertsService) { 
		this.rootpath = localStorage.getItem('baseurl');
	}
	ngOnInit() {
		
		this.currtime = Math.random();
		this.dbserv.getAll("getloupeforhome/"+this.pageno+"/" + this.gender).subscribe(res => {
																	  	this.loupelist = res.data;
										console.log(res.data);							  	  
                                  });

setTimeout( function(){ 
 carouselObject.eventCarousel();
  },2000 );
		
 		if (this.authserv.isloggedin()) {
			this.loggedin = "Yes";
		}
	}
		street(id){
		$("#ellipsis-"+id).children().toggleClass('fa fa-ellipsis-h fa fa-ellipsis-v');
		$("#street-"+id).toggle();
	}
		likeme(id,type)
	{
		let params = {luxurypedia_id:id,status:type};
		this.dbserv.post("luxurypedialike",params).subscribe(res => {
																if(res.type=="success")
																{
																	if(type=="like")
																	{
																		$("#reclike" + id).css("display","none");
																		$("#recunlike" + id).css("display","block");
																	}
																	else if(type=="unlike")
																	{
																		$("#reclike" + id).css("display","block");
																		$("#recunlike" + id).css("display","none");
																	}
																	// this.loadpage(1);
																	/*this._alert.create(res.type,res.message+type);*/
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/login') ;	
																}
																else
																	this._alert.create(res.type,res.message);
														});
	}
	saveme(id,type)
	{
		let params = {articleid:id,status:type};
		this.dbserv.post("luxurybookmark",params).subscribe(res => {
																if(res.type=="success")
																{
																	if(type=="save")
																	{
																		$("#recsave" + id).css("display","none");
																		$("#recunsave" + id).css("display","block");
																	}
																	else if(type=="unsave")
																	{
																		$("#recsave" + id).css("display","block");
																		$("#recunsave" + id).css("display","none");
																	}
																	// s
																	/*this._alert.create(res.type,res.message+type);*/
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/login') ;	
																}
																else
																	this._alert.create(res.type,res.message);
														});
	}
	opensharebox(id)
	{
		this.lnktimelinesharebox.nativeElement.click();
	}	
}