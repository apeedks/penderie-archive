import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoupesliderComponent } from './loupeslider.component';

describe('LoupesliderComponent', () => {
  let component: LoupesliderComponent;
  let fixture: ComponentFixture<LoupesliderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoupesliderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoupesliderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
