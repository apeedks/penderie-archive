import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrueluxurystoriessliderComponent } from './trueluxurystoriesslider.component';

describe('TrueluxurystoriessliderComponent', () => {
  let component: TrueluxurystoriessliderComponent;
  let fixture: ComponentFixture<TrueluxurystoriessliderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrueluxurystoriessliderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrueluxurystoriessliderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
