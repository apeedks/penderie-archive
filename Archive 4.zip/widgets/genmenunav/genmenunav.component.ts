import { Component, OnInit, trigger, state, style, transition, animate, Input, Output, EventEmitter, HostListener, ElementRef, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';

import $ from 'jquery';
@Component({
  selector: 'app-genmenunav',
  templateUrl: './genmenunav.component.html',
  styleUrls: ['./genmenunav.component.css']
})
export class GenmenunavComponent implements OnInit {
    isuserloggedin:boolean=false;
    visittype = '';
    userid:number = 0;
    gender:string="";
  constructor(private dbserv:DbserviceService) { 
      this.visittype = localStorage.getItem('visittype');
      if(this.visittype == 'Men')
          {
              this.visittype = 'man'
          }
      else{
              this.visittype = 'women'
      }
  }

  ngOnInit() {
      if(this.userid>0)
      {
          this.isuserloggedin = true;
          this.dbserv.getById("getuserdetail",this.userid).subscribe(res => {
              if(res.type=="success")
              {
                  this.gender = res.data.gender;
              }
          });
      }
  }
  activeclass(){
      $("li").click(function() {
        $("li").removeClass("navactive");
        $(this).addClass("navactive");
});
        }
}
