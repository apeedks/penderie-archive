import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GenmenunavComponent } from './genmenunav.component';

describe('GenmenunavComponent', () => {
  let component: GenmenunavComponent;
  let fixture: ComponentFixture<GenmenunavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenmenunavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenmenunavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
