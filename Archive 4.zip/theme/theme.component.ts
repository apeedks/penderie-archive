import { Component, OnInit } from '@angular/core';
import { DomSanitizer,Meta,Title } from '@angular/platform-browser'
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../services/dbservice.service';

@Component({
  selector: 'app-theme',
  templateUrl: './theme.component.html',
  styleUrls: ['./theme.component.css']
})
export class ThemeComponent implements OnInit {
	pageid:string;
	records = []
	currtime:any;
	rootpath:string;
  	model = {id:0, title: '',menulink: "",section: "",linkpos: "",image: "",paccess: "",gender: "",metatitle: "",metakeyword: "",metadescr: ""};
	constructor(private dbserv:DbserviceService,private route: ActivatedRoute,private sanitizer: DomSanitizer,private meta: Meta, private titleService: Title) { 
		this.rootpath = localStorage.getItem('baseurl');
	}
	ngOnInit() {
	  this.route.params.subscribe(params => {
			this.pageid = params['pageid']; // (+) converts string 'id' to a number
			this.currtime = Math.random();
			this.dbserv.getByStringId("getthemepage",this.pageid).subscribe(res => {
													if(res.type=="success")
													{
														this.model=res.data;
														this.records=res.data.records;
														this.meta.addTag({ name: 'keywords', content: this.model.metakeyword });
														this.meta.addTag({ name: 'description', content: this.model.metadescr });
														this.titleService.setTitle(this.model.metatitle);
													}
												});
		});
	  scroll(0,0);
	}}