import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThemepreviewComponent } from './themepreview.component';

describe('ThemepreviewComponent', () => {
  let component: ThemepreviewComponent;
  let fixture: ComponentFixture<ThemepreviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThemepreviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThemepreviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
