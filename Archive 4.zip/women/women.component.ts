import { Component, OnInit } from '@angular/core';
import { DbserviceService } from '../services/dbservice.service';
import { Http, Response } from '@angular/http';
import '../../assets/js/slider/jquery.slitslider.js';
import '../../assets/js/owl-carousel-custom.js';
import * as Immutable from 'immutable';
import { AuthenticationService } from '../services/authentication.service';
import $ from 'jquery';
import { Router, ActivatedRoute } from '@angular/router';

declare var webGlObject: any;
declare var carouselObject: any;

@Component({
  selector: 'app-women',
  templateUrl: './women.component.html',
  styleUrls: ['./women.component.css']
})
export class WomenComponent implements OnInit {
  pageno: number = 1;
  showbecomeapenderian: boolean = true;
  basepageurl: string;
  constructor(private dbserv: DbserviceService, private route: ActivatedRoute, private router: Router, private authserv: AuthenticationService) {
    this.basepageurl = localStorage.getItem('baseurl');
  }
  options = Immutable.Map({
    showDots: true,         // Shows a dot navigation component 
    height: 458,            // The initial slideshow height 
    showThumbnails: false,   // Optionally include thumbnails a navigation option 
    thumbnailWidth: 150     // Thumbnail individual width for the thumbnail navigation component 
  });
  gotoregister(type: string) {
    this.router.navigate(['register']);
  }
  ngOnInit() {
    carouselObject.logoCarousel();
    if (this.authserv.isloggedin()) {
      this.showbecomeapenderian = false;
    }
    this.dbserv.getAll("getslides/" + this.pageno + "/Women").subscribe(res => {
      this.images = [];
      this.pageno = res.current_page;
      for (let result of res.data) {
        //  let newName = {
        //    url:"assets/photogallery/" + result.url
        // };
        this.images.push("assets/photogallery/" + result.url);
        // neimages.push(newName);
      }


      // this.images = Immutable.List(neimages);
      webGlObject.init();
    });
  }
  ngAfterViewInit() {
    webGlObject.init();
  }
  // images = Immutable.List([
  // 		{url: 'assets/img/banner1.jpg'},
  // 		{url: 'assets/img/banner3.png'},
  // 		{url: 'assets/img/banner4.png'},
  // 	]);
  images = [
    'assets/img/banner1.jpg',
    'assets/img/banner3.png',
    'assets/img/banner4.png',
  ];
  showByIndex() {
    //getslides/{pageno}/{gender}
  }
  currentuserselect(colorClass: string) {
    $("#own-category-toggle").attr("class", "");
    $("#own-category-toggle").attr("class", "own-category-sec fullHt " + colorClass + "");
  }
}
