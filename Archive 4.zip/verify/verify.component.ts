import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../services/dbservice.service';
import { Meta,Title} from '@angular/platform-browser';
import {AlertsService} from '@jaspero/ng2-alerts';
@Component({
  selector: 'app-verify',
  templateUrl: './verify.component.html',
  styleUrls: ['./verify.component.css']
})
export class VerifyComponent implements OnInit {
	token:string;
	options:any;
	constructor(private dbserv:DbserviceService,private route: ActivatedRoute,private router: Router,private _alert: AlertsService) { 
		
	}
	
	ngOnInit() {
		this.route.params.subscribe(params => {
		    this.token = params['token']; // (+) converts string 'id' to a number
			this.dbserv.getByStringId("verifytoken",this.token).subscribe(res => {
													this._alert.create(res.type,res.message);
													if(res.type=="success")
													{
														this.router.navigate(['login']);
													}
												});
		});	
	}

}
