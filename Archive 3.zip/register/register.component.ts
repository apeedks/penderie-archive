
import { Component, OnInit, trigger, state, style, transition, animate, Input, Output, EventEmitter, HostListener, ElementRef, ViewChild } from '@angular/core';
import { TranslateService } from '../translate';
import {DbserviceService} from '../services/dbservice.service';
import { AuthenticationService } from '../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { Router, ActivatedRoute } from '@angular/router';
import $ from 'jquery';
// import { AuthService } from 'ng4-social-login';
// import { SocialUser } from 'ng4-social-login';
// import {GoogleLoginProvider, FacebookLoginProvider,LinkedinLoginProvider} from 'ng4-social-login';
import { AuthService }from "angular2-social-login";
import { FacebookService, LoginResponse, LoginOptions, UIResponse, UIParams, FBVideoComponent, InitParams } from 'ngx-facebook';
import {IMyDpOptions,IMyDateModel} from 'mydatepicker';
import {ImageCropperComponent, CropperSettings} from 'ng2-img-cropper';
//fb and google end
@Component({
	selector: 'app-register',
	templateUrl: './register.component.html',
	styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
    countryArray = [
        {
            countryCode:"GB",
            pattern:"GIR[ ]?0AA|((AB|AL|B|BA|BB|BD|BH|BL|BN|BR|BS|BT|CA|CB|CF|CH|CM|CO|CR|CT|CV|CW|DA|DD|DE|DG|DH|DL|DN|DT|DY|E|EC|EH|EN|EX|FK|FY|G|GL|GY|GU|HA|HD|HG|HP|HR|HS|HU|HX|IG|IM|IP|IV|JE|KA|KT|KW|KY|L|LA|LD|LE|LL|LN|LS|LU|M|ME|MK|ML|N|NE|NG|NN|NP|NR|NW|OL|OX|PA|PE|PH|PL|PO|PR|RG|RH|RM|S|SA|SE|SG|SK|SL|SM|SN|SO|SP|SR|SS|ST|SW|SY|TA|TD|TF|TN|TQ|TR|TS|TW|UB|W|WA|WC|WD|WF|WN|WR|WS|WV|YO|ZE)(\\d[\\dA-Z]?[ ]?\\d[ABD-HJLN-UW-Z]{2}))|BFPO[ ]?\\d{1,4}"
        },
        {
            countryCode:"JE",
            pattern:"JE\\d[\\dA-Z]?[ ]?\\d[ABD-HJLN-UW-Z]{2}"
        },
        {
            countryCode:"GG",
            pattern:"GY\\d[\\dA-Z]?[ ]?\\d[ABD-HJLN-UW-Z]{2}"
        },
        {
            countryCode:"IM",
            pattern:"IM\\d[\\dA-Z]?[ ]?\\d[ABD-HJLN-UW-Z]{2}"
        },
        {
            countryCode:"US",
            pattern:"\\d{5}([ \\-]\\d{4})?"
        },
        {
            countryCode:"CA",
            pattern:"[ABCEGHJKLMNPRSTVXY]\\d[ABCEGHJ-NPRSTV-Z][ ]?\\d[ABCEGHJ-NPRSTV-Z]\\d"
        },
        {
            countryCode:"DE",
            pattern:"\\d{5}"
        },
        {
            countryCode:"JP",
            pattern:"\\d{3}-\\d{4}"
        },
        {
            countryCode:"FR",
            pattern:"\\d{2}[ ]?\\d{3}"
        },
        {
            countryCode:"AU",
            pattern:"\\d{4}"
        },
        {
            countryCode:"IT",
            pattern:"\\d{5}"
        },
        {
            countryCode:"CH",
            pattern:"\\d{4}"
        },
        {
            countryCode:"AT",
            pattern:"\\d{4}"
        },
        {
            countryCode:"ES",
            pattern:"\\d{5}"
        },
        {
            countryCode:"NL",
            pattern:"\\d{4}[ ]?[A-Z]{2}"
        },
        {
            countryCode:"BE",
            pattern:"\\d{4}"
        },
        {
            countryCode:"DK",
            pattern:"\\d{4}"
        },
        {
            countryCode:"SE",
            pattern:"\\d{3}[ ]?\\d{2}"
        },
        {
            countryCode:"NO",
            pattern:"\\d{4}"
        },
        {
            countryCode:"BR",
            pattern:"\\d{5}[\\-]?\\d{3}"
        },
        {
            countryCode:"PT",
            pattern:"\\d{4}([\\-]\\d{3})?"
        },
        {
            countryCode:"FI",
            pattern:"\\d{5}"
        },
        {
            countryCode:"AX",
            pattern:"22\\d{3}"
        },
        {
            countryCode:"KR",
            pattern:"\\d{3}[\\-]\\d{3}"
        },
        {
            countryCode:"CN",
            pattern:"\\d{6}"
        },
        {
            countryCode:"TW",
            pattern:"\\d{3}(\\d{2})?"
        },
        {
            countryCode:"SG",
            pattern:"\\d{6}"
        },
        {
            countryCode:"DZ",
            pattern:"\\d{5}"
        },
        {
            countryCode:"AD",
            pattern:"AD\\d{3}"
        },
        {
            countryCode:"AR",
            pattern:"([A-HJ-NP-Z])?\\d{4}([A-Z]{3})?"
        },
        {
            countryCode:"AM",
            pattern:"(37)?\\d{4}"
        },
        {
            countryCode:"AZ",
            pattern:"\\d{4}"
        },
        {
            countryCode:"BH",
            pattern:"((1[0-2]|[2-9])\\d{2})?"
        },
        {
            countryCode:"BD",
            pattern:"\\d{4}"
        },
        {
            countryCode:"BB",
            pattern:"(BB\\d{5})?"
        },
        {
            countryCode:"BY",
            pattern:"\\d{6}"
        },
        {
            countryCode:"BM",
            pattern:"[A-Z]{2}[ ]?[A-Z0-9]{2}"
        },
        {
            countryCode:"BA",
            pattern:"\\d{5}"
        },
        {
            countryCode:"IO",
            pattern:"BBND 1ZZ"
        },
        {
            countryCode:"BN",
            pattern:"[A-Z]{2}[ ]?\\d{4}"
        },
        {
            countryCode:"BG",
            pattern:"\\d{4}"
        },
        {
            countryCode:"KH",
            pattern:"\\d{5}"
        },
        {
            countryCode:"CV",
            pattern:"\\d{4}"
        },
        {
            countryCode:"CL",
            pattern:"\\d{7}"
        },
        {
            countryCode:"CR",
            pattern:"\\d{4,5}|\\d{3}-\\d{4}"
        },
        {
            countryCode:"HR",
            pattern:"\\d{5}"
        },
        {
            countryCode:"CY",
            pattern:"\\d{4}"
        },
        {
            countryCode:"CZ",
            pattern:"\\d{3}[ ]?\\d{2}"
        },
        {
            countryCode:"DO",
            pattern:"\\d{5}"
        },
        {
            countryCode:"EC",
            pattern:"([A-Z]\\d{4}[A-Z]|(?:[A-Z]{2})?\\d{6})?"
        },
        {
            countryCode:"EG",
            pattern:"\\d{5}"
        },
        {
            countryCode:"EE",
            pattern:"\\d{5}"
        },
        {
            countryCode:"FO",
            pattern:"\\d{3}"
        },
        {
            countryCode:"GE",
            pattern:"\\d{4}"
        },
        {
            countryCode:"GR",
            pattern:"\\d{3}[ ]?\\d{2}"
        },
        {
            countryCode:"GL",
            pattern:"39\\d{2}"
        },
        {
            countryCode:"GT",
            pattern:"\\d{5}"
        },
        {
            countryCode:"HT",
            pattern:"\\d{4}"
        },
        {
            countryCode:"HN",
            pattern:"(?:\\d{5})?"
        },
        {
            countryCode:"HU",
            pattern:"\\d{4}"
        },
        {
            countryCode:"IS",
            pattern:"\\d{3}"
        },
        {
            countryCode:"IN",
            pattern:"\\d{6}"
        },
        {
            countryCode:"ID",
            pattern:"\\d{5}"
        },
        {
            countryCode:"IL",
            pattern:"\\d{5}"
        },
        {
            countryCode:"JO",
            pattern:"\\d{5}"
        },
        {
            countryCode:"KZ",
            pattern:"\\d{6}"
        },
        {
            countryCode:"KE",
            pattern:"\\d{5}"
        },
        {
            countryCode:"KW",
            pattern:"\\d{5}"
        },
        {
            countryCode:"LA",
            pattern:"\\d{5}"
        },
        {
            countryCode:"LV",
            pattern:"\\d{4}"
        },
        {
            countryCode:"LB",
            pattern:"(\\d{4}([ ]?\\d{4})?)?"
        },
        {
            countryCode:"LI",
            pattern:"(948[5-9])|(949[0-7])"
        },
        {
            countryCode:"LT",
            pattern:"\\d{5}"
        },
        {
            countryCode:"LU",
            pattern:"\\d{4}"
        },
        {
            countryCode:"MK",
            pattern:"\\d{4}"
        },
        {
            countryCode:"MY",
            pattern:"\\d{5}"
        },
        {
            countryCode:"MV",
            pattern:"\\d{5}"
        },
        {
            countryCode:"MT",
            pattern:"[A-Z]{3}[ ]?\\d{2,4}"
        },
        {
            countryCode:"MU",
            pattern:"(\\d{3}[A-Z]{2}\\d{3})?"
        },
        {
            countryCode:"MX",
            pattern:"\\d{5}"
        },
        {
            countryCode:"MD",
            pattern:"\\d{4}"
        },
        {
            countryCode:"MC",
            pattern:"980\\d{2}"
        },
        {
            countryCode:"MA",
            pattern:"\\d{5}"
        },
        {
            countryCode:"NP",
            pattern:"\\d{5}"
        },
        {
            countryCode:"NZ",
            pattern:"\\d{4}"
        },
        {
            countryCode:"NI",
            pattern:"((\\d{4}-)?\\d{3}-\\d{3}(-\\d{1})?)?"
        },
        {
            countryCode:"NG",
            pattern:"(\\d{6})?"
        },
        {
            countryCode:"OM",
            pattern:"(PC )?\\d{3}"
        },
        {
            countryCode:"PK",
            pattern:"\\d{5}"
        },
        {
            countryCode:"PY",
            pattern:"\\d{4}"
        },
        {
            countryCode:"PH",
            pattern:"\\d{4}"
        },
        {
            countryCode:"PL",
            pattern:"\\d{2}-\\d{3}"
        },
        {
            countryCode:"PR",
            pattern:"00[679]\\d{2}([ \\-]\\d{4})?"
        },
        {
            countryCode:"RO",
            pattern:"\\d{6}"
        },
        {
            countryCode:"RU",
            pattern:"\\d{6}"
        },
        {
            countryCode:"SM",
            pattern:"4789\\d"
        },
        {
            countryCode:"SA",
            pattern:"\\d{5}"
        },
        {
            countryCode:"SN",
            pattern:"\\d{5}"
        },
        {
            countryCode:"SK",
            pattern:"\\d{3}[ ]?\\d{2}"
        },
        {
            countryCode:"SI",
            pattern:"\\d{4}"
        },
        {
            countryCode:"ZA",
            pattern:"\\d{4}"
        },
        {
            countryCode:"LK",
            pattern:"\\d{5}"
        },
        {
            countryCode:"TJ",
            pattern:"\\d{6}"
        },
        {
            countryCode:"TH",
            pattern:"\\d{5}"
        },
        {
            countryCode:"TN",
            pattern:"\\d{4}"
        },
        {
            countryCode:"TR",
            pattern:"\\d{5}"
        },
        {
            countryCode:"TM",
            pattern:"\\d{6}"
        },
        {
            countryCode:"UA",
            pattern:"\\d{5}"
        },
        {
            countryCode:"UY",
            pattern:"\\d{5}"
        },
        {
            countryCode:"UZ",
            pattern:"\\d{6}"
        },
        {
            countryCode:"VA",
            pattern:"00120"
        },
        {
            countryCode:"VE",
            pattern:"\\d{4}"
        },
        {
            countryCode:"ZM",
            pattern:"\\d{5}"
        },
        {
            countryCode:"AS",
            pattern:"96799"
        },
        {
            countryCode:"CC",
            pattern:"6799"
        },
        {
            countryCode:"CK",
            pattern:"\\d{4}"
        },
        {
            countryCode:"RS",
            pattern:"\\d{6}"
        },
        {
            countryCode:"ME",
            pattern:"8\\d{4}"
        },
        {
            countryCode:"CS",
            pattern:"\\d{5}"
        },
        {
            countryCode:"YU",
            pattern:"\\d{5}"
        },
        {
            countryCode:"CX",
            pattern:"6798"
        },
        {
            countryCode:"ET",
            pattern:"\\d{4}"
        },
        {
            countryCode:"FK",
            pattern:"FIQQ 1ZZ"
        },
        {
            countryCode:"NF",
            pattern:"2899"
        },
        {
            countryCode:"FM",
            pattern:"(9694[1-4])([ \\-]\\d{4})?"
        },
        {
            countryCode:"GF",
            pattern:"9[78]3\\d{2}"
        },
        {
            countryCode:"GN",
            pattern:"\\d{3}"
        },
        {
            countryCode:"GP",
            pattern:"9[78][01]\\d{2}"
        },
        {
            countryCode:"GS",
            pattern:"SIQQ 1ZZ"
        },
        {
            countryCode:"GU",
            pattern:"969[123]\\d([ \\-]\\d{4})?"
        },
        {
            countryCode:"GW",
            pattern:"\\d{4}"
        },
        {
            countryCode:"HM",
            pattern:"\\d{4}"
        },
        {
            countryCode:"IQ",
            pattern:"\\d{5}"
        },
        {
            countryCode:"KG",
            pattern:"\\d{6}"
        },
        {
            countryCode:"LR",
            pattern:"\\d{4}"
        },
        {
            countryCode:"LS",
            pattern:"\\d{3}"
        },
        {
            countryCode:"MG",
            pattern:"\\d{3}"
        },
        {
            countryCode:"MH",
            pattern:"969[67]\\d([ \\-]\\d{4})?"
        },
        {
            countryCode:"MN",
            pattern:"\\d{6}"
        },
        {
            countryCode:"MP",
            pattern:"9695[012]([ \\-]\\d{4})?"
        },
        {
            countryCode:"MQ",
            pattern:"9[78]2\\d{2}"
        },
        {
            countryCode:"NC",
            pattern:"988\\d{2}"
        },
        {
            countryCode:"NE",
            pattern:"\\d{4}"
        },
        {
            countryCode:"VI",
            pattern:"008(([0-4]\\d)|(5[01]))([ \\-]\\d{4})?"
        },
        {
            countryCode:"PF",
            pattern:"987\\d{2}"
        },
        {
            countryCode:"PG",
            pattern:"\\d{3}"
        },
        {
            countryCode:"PM",
            pattern:"9[78]5\\d{2}"
        },
        {
            countryCode:"PN",
            pattern:"PCRN 1ZZ"
        },
        {
            countryCode:"PW",
            pattern:"96940"
        },
        {
            countryCode:"RE",
            pattern:"9[78]4\\d{2}"
        },
        {
            countryCode:"SH",
            pattern:"(ASCN|STHL) 1ZZ"
        },
        {
            countryCode:"SJ",
            pattern:"\\d{4}"
        },
        {
            countryCode:"SO",
            pattern:"\\d{5}"
        },
        {
            countryCode:"SZ",
            pattern:"[HLMS]\\d{3}"
        },
        {
            countryCode:"TC",
            pattern:"TKCA 1ZZ"
        },
        {
            countryCode:"WF",
            pattern:"986\\d{2}"
        },
        {
            countryCode:"XK",
            pattern:"\\d{5}"
        },
        {
            countryCode:"YT",
            pattern:"976\\d{2}"
        }
    ];
    zippattern="";
	pointlist:any;
	totalpoints:number = 0;
	isprofilephotouploaded = false;
	uploadedimagebtn:boolean=false;
	rootpath = '';
	uploadedimage:any=null;
	dragAreaClass:string='dragarea';
	imagedata: any;
	imagepreviewurl:string='';
	cropperSettings: CropperSettings;
	@ViewChild('lnksaveprofilebox') lnksaveprofilebox:ElementRef;
	@ViewChild('cropper', undefined) cropper:ImageCropperComponent;
	@ViewChild('lnkfollowerpopup') lnkfollowerpopup:ElementRef;
	model={id:0,username:'',password:'',email:'',confirmemail:'',image:'',registeredby:'Normal',socialid:'',mobilecode:'',mobileno:'',firstname:'',lastname:'',name:'',connectiontype:"Connections",country:'',state:'',city:'',zipcode:'',gender:'',maritalstatus:'',occupation:'',birthday:'',initials1:'',initials2:'',initials3:'',aboutme:"",personality:'', facebook: "",twitter: "",linkedin:"",instagram: "",pinterest: "",youtube: "",google: "",website: "",penderiepromise:false,agreeterms:false};
	isshowverification:boolean = false;
	isshowconfirmation:boolean = false;
	countrylist:any;
	codeslist:any;
	statelist:any;
	citylist:any;
	userid:number;
	formdisplay:string = 'member';
	nameforverification:string;
	memberorseller:boolean = true;
	memberstepshow:boolean = true;
	followerstep:boolean = true;
	countWebPresense = 0;
	isallowed = true;
	isemail = 0;
	userverified = '';
	emailverified = '';
	disableSince:any = {};
	
	public myDatePickerOptions: IMyDpOptions = {
				// other options...
				dateFormat: 'mm/dd/yyyy',
				editableDateField:false,
				openSelectorTopOfInput: true,
				// disableUntil: {year: 2018, month: 7, day: 01}
		};
	public model2: any = {  };
	constructor(private _translate: TranslateService,private dbserv:DbserviceService,private authserv: AuthenticationService,private _alert: AlertsService,private route: ActivatedRoute,private router: Router,private socialLoginAuthService	: AuthService, private fb : FacebookService) { 
			window['verifyCaptch'] = this.verifyCaptch.bind(this);
		let today = new Date();
		this.disableSince = { year: today.getFullYear(), month: today.getMonth() + 1, day: today.getDate() };
		this.myDatePickerOptions.disableSince = this.disableSince;
		let date = new Date();
		
		// this.model2.date.year = date.getFullYear();
		// this.model2.date.month = date.getMonth();
		// this.model2.date.day = date.getDate();
		// this.model.birthday = this.model2.date.year + "-" + this.model2.date.month + "-" + this.model2.date.day;
		this.rootpath = localStorage.getItem('apiurl');
		this.cropperSettings = new CropperSettings();
				this.cropperSettings.width = 600;
				this.cropperSettings.height = 600;
				this.cropperSettings.croppedWidth = 600;
				this.cropperSettings.croppedHeight = 600;
				this.cropperSettings.canvasWidth = 420;
				this.cropperSettings.noFileInput = true;
				this.cropperSettings.canvasHeight = 300;
				this.cropperSettings.touchRadius = 92;
				this.cropperSettings.rounded = true;
				this.cropperSettings.keepAspect = true;
				this.imagedata = {};
		let initParams: InitParams = {
			appId: '1780419275334741',
			xfbml: true,
			version: 'v2.10'
		};

		this.fb.init(initParams);
	}
	// user: SocialUser;
	options:any;
	onDateChanged(event: IMyDateModel) {
				// event properties are: event.date, event.jsdate, event.formatted and event.epoc
		if(event.jsdate)
		{
			this.model.birthday = event.jsdate.getFullYear() + "-" + event.jsdate.getMonth() + "-" + event.jsdate.getDate();
			console.log(this.model.birthday);
		}
	}
	changepersonality(type)
	{
		$(".personality").removeClass("active");
		$("#lnk"+type).addClass("active");
		this.model.personality = type;	
	}
	switchsellernmember()
	{
		this.memberorseller = !this.memberorseller;
		
	}
	showformnum()
	{
		$(".formssect").css("display",'none');
		$("#form"+this.formdisplay).css("display",'block');
	}
	ngOnInit() {
	    
		// setTimeout( () => { this.displayRecaptcha(); }, 100 );
		this.userid = this.authserv.getUserId();
		if(this.userid>0)
		{
			this.router.navigate(['myaccount']);

		}
		else
		{
			// this.authService.authState.subscribe((user) => {
			// 	console.log('regi',user);
			// 	if(user != null){
			// 		let mydate = new Date().getTime() + (60*60*24*1000);
			// 		this.model.socialid = user.id;
			// 		this.model.registeredby = user.provider;
			// 		this.model.name = user.name;
			// 		this.model.email = user.email;
			// 		this.model.image = user.photoUrl;
			// 		// this.model.lastname = user.firstName;
			// 		// this.model.lastname = user.lastName;	
			// 		this.model.username = mydate + "";
			// 		this.nameforverification = user.name;
			// 		/*this.memregisterstep();*/
			// 		/*this.dbserv.save("register",this.model).subscribe(res => {
			// 						 if(res.type=="success")
			// 						 {
			// 							this.router.navigate(['login']);
			// 						 }
			// 						 else
			// 							 this._alert.create(res.type,res.message);
			// 				});*/ 
			// 	}else{
			// 		this.authserv.logout();
			// 	}
			// });
			let currlang = localStorage.getItem('currlang');
			this._translate.use(currlang);
			this.dbserv.getAll("countries").subscribe(res => {this.countrylist = res;});
			this.dbserv.getAll("phonecodes").subscribe(res => {this.codeslist = res;});
		}
	}


	saveprofileimage(){
		this.uploadedimagebtn = true;
		if(this.imagedata.image!=null && this.uploadedimage!=null && this.uploadedimage.name!='')
		{
			console.log(this.uploadedimage);
			let _formData = new FormData();
			_formData.append("id",this.userid.toString());
			_formData.append('image',this.uploadedimage, this.uploadedimage.name);
			_formData.append('image',this.imagedata.image);
			if (this.uploadedimage && this.uploadedimage) {
				_formData.append('imagesrc',this.uploadedimage, this.uploadedimage.name);
			}
			this.dbserv.saveimage("userprofileimage",_formData).subscribe(res => {
				this.uploadedimagebtn = false;
				this.isprofilephotouploaded = true;
				// this.dbserv.getById("getuserdetail",this.auth.getUserId()).subscribe(ures => {
				// 	if(ures.type=="success")
				// 	{
					console.log("res.image"+res.image);
					
						this.imagepreviewurl = res.image+"?time="+Math.random();
						console.log("imagepreviewurl"+this.imagepreviewurl);
						this.model.image = res.image;
				// 		console.log("imagepreviewurl=",this.imagepreviewurl);
				// 	}
				// });
				this.lnksaveprofilebox.nativeElement.click();
				this.getporfilepoints();
				this._alert.create(res.type,res.message);
			}); 
		}
		else
		{
			this._alert.create('error','Please, select an image first.');
			this.uploadedimagebtn = false;
		}
	}
	getporfilepoints()
	{
		this.dbserv.getAll("profilepoints").subscribe(res => {
			this.pointlist = res;
			this.totalpoints = 0;
			this.totalpoints += +this.pointlist[0].point;
			this.totalpoints += +this.pointlist[1].point;
			this.totalpoints += +this.pointlist[2].point;
			this.totalpoints += +this.pointlist[3].point;
			this.totalpoints += +this.pointlist[4].point;
		});	
	}
	switchconnections(type)
	{
		this.model.connectiontype = type;
	}
	patternEmail = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
	memregisterstep()
	{
	    let zippattern = new RegExp(this.zippattern);
		if(this.memberstepshow)
		{
			
		console.log(this.model.birthday,this.model2);
			if(this.model.username=='' ||
				this.model.password=='' ||
				this.model.password.length < 6 || !(/^(?=.*\d)(?=.*[A-Z])(?=.*[$@$!%*#?&]).{6,}$/.test(this.model.password)) ||
				this.model.email=='' ||
				this.model.confirmemail=='' ||
				this.model.email  !== this.model.confirmemail || !(this.patternEmail.test(this.model.email)) || !(this.patternEmail.test(this.model.email)) ||
				this.model.firstname=='' ||
				this.model.lastname=='' ||
				this.model.name=='' ||
				this.model.country=='' ||
				this.model.state=='' ||
				this.model.city=='' ||
				this.model.zipcode=='' ||  !(zippattern.test(this.model.zipcode)) || 
				this.model.gender=='' ||
				this.model.maritalstatus=='' ||
				this.userverified!='' ||
				this.emailverified!='' ||
				this.model.occupation=='' ||
				this.model.birthday=='' || this.model2 == null || this.model2 == '')
			{
				 console.log("");
				//this._alert.create('error',"Please, fill the required fields.");
				//console.log("actual mail: "+this.model.email);
				//console.log("confirm mail: "+this.model.confirmemail);
				if(this.model.email !== this.model.confirmemail)
				{
					this.isemail = 1;
				}else{
					this.isemail = 0;
				}
			}else{
				this.memberstepshow = !this.memberstepshow;
				setTimeout( () => { this.displayRecaptcha(); }, 100 );
				this.isemail = 0;
				}
		}
		else
		{
			this.memberstepshow = !this.memberstepshow;
		}
	}
		
	//fb and google 
	signInWithGoogle(): void {
		this.socialLoginAuthService.login('google').subscribe((data: any) => {
			this.authserv.loginwithsocialid(data.uid).subscribe(
				res => {
					if (res.type == 'error') {
						let mydate = new Date().getTime() + (60*60*24*1000);
						this.model.socialid = data.uid;
						this.model.registeredby = data.provider;
						this.model.name = data.name;
						this.model.firstname = this.model.name.split(' ').slice(0, -1).join(' ');
						this.model.lastname =  this.model.name.split(' ').slice(-1).join(' ');
						this.model.email = data.email;
						this.model.image = data.image;
						// this.model.lastname = user.firstName;
						// this.model.lastname = user.lastName;	
						this.model.username = mydate + "";
						this.nameforverification = data.name;
//						this.dbserv.save("register",this.model).subscribe(res => {
//							if (res && res.token) {
//								// store user details and jwt token in local storage to keep user logged in between page refreshes
//								localStorage.setItem('currentUser', JSON.stringify(res));
//								this.authserv.sessionreq();
//								this.authserv.session().subscribe(res => {
//									this.router.navigate(['/myaccount']);
//								});
//							}
//						});
					}
					if (res && res.token) {
						// store user details and jwt token in local storage to keep user logged in between page refreshes
						localStorage.setItem('currentUser', JSON.stringify(res));
						this.authserv.sessionreq();
						this.authserv.session().subscribe(res => {
							this.router.navigate(['/myaccount']);
						});
					}
				},
				error => {
					console.log(data);
					let mydate = new Date().getTime() + (60*60*24*1000);
					this.model.socialid = data.uid;
					this.model.registeredby = data.provider;
					this.model.name = data.name;
					this.model.firstname = this.model.name.split(' ').slice(0, -1).join(' ');
					this.model.lastname =  this.model.name.split(' ').slice(-1).join(' ');
					this.model.email = data.email;
					this.model.image = data.image;
					// this.model.lastname = user.firstName;
					// this.model.lastname = user.lastName;	
					this.model.username = mydate + "";
					this.nameforverification = data.name;
//					this.dbserv.save("register",this.model).subscribe(res => {
//						if (res && res.token) {
//							// store user details and jwt token in local storage to keep user logged in between page refreshes
//							localStorage.setItem('currentUser', JSON.stringify(res));
//							this.authserv.sessionreq();
//							this.authserv.session().subscribe(res => {
//								this.router.navigate(['/myaccount']);
//							});
//						}
//					});
				});
			
		});
	}
	
	signInWithFB(): void {
		const loginOptions: LoginOptions = {
			enable_profile_selector: true,
			return_scopes: true,
			scope: 'public_profile,email'
		};

		this.fb.login(loginOptions).then((response: LoginResponse) => {
				if(response.status === "connected"){
					this.fb.api('/me?fields=name,email,picture').then((res: any) => {
							let userDetails = {
									name: res.name,
									email: res.email,
									uid: res.id,
									provider: "facebook",
									image: res.picture.data.url,
									token: response.authResponse.accessToken
							}

							console.log(userDetails);
							this.authserv.loginwithsocialid(userDetails.uid).subscribe(
								res => {
									if (res.type == 'error') {
										let mydate = new Date().getTime() + (60*60*24*1000);
										this.model.socialid = userDetails.uid;
										this.model.registeredby = userDetails.provider;
										this.model.name = userDetails.name;
										this.model.firstname = this.model.name.split(' ').slice(0, -1).join(' ');
										this.model.lastname =  this.model.name.split(' ').slice(-1).join(' ');
										this.model.email = userDetails.email;
										this.model.image = userDetails.image;
										// this.model.lastname = user.firstName;
										// this.model.lastname = user.lastName;	
										this.model.username = userDetails.uid;
										this.nameforverification = userDetails.name;
										/*this.dbserv.save("register",this.model).subscribe(res => {
											if (res && res.token) {
												// store user details and jwt token in local storage to keep user logged in between page refreshes
												localStorage.setItem('currentUser', JSON.stringify(res));
												this.authserv.sessionreq();
												this.authserv.session().subscribe(res => {
													this.router.navigate(['/myaccount']);
												});
											}
										});*/
									}
									if (res && res.token) {
										// store user details and jwt token in local storage to keep user logged in between page refreshes
										localStorage.setItem('currentUser', JSON.stringify(res));
										this.authserv.sessionreq();
										this.authserv.session().subscribe(res => {
											this.router.navigate(['/myaccount']);
										});
									}
								},
								error => {
									let mydate = new Date().getTime() + (60*60*24*1000);
									this.model.socialid = userDetails.uid;
									this.model.registeredby = userDetails.provider;
									this.model.name = userDetails.name;
									this.model.firstname = this.model.name.split(' ').slice(0, -1).join(' ');
									this.model.lastname =  this.model.name.split(' ').slice(-1).join(' ');
									this.model.email = userDetails.email;
									this.model.image = userDetails.image;
									// this.model.lastname = user.firstName;
									// this.model.lastname = user.lastName;	
									this.model.username = mydate + "";
									this.nameforverification = userDetails.name;
									/*this.dbserv.save("register",this.model).subscribe(res => {
										if (res && res.token) {
											// store user details and jwt token in local storage to keep user logged in between page refreshes
											localStorage.setItem('currentUser', JSON.stringify(res));
											this.authserv.sessionreq();
											this.authserv.session().subscribe(res => {
												this.router.navigate(['/myaccount']);
											});
										}
									});*/
								});
					});
				}
			}).catch();
	}
	
	signOut(): void {
		// this.authService.signOut();
	}
	//fb and google end
	states()
	{
		this.dbserv.getAll("states/" + this.model.country).subscribe(res => {this.statelist = res;});
		this.citylist = [];
		this.model.city = '';
		//this.statelist = [];
		this.model.state = '';
		let pattern = this.countryArray.find(x => x.countryCode === this.model.country);
		console.log(pattern);
		if(pattern != undefined)
		    this.zippattern = pattern.pattern;
		else
		    this.zippattern = "";
	}
	cities()
	{
		this.dbserv.getAll("cities/" + this.model.country + "/" + this.model.state).subscribe(res => {
		    this.citylist = res;
		    this.citylist.push({city:"Other"});
		});
	}
	signInWithLinkedIN(): void {
		this.socialLoginAuthService.login('linkedin').subscribe((data: any) => {
			this.authserv.loginwithsocialid(data.uid).subscribe(
				res => {
					if (res.type == 'error') {
						let mydate = new Date().getTime() + (60*60*24*1000);
						this.model.socialid = data.uid;
						this.model.registeredby = data.provider;
						this.model.name = data.name;
						this.model.firstname = this.model.name.split(' ').slice(0, -1).join(' ');
						this.model.lastname =  this.model.name.split(' ').slice(-1).join(' ');
						this.model.email = data.email;
						this.model.image = data.image;
						// this.model.lastname = user.firstName;
						// this.model.lastname = user.lastName;	
						this.model.username = mydate + "";
						this.nameforverification = data.name;
						/*this.dbserv.save("register",this.model).subscribe(res => {
							if (res && res.token) {
								// store user details and jwt token in local storage to keep user logged in between page refreshes
								localStorage.setItem('currentUser', JSON.stringify(res));
								this.authserv.sessionreq();
								this.authserv.session().subscribe(res => {
									this.router.navigate(['/myaccount']);
								});
							}
						});*/
					}
					if (res && res.token) {
						// store user details and jwt token in local storage to keep user logged in between page refreshes
						localStorage.setItem('currentUser', JSON.stringify(res));
						this.authserv.sessionreq();
						this.authserv.session().subscribe(res => {
							this.router.navigate(['/myaccount']);
						});
					}
				},
				error => {
					console.log(data);
					let mydate = new Date().getTime() + (60*60*24*1000);
					this.model.socialid = data.uid;
					this.model.registeredby = data.provider;
					this.model.name = data.name;
					this.model.firstname = this.model.name.split(' ').slice(0, -1).join(' ');
					this.model.lastname =  this.model.name.split(' ').slice(-1).join(' ');
					this.model.email = data.email;
					this.model.image = data.image;
					// this.model.lastname = user.firstName;
					// this.model.lastname = user.lastName;	
					this.model.username = mydate + "";
					this.nameforverification = data.name;
				/*	this.dbserv.save("register",this.model).subscribe(res => {
						if (res && res.token) {
							// store user details and jwt token in local storage to keep user logged in between page refreshes
							localStorage.setItem('currentUser', JSON.stringify(res));
							this.authserv.sessionreq();
							this.authserv.session().subscribe(res => {
								this.router.navigate(['/myaccount']);
							});
						}
					});*/
				});
			
		});
	}
	register()
	{
		console.log('regitor',this.memberstepshow);
		if(this.memberstepshow == false && this.captcha.response != ''){
			if(this.model.connectiontype=='Follower Only'){
				if(this.model.aboutme==''){
					this.lnkfollowerpopup.nativeElement.click();
					// this._alert.create('error',this._translate.instant('Please enter about you before register.'));
					this.isallowed = false;
				}
				else if(this.model.personality=='')
				{
					this.lnkfollowerpopup.nativeElement.click();
					// this._alert.create('error',this._translate.instant('Please select a member type before register.'));
					this.isallowed = false;
				}
				else{
					this.isallowed =true;
				}
			}
			/*alert(isallowed + this.model.connectiontype)*/
			if(this.isallowed == true)
			{
				this.model.birthday = this.model2.jsdate.getFullYear() + "-" + this.model2.jsdate.getMonth() + "-" + this.model2.jsdate.getDate();
				if (this.model.registeredby == '' || this.model.registeredby == undefined) {
					this.model.registeredby='Normal';
				}
				if (this.model.socialid == undefined) {
					this.model.socialid='';
				}
				this.dbserv.save("register",this.model).subscribe(res => {
					this._alert.create(res.type,res.message);
					if(res.type.trim()=="success")
					{
						this.model.id=res.userid;
						this.nameforverification = this.model.name;
						this.isshowverification=true;
						if(this.model.connectiontype=="Follower Only")
							this.isshowconfirmation=true;
						else
							this.isshowconfirmation=false;
						}
				});
			}
		}
	}
	checkWebPres()
	{
		this.countWebPresense = 0;
		if(this.model.facebook !== ''){
			this.countWebPresense++;
		}

		if(this.model.twitter !== ''){
			this.countWebPresense++;
		}

		if(this.model.linkedin !== ''){
			this.countWebPresense++;
		}

		if(this.model.instagram !== ''){
			this.countWebPresense++;
		}

		if(this.model.pinterest !== ''){
			this.countWebPresense++;
		}

		if(this.model.youtube !== ''){
			this.countWebPresense++;
		}

		if(this.model.google !== ''){
			this.countWebPresense++;
		}

		if(this.model.website !== ''){
			this.countWebPresense++;
		}
		
		if(this.countWebPresense >= 3){
			this.isallowed = true;
		}else {
			this.isallowed = false;
		}
	}

	resendverification()
	{
		if(this.model.id>0){
			this.dbserv.getById("resendverifiction",this.model.id).subscribe(res => {
				this._alert.create(res.type,res.message);
			});
		}
		else{
			this._alert.create('error',this._translate.instant('Please, register before clicking on Resend Request button.'));	
		}
	}
	
	readImageUrl() {
		if (this.uploadedimage && this.uploadedimage) {
		var reader = new FileReader();
		var image:any = new Image();
		reader.onload = (event:any) => {
			 image.src = event.target.result; 
			this.cropper.setImage(image);
		}
		reader.onloadend = (event:any) => {
					 image.src = event.target.result; 
			this.cropper.setImage(image);
				};
		reader.readAsDataURL(this.uploadedimage);
		}
	}
	onFileChange($event){
		 this.uploadedimage = $event.target.files[0];
		 this.readImageUrl();
		 //this.saveprofileimage( $event.target.files[0]);
	}
	@HostListener('dragover', ['$event']) onDragOver(event) {
				this.dragAreaClass = "droparea";
				event.preventDefault();
		}
	@HostListener('dragenter', ['$event']) onDragEnter(event) {
		this.dragAreaClass = "droparea";
		event.preventDefault();
	}
	@HostListener('dragend', ['$event']) onDragEnd(event) {
		this.dragAreaClass = "dragarea";
		event.preventDefault();
	}
	@HostListener('dragleave', ['$event']) onDragLeave(event) {
		this.dragAreaClass = "dragarea";
		event.preventDefault();
	}
	@HostListener('drop', ['$event']) onDrop(event) {   
		this.dragAreaClass = "dragarea";           
		event.preventDefault();
		event.stopPropagation();
		this.uploadedimage = event.dataTransfer.files[0];
		this.readImageUrl();
		//this.saveprofileimage(event.dataTransfer.files[0]);
	}
		displayRecaptcha(){
		grecaptcha.render('captcha',{
			'sitekey' : '6Ldfl2AUAAAAAJ1X1mK3bt1qxqsavpO3x5NVxBVc',
		})
	}
	
	captcha:any = {
		secret:'',
		response:''
	};
	verifyCaptch() {
		let captchaResponse = grecaptcha.getResponse();
		this.captcha.secret = "6Ldfl2AUAAAAAB0eItGgN13dk0eUtbqsohYRYvjF";
		this.captcha.response = captchaResponse;
		this.dbserv.save("verify_captch",this.captcha).subscribe(res => {
			console.log(res);
		});
	}
	
	cropped($event)
	{
		/*this.imagepreviewurl = this.imagedata.image;
		this.imagepreviewurl2 = this.imagedata.image;*/
	}

	// let myApp = angular.module('myApp',[]);
	// 			function MyCtrl($scope) {
    // 				$scope.url ='http://jsfiddle.net/HB7LU/16771/';
	// 			}

	verificationusername(){
		this.userverified ='';
		this.dbserv.save("verificationusername",this.model).subscribe(res => {
			// this._alert.create(res.type,res.message);
			this.userverified ='Username is already exist';
		});
	}
	verificationemail(){
		this.emailverified ='';
		this.dbserv.save("verificationemail",this.model).subscribe(res => {
			this.emailverified ='Email is already exist';
		});
	}
}
