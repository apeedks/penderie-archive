import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MemdashboardiconsComponent } from './memdashboardicons.component';

describe('MemdashboardiconsComponent', () => {
  let component: MemdashboardiconsComponent;
  let fixture: ComponentFixture<MemdashboardiconsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MemdashboardiconsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MemdashboardiconsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
