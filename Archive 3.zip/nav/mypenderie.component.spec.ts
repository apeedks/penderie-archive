import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MypenderieComponent } from './mypenderie.component';

describe('MypenderieComponent', () => {
  let component: MypenderieComponent;
  let fixture: ComponentFixture<MypenderieComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MypenderieComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MypenderieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
