import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';
@Component({
  selector: 'app-innerheader',
  templateUrl: './innerheader.component.html',
  styleUrls: ['./innerheader.component.css']
})
export class InnerheaderComponent implements OnInit {
  visittype: string = "";
  rootnode;
  currentnode: any;
  options:any;

  // Hide Header on on scroll down
  didScroll;
  lastScrollTop = 0;
  delta = 5;
  navbarHeight = $('header').outerHeight();

  constructor(private router: Router, private cookieService: CookieService) {
      this.visittype = localStorage.getItem('visittype');
      if(this.visittype == null || this.visittype == '' || this.visittype == undefined)
        this.visittype = 'Women';
        this.currentnode = $('header').parent().next();
        console.log(this.visittype);
  }

  ngOnInit() {
    // $(window).scroll(function() {    
    //     var scroll = $(window).scrollTop();
    //      //console.log(scroll);
    //     if (scroll >= 100) {
    //         //console.log('a');
    //         $(".innper-pages-header").addClass("innper-pages-header-white");
    //     } else {
    //         //console.log('a');
    //         $(".innper-pages-header").removeClass("innper-pages-header-white");
    //     }
    // });
  }

  ngAfterViewInit() {
    this.navbarHeight = $('header').outerHeight();
    $(window).scroll((event) => {
      this.didScroll = true;
    });

    // setInterval(()=> {
    //     if (this.didScroll) {
    //         this.hasScrolled();
    //         this.didScroll = false;
    //     }
    // }, 250);
  }

  switchtopgender(type: string) {

    this.cookieService.set('visittype', type);
    localStorage.setItem('visittype', type);
    console.log(this.visittype);
    setTimeout((router: Router) => {
      this.router.navigate(['home']);
    }, 500);

  }
	/*switchsections(type:string)
	{
		this.cookieService.set('sectiontheme',type);
		switch(type)
		{
			case "Fine Material":
				this.router.navigate(['fine-material']);
				break;
			case "Superiar Craftmanship":
				this.router.navigate(['superiar-craftmanship']);
				break;
			case "Art of Styling":
				this.router.navigate(['art-of-styling']);
				break;
			case "Balanced Living":
				this.router.navigate(['balanced-living']);
				break;
		}
	}*/
  // hasScrolled() {
  //    	let st = $(window).scrollTop();
  //     // Make sure they scroll more than delta
  //     if(Math.abs(this.lastScrollTop - st) <= this.delta)
  //         return;

  //    	// console.log(st,this.lastScrollTop,this.navbarHeight);
  //     // If they scrolled down and are past the navbar, add class .nav-up.
  //     // This is necessary so you never see what is "behind" the navbar.
  //     if (st > this.lastScrollTop && st > this.navbarHeight){
  //         // Scroll Down
  //         $('header').removeClass('nav-down').addClass('nav-up');
  //     } else {
  //         // Scroll Up
  //         if(st + $(window).height() < $(document).height()) {
  //             $('header').removeClass('nav-up').addClass('nav-down');
  //         }
  //     }

  //     this.lastScrollTop = st;
  // }

  wasClicked = true;
  dashleftpannel = false;
  dashdesignpannel = false;

  rotateLeft() {
    this.wasClicked = !this.wasClicked;
    if (this.wasClicked) {
      this.dashleftpannel = true;
      this.dashdesignpannel = true;
    }
    else {
      this.dashleftpannel = false;
      this.dashdesignpannel = false;
    }
  }
    scrolltonext(direction: string) {
    if (!this.rootnode)
      this.rootnode = $('header').parent().next();
    let currindex = 0;
    if (direction == 'up') {
      let prevnode = this.rootnode.prev();
      if (prevnode.is('section')) {
        if ($(window).width() < 992) {
          if($(window).width() < 426){
             $("html, body").animate({
              scrollTop: prevnode.offset().top - 53
            }, 500);
          }else{
            $("html, body").animate({
              scrollTop: prevnode.offset().top - 66
            }, 500);
          }
        }else{
          $("html, body").animate({
            scrollTop: prevnode.offset().top - 103
          }, 500);
        }
        this.rootnode = prevnode;
      }
    }
    else {
      let  nextnode = this.rootnode.next();
      if (nextnode.is('section') || nextnode.prop('nodeName') == "APP-FRONTFOOTER") {
        if ($(window).width() < 992) {
          if($(window).width() < 426){
             $("html, body").animate({
              scrollTop: nextnode.offset().top - 53
            }, 500);
          }else{
            $("html, body").animate({
              scrollTop: nextnode.offset().top - 66
            }, 500);
          }
        }else{
          $("html, body").animate({
            scrollTop: nextnode.offset().top - 102
          }, 500);
        }
        this.rootnode = nextnode;
      }
    }

  }
  funcsearchclicked()
  {
    $('body').toggleClass('custo-search-open')
    $('.search-clicker').toggleClass('search-cross')
  }
}