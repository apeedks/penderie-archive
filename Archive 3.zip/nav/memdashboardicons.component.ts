import { Component, OnInit } from '@angular/core';
import {DbserviceService} from '../services/dbservice.service';
import { AuthenticationService } from '../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { TranslateService } from '../translate';
import { Router, ActivatedRoute } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';
@Component({
  selector: 'app-memdashboardicons',
  templateUrl: './memdashboardicons.component.html',
  styleUrls: ['./memdashboardicons.component.css']
})
export class MemdashboardiconsComponent implements OnInit {
	isuserloggedin:boolean=false;
    userid:number = 0;
    isnew:string="";
	constructor(private _translate: TranslateService, private cookieService:CookieService,private dbserv:DbserviceService,private authserv: AuthenticationService,private _alert: AlertsService,private route: ActivatedRoute,private router: Router) { }
	
	ngOnInit() {
		this.isuserloggedin = this.authserv.isloggedin();
		this.userid = this.authserv.getUserId();
        if(this.userid>0)
        {
            this.isuserloggedin = true;
            this.dbserv.getById("getuserdetail",this.userid).subscribe(res => {
                if(res.type=="success")
                {
                    this.isnew = res.data.isnew;
                }
            });
        }
	}

}
