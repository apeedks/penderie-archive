import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';
import * as _ from 'lodash';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  visittype: string = "";
  rootnode;
  currentnode: any;
  options:any;

  // Hide Header on on scroll down
  didScroll;
  lastScrollTop = 0;
  delta = 5;
  navbarHeight = $('header').outerHeight();


  constructor(private router: Router, private cookieService: CookieService, private route: ActivatedRoute) {
    this.visittype = localStorage.getItem('visittype');
    if(this.visittype == null || this.visittype == undefined)
      this.visittype = 'Women';
    this.currentnode = $('header').parent().next();
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd ) {
        // this.currentUrl = event.url;
        console.log(event.url);
      }
    });
  }

  hideMobile() {
    $('.for_mobile').toggle('slide');
  }

  ngOnInit() {
      // $(window).scroll(function() {    
      //   var scroll = $(window).scrollTop();
      //    console.log(scroll);
      //   if (scroll >= 100) {
      //       // console.log('a');
      //       $(".innper-pages-header .custom-nav").addClass("innper-pages-header-white");
      //   } else {
      //       // console.log('b');
      //       $(".innper-pages-header .custom-nav").removeClass("innper-pages-header-white");
      //   }
      // });
  }
  ngAfterViewInit() {
    this.navbarHeight = $('header').outerHeight();
    $(window).scroll((event) => {
      this.didScroll = true;
    });

    /*setInterval(()=> {
         if (this.didScroll) {
             this.hasScrolled();
             this.didScroll = false;
         }
     }, 250);*/
  }
  switchtopgender(type: string) {

    this.cookieService.set('visittype', type);
    localStorage.setItem('visittype', type);

    setTimeout((router: Router) => {
      if(type == 'Women')
        this.router.navigate(['women']);
      else
        this.router.navigate(['man']);
    }, 0);

  }
  tmpclass = "";
  tmppos = 0;
  scrolltonext(direction: string) {
    let topsectionArray=[];
    let bottomsectionArray=[];
    // $(window).bind('scroll', function() {
        $('app-women > section').each(function() {
            var post = $(this);
            var position = post.position().top - $(window).scrollTop();
            if (position <= 0) {
              // console.log("ll",position);
              bottomsectionArray.push({pos:-(position),class:$(this).attr('class')});
            } else {
              // console.log("rr",position+","+$(this).attr('class'));
              topsectionArray.push({pos:position,class:$(this).attr('class')});
            }
        });
        $('app-men > section').each(function() {
            var post = $(this);
            var position = post.position().top - $(window).scrollTop();
            if (position <= 0) {
              // console.log("ll",position);
              bottomsectionArray.push({pos:-(position),class:$(this).attr('class')});
            } else {
              // console.log("rr",position+","+$(this).attr('class'));
              topsectionArray.push({pos:position,class:$(this).attr('class')});
            }
        });
        let sectionClass = "";
        // console.log("All",topsectionArray,bottomsectionArray);
        if (direction == 'up') {
          bottomsectionArray = bottomsectionArray.sort(function(a,b) { return a.pos - b.pos; });
          // console.log(this.tmpclass,bottomsectionArray[0],bottomsectionArray);
          sectionClass = bottomsectionArray[0].class.split(" ")[0];
          if (this.tmpclass == sectionClass) {
            // console.log(this.tmpclass,bottomsectionArray[1]);
            if (bottomsectionArray[1] != undefined) {
              sectionClass = bottomsectionArray[1].class.split(" ")[0];
              // this.tmpclass = sectionClass;
            }
          }
          this.tmpclass = sectionClass;
        }else{
          topsectionArray = topsectionArray.sort(function(a,b) { return a.pos - b.pos; });
          // console.log(this.tmpclass,topsectionArray[0],topsectionArray);
          sectionClass = topsectionArray[0].class.split(" ")[0];
          if (this.tmpclass == sectionClass) {
            // console.log(this.tmpclass,topsectionArray[1]);
            if (topsectionArray[1] != undefined) {
              sectionClass = topsectionArray[1].class.split(" ")[0];
              // this.tmpclass = sectionClass;
            }
          }
          this.tmpclass = sectionClass;
        }
        // console.log(direction,this.tmpclass,sectionClass);
        if ($(window).width() < 992) {
          if($(window).width() < 426){
             $("html, body").animate({
              scrollTop: $("."+sectionClass).offset().top - 53
            }, 500);
          }else{
            $("html, body").animate({
              scrollTop: $("."+sectionClass).offset().top - 66
            }, 500);
          }
        }else{
          $("html, body").animate({
            scrollTop: $("."+sectionClass).offset().top - 102
          }, 500);
        }
    // });
    // console.log($('section').offset().top - $(window).scrollTop());
    // if (!this.rootnode)
    //   this.rootnode = $('header').parent().next();
    // let currindex = 0;
    // if (direction == 'up') {
    //   let prevnode = this.rootnode.prev();
    //   if (prevnode.is('section')) {
    //     console.log($(window).width());
    //     if ($(window).width() < 992) {
    //       if($(window).width() < 426){
    //          $("html, body").animate({
    //           scrollTop: prevnode.offset().top - 53
    //         }, 500);
    //       }else{
    //         $("html, body").animate({
    //           scrollTop: prevnode.offset().top - 66
    //         }, 500);
    //       }
    //     }else{
    //       $("html, body").animate({
    //         scrollTop: prevnode.offset().top - 103
    //       }, 500);
    //     }
    //     this.rootnode = prevnode;
    //   }
    // }
    // else {
    //   let  nextnode = this.rootnode.next();
    //   console.log("nextnode=",nextnode);
    //   if (nextnode.is('section')) {
    //     console.log($(window).width());
    //     if ($(window).width() < 992) {
    //       if($(window).width() < 426){
    //          $("html, body").animate({
    //           scrollTop: nextnode.offset().top - 53
    //         }, 500);
    //       }else{
    //         $("html, body").animate({
    //           scrollTop: nextnode.offset().top - 66
    //         }, 500);
    //       }
    //     }else{
    //       $("html, body").animate({
    //         scrollTop: nextnode.offset().top - 102
    //       }, 500);
    //     }
    //     this.rootnode = nextnode;
    //   }
    // }

  }

  // hasScrolled() {
  //    	let st = $(window).scrollTop();
  //     // Make sure they scroll more than delta
  //     if(Math.abs(this.lastScrollTop - st) <= this.delta)
  //         return;

  //    	// console.log(st,this.lastScrollTop,this.navbarHeight);
  //     // If they scrolled down and are past the navbar, add class .nav-up.
  //     // This is necessary so you never see what is "behind" the navbar.
  //     if (st > this.lastScrollTop && st > this.navbarHeight){
  //         // Scroll Down
  //         $('header').removeClass('nav-down').addClass('nav-up');
  //         $('.dashboard-header-sec').addClass('nav-up');
  //         $('.dash-nav-btn').addClass('nav-up');
  //     } else {
  //         // Scroll Up
  //         if(st + $(window).height() < $(document).height()) {
  //             $('header').removeClass('nav-up').addClass('nav-down');
  //             $('.dashboard-header-sec').removeClass('nav-up');
  //             $('.dash-nav-btn').removeClass('nav-up');
  //         }
  //     }

  //     this.lastScrollTop = st;
  // }

  wasClicked = true;
  dashleftpannel = false;
  dashdesignpannel = false;

  rotateLeft() {
    this.wasClicked = !this.wasClicked;
    if (this.wasClicked) {
      this.dashleftpannel = true;
      this.dashdesignpannel = true;
    }
    else {
      this.dashleftpannel = false;
      this.dashdesignpannel = false;
    }
  }

  funcsearchclicked()
  {
    $('body').toggleClass('custo-search-open')
    $('.search-clicker').toggleClass('search-cross')
  }
}