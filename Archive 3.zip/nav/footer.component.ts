import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../services/dbservice.service';
import { CookieService } from 'ngx-cookie-service';
import { AuthenticationService } from '../services/authentication.service';
import $ from 'jquery';

@Component({
  selector: 'app-frontfooter',
  templateUrl: './footer.component.html',
  //styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
	visittype:string = 'Women';
	paccess:string;
	sectiontheme:string;
	model = {gender:'', section: '',paccess:"Anonymous"};
	public companiesfooter:Object;
	public memberfooter:Object;
	public serviceprofooter:Object;
	public designerfooter:Object;
	public suppliersfooter:Object;

	public templatecompaniesfooter:Object;
	public templatememberfooter:Object;
	public templateserviceprofooter:Object;
	public templatedesignerfooter:Object;
	public templatesuppliersfooter:Object;
	
	constructor(private dbserv:DbserviceService,private cookieService: CookieService, private authserv: AuthenticationService) { 
		this.visittype = localStorage.getItem('visittype');
		if(this.visittype == null || this.visittype == '' || this.visittype == undefined)
    	this.visittype = 'Women';
		this.sectiontheme = localStorage.getItem('sectiontheme');
		this.paccess = 'Anonymous';//this.cookieService.get('theme');
	}
	
	ngOnInit() {
	    if (this.authserv.isloggedin()) {
	        this.paccess = 'Registered';
	        this.dbserv.getdirectAll("contentbytype/Company Footer/"+this.sectiontheme+"/"+this.visittype+"/"+this.paccess).subscribe(res => {this.companiesfooter = res;});
	        this.dbserv.getdirectAll("contentbytype/Members Footer/"+this.sectiontheme+"/"+this.visittype+"/"+this.paccess).subscribe(res => {this.memberfooter = res;});
	        this.dbserv.getdirectAll("contentbytype/Service Providers Footer/"+this.sectiontheme+"/"+this.visittype+"/"+this.paccess).subscribe(res => {this.serviceprofooter = res;});
	        this.dbserv.getdirectAll("contentbytype/Designer Footer/"+this.sectiontheme+"/"+this.visittype+"/"+this.paccess).subscribe(res => {this.designerfooter = res;});
	        this.dbserv.getdirectAll("contentbytype/Suppliers Footer/"+this.sectiontheme+"/"+this.visittype+"/"+this.paccess).subscribe(res => {this.suppliersfooter = res;});

	        this.dbserv.getdirectAll("templatebytype/Company Footer/"+this.sectiontheme+"/"+this.visittype+"/"+this.paccess).subscribe(res => {this.templatecompaniesfooter = res;});
	        this.dbserv.getdirectAll("templatebytype/Members Footer/"+this.sectiontheme+"/"+this.visittype+"/"+this.paccess).subscribe(res => {this.templatememberfooter = res;});
	        this.dbserv.getdirectAll("templatebytype/Service Providers Footer/"+this.sectiontheme+"/"+this.visittype+"/"+this.paccess).subscribe(res => {this.templateserviceprofooter = res;});
	        this.dbserv.getdirectAll("templatebytype/Designer Footer/"+this.sectiontheme+"/"+this.visittype+"/"+this.paccess).subscribe(res => {this.templatedesignerfooter = res;});
	        this.dbserv.getdirectAll("templatebytype/Suppliers Footer/"+this.sectiontheme+"/"+this.visittype+"/"+this.paccess).subscribe(res => {this.templatesuppliersfooter = res;});
	        
	    }
	  //this.dbserv.getAll("contents/").subscribe(res => {this.items = res.data; this.page = res.current_page; this.totalitems = res.total;this.pageSize = res.per_page;}); 
	  this.dbserv.getdirectAll("contentbytype/Company Footer/"+this.sectiontheme+"/"+this.visittype+"/"+this.paccess).subscribe(res => {this.companiesfooter = res;});
	  this.dbserv.getdirectAll("contentbytype/Members Footer/"+this.sectiontheme+"/"+this.visittype+"/"+this.paccess).subscribe(res => {this.memberfooter = res;});
	  this.dbserv.getdirectAll("contentbytype/Service Providers Footer/"+this.sectiontheme+"/"+this.visittype+"/"+this.paccess).subscribe(res => {this.serviceprofooter = res;});
	  this.dbserv.getdirectAll("contentbytype/Designer Footer/"+this.sectiontheme+"/"+this.visittype+"/"+this.paccess).subscribe(res => {this.designerfooter = res;});
	  this.dbserv.getdirectAll("contentbytype/Suppliers Footer/"+this.sectiontheme+"/"+this.visittype+"/"+this.paccess).subscribe(res => {this.suppliersfooter = res;});

	  this.dbserv.getdirectAll("templatebytype/Company Footer/"+this.sectiontheme+"/"+this.visittype+"/"+this.paccess).subscribe(res => {this.templatecompaniesfooter = res;});
	  this.dbserv.getdirectAll("templatebytype/Members Footer/"+this.sectiontheme+"/"+this.visittype+"/"+this.paccess).subscribe(res => {this.templatememberfooter = res;});
	  this.dbserv.getdirectAll("templatebytype/Service Providers Footer/"+this.sectiontheme+"/"+this.visittype+"/"+this.paccess).subscribe(res => {this.templateserviceprofooter = res;});
	  this.dbserv.getdirectAll("templatebytype/Designer Footer/"+this.sectiontheme+"/"+this.visittype+"/"+this.paccess).subscribe(res => {this.templatedesignerfooter = res;});
	  this.dbserv.getdirectAll("templatebytype/Suppliers Footer/"+this.sectiontheme+"/"+this.visittype+"/"+this.paccess).subscribe(res => {this.templatesuppliersfooter = res;});
 
	}
	

	openFooter(event){
	  if($(window).width() < 992){
	  	    // event.addEventListener("click", function() {
		    	console.log($(window).width(),event);
		    	if(event.target.tagName == "I"){
		    		event.target.parentElement.classList.toggle("active");
		    		let panel = event.target.parentElement.nextElementSibling;
					$(panel).toggle(200);
		        	$(event.target.parentElement).children().toggleClass('fa fa-plus fa fa-minus');
		    	}else{
					event.target.classList.toggle("active");
					let panel = event.target.nextElementSibling;
					$(panel).toggle(200);
		        	$(event.target).children().toggleClass('fa fa-plus fa fa-minus');
		    	}
		    // });
	  }
	}

}
