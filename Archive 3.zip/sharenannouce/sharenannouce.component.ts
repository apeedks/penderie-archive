import { Component, OnInit, OnDestroy } from '@angular/core';

import { HttpClient } from '@angular/common/http';
// import {HTTP_PROVIDERS, Http, Request, RequestMethod} from '@angular/http';

import { Router, ActivatedRoute } from '@angular/router';
import { Meta,Title} from '@angular/platform-browser';
import { AuthenticationService } from '../services/authentication.service';
import {DbserviceService} from '../services/dbservice.service';
import { AuthService }from "angular2-social-login";
import {AlertsService} from '@jaspero/ng2-alerts';
import $ from 'jquery';

import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/observable/interval';
import 'rxjs/add/operator/takeUntil';

declare var gapi: any;

declare var contactObject: any;
declare var WL: any;

@Component({
  selector: 'app-sharenannouce',
  templateUrl: './sharenannouce.component.html',
  styleUrls: ['./sharenannouce.component.css']
})
export class SharenannouceComponent implements OnInit, OnDestroy {
	sharedtags:string='';
	shareddescription:string='I Have recently Joined Penderie - an awesome website that focuses on the true Luxury lifestyle. I would like to invite my friends to connect with me on Penderie and alse enjoy various benefits Penderie has to offer.';
	sharedtitle:string='https://www.penderie.com/myprofile/username';
	sharedheaderimage:string='';
	basepageurl:string = '';
	email_message:string = 'I Have recently Joined Penderie - an awesome website that focuses on the true Luxury lifestyle. I would like to invite my friends to connect with me on Penderie and alse enjoy various benefits Penderie has to offer.';
	totalpoints = 0;
	pointlist:any;
	options:any;
	loading:boolean=false;
	emailContacts: any;
	emails = [];
	tagslist = [];
	tags = [];
	settings = {};
	destroy$: Subject<boolean> = new Subject<boolean>();
	clientId = '767946714520-f5vlvlsmfhhe93k51s7ssdmeuipq05an.apps.googleusercontent.com';
	apiKey = 'AIzaSyDDKvIvP6GBTsP40YoPfm5DBtp4m2nRJsw';
	scopes = 'https://www.googleapis.com/auth/contacts.readonly';

	YclientId = 'dj0yJmk9RU5pNHdxRnU5UjF6JmQ9WVdrOVdFZHJRbVJvTkdNbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD01Yw--';
	// YapiKey = 'AIzaSyDDKvIvP6GBTsP40YoPfm5DBtp4m2nRJsw';
	YSecret  = '56716d3f33543facaa235d4672d4673612aa2e32';
	Yscopes = 'Read/Write:sdct-w';
	Yredirect_uri = 'https://yahoo.com';

	// App configuration
	OauthEndpoint = 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize?';
	OredirectUri = 'http://localhost:4200';
	OappId = '000000004824443E';
	Oscopes = 'openid profile User.Read Mail.Read Contacts.Read';

	constructor(private route: ActivatedRoute,private router: Router,private meta: Meta, private titleService: Title,private authserv: AuthenticationService,private dbserv:DbserviceService, private socialLoginAuthService:AuthService,private _alert: AlertsService,private http: HttpClient) { 
		this.settings = { 
          singleSelection: false, 
          text:"Select Email",
          selectAllText:'Select All',
          unSelectAllText:'UnSelect All',
          enableSearchFilter: true,
		  limitSelection:500,
		  enableCheckAll:true,
          classes:"myclass custom-class"
        };
	}
	
	
	ngOnInit() {
                this.getporfilepoints();
		this.basepageurl =  localStorage.getItem("baseurl");
		this.sharedheaderimage= this.basepageurl + 'assets/img/images/logo_standard.png';
		let user = JSON.parse(localStorage.getItem('user'));
		let username = '';
        if (user && user.username) {
            username = user.username;
        }
		this.sharedtitle= "https://demo.penderie.com/build/" + 'mprofile/'+username;
		this.email_message = this.sharedtitle + '\n' + this.email_message
		this.meta.addTag({ name: 'keywords', content: this.sharedtitle });
		this.meta.addTag({ name: 'description', content: this.shareddescription });
		this.meta.addTag({ property: 'og:title', content: this.sharedtitle });
		this.meta.addTag({ property: 'og:description', content: this.shareddescription});
		this.meta.addTag({ property: 'og:image', content: this.sharedheaderimage });
		this.meta.addTag({ property: 'og:url', content: this.sharedtitle });
		this.titleService.setTitle(this.sharedtitle);
		
		Observable.interval(1000).takeUntil(this.destroy$).subscribe(val => {
	    	let emailcontactdata = JSON.parse(localStorage.getItem("socialMediaEmailContact"));
                if(emailcontactdata){
                        //console.log(emailcontactdata);
	    		//this.emails = emailcontactdata;
	    		this.tagslist = emailcontactdata;
	    		localStorage.removeItem("socialMediaEmailContact");
	    	}
                let yahooCon = localStorage.getItem("yahooContact");
                if(yahooCon){
                    this.getSocialContact(2);
                    localStorage.removeItem("yahooContact");
                }
                let outlookCon = localStorage.getItem("outlookContact");
                if(outlookCon){
                    this.getSocialContact(1);
                    localStorage.removeItem("outlookContact");
                }
	    });

	}
	getporfilepoints()
	{
		this.dbserv.getAll("profilepoints").subscribe(res => {
														  
				    this.pointlist = res;
					this.totalpoints = 0;
					this.totalpoints += +this.pointlist[0].point;
					this.totalpoints += +this.pointlist[1].point;
					this.totalpoints += +this.pointlist[2].point;
					this.totalpoints += +this.pointlist[3].point;
					this.totalpoints += +this.pointlist[4].point;
		});	
	}


	signInWithGoogle(): void {

		let config = {
	      'client_id': this.clientId,
	      'scope': 'https://www.google.com/m8/feeds'
	    };
	    gapi.auth.authorize(config, function() {

	    	localStorage.removeItem("socialMediaEmailContact");

	    	let token = gapi.auth.getToken();
	      	$.ajax({
			    url: "https://www.google.com/m8/feeds/contacts/default/full?access_token=" + token.access_token + "&alt=json&max-results=500",
			    dataType: "json",
			    async:true,
			    success:function(data) {
	                //console.log(data);
	                if (typeof data.feed.entry !== 'undefined' && data.feed.entry.length > 0) {
	                	//let allEmails = '';
	                	this.emails = [];
					    for (var i = 0; i < data.feed.entry.length; i++) {
					    	//console.log(data);
					    	if(typeof data.feed.entry[i].gd$email !== 'undefined'){
						    	if(typeof data.feed.entry[i].gd$email[0].address !== 'undefined'){
						    		//let name = data.feed.entry[i].title.$t;
						    		let email = data.feed.entry[i].gd$email[0].address;
									//console.log("data"+i+"="+email);
									/*if((data.feed.entry.length - 1) == i){
										allEmails += email;
									} else {
										allEmails += email+',';
									}*/
									//this.emails.push({"email":email,"checked":true});
									this.emails.push({"id":email,"itemName":email});
								}
							}
						}
						let tmpemailjson = JSON.stringify(this.emails);
						localStorage.setItem("socialMediaEmailContact", tmpemailjson);
						//this.emails = allEmails;
						//$("#emailContacts").val(allEmails);
						//$("#emailContacts").focus();
					}
			    }
			});
	    });
	} 

	signInWithYahoo() : void {
		
                let url = 'https://demo.penderie.com/api/yahoocontact';

                let strWindowFeatures = "location=yes,scrollbars=yes,status=yes";
                let yahoo_win = window.open(url, "_blank", strWindowFeatures);
                //yahoo_win.onunload = function(){
                    //localStorage.setItem('yahooContact','Yes');
                //};
                let timer = setInterval(function() { 
                    if(yahoo_win.closed) {
                        clearInterval(timer);
                        localStorage.setItem('yahooContact','Yes');
                    }
                }, 1000);
	}
        
	signInWithOutlook(): void {

            let client_id = 'c536f1b0-2a78-4fb8-b6ae-9ae982b14b89';
            let client_secret = 'ulmROI655_*qdqjTNYP35#!';
            let redirect_uri = 'https://demo.penderie.com/api/hotmailcontact/oauth-hotmail.php';
            let urls = 'https://login.live.com/oauth20_authorize.srf?client_id='+client_id+'&scope=wl.signin wl.basic wl.emails wl.contacts_emails&response_type=code&redirect_uri='+redirect_uri;
            
            let strWindowFeatures = "location=yes,scrollbars=yes,status=yes";
            let win = window.open(urls, "_blank", strWindowFeatures);
            win.onunload = function(){ 
                localStorage.setItem('outlookContact','Yes');
            };
	}
        getSocialContact(socialmedia:number){
            this.dbserv.get("get-tmp-socialmedia-contacts/"+socialmedia).subscribe(res => {											  
                    if(res.type == "success"){
                        let contactData = JSON.parse(res.data);
                        if(contactData.length > 0){
                            this.tagslist = contactData; 
                        } else {
                            this.tagslist = [];
                            this._alert.create('error',"You have no any contact!");
                        }
                    } else {
                        this._alert.create('error',res.message);
                    }
            });
        }
	ngOnDestroy() {
	  	this.destroy$.next(true);
	  	// Now let's also unsubscribe from the subject itself:
    	this.destroy$.unsubscribe();
	}

	onItemSelect(item:any){
        console.log(item);
        console.log(this.tags);
    }
    OnItemDeSelect(item:any){
        console.log(item);
        console.log(this.tags);
    }
    onSelectAll(items: any){
        console.log(this.tags);
    }
    onDeSelectAll(items: any){
        console.log(this.tags);
    }
    //Ajay Parmar
    sendEmails(items: any)
	{
                this.loading = true;
		let data_arr = [];
		let email_message = this.email_message;
		let tagsObj = this.tags;
		
		for (let prop of tagsObj) 
		{
			let  emailId = JSON.stringify(prop.id);
			let json_data = {email:emailId, message:email_message};
		    data_arr.push(json_data);
		}
		if(this.emailContacts != '' && this.emailContacts != null)
		    {
		    let emailc = this.emailContacts.split(/,| /);
		      for (let prop of emailc) 
		        {
		            if(prop != ''){
		                let json_data = {email:prop, message:email_message};
		                data_arr.push(json_data);
		            }
		        }
		    }

//		data_arr = data_arr.concat();
		this.dbserv.sendEmailMulti("send-email-multiple",data_arr).subscribe(res => {
			this.loading = false;
                        if(res.type=="success")
			{
				this._alert.create(res.type,res.message);
                                this.tags = [];
                                this.tagslist = [];
                                this.email_message = "";
			}
			else if(res.type=="expired")
			{
				this.router.navigateByUrl('/login') ;	
			}
			else
				this._alert.create(res.type,res.message);
		});
	}
}
