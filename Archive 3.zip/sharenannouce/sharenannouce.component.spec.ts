import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SharenannouceComponent } from './sharenannouce.component';

describe('SharenannouceComponent', () => {
  let component: SharenannouceComponent;
  let fixture: ComponentFixture<SharenannouceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SharenannouceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SharenannouceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
