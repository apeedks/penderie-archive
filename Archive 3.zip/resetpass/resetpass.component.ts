import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';

@Component({
  selector: 'app-resetpass',
  templateUrl: './resetpass.component.html',
  styleUrls: ['./resetpass.component.css']
})
export class ResetpassComponent implements OnInit {
	options:any;
  loading:boolean=false;
  valid = 0;
  successMsg='';
  errorMsg='';

	constructor(private route: ActivatedRoute,
        private router: Router,private _alert: AlertsService,private dbserv:DbserviceService) { }
	
	ngOnInit() {
		this.route.params.subscribe(params => {
		    this.model.secretkey = params['resettoken']; // (+) converts string 'id' to a number
		});
	}
	
	model = {password: '',confirmpassword: '',secretkey: ''};

	resetpassword()
	{
        if(this.model.password == this.model.confirmpassword)
        {
            this.dbserv.save("reset-member-password",this.model)
            .subscribe(res => {
              if (res.type == "success")
              {
                this._alert.create(res.type,res.message);
                this.successMsg = res.message;
                this.model = {password: '',confirmpassword:'',secretkey: ''};
                this.errorMsg = '';
                setTimeout(()=>{
                  this.router.navigate(['/login']);
                },3000);
              }else {
                // if(res.message == "Invalid Data"){
                  for(let data in res.data){
                    if(data == 'secretkey'){
                      this._alert.create(res.type,'Expire token.');
                    }else{
                      this._alert.create(res.type,res.data[data]);
                    }
                  }
                  this.errorMsg = res.message;
                  this.successMsg = '';
                // }
              }
            }); 
        }
	}
}
