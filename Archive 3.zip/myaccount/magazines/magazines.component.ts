import { Component, OnInit, ElementRef, ViewChild} from '@angular/core';
import {DbserviceService} from '../services/dbservice.service';
import { AuthenticationService } from '../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';
import * as _ from 'lodash';

@Component({
  selector: 'app-magazines',
  templateUrl: './magazines.component.html',
  styleUrls: ['./magazines.component.css']
})
export class MagazinesComponent implements OnInit {
	@ViewChild('lnktimelinesharebox') lnktimelinesharebox:ElementRef;
	visiblefilter = false;
	loaded:boolean = false;
	loggedin="No";
	categories: any;
	loading = false;
	loading2 = false;
	category:any = '';
  	categorytitle:any = '';
	custo_filter_onen_close = false;
	visittype = '';
	theme:string = '';
	thetrueluxury:any;
	finematerial:any;
	superiorcraftsmanship:any;
	magazineslist:any;
	artofstyling:any;
	balancedliving:any;
	thetrueluxury1:any;
    finematerial1:any;
    superiorcraftsmanship1:any;
    artofstyling1:any;
    balancedliving1:any;
	filters:any = {thetrueluxury:[],finematerial:[],superiorcraftsmanship:[],artofstyling:[],balancedliving:[]};
	filters1:any = {thetrueluxury:[],finematerial:[],superiorcraftsmanship:[],artofstyling:[],balancedliving:[]};
	mysummary = {Published:0, Uploaded:0,Trash:0,Draft:0,Workinprogress:0,Total:0};
	params = {sortfield:'latest', searchfield:'', filtercat:[],tag:''};
	paramssave = {sortfield:'latest', searchfield:'', filtercat:[],tag:''};
	userid = 0;
	mytotalitems: any;
	mylastpage: number = 1;
	mypage: number = 1;
	mylimit:number = 12;
	//params:any = {sortfield:'',searchfield:'',themefield:'All'};
	genderfilter = 'Both';
	myitems = [];
	websiteroot = '';
	savedtotalitems: any;
	savedlastpage: number = 1;
	savedpage: number = 1;
	savedlimit:number = 12;
	saveditems = [];
	
	rootpath = '';
	options:any;
	currtime:any;
	
	mysharedstoryid: number =1;
	mysharedtype = 'Magazine';
	mysharedurl = '';
	mysharedescription = '';
	mysharedtitle = '';
	mysharedimage = '';
	constructor(private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private cookieService: CookieService) {
		this.rootpath = localStorage.getItem('baseurl');
		this.websiteroot = localStorage.getItem('basewebsiteurl');
		this.visittype = localStorage.getItem('visittype');
	}
	
	ngOnInit() {
		this.loadddl();
		if(this.authserv.isloggedin())
		{
			this.authserv.session().subscribe(res => {
							if(res.isnew=='Yes')
								this.router.navigate(['/home']);
						});
			this.loadmyrecs(this.mypage); 
		}

		$(".custo-filter-colap").click(function(e){
            if(!$(this).hasClass('custo_filter_onen_close')){
                $(".utl-filter-box").addClass('visiblefilter');
                $(".custo-filter-colap").addClass('custo_filter_onen_close');
                e.stopPropagation();
            }else{
                $(".utl-filter-box").removeClass('visiblefilter');
                $(".custo-filter-colap").removeClass('custo_filter_onen_close');
                e.stopPropagation();
            }
        });

        $(".utl-filter-box").click(function(e){
            e.stopPropagation();
        });

        $(document).click(function(){
            $(".utl-filter-box").removeClass('visiblefilter');
            $(".custo-filter-colap").removeClass('custo_filter_onen_close');
            // self.filterby();
        });

		if (this.authserv.isloggedin()) {
			this.loggedin = "Yes";
		}

		
	}
	/*setlimit(type,limit)
	{
		this.mylimit = limit;
		if(type=="my")
		{
			this.myitems = [];
			this.loadmyrecs(1);
		}
		else
		{
			this.saveditems = [];
			this.loadsavedrecs(1);	
		}
	}*/
/*	sortswitch(type)
	{
		if(type=="my")
		{
			this.myitems = [];
			this.loadmyrecs(1);
		}
		else
		{
			this.saveditems = [];
			this.loadsavedrecs(1);	
		}
	}*/
	themefilterwitch(type)
	{
		if(type=="my")
		{
			this.myitems = [];
			this.loadmyrecs(1);
		}
		else
		{
			this.saveditems = [];
			this.loadsavedrecs(1);	
		}
	}
    throttle = (250 * 3);
    scrollDistance = 1;
    scrollUpDistance = 2;
    onScrollDownMyRecs() {
        //console.log("my");
        if(this.mytotalitems>this.myitems.length){
            this.mypage++;
            this.loadmyrecs(this.mypage);
        }
    }
	loadmyrecs(page:number)
	{
		if(page == 1)
			this.myitems = [];
		this.currtime = Math.random();
		this.loading = true;
		let cararray = [];
		this.filters.thetrueluxury.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.filters.finematerial.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.filters.superiorcraftsmanship.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.filters.artofstyling.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.filters.balancedliving.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.params.filtercat = cararray;
		/*this.params.searchfield = this.searchfield;*/
		this.currtime = Math.random();
		this.dbserv.post("mymagazines/"+this.genderfilter+"/"+page+"/"+this.mylimit,this.params).subscribe(res => {
																					if(res.type=="success")
																					{
																						this.myitems = [ ...this.myitems, ...res.records.data]
																						this.mypage = res.records.current_page;
																						this.mylastpage = res.records.last_page; 
																						this.mytotalitems = res.records.total;
																						this.loaded = true;
			this.dbserv.post("mymagazinesummary/"+this.genderfilter+"/"+page+"/"+this.mylimit,this.params)
					.subscribe(res => {
						if(res.type=="success"){
							this.mysummary = res.records;
						}
					});
																					}
																					else if(res.type=="expired")
																					{
																						this.router.navigateByUrl('/login') ;	
																					}
																					else
																						this._alert.create(res.type,res.message); 
																					    this.loading = false; 	   
																		}); 
	}
	loadsavedrecs(page:number)
	{
		if(page == 1)
			this.saveditems = [];
		this.currtime = Math.random();
		this.loading2 = true;
		let cararray1 = [];
		this.filters1.thetrueluxury.forEach(obj=>{
			if(obj.checked)
				cararray1.push(obj.id);
		})
		this.filters1.finematerial.forEach(obj=>{
			if(obj.checked)
				cararray1.push(obj.id);
		})
		this.filters1.superiorcraftsmanship.forEach(obj=>{
			if(obj.checked)
				cararray1.push(obj.id);
		})
		this.filters1.artofstyling.forEach(obj=>{
			if(obj.checked)
				cararray1.push(obj.id);
		})
		this.filters1.balancedliving.forEach(obj=>{
			if(obj.checked)
				cararray1.push(obj.id);
		})
		
		this.paramssave.filtercat = cararray1;
		this.currtime = Math.random();
		this.dbserv.post("savedmagazines/"+this.genderfilter+"/"+page+"/"+this.savedlimit,this.paramssave).subscribe(res => {
																					if(res.type=="success")
																					{
																						this.saveditems = [ ...this.saveditems, ...res.records.data]
																						this.savedpage = res.records.current_page;
																						this.savedlastpage = res.records.last_page; 
																						this.savedtotalitems = res.records.total;
																						this.loaded = true;
																					}
																					else if(res.type=="expired")
																					{
																						this.router.navigateByUrl('/login') ;	
																					}
																					else
																						this._alert.create(res.type,res.message); 
																					    this.loading2 = false;
																		}); 
	}
	deleterecord(id)
	{
		if(confirm('Are you sure?'))
		{
			this.dbserv.delete("magazinedel", id).subscribe(res => { 
																if(res.type=="success")
																{
																	this.myitems = [];
																	this.loadmyrecs(this.mypage);
																	this._alert.create(res.type,res.message);
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/admin/login') ;	
																}
																else
																	this._alert.create(res.type,res.message);
														   });
		}	
	}
	likeme(id,type,inx)
    {
        let params = {magazine_id:id,status:type};
        this.dbserv.post("magazinelike",params)
            .subscribe(res => {
                if(res.type=="success")
                {
                    if(type=="like")
                    {
                        $("#reclike" + id).css("display","none");
                        $("#recunlike" + id).css("display","block");
                    }
                    else if(type=="unlike")
                    {
                        $("#reclike" + id).css("display","block");
                        $("#recunlike" + id).css("display","none");
                    }
                    this.saveditems[inx].liked = res.total;
                }
                else if(res.type=="expired")
                {
                    this.router.navigateByUrl('/login') ;   
                }
                else
                    this._alert.create(res.type,res.message);
        });
    }
    saveme(id,type,inx)
    {
        let params = {magazine_id:id,status:type};
        this.dbserv.post("magazinemysavedlist",params).subscribe(res => {
                if(res.type=="success")
                {
                    if(type=="save")
                    {
                        $("#recsave" + id).css("display","none");
                        $("#recunsave" + id).css("display","block");
                    }
                    else if(type=="unsave")
                    {
                        $("#recsave" + id).css("display","block");
                        $("#recunsave" + id).css("display","none");
                    }
                    this.saveditems[inx].saved = res.total;
                    this.loadsavedrecs(this.savedpage);
                }
                else if(res.type=="expired")
                {
                    this.router.navigateByUrl('/login') ;   
                }
                else
                    this._alert.create(res.type,res.message);
        });
    }
	shareme(currrec)
	{
		this.currtime = Math.random();
		this.mysharedurl = this.websiteroot+"magazines/show/"+currrec.id;
		this.mysharedescription = currrec.title;
		this.mysharedtitle = currrec.shortdesc;
		this.mysharedstoryid = currrec.id;
		this.mysharedimage = this.rootpath+'assets/magazines/'+currrec.cover+'?newtime='+this.currtime;
		this.lnktimelinesharebox.nativeElement.click();
	}

	/*filterby()
	{
		this.visiblefilter = !this.visiblefilter;
		if(this.visiblefilter)
		{
			this.custo_filter_onen_close = true;
		}
		else
		{
			this.custo_filter_onen_close = false;
		}
	}*/
	    selectAll(event:any){
    	this.thetrueluxury = event.target.checked;
    	this.finematerial = event.target.checked;
    	this.superiorcraftsmanship = event.target.checked;
    	this.artofstyling = event.target.checked;
    	this.balancedliving = event.target.checked;
    	event.target.value = 'thetrueluxury';
    	this.selecfillter(event);
    	event.target.value = 'finematerial';
    	this.selecfillter(event);
    	event.target.value = 'superiorcraftsmanship';
    	this.selecfillter(event);
    	event.target.value = 'artofstyling';
    	this.selecfillter(event);
    	event.target.value = 'balancedliving';
    	this.selecfillter(event);
    	this.myitems = [];
    	this.loadmyrecs(this.mypage);
    	  }
    	 selectAll1(event:any){
    	          this.thetrueluxury1 = event.target.checked;
    	          this.finematerial1 = event.target.checked;
    	          this.superiorcraftsmanship1 = event.target.checked;
    	          this.artofstyling1 = event.target.checked;
    	          this.balancedliving1 = event.target.checked;
    	          event.target.value = 'thetrueluxury';
    	          this.selecfillter1(event);
    	          event.target.value = 'finematerial';
    	          this.selecfillter1(event);
    	          event.target.value = 'superiorcraftsmanship';
    	          this.selecfillter1(event);
    	          event.target.value = 'artofstyling';
    	          this.selecfillter1(event);
    	          event.target.value = 'balancedliving';
    	          this.selecfillter1(event);
    	        this.saveditems = [];
    	        this.loadsavedrecs(this.savedpage);
    	      }  

	    key_down(e) {
	        console.log(e);
	        if(e.target.value == '')
	        {
	            this.loadmyrecs(this.mypage); 
	        }
	            if(e.keyCode === 13) {
	                    this.filterswitch();
	        }
	    }
	    	selecfillter(event:any, id:any = ''){
		// console.log(event);
		if(id == '' || id == 0 || id == null || id == undefined){
			switch (event.target.value) {
				case "thetrueluxury":
					this.filters.thetrueluxury.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "finematerial":
					this.filters.finematerial.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "superiorcraftsmanship":
					this.filters.superiorcraftsmanship.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "artofstyling":
					this.filters.artofstyling.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "balancedliving":
					this.filters.balancedliving.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
			}
			this.myitems = [];
			this.loadmyrecs(this.mypage); 
		}
	}
		filterswitch()
	{
		this.myitems = [];
		this.loadmyrecs(this.mypage); 
	}
		sortswitch()
	{
		this.myitems = [];
		this.loadmyrecs(this.mypage); 
	}
		sortswitch1()
	{
		this.saveditems = [];
		this.loadsavedrecs(1);
	}
		selecrmethod1()
	{
		this.saveditems = [];
		this.loadsavedrecs(1);
	}
		selecfillter1(event:any, id:any = ''){
		if(id == '' || id == 0 || id == null || id == undefined){
			switch (event.target.value) {
				case "thetrueluxury":
					this.filters1.thetrueluxury.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "finematerial":
					this.filters1.finematerial.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "superiorcraftsmanship":
					this.filters1.superiorcraftsmanship.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "artofstyling":
					this.filters1.artofstyling.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "balancedliving":
					this.filters1.balancedliving.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
			}
			
			this.saveditems = [];
			this.loadsavedrecs(1);
		}
	}
	loadddl()
	{
		this.categories = [];
		this.dbserv.getAll("magazinecatlist/-/"+this.visittype).
		subscribe(res => { 
			this.categories = res;
			if(this.category != '' && this.category != null)
				this.categorytitle = this.categories.find(x=>x.id == this.category).title;
			else
				this.categorytitle = '';
		});
		this.dbserv.getAll("magazinecatlist/The True Luxury/"+this.visittype)
		.subscribe(res => { 
		    this.filters.thetrueluxury = _.cloneDeep(res);
			this.filters1.thetrueluxury = _.cloneDeep(res);
		});
		this.dbserv.getAll("magazinecatlist/Fine Material/"+this.visittype)
		.subscribe(res => { 
		    this.filters.finematerial = _.cloneDeep(res);
			this.filters1.finematerial = _.cloneDeep(res);
		});
		this.dbserv.getAll("magazinecatlist/Superior Craftsmanship/"+this.visittype)
		.subscribe(res => { 
            this.filters.superiorcraftsmanship = _.cloneDeep(res);
            this.filters1.superiorcraftsmanship = _.cloneDeep(res);
		});
		this.dbserv.getAll("magazinecatlist/Art of Styling/"+this.visittype)
		.subscribe(res => { 
            this.filters.artofstyling = _.cloneDeep(res);
            this.filters1.artofstyling = _.cloneDeep(res);
		});
		this.dbserv.getAll("magazinecatlist/Balanced Living/"+this.visittype)
		.subscribe(res => { 
            this.filters.balancedliving = _.cloneDeep(res);
            this.filters1.balancedliving = _.cloneDeep(res);
		});
	}
		selecrmethod()
	{	this.myitems = [];
		this.loadmyrecs(1);
	}
		
	    throttleSave = (250 * 3);
	    scrollSaveDistance = 1;
	    scrollUpSaveDistance = 2;
	    onScrollDownSaveRecs() {
	        if(this.savedtotalitems>this.saveditems.length){
	            this.savedpage++;
	            this.loadsavedrecs(this.savedpage);
	        }
	    }
	    datecompare(date:any)
	    {
	        let oneDay = 24*60*60*1000; // hours*minutes*seconds*milliseconds
	        let firstDate = new Date();
	        let secondDate = new Date(date);
	        return Math.round(Math.abs((firstDate.getTime() - secondDate.getTime())/(oneDay)));
	    }
	    clicktab(tab)
	    {
	        this.saveditems = [];
	        this.myitems = [];
	        $(".tabs").removeClass("active");
	        $(".tab_content").css("display","none");
	        $("#hd" + tab).addClass("active");
	        $("#" + tab).css("display","block");
	        if(tab=="my-magazines")
	            this.loadmyrecs(0); 
	        else
	            this.loadsavedrecs(0); 
	    }
	    /*switchtabs(tab)
	    {
	        switch(tab)
	        {
	            case "1":
	                this.myitems = [];
	                this.loadmyrecs(this.mypage);
	                break;
	            case "2":
	                this.saveditems = [];
	                this.loadsavedrecs(this.savedpage);
	                break;
	        }
            $(".tabs").removeClass("active");
            $(".tab_content").css("display","none");
            $("#hd" + tab).addClass("active");
            $("#" + tab).css("display","block");
	    }*/
}
