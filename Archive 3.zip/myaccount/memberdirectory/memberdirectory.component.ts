import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../services/dbservice.service';
import { AuthenticationService } from '../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
@Component({
  selector: 'app-memberdirectory',
  templateUrl: './memberdirectory.component.html',
  styleUrls: ['./memberdirectory.component.css']
})
export class MemberdirectoryComponent implements OnInit {
	model = {country:"",state:"",city:"",zipcode:"",miles:"",firstname:"",lastname:"",occupation:"",text:"",sprtby:""};
	fmodel = {touser:0,fromuser:0};
	options:any;
	pageSize: number;
	totalitems: any;
	page: number = 1;
	limit:number = 12;
	params:any = {};
	public items:any;
	
	countrylist:any;
	statelist:any;
	citylist:any;
	userid:number;
	
	constructor(private dbserv:DbserviceService,private _alert: AlertsService,private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router) {}
	
	ngOnInit() {
		if(this.authserv.isloggedin())
		{
			this.authserv.session().subscribe(res => {
							if(res.isnew=='Yes')
								this.router.navigate(['/home']);
						});
			this.loadpage(this.page);
			this.dbserv.getAll("countries").subscribe(res => {this.countrylist = res;});
		}
	}
	pageChanged($event)
	{
	  this.loadpage($event) ; 
	}
	loadpage(pageno:number)
	{
		this.dbserv.post("memdirectory/"+pageno+"/"+this.limit,this.model).subscribe(res => {this.items = res.data; this.page = res.current_page; this.totalitems = res.total;this.pageSize = res.per_page;}); 
	}
	changelimit(lmt:number)
	{
		this.limit = lmt;
		this.page = 1;
		this.loadpage(this.page)
	}
	followthisguys(user:number)
	{
		if(this.authserv.isloggedin())
		{
			this.fmodel.fromuser = +this.authserv.getUserId();
			this.fmodel.touser = +user;
			this.dbserv.save("followuser",this.fmodel).subscribe(res => {
														   this._alert.create(res.type,res.message);
														 });
		}
	}
	makeconnection(user:number)
	{
		if(this.authserv.isloggedin())
		{
			this.fmodel.fromuser = +user;
			this.fmodel.touser = +this.authserv.getUserId();
			this.dbserv.save("makeconnection",this.fmodel).subscribe(res => {
														   this._alert.create(res.type,res.message);
														 });
		}
	}
	states()
	{
		this.dbserv.getAll("states/" + this.model.country).subscribe(res => {this.statelist = res;});
	}
	cities()
	{
		this.dbserv.getAll("cities/" + this.model.country + "/" + this.model.state).subscribe(res => {this.citylist = res;});
	}
}
