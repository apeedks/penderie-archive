import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userpublicprefs',
  templateUrl: './userpublicprefs.component.html',
  styleUrls: ['./userpublicprefs.component.css']
})
export class UserpublicprefsComponent implements OnInit {
	options:any;
	constructor() { }
	
	ngOnInit() {
	}

}
