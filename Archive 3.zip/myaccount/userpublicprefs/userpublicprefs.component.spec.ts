import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserpublicprefsComponent } from './userpublicprefs.component';

describe('UserpublicprefsComponent', () => {
  let component: UserpublicprefsComponent;
  let fixture: ComponentFixture<UserpublicprefsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserpublicprefsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserpublicprefsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
