import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule}    from '@angular/forms';
import {HttpModule} from '@angular/http';
import { CKEditorModule } from 'ng2-ckeditor';
import {CookieService} from 'ngx-cookie-service';
import {MyaccountAuthGuard} from './myaccount.auth.guard';
import {AppRoutingModule} from './routing.module';
import { AboutComponent } from './about/about.component';
import {PasswordComponent } from './password/password.component';
import {AuthenticationService } from './services/authentication.service';
import {DbserviceService } from './services/dbservice.service';
import {JasperoAlertsModule } from '@jaspero/ng2-alerts';
import {InnerheaderComponent } from './nav/innerheader.component';
import {InnerfooterComponent } from './nav/innerfooter.component';
import {PrimarynavComponent } from './nav/primarynav.component';
import {HttpClientModule, HttpClientJsonpModule } from '@angular/common/http';
import {ShareButtonsModule} from 'ngx-sharebuttons';
import { ActivityComponent } from './activity/activity.component';
import { PreferenceComponent } from './preference/preference.component';
import { MailboxComponent } from './mailbox/mailbox.component';
import { SettingsComponent } from './settings/settings.component';
import { NetworkComponent } from './network/network.component';
import { MemberdirectoryComponent } from './memberdirectory/memberdirectory.component';
import { OrgdirectoryComponent } from './orgdirectory/orgdirectory.component';
import { TimelineComponent } from './timeline/timeline.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { UserpublicprefsComponent } from './userpublicprefs/userpublicprefs.component';
import { BookmarkComponent } from './bookmark/bookmark.component';
import { FotodiaryAlbumsComponent } from './fotodiary-albums/fotodiary-albums.component';
import { FotodiaryMediaComponent } from './fotodiary-media/fotodiary-media.component';
import { MemguestbookComponent } from './memguestbook/memguestbook.component';
import { PubguestbookComponent } from './pubguestbook/pubguestbook.component';
import { EducationsComponent } from './widgets/educations/educations.component';
import { AffilationsComponent } from './widgets/affilations/affilations.component';
import { MomentsComponent } from './widgets/moments/moments.component';
import { ProfessionsComponent } from './widgets/professions/professions.component';
import { AspirationsComponent } from './widgets/aspirations/aspirations.component';
import { FmailynpetsComponent } from './widgets/fmailynpets/fmailynpets.component';
import { AwardsComponent } from './widgets/awards/awards.component';
import { HobbiesComponent } from './widgets/hobbies/hobbies.component';
import { PlaceComponent } from './widgets/place/place.component';
import { LanguageComponent } from './widgets/language/language.component';
import {NgxPaginationModule} from 'ngx-pagination';
import { TimelinelistComponent } from './bookmark/timelinelist/timelinelist.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { StoriesComponent } from './stories/stories.component';
import { StoryComponent } from './stories/story/story.component';
import { ReviewComponent } from './loupe/review/review.component';
import { ReviewProductComponent } from './loupe/review/reviewproduct.component';
import { LoupeComponent } from './loupe/loupe.component';
import { SecurehtmlPipe } from './securehtml.pipe';
import { SecureurlPipe } from './secureurl.pipe';
import {TooltipModule} from "ngx-tooltip";
import { ColorPickerModule } from 'ngx-color-picker';
import { LoupemarkersComponent } from './loupe/loupemarkers/loupemarkers.component';
import { MyDatePickerModule } from 'mydatepicker';
import { ImageCropperModule } from 'ng2-img-cropper';
import { QuoteComponent } from './quote/quote.component';
import { ShareboxComponent } from './sharebox/sharebox.component';
import { limitToPipe } from './pipe/limit.pipe';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import { MagazinesComponent } from './magazines/magazines.component';
import { EmojiPickerModule } from 'angular2-emoji-picker';
import { CkEditorComponent } from './ckeditor.component';
import { UniquePipe } from './unique.pipe';
import { Unique1Pipe } from './unique1.pipe';
import { InfiniteScrollModule } from 'angular2-infinite-scroll';
import { IconFilterComponent } from './iconfilter.component';

@NgModule({
  imports: [
    BrowserModule,
	FormsModule,
	HttpModule,
	CommonModule,
	CKEditorModule,
	AppRoutingModule,
	JasperoAlertsModule,
	NgxPaginationModule,
	ColorPickerModule,
	AngularMultiSelectModule,
	TooltipModule,
	ImageCropperModule,
	MyDatePickerModule,
	HttpClientModule,             // (Required) for share counts
    HttpClientJsonpModule,        // (Optional) for linkedIn and tumblr share counts
    ShareButtonsModule.forRoot(),
    EmojiPickerModule.forRoot(),
    InfiniteScrollModule,
  ],
  declarations: [
	AboutComponent,
	PasswordComponent,
	InnerheaderComponent, 
	PrimarynavComponent,
	InnerfooterComponent,
	ActivityComponent,
	PreferenceComponent,
	MailboxComponent,
	/*ImgMapComponent,*/
	SettingsComponent,
	NetworkComponent,
	MemberdirectoryComponent,
	OrgdirectoryComponent,
	TimelineComponent,
	UserprofileComponent, 
	UserpublicprefsComponent, 
	BookmarkComponent, 
	FotodiaryAlbumsComponent, 
	FotodiaryMediaComponent, 
	MemguestbookComponent, 
	PubguestbookComponent, 
	EducationsComponent, 
	AffilationsComponent, 
	MomentsComponent, 
	ProfessionsComponent, 
	AspirationsComponent, 
	FmailynpetsComponent, 
	AwardsComponent, 
	HobbiesComponent,
	PlaceComponent,
	LanguageComponent,
	ShareboxComponent,
	TimelinelistComponent, 
	ReviewComponent,
	ReviewProductComponent,
	NotificationsComponent, StoriesComponent, StoryComponent, LoupeComponent,SecurehtmlPipe,SecureurlPipe, LoupemarkersComponent, QuoteComponent, MagazinesComponent,
	limitToPipe, CkEditorComponent,	UniquePipe,
	Unique1Pipe,
	IconFilterComponent,
  ],
  providers: [MyaccountAuthGuard, AuthenticationService, DbserviceService,CookieService],
})
export class MyaccountModule { }
