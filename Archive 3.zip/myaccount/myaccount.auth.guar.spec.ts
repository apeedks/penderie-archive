import { TestBed, async, inject } from '@angular/core/testing';

import { MyaccountAuthGuard } from './myaccount.auth.guard';

describe('MyaccountAuthGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MyaccountAuthGuard]
    });
  });

  it('should ...', inject([MyaccountAuthGuard], (guard: MyaccountAuthGuard) => {
    expect(guard).toBeTruthy();
  }));
});
