import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import { AuthenticationService } from '../../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
@Component({
  selector: 'app-timelinelist',
  templateUrl: './timelinelist.component.html',
  styleUrls: ['./timelinelist.component.css']
})
export class TimelinelistComponent implements OnInit {
	model = {};
	options:any;
	pageSize: number;
	totalitems: any;
	page: number = 1;
	limit:number = 12;
	params:any = {};
	public items:any;
	constructor(private dbserv:DbserviceService,private _alert: AlertsService,private route: ActivatedRoute,private authserv: AuthenticationService) {}
	ngOnInit() {
		this.loadpage(this.page)
	}
	loadpage(pageno:number)
	{
		this.dbserv.post("membookmark/Timeline/"+pageno+"/"+this.limit,this.model).subscribe(res => {this.items = res.data; this.page = res.current_page; this.totalitems = res.total;this.pageSize = res.per_page;}); 
	}
}
