import { Component, OnInit } from '@angular/core';
import {DbserviceService} from '../services/dbservice.service';
import { AuthenticationService } from '../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';
@Component({
  selector: 'app-activity',
  templateUrl: './activity.component.html',
  styleUrls: ['./activity.component.css']
})
export class ActivityComponent implements OnInit {
	wasClicked:boolean = false;
	custo_filter_onen_close = false;
	visiblefilter = false;
	options:any;
	lastpage: number;
	totalitems: any;
	page: number = 1;
	limit:number = 3;
	items = [];
	oldid : any;
	params:any = {};
	userid = 0;
	monthText:string = '';
	yearText:number = 0;
	yearArray=[];
	sortfield:any='latest';
	constructor(private authserv: AuthenticationService,private _alert: AlertsService,private dbserv:DbserviceService,private router: Router,private cookieService: CookieService)  {

	}
	ngOnInit() {
	    scroll(0,0);
		let today = new Date();
		let year = today.getFullYear();
		for (var i = 2015; i <= year; i++) {
			this.yearArray.push(i);
		}
		this.yearArray = this.yearArray.reverse();
		if(this.authserv.isloggedin())
		{
			this.authserv.session().subscribe(res => {
							if(res.isnew=='Yes')
								this.router.navigate(['/home']);
						});

			this.userid = +this.authserv.getUserId();
			this.loadrecs(this.page);
		}
	}
	ngAfterViewInit(){
		// $('html, body').animate({
  //       	scrollTop: $("#collapseExample").offset().top - 70
  //   	});
	}
	showmorerecs()
	{
		this.page = this.page + 1;
		this.dbserv.post("memactivity/"+this.page+"/"+this.limit,this.params).subscribe(res => {
																										   this.items = [ ...this.items, ...res.records.data];
																										   this.page = res.records.current_page;
																										   this.lastpage = res.records.last_page;
																										   this.totalitems = res.records.total;
																										});
	}
	viewmore(event,idx)
	{
		console.log(event.target.text);
		$(".viewmorelist").css("display","none");
		if(this.oldid!=idx){
			$("#viewmore"+idx).css("display","block");
			this.oldid = idx;
			event.target.text = 'View Less';
		}
		else{
			this.oldid = -1;
			event.target.text = 'View More';
		}
	}
	filterby()
	{
		this.wasClicked = !this.wasClicked;
		if(this.wasClicked)
		{
			this.custo_filter_onen_close = true;
			this.visiblefilter = true;

		}
		else
		{
			this.custo_filter_onen_close = false;
			this.visiblefilter = false;
		}

	}
	loadrecs(page)
	{
		this.page = page;
		this.params = {
			year:this.yearText,
			month:(this.monthShorNames.indexOf(this.monthText) + 1)
		};
		this.params.sortfield = this.sortfield;
		/*this.params.searchfield = this.searchfield;*/
		this.dbserv.post("memactivity/"+this.page+"/"+this.limit,this.params)
		.subscribe(res => {
			if(this.page == 1)
				this.items = [];
			if(res.records.total>this.items.length)
				this.items = [ ...this.items, ...res.records.data]
			// this.items = res.records.data;
			this.page = res.records.current_page;
			this.lastpage = res.records.last_page;
			this.totalitems = res.records.total;
		});
	}
	monthNames = [
		"January", "February", "March",
		"April", "May", "June",
		"July", "August", "September",
		"October", "November", "December"
	];
	monthShorNames = [
		"Jan", "Feb", "Mar","Apr", "May", "Jun",
		"Jul", "Aug", "Sep","Oct", "Nov", "Dec"
	];

	getMonthName(date) {
		return this.monthNames[date.getMonth()];
	}
	getShortMonthName(date) {
		return this.getMonthName(date).substr(0, 3);
	};
	throttle = 380;
  scrollDistance = 1;
  scrollUpDistance = 2;
	onScrollDown() {
		if(this.totalitems>this.items.length){
			this.page++
			this.loadrecs(this.page);
		}
  }
}
