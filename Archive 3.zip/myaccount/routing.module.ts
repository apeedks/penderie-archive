import { RouterModule, Routes } from '@angular/router'; 
import { NgModule } from '@angular/core';
import {MyaccountAuthGuard} from './myaccount.auth.guard';
import { AboutComponent } from './about/about.component';
import { PasswordComponent } from './password/password.component';
import { ActivityComponent } from './activity/activity.component';
import { PreferenceComponent } from './preference/preference.component';
import { MailboxComponent } from './mailbox/mailbox.component';
import { SettingsComponent } from './settings/settings.component';
import { NetworkComponent } from './network/network.component';
import { MemberdirectoryComponent } from './memberdirectory/memberdirectory.component';
import { OrgdirectoryComponent } from './orgdirectory/orgdirectory.component';
import { TimelineComponent } from './timeline/timeline.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { UserpublicprefsComponent } from './userpublicprefs/userpublicprefs.component';
import { BookmarkComponent } from './bookmark/bookmark.component';
import { FotodiaryAlbumsComponent } from './fotodiary-albums/fotodiary-albums.component';
import { FotodiaryMediaComponent } from './fotodiary-media/fotodiary-media.component';
import { MemguestbookComponent } from './memguestbook/memguestbook.component';
import { PubguestbookComponent } from './pubguestbook/pubguestbook.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { StoriesComponent } from './stories/stories.component';
import { ReviewComponent } from './loupe/review/review.component';
import { ReviewProductComponent } from './loupe/review/reviewproduct.component';
import { LoupeComponent } from './loupe/loupe.component';
import { MagazinesComponent } from './magazines/magazines.component';

const routes: Routes = [  
	{path: 'myaccount', pathMatch: 'full', component: ActivityComponent,canActivate: [MyaccountAuthGuard] },
	{path: 'myaccount/activity', pathMatch: 'full', component: ActivityComponent,canActivate: [MyaccountAuthGuard] },
	{path: 'myaccount/dashboard', component: ActivityComponent,canActivate: [MyaccountAuthGuard] },
	{path: 'myaccount/loupe', component: LoupeComponent,canActivate: [MyaccountAuthGuard] },
	{path: 'myaccount/loupe/review',component: ReviewComponent,canActivate: [MyaccountAuthGuard]},
	{path: 'myaccount/loupe/reviewproduct',component: ReviewProductComponent,canActivate: [MyaccountAuthGuard]},
	{path: 'myaccount/loupe/review/:id',component: ReviewComponent,canActivate: [MyaccountAuthGuard]},
    {path: 'myaccount/password',component: PasswordComponent,canActivate: [MyaccountAuthGuard]},
	{path: 'myaccount/about',component: AboutComponent,canActivate: [MyaccountAuthGuard]},
	{path: 'myaccount/preference',component: PreferenceComponent,canActivate: [MyaccountAuthGuard]},
	{path: 'myaccount/mailbox',component: MailboxComponent,canActivate: [MyaccountAuthGuard]},
	{path: 'myaccount/settings',component: SettingsComponent,canActivate: [MyaccountAuthGuard]},
	{path: 'myaccount/network',component: NetworkComponent,canActivate: [MyaccountAuthGuard]},
	{path: 'myaccount/network/:type',component: NetworkComponent,canActivate: [MyaccountAuthGuard]},
	{path: 'myaccount/memberdirectory',component: MemberdirectoryComponent,canActivate: [MyaccountAuthGuard]},
	{path: 'myaccount/organizationdirectory',component: OrgdirectoryComponent,canActivate: [MyaccountAuthGuard]},
	{path: 'myaccount/timeline',component: TimelineComponent,canActivate: [MyaccountAuthGuard]},
	{path: 'myaccount/timeline/:timelineid',component: TimelineComponent,canActivate: [MyaccountAuthGuard]},
	{path: 'myaccount/bookmark',component: BookmarkComponent,canActivate: [MyaccountAuthGuard]},
	{path: 'myaccount/albums',component: FotodiaryAlbumsComponent,canActivate: [MyaccountAuthGuard]},
	{path: 'myaccount/media',component: FotodiaryMediaComponent,canActivate: [MyaccountAuthGuard]},
	{path: 'myaccount/guestbook',component: MemguestbookComponent,canActivate: [MyaccountAuthGuard]},
	{path: 'mprofile/:username', pathMatch: 'full', component: UserprofileComponent },
	{path: 'publicprefs', pathMatch: 'full', component: UserpublicprefsComponent },
	{path: 'publicguestbook', pathMatch: 'full', component: PubguestbookComponent },
	{path: 'myaccount/notifications', component: NotificationsComponent,canActivate: [MyaccountAuthGuard] },
	{path: 'myaccount/stories', component: StoriesComponent,canActivate: [MyaccountAuthGuard] },
/*	{path: 'myaccount/poststory', component: StoryComponent,canActivate: [MyaccountAuthGuard] },
	{path: 'myaccount/editstory/:id',component: StoryComponent,canActivate: [MyaccountAuthGuard]},
*/	{path: 'myaccount/magazines', component: MagazinesComponent,canActivate: [MyaccountAuthGuard] },
	
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports:[
	RouterModule	   
  ],
  declarations: [],
  bootstrap: [ActivityComponent],

})
export class AppRoutingModule { }
