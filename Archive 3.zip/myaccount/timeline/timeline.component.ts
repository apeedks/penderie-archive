import { Component, OnInit, trigger, state, style, transition, animate, ElementRef, ViewChild } from '@angular/core';
import { DatePipe } from '@angular/common';
import {DbserviceService} from '../services/dbservice.service';
import { AuthenticationService } from '../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.css']
})
export class TimelineComponent implements OnInit {
	@ViewChild('openviewModal') openModal:ElementRef;
	@ViewChild('postmodalcancel') postmodalcancel:ElementRef;
	wasClicked:boolean = false;
	currentmenu:number = 0;
	tooltipshow = false;
	tooltipiconactive = false;
	modelview = {id:'',content:'',userid:0,type:'Post',permit:'Private',recordfromid:0,sharedfromid:0,username:'',dateadded:'',hasliked:'',likes:'',comments:[],name:'',image:'',durationhour:0,durationdays:0,durationmonth:0};
	modeledit = {id:'',content:'',userid:0,type:'Post',permit:'Private',recordfromid:0,sharedfromid:0,dateadded:''};
	model = {};
	timelineid = '';
	userid = 0;
	userimage = '';
	modelcomment = {comment:"",timeline_id:""};
	showeditloadingmodal:boolean=true;
	showviewloadingmodal:boolean=true;
	rootpath = '';
	options:any;
	currtime:any;
	pageSize: number;
	totalitems:number;
	last_page:number = 1;
	page: number = 1;
	limit:number = 5;
	public items = [];
	
	emotics:any;
	postcontent = "";
	emoticselected = "";
	constructor(private authserv: AuthenticationService,private _alert: AlertsService,private route: ActivatedRoute,private dbserv:DbserviceService,private router: Router,private cookieService: CookieService) 
	{ 
		this.currtime = Math.random();
		this.rootpath = localStorage.getItem('baseurl');
		if(this.authserv.isloggedin())
		{
			this.userid = +this.authserv.getUserId();
			this.userimage = this.authserv.getUserImage();
			this.loadpage(this.page);
		}
		else
			this.router.navigate(["/login"]);
	}
	loadpage(pageno:number)
	{
		this.currtime = Math.random();
		if(this.authserv.isloggedin())
		{
			this.authserv.session().subscribe(res => {
							if(res.isnew=='Yes')
								this.router.navigate(['/home']);
						});
			this.dbserv.post("mytimeline/" + pageno+"/"+this.limit,this.model).subscribe(res => {
																					this.items = [ ...this.items, ...res.reclist.data]
																					this.page = res.reclist.current_page; 
																					this.totalitems = res.reclist.total;
																					this.pageSize = res.reclist.per_page;
																					this.last_page = res.reclist.last_page;
																			}); 
		}
		
	}
	ngOnInit() {
	    scroll(0,0);
		//timelineid
		this.route.params.subscribe(params => {
		    this.timelineid = params['timelineid']; // (+) converts string 'id' to a number
			if(this.timelineid!='' && this.timelineid)
			{
				this.viewpost(this.timelineid);
				this.openModal.nativeElement.click();
				 alert(this.timelineid);
			}
		});
		this.dbserv.get("emotics/Timeline").subscribe(res => {this.emotics = res;});
	}
	tooltip()
	{
		this.wasClicked = !this.wasClicked;
		if(this.wasClicked)
		{
			this.tooltipshow = true;
			this.tooltipiconactive = true;
		}
		else
		{
			this.tooltipshow = false;
			this.tooltipiconactive = false;

		}

	}
	savepost()
	{
		let model = {emotic:this.emoticselected,content:this.postcontent};
		this.dbserv.post("mytimelinepost",model).subscribe(res => {
																if(res.type=="success")
																{
																	this.loadpage(1);
																	this.postcontent = '';
																	this.emoticselected = '';
																	this.postmodalcancel.nativeElement.click();
																}
														   }); 

	}
	viewpost(timeline)
	{
		this.showviewloadingmodal = true;
		this.currtime = Math.random();
		this.dbserv.getById("mytimelinebyidview",timeline).subscribe(res => {
																			//this._alert.create(res.type,res.message);
																		   if(res.type=="success")
																		   {
																				this.showviewloadingmodal = false;
																				this.modelview = res.data;
																				$('#viewmodal').modal('show');
																		   }	  
																	});
	}
	bookmarkpost(timelineid)
	{
		let commmodel = {timeline:timelineid};
		this.dbserv.save("mytimelinebookmark",commmodel).subscribe(res => {
																			this._alert.create(res.type,res.message);
																		   if(res.type=="success")
																		   {
																				this.loadpage(this.page);
																				if(this.timelineid!='' && this.timelineid)
																					this.viewpost(this.timelineid);
																		   }	  
																	});
	}
	deletecomment(commentid)
	{
		this.dbserv.delete("mytimelinedeletecomment",commentid).subscribe(res => {
																			this.loadpage(this.page);
																			if(this.timelineid!='' && this.timelineid)
																					this.viewpost(this.timelineid);
																	});
	}
	deletepost(timeline)
	{
		this.dbserv.delete("mytimelinedeletepost",timeline).subscribe(res => {
																			this.loadpage(this.page);
																			if(this.timelineid!='' && this.timelineid)
																					this.viewpost(this.timelineid);
																	});
	}
	changestatus(id,newstatus)
	{
		let statusmodel = {postid:id,status:newstatus};
		this.dbserv.save("mytimelinepoststatus",statusmodel).subscribe(res => {
																			this._alert.create(res.type,res.message);
																		   if(res.type=="success")
																		   {
																				this.loadpage(this.page);
																				if(this.timelineid!='' && this.timelineid)
																					this.viewpost(this.timelineid);
																		   }	  
																	});	
	}
	flagpost(timeline)
	{
		alert(timeline + ":flagpost");
	}
	likepost(timelineid)
	{
		this.dbserv.getById("mytimelinepostlike",timelineid).subscribe(res => {
																			this.loadpage(this.page);  
																	});
	}
	likecomment(commentid)
	{
		this.dbserv.getById("mytimelinecommentlike",commentid).subscribe(res => {
																			this.loadpage(this.page);	  
																	});
	}
	editsave()
	{
		this.dbserv.save("mytimelinesavepost",this.modeledit).subscribe(res => {
																			/*this._alert.create(res.type,res.message);*/
																		   if(res.type=="success")
																		   {
																				this.loadpage(this.page);
																		   }	  
																	});	
	}
	editpost(timeline)
	{
		this.showeditloadingmodal = true;
		this.dbserv.getById("mytimelinebyid",timeline).subscribe(res => {
																			//this._alert.create(res.type,res.message);
																		   if(res.type=="success")
																		   {
																				this.modeledit = res.data;
																				this.showeditloadingmodal = false;
																				$('#editmodal').modal('show');
																		   }	  
																	});
	}
	messagepost(timeline)
	{
		alert("This module is currently under construction");
	}
	sharepost(timeline)
	{
		this.dbserv.getById("mytimelineshare",timeline).subscribe(res => {
																		   this._alert.create(res.type,res.message);
																		   this.loadpage(this.page);
																	});
	}
	savecomment(event,timelineid)
	{
		if(event.keyCode == 13) {
			let commmodel = {timeline:timelineid,comment:event.target.value};
			this.dbserv.save("mytimelinesavecomment",commmodel).subscribe(res => {
																			/*this._alert.create(res.type,res.message);*/
																		   if(res.type=="success")
																		   {
																				this.loadpage(this.page);
																				if(this.timelineid!='' && this.timelineid)
																					this.viewpost(this.timelineid);
																		   }	  
																	});
		}
	}
	unselectcompliment()
	{
		this.emoticselected = '';	
	}
}
