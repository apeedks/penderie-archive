import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../services/dbservice.service';
import { AuthenticationService } from '../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import $ from 'jquery';
@Component({
  selector: 'app-network',
  templateUrl: './network.component.html',
  styleUrls: ['./network.component.css']
})
export class NetworkComponent implements OnInit {
	wasClicked:boolean = false;
	custo_filter_onen_close = false;
	visiblefilter = false;

	model = {sprtby:""};
	options:any;
	pageSize: number;
	totalitems: any;
	page: number = 1;
	limit:number = 12;
	params:any = {};
	public items1:any;
	public items2:any;
	public items3:any;
	public items4:any;
	currentlist:string = "connections";
	currentalphabett:string = "a";
	
	constructor(private dbserv:DbserviceService,private _alert: AlertsService,private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router) {}
	
	ngOnInit() {
		if(this.authserv.isloggedin())
		{
			this.authserv.session().subscribe(res => {
							if(res.isnew=='Yes')
								this.router.navigate(['/home']);
						});
			this.loadpage(this.page);
		}
		
		
	}
	loadpage(pageno:number)
	{
		if(this.currentlist=="connections")
			this.dbserv.post("myconnections/"+ this.currentalphabett + "/" + pageno +"/"+this.limit,this.model).subscribe(res => {this.items1 = res.data; this.page = res.current_page; this.totalitems = res.total;this.pageSize = res.per_page;}); 
		else if(this.currentlist=="following")
			this.dbserv.post("myfollowing/"+ this.currentalphabett + "/" + pageno +"/"+this.limit,this.model).subscribe(res => {this.items2 = res.data; this.page = res.current_page; this.totalitems = res.total;this.pageSize = res.per_page;}); 
		else if(this.currentlist=="followed")
			this.dbserv.post("memfollowed/"+ this.currentalphabett + "/" + pageno +"/"+this.limit,this.model).subscribe(res => {this.items3 = res.data; this.page = res.current_page; this.totalitems = res.total;this.pageSize = res.per_page;}); 
		else
		{
			
		}
	}
	pageChanged($event)
	{
	  this.loadpage($event) ; 
	}
	filterapha(alphabet:string)
	{
		this.currentalphabett = alphabet;
		$(".abc-lister-pros li").removeClass("active");
		$(".alphabet"+ alphabet).addClass("active");
		this.loadpage(this.page);
	}
	changecurrentlist(type:string)
	{
		this.currentlist = type;
		this.loadpage(this.page);
	}
	filterby()
	{
		this.wasClicked = !this.wasClicked;
		if(this.wasClicked)
		{
			this.custo_filter_onen_close = true;
			this.visiblefilter = true;
			
		}
		else
		{
			this.custo_filter_onen_close = false;	
			this.visiblefilter = false;	
		}
	
	}
}
