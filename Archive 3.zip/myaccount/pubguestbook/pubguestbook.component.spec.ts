import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PubguestbookComponent } from './pubguestbook.component';

describe('PubguestbookComponent', () => {
  let component: PubguestbookComponent;
  let fixture: ComponentFixture<PubguestbookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PubguestbookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PubguestbookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
