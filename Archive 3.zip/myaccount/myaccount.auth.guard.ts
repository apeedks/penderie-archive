import { Injectable } from '@angular/core';
import {Response} from '@angular/http';
import { Router, CanActivate, CanActivateChild, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from './services/authentication.service';
import { User } from './services/user';
@Injectable()
export class MyaccountAuthGuard implements CanActivate,CanActivateChild {
   myuser: User;
  constructor(private router: Router,private authserv: AuthenticationService) { }
  
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
	  
		return this.authserv.adminsession().map((response: Response) =>  {
            console.log(response.status);
			let user:User;
			user = response.json();
			
			if (user.usertype =='Member') {
				localStorage.setItem('user', JSON.stringify(user));
                return true;
            }
			else
			{
				return false;
			
			}
        }).catch((err: Response) => {
			
			// The err.statusText is empty if server down (err.type === 3)
			//console.log((err.statusText || "Can't join the server."));
			/// Really usefull. The app can't catch this in "(err)" closure
			//reject((err.statusText || "Can't join the server."));
			// This return is required to compile but unuseable in your app
			this.router.navigateByUrl('/login') ;
			
			return Observable.throw(false);
        });
		
		/*return this.authserv.adminsession().subscribe(response => {
					let user:User;
					user = response;
					if (user.usertype !='Admin') {
						this.router.navigateByUrl('/admin/login') ;
					}
					return true;
				}, (err) => {
					console.log(err);
					if (err === 'Unauthorized') { this.router.navigateByUrl('/admin/login') ; return false;};
				});*/
		
		/**if (localStorage.getItem('currentUser')) {
            // logged in so return true
            return true;
        }

        // not logged in so redirect to login page with the return url
        //this.router.navigate(['/admin/login']);
        return false;*/
  }
  canActivateChild(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
     this.authserv.session().subscribe(user => { 
										  
										  	this.myuser = user;
											if(this.myuser.usertype=="Admin")
											{
												
												localStorage.setItem('user', JSON.stringify(this.myuser));
												return true;
											}
											else
											{
												
												localStorage.removeItem('currentUser');
												localStorage.removeItem('user');
												this.router.navigate(['/admin/login']);
												return false;
											}
										  });
	 return false;
  }
}
