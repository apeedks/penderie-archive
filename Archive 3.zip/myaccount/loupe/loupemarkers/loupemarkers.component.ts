import {Component,Input,ViewChild, OnInit, ElementRef,AfterViewChecked} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import {AuthenticationService} from '../../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import {CookieService} from 'ngx-cookie-service';
import $ from 'jquery';

@Component({
  selector: 'app-loupemarkers',
  templateUrl: './loupemarkers.component.html',
  styleUrls: ['./loupemarkers.component.css']
})
export class LoupemarkersComponent implements OnInit,AfterViewChecked{
	productid=0;
	record = {id:0,user_id:0,category_id:0,brand_id:0,shortdesc:'',title:"",type:"",gender:"",productline:"",season:"",overview:"",material:"",materialrate:0,craftsmanship:"",craftsmanshiprate:0,designnstyle:"",designnstylerate:0,usage:"",usagerate:0,exclusivity:"",exclusivityrate:0,conclusions:"",coverphototvp:"",coverphoto:"",mainphoto1tvp:"",mainphoto1:"",mainphoto2tvp:"",mainphoto2:"",mainphoto3tvp:"",mainphoto3:"",mainphoto4tvp:"",mainphoto4:"",mainphoto5tvp:"",mainphoto5:"",mainphoto6tvp:"",mainphoto6:"",created_at:"",updated_at:"",active:"",brand:"",category:"",username:"",image:""};
	model = {id:0,title:'',description:'',xpos:0,ypos:0};
	rootpath:any;
	currtime:any;

	rectColor:string = "#0F9D58";
	context:CanvasRenderingContext2D;
	@ViewChild('canvas') canvas;
	originalmarkers: number[][] = [];/*[25, 25], [50, 50], [75, 75]*/
	markers: number[][];
	markerlist = [];
	constructor(private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private cookieService: CookieService) {
		this.rootpath = localStorage.getItem('baseurl');
		this.currtime = Math.random();
		this.markers = this.originalmarkers;
		
		
	}
	ngOnInit(){
	}
	ngAfterViewChecked(){
		if(this.canvas)
		{
			this.context = this.canvas.nativeElement.getContext("2d");	
			this.draw() ;
		}
	}
	draw() {
		/*alert('url('+this.rootpath+'assets/loupe/'+this.record.coverphoto+'?time='+this.currtime+')');*/
		this.context.clearRect(0,0,300,225);
		$("#canvasdiv").css("background-image",'url('+this.rootpath+'assets/loupe/'+this.record.coverphoto+'?time='+this.currtime+')');
		for (let i = 0; i < this.markers.length; i++) {
			this.context.beginPath();
			var x = this.markers[i][0]; // x coordinate
			var y = this.markers[i][1]; // y coordinate
			var radius = 10; // Arc radius
			var startAngle = 0; // Starting point on circle
			var endAngle = Math.PI*2; // End point on circle
			var anticlockwise = i % 2 !== 0; // clockwise or anticlockwise
		
			this.context.arc(x, y, radius, startAngle, endAngle, anticlockwise);
			this.context.fillStyle = this.rectColor;
			this.context.fill();
		}
	}
	showmainproduct(id)
	{
		this.productid = id;
		//console.log(this.canvas);
		this.dbserv.getById("getproductreviewall",this.productid).subscribe(res => {
													if(res.type=="success"){
														this.record=res.data;
														/*this.context = this.canvas.getContext("2d");*/
														this.dbserv.getById("getproductmarkers",this.productid).subscribe(res1 => {
															if(res1.type=="success"){
																this.markers = [];
																this.markerlist=res1.data;
																for(let i = 0; i < this.markerlist.length; i++) {
																	let item: [number, number] = [this.markerlist[i].xpos,this.markerlist[i].ypos];
																	this.markers.push(item);
																};
																this.draw();
															}
															
														});	
													}
												});
		
	}
	saverecord()
	{
		this.markerlist[this.model.id] = this.model;
		let reclist = {recs:this.markerlist,productid:this.productid};
		this.dbserv.post("saveloupemarker",reclist).subscribe(res => {
															this.showmainproduct(this.productid);
															this.model = {id:0,title:'',description:'',xpos:0,ypos:0};
														});	
	}
	markpoint($event)
	{
		console.log($event.offsetX + "--" + $event.offsetY);
		this.model.xpos = $event.offsetX;
		this.model.ypos = $event.offsetY;
		this.model.id = this.getindex($event.offsetX,$event.offsetY);
	}
	getindex(offsetX:number,offsetY:number)
	{
		for(let i=0; i<this.markers.length;i++)
		{
			if(this.markers[i][0]==offsetX && this.markers[i][1]==offsetY)	
				return i;
		}
		return this.markers.length;
	}
	editmarker(index: number) {
		this.model.xpos 		= this.markerlist[index].xpos;
		this.model.ypos 		= this.markerlist[index].ypos;
		this.model.title 		= this.markerlist[index].title;
		this.model.description 	= this.markerlist[index].description;
		this.model.id = index;
	}
	savenupdate()
	{
		let reclist = {recs:this.markerlist,productid:this.productid};
		this.dbserv.post("saveloupemarker",reclist).subscribe(res => {
															this.showmainproduct(this.productid);
															this.model = {id:0,title:'',description:'',xpos:0,ypos:0};
														});		
	}
	removeMarker(index: number) {
		this.markers.splice(index, 1);
		this.markerlist.splice(index, 1);
		this.savenupdate();
	}
	/*onMark(marker: number[]) {
		this.markers.splice(this.markers.length-1, 1);
		this.imgMap.draw();
		this.model.xpos = marker[0];
		this.model.ypos = marker[1];
		if(this.imgMap.markerActive)
			this.model.id = this.imgMap.markerActive;
		else
			this.model.id = this.getindex(marker);
	}
	
	editmarker(index: number) {
		this.model.xpos 		= this.markerlist[index].xpos;
		this.model.ypos 		= this.markerlist[index].ypos;
		this.model.title 		= this.markerlist[index].title;
		this.model.description 	= this.markerlist[index].description;
		this.model.id = index;
	}
	savenupdate()
	{
		let reclist = {recs:this.markerlist,productid:this.productid};
		this.dbserv.post("saveloupemarker",reclist).subscribe(res => {
															this.showmainproduct(this.productid);
															this.model = {id:0,title:'',description:'',xpos:0,ypos:0};
														});		
	}
	removeMarker(index: number) {
		this.markers.splice(index, 1);
		if (index === this.imgMap.markerActive) {
			this.imgMap.markerActive = null;
		} else if (index < this.imgMap.markerActive) {
			this.imgMap.markerActive--;
		}
		this.markerlist.splice(index, 1);
		this.savenupdate();
		this.imgMap.draw();
	}*/
}
