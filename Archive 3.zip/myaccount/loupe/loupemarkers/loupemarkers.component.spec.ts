import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoupemarkersComponent } from './loupemarkers.component';

describe('LoupemarkersComponent', () => {
  let component: LoupemarkersComponent;
  let fixture: ComponentFixture<LoupemarkersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoupemarkersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoupemarkersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
