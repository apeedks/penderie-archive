import { Component, OnInit, AfterViewChecked, ElementRef, ViewChild, HostListener } from '@angular/core';
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { DbserviceService } from '../../services/dbservice.service';
import { AlertsService } from '@jaspero/ng2-alerts';
import { DataTable } from 'angular-4-data-table/src/index';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { ImageCropperComponent, CropperSettings, Bounds } from 'ng2-img-cropper';
import $ from 'jquery';
import * as _ from 'lodash';

@Component({
    selector: 'app-review',
    templateUrl: './reviewproduct.component.html',
    styleUrls: ['./reviewproduct.component.css']
  })
  export class ReviewProductComponent implements OnInit,AfterViewChecked {
    @ViewChild( 'imagedialogue' ) imagedialogue: ElementRef;
    @ViewChild( 'coverimagedialogue' ) coverimagedialogue: ElementRef;
    @ViewChild( 'lnktimelinemarkers' ) lnktimelinemarkers: ElementRef;
    parentMessage = "message from parent";
    public items = [];
    //model = {id:0, title: '',category_id:0,user_id:0,credits:"",description:"",image:null,tags:[],gender:"",theme:"",imagetitle:"",active:""};
    imagesmodel = {
        id: 0,
        media_type: '',
        media_url: '',
        media_name: null,
        mediatitle: '',
        mediacredit: '',
        mediadesc: '',
        coverimage: false
    };
    model = {
        id: 0,
        user_id: 0,
        title: '',
        category_id: '',
        sub_category_id: '',
        brand_id: '',
        shortdesc: '',
        type: 'Service',
        productline: '',
        season: '',
        overview: '',
        material: '',
        materialrate: 0,
        craftsmanship: '',
        craftsmanshiprate: 0,
        designnstyle: '',
        designnstylerate: 0,
        usage: '', usagerate: 0,
        exclusivity: '',
        exclusivityrate: 0,
        conclusions: '',
        country: '',
        state: '',
        city: '',
        zipcode: '',
        active: "",
        address1: "",
        address2: "",
        storetype: "",
        phone: "",
        email: "",
        website: "",
        tags: [],
        release_year: 0,
        coverimagestyle: "standard",
        service_date: "",
        mediatitle: "",
        mediacredit: "",
        mediadesc: "",
        gender: 'Both',
        mainphoto: [
            {
                id: 0,
                media_type: '',
                media_url: '',
                media_name: null,
                mediatitle: '',
                mediacredit: '',
                mediadesc: '',
                coverimage: true
            },
            _.cloneDeep( this.imagesmodel ),
            _.cloneDeep( this.imagesmodel ),
            _.cloneDeep( this.imagesmodel ),
            _.cloneDeep( this.imagesmodel ),
            _.cloneDeep( this.imagesmodel ),
            _.cloneDeep( this.imagesmodel )
        ]
    };
    tagslist = [];
    tags:any = '';
    options: any;
    pageSize: number;
    totalitems: any;
    categories: any;
    categories1: any;
    linetypes: any;
    loading: boolean = false;
    filtertagids: any = [];
    page: number = 1;
    last_page: number = 1;
    public defaultparam = {
        sortBy: "id",
        sortAsc: true,
        offset: 0,
        limit: 10,
        catfilter: 0,
        brandsfilter: 0,
        type: "All",
        searchstr: "",
        status: [],
        service: [],
        gender: [],
        catid: 0,
        protype: []
    };
    // model2: any = { date: { year: 2018, month: 10, day: 9 } };
    public model2: any = {};
    filterfield: string = 'All';
    filtertype: string = 'All';
    isshowform = false;
    currentlist: string = 'All';
    applybtnval: string = '';
    headerimage: string = '';
    uploadedimage = null;
    uploadedimage1 = null;
    uploadedimage2 = null;
    uploadedimage3 = null;
    uploadedimage4 = null;
    uploadedimage5 = null;
    uploadedimage6 = null;
    visiblefilter = false;
    filtercatids: any = [];
    filterbrandids: any = [];
    custo_filter_onen_close = false;
    selectedrecs = [];
    release_year = [];
    public myDatePickerOptions: IMyDpOptions = {
        // other options...
        dateFormat: 'mm/dd/yyyy',
    };
    searchfield: string = '';
    summary = {
        Published: 0,
        Draft: 0,
        Trash: 0,
        Unpublished: 0,
        Workinprogress: 0,
        Archived: 0,
        Total: 0
    };
    searchgender: string = "Both";
    @ViewChild( DataTable ) recTable: DataTable;
    @ViewChild( 'theme' ) theme: ElementRef;
    currtime: any;
    websiteroot: string;
    rootpath: string;
    ddltype: string;
    ddlcategory_id: string;
    ddlbrand_id: string;
    brandsform = [];
    brands = [];
    subcatsform = [];
    ratingddl = [0, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5];
    countrylist: any;
    statelist: any;
    citylist: any;
    tagsfillter: any;
    settings = {};
    disableSince: any = {};
    category: any = '';
    tag: any = '';
    productid = 0;
    counterrecord = 0;
    upladmodelTitle = 'Cover';
    currentmodel = 0;
    showSavingData: boolean = false;
    imagedata: any = {};
    cropperSettings: CropperSettings;
    coverimagedata: any;
    homeimagedata: any;
    modelradio: 'Photo_pop';
    coverCropperSettings: CropperSettings;
    homeCropperSettings: CropperSettings;
    croppedWidth: number;
    croppedHeight: number;
    dragAreaClass: string = 'dragarea';
    uploadedsymbol: any = null;
    symbolimage = '';
    uploadedimagebtn: boolean = false;
    uploadedsymbolbtn: boolean = false;
    imagepreviewurl: string = '';
    isVideoUpload: boolean = false;

    @ViewChild( 'cropper', undefined ) cropper: ImageCropperComponent;
    @ViewChild( 'homecropper', undefined ) homecropper: ImageCropperComponent;
    @ViewChild( 'covercropper', undefined ) covercropper: ImageCropperComponent;
    @ViewChild( 'lnksaveprofilebox' ) lnksaveprofilebox: ElementRef;

    marker = { id: 0, title: '', description: '', xpos: '', ypos: '' };
    rectColor: string = "#0F9D58";
    context: CanvasRenderingContext2D;
    @ViewChild( 'canvas' ) canvas;
    markers: number[][] = [];
    markerlist = [];
    canvasDynamicWidth = 1280;
    isUpdateMode:boolean=false;
    ngAfterViewChecked() {
        if ( this.canvas ) {
            this.context = this.canvas.nativeElement.getContext( "2d" );
            this.draw();
        }
    }

    currentuploadtype = '';
    videourl = "";
    videoCoverUrl = "";
    videopreview: SafeUrl;

    constructor( private dbserv: DbserviceService, private _alert: AlertsService, private route: ActivatedRoute, private router: Router ) {
        let today = new Date();
        this.disableSince = { year: today.getFullYear(), month: today.getMonth() + 1, day: today.getDate() };
        this.myDatePickerOptions.disableSince = this.disableSince;
        this.searchgender = localStorage.getItem( 'visittype' );
        this.rootpath = localStorage.getItem( 'baseurl' );
        this.websiteroot = localStorage.getItem( 'basewebsiteurl' );
        // for (var i = 1; i <= 8; i++) {
        //    this.ratingddl.push(i);
        // }
        this.route.params.subscribe(params => {
            if(params['id'])
            {
                this.isUpdateMode = true;
                this.model.id = +params['id'];
                this.editrecord(this.model.id);    
                
            }
        });
        this.settings = {
            singleSelection: false,
            text: "Select Tags",
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            enableSearchFilter: true,
            limitSelection: 10,
            enableCheckAll: false,
            classes: "myclass custom-class"
        };
        this.cropperSettings = new CropperSettings();
        this.cropperSettings.width = 1920;
        this.cropperSettings.height = 1280;
        this.cropperSettings.croppedWidth = 1920;
        this.cropperSettings.croppedHeight = 1280;
        this.cropperSettings.canvasWidth = 850;
        this.cropperSettings.canvasHeight = 300;
        this.cropperSettings.touchRadius = 20;
        this.cropperSettings.rounded = false;
        this.cropperSettings.keepAspect = true;
        this.cropperSettings.noFileInput = true;
        this.cropperSettings.preserveSize = false;
        // for image
        this.homeCropperSettings = new CropperSettings();
        //this.homeCropperSettings.width = 645;
        //this.homeCropperSettings.croppedWidth = 645;
        this.homeCropperSettings.width = 1220;
        this.homeCropperSettings.croppedWidth = 1220;
        this.homeCropperSettings.height = 560;
        this.homeCropperSettings.croppedHeight = 560;
        this.homeCropperSettings.canvasWidth = 420;
        this.homeCropperSettings.noFileInput = true;
        this.homeCropperSettings.canvasHeight = 300;
        this.homeCropperSettings.touchRadius = 20;
        this.homeCropperSettings.rounded = false;
        this.homeCropperSettings.keepAspect = true;
        this.homeimagedata = {};

        this.coverCropperSettings = new CropperSettings();
        this.coverCropperSettings.width = 1280;
        this.coverCropperSettings.height = 560;
        this.coverCropperSettings.croppedWidth = 1280;
        this.coverCropperSettings.croppedHeight = 560;
        this.coverCropperSettings.canvasWidth = 420;
        this.coverCropperSettings.noFileInput = true;
        this.coverCropperSettings.canvasHeight = 300;
        this.coverCropperSettings.touchRadius = 20;
        this.coverCropperSettings.rounded = false;
        this.coverCropperSettings.keepAspect = true;
        this.coverimagedata = {};
        this.dbserv.getAll("loupetagslist").subscribe(res => { this.tagslist = res.records;});
        // this.dbserv.getAll("loupetagslist").subscribe(res => {
        //  this.tagslist = res.records;
        // });
    }
    states() {
        this.dbserv.getAll( "states/" + this.model.country ).subscribe( res => { this.statelist = res; } );
        this.citylist = [];
        if ( this.model.state == '' )
            this.model.city = '';
        // this.model.state = '';
        // this.dbserv.getAll("states/" + this.model.country).subscribe(res => {this.statelist = res;});
    }
    cities() {
        this.dbserv.getAll( "cities/" + this.model.country + "/" + this.model.state ).subscribe( res => { this.citylist = res; } );
    }
  /*  loadddl() {
        this.brands = [];
        this.dbserv.post( "loupebrandsalllist/" + this.searchgender, {} ).subscribe( res => { this.brands = res; } );
        this.loadpage( this.defaultparam );
    }*/
    loadbrands() {
        // this.loadsubcats();
        this.brandsform = [];
        this.dbserv.getAll( "loupebrandstlist/" + this.model.gender + "/" + this.model.category_id )
            .subscribe( res => {
                this.brandsform = res;
            } );
    }
   /* loadtags() {
        this.tagsfillter = [];
        this.dbserv.getAll( "loupetagslist" ).subscribe( res => {
            this.tagslist = res.records;
            this.tagsfillter = res.records;
            if ( this.tag != null ) {
                this.tagsfillter.forEach( obj => {
                    if ( obj.id == this.tag ) {
                        obj.checked = true;
                        this.filtertagids.push( obj.id );
                    }
                } );
                if ( this.filtertagids.length > 0 ) {
                    this.loadpage( this.defaultparam );
                }
            }
        } );
    }*/
    loadcats() {
        this.categories = [];
        this.dbserv.getAll( "loupeallcatlist/" + this.model.gender + "/" + this.model.type )
            .subscribe( res => {
                this.categories = res;
            } );
    }
    /*loadcats1() {
        this.categories1 = [];
        this.dbserv.getAll( "loupeallcatlist/" + this.searchgender )
            .subscribe( res => {
                this.categories1 = res;
                if ( this.category != null ) {
                    this.categories1.forEach( obj => {
                        if ( obj.id == this.category ) {
                            obj.checked = true;
                            this.filtercatids.push( obj.id );
                        }
                    } );
                    if ( this.filtercatids.length > 0 ) {
                        this.loadpage( this.defaultparam );
                    }
                }
            } );
    }*/
    ngOnInit() {
        let today = new Date();
        let year = today.getFullYear();
        for ( var i = 2000; i <= year; i++ ) {
            this.release_year.push( i );
        }
        this.release_year = this.release_year.reverse();
        this.route.queryParamMap.subscribe( params => {
            this.category = params.get( 'category' );
            this.tag = params.get( 'tag' );
            this.loadcats();
            this.dbserv.getAll( "countries" ).subscribe( res => { this.countrylist = res; } );
            this.dbserv.getAll("loupeallcatlist/"+this.searchgender).subscribe(res => { this.categories = res;});
            this.dbserv.getAll("sourcebytype/linetypes").subscribe(res => {this.linetypes = res;});
            this.showhideextra( 'Product' );
        } );
        let dob: string = this.model.service_date;
        if ( dob && dob != '' ) {
            let db_date = new Date( dob );
            this.model2 = { date: { year: +( db_date.getFullYear() ), month: +( db_date.getMonth() + 1 ), day: +( db_date.getDate() ) } };
        }
        scroll( 0, 0 );
    }
    // switchimagetvp(type){
    //  switch(type){
    //      case "cover":
    //          if(this.model.coverphototvp=="Video"){
    //              $("#divcoverimage").css("display","none");
    //              $("#divcovervideo").css("display","block");
    //          }
    //          else{
    //              $("#divcoverimage").css("display","block");
    //              $("#divcovervideo").css("display","none");
    //          }
    //      break;
    //      case "1":
    //          if(this.model.mainphoto1tvp=="Video"){
    //              $("#divmain1image").css("display","none");
    //              $("#divmain1video").css("display","block");
    //          }
    //          else{
    //              $("#divmain1image").css("display","block");
    //              $("#divmain1video").css("display","none");
    //          }
    //      break;
    //      case "2":
    //          if(this.model.mainphoto2tvp=="Video"){
    //              $("#divmain2image").css("display","none");
    //              $("#divmain2video").css("display","block");
    //          }
    //          else{
    //              $("#divmain2image").css("display","block");
    //              $("#divmain2video").css("display","none");
    //          }
    //      break;
    //      case "3":
    //          if(this.model.mainphoto3tvp=="Video"){
    //              $("#divmain3image").css("display","none");
    //              $("#divmain3video").css("display","block");
    //          }
    //          else{
    //              $("#divmain3image").css("display","block");
    //              $("#divmain3video").css("display","none");
    //          }
    //      break;
    //      case "4":
    //          if(this.model.mainphoto4tvp=="Video"){
    //              $("#divmain4image").css("display","none");
    //              $("#divmain4video").css("display","block");
    //          }
    //          else{
    //              $("#divmain4image").css("display","block");
    //              $("#divmain4video").css("display","none");
    //          }
    //      break;
    //      case "5":
    //          if(this.model.mainphoto5tvp=="Video"){
    //              $("#divmain5image").css("display","none");
    //              $("#divmain5video").css("display","block");
    //          }
    //          else{
    //              $("#divmain5image").css("display","block");
    //              $("#divmain5video").css("display","none");
    //          }
    //      break;
    //      case "6":
    //          if(this.model.mainphoto6tvp=="Video"){
    //              $("#divmain6image").css("display","none");
    //              $("#divmain6video").css("display","block");
    //          }
    //          else{
    //              $("#divmain6image").css("display","block");
    //              $("#divmain6video").css("display","none");
    //          }
    //      break;
    //  }
    // }
    /*statusselectedchange() {
        if ( this.applybtnval != '' ) {
            if ( this.recTable.selectedRows.length > 0 ) {
                if ( confirm( 'Are you sure?' ) ) {
                    this.selectedrecs = [];
                    for ( var i = 0; i < this.recTable.selectedRows.length; i++ ) {
                        this.selectedrecs.push( this.recTable.selectedRows[i].item.id );
                    }
                    let newmodel = { 'action': this.applybtnval, 'vals': JSON.stringify( this.selectedrecs ) };
                    this.dbserv.save( "loupesperformaction", newmodel )
                        .subscribe( res => {
                            if ( res.type == "success" ) {
                                this._alert.create( res.type, res.message );
                                this.loadpage( this.defaultparam );
                                this.isshowform = false;
                            }
                            else if(res.type=="expired"){
                                this.router.navigateByUrl('/login') ;
                            }
                            else {
                                this._alert.create( res.type, res.message );
                            }
                        } );
                }
            }
            else {
                this._alert.create( 'error', 'Please, select some record first.' );
            }
        }
    }*/
    /*statuschange( id: number, action: string ) {
        if ( confirm( 'Are you sure?' ) ) {
            this.selectedrecs = [id];
            this.applybtnval = action;
            let newmodel = { 'action': this.applybtnval, 'vals': JSON.stringify( this.selectedrecs ) };
            this.dbserv.save( "loupesperformaction", newmodel )
                .subscribe( res => {
                    if ( res.type == "success" ) {
                        this._alert.create( res.type, res.message );
                        this.loadpage( this.defaultparam );
                        this.isshowform = false;
                    }
                    else if(res.type=="expired"){
                        this.router.navigateByUrl('/login') ;
                    }
                    else {
                        this._alert.create( res.type, res.message );
                    }
                } );
        }
    }*/
   /* loadpage( params: any ) {
        let cararray = [];
        params.filtertype = this.filtertype;
        params.type = this.ddltype;
        // params.catfilter = this.ddlcategory_id;
        // params.brandsfilter = this.ddlbrand_id;
        // params.catfilter = this.filtercatids;
        // params.brandsfilter = this.filtercatids;
        params.status = this.defaultparam.status;
        params.protype = this.defaultparam.protype;
        params.service = this.defaultparam.service;
        params.filtercat = this.filtercatids;
        params.filtertag = this.filtertagids;
        params.filterbrand = this.filterbrandids;
        params.searchstr = this.searchfield;
        // if(params.filtertag.length == 0){
        //  if(this.tag != '' && this.tag != null)
        //      params.filtertag.push(this.tag);
        // }
        // if(params.filtercat.length == 0){
        //  if(this.category != '' && this.category != null)
        //      params.filtercat.push(this.category);
        // }
        this.currtime = Math.random();
        this.dbserv.post( "loupes/" + this.searchgender + "/" + this.currentlist, params )
            .subscribe( res => {
                if ( res.type == "success" ) {
                    this.items = res.records.data;
                    this.page = res.records.current_page;
                    this.totalitems = res.records.total;
                    this.pageSize = res.records.per_page;
                    this.last_page = res.records.last_page;
                    this.dbserv.post( "loupessummary/" + this.searchgender + "/" + this.currentlist, params ).subscribe( res => {
                        this.summary = res.records;
                    } );
                }
                else if(res.type=="expired"){
                    this.router.navigateByUrl('/login') ;
                }                else {
                    this._alert.create( res.type, res.message );
                }
            } );
        this.defaultparam = params;
        this.isshowform = false;
    }*/
  /*  switchcurrentlist() {
        this.currentlist = this.filterfield;
        this.loadpage( this.defaultparam );
    }*/
    hideform() {
        this.isshowform = false;
    }
    editrecord( id ) {
        this.imagesmodel = {
            id: 0,
            media_type: '',
            media_url: '',
            media_name: null,
            mediatitle: '',
            mediacredit: '',
            mediadesc: '',
            coverimage: false
        };
        this.isshowform = true;
        this.dbserv.getById( "loupe", id )
            .subscribe( res => {
                if ( res.type == "success" ) {
                    this.model = res.data;
                    this.clean( this.model );
                    this.loadbrands();
                    // this.switchimagetvp('cover');
                    // this.switchimagetvp('1');
                    // this.switchimagetvp('2');
                    // this.switchimagetvp('3');
                    // this.switchimagetvp('4');
                    // this.switchimagetvp('5');
                    // this.switchimagetvp('6');
                    this.showhideextra( this.model.type );
                    if ( this.model.country ) {
                        this.states();
                        this.cities();
                    }
                    if ( this.model.service_date != '' ) {
                        let db_date = new Date( this.model.service_date );
                        this.model2 = { date: { year: +( db_date.getFullYear() ), month: +( db_date.getMonth() + 1 ), day: +( db_date.getDate() ) } };
                    }
                    let totma = 7 - this.model.mainphoto.length;
                    for ( var i = 0; i < totma; ++i ) {
                        this.model.mainphoto.push( _.cloneDeep( this.imagesmodel ) );
                    }
                    if ( res.data.coverphototvp != '' ) {
                        this.model.mainphoto[0].media_type = res.data.coverphototvp;
                        this.model.mainphoto[0].coverimage = true;
                    }
                    if ( res.data.mainphoto1tvp != '' ) {
                        this.model.mainphoto[1].media_type = res.data.mainphoto1tvp;
                    }
                    if ( res.data.mainphoto2tvp != '' ) {
                        this.model.mainphoto[2].media_type = res.data.mainphoto2tvp;
                    }
                    if ( res.data.mainphoto3tvp != '' ) {
                        this.model.mainphoto[3].media_type = res.data.mainphoto3tvp;
                    }
                    if ( res.data.mainphoto4tvp != '' ) {
                        this.model.mainphoto[4].media_type = res.data.mainphoto4tvp;
                    }
                    if ( res.data.mainphoto5tvp != '' ) {
                        this.model.mainphoto[5].media_type = res.data.mainphoto5tvp;
                    }
                    if ( res.data.mainphoto6tvp != '' ) {
                        this.model.mainphoto[6].media_type = res.data.mainphoto6tvp;
                    }
                    if ( this.model.mainphoto[0].media_name == null && res.data.coverphototvp == 'Image' && res.data.coverphoto != "" ) {
                        this.model.mainphoto[0].media_name = res.data.coverphoto;
                    } else if ( res.data.coverphototvp == 'Video' && res.data.coverphoto != "" ) {
                        this.model.mainphoto[0].media_url = res.data.coverphoto;
                    }
                    if ( this.model.mainphoto[1].media_name == null && res.data.mainphoto1tvp == 'Image' && res.data.mainphoto1 != "" ) {
                        this.model.mainphoto[1].media_name = res.data.mainphoto1;
                    } else if ( res.data.mainphoto1tvp == 'Video' && res.data.mainphoto1 != "" ) {
                        this.model.mainphoto[1].media_url = res.data.mainphoto1;
                    }
                    if ( this.model.mainphoto[2].media_name == null && res.data.mainphoto2tvp == 'Image' && res.data.mainphoto2 != "" ) {
                        this.model.mainphoto[2].media_name = res.data.mainphoto2;
                    } else if ( res.data.mainphoto2tvp == 'Video' && res.data.mainphoto2 != "" ) {
                        this.model.mainphoto[2].media_url = res.data.mainphoto2;
                    }
                    if ( this.model.mainphoto[3].media_name == null && res.data.mainphoto3tvp == 'Image' && res.data.mainphoto3 != "" ) {
                        this.model.mainphoto[3].media_name = res.data.mainphoto3;
                    } else if ( res.data.mainphoto3tvp == 'Video' && res.data.mainphoto3 != "" ) {
                        this.model.mainphoto[3].media_url = res.data.mainphoto3;
                    }
                    if ( this.model.mainphoto[4].media_name == null && res.data.mainphoto4tvp == 'Image' && res.data.mainphoto4 != "" ) {
                        this.model.mainphoto[4].media_name = res.data.mainphoto4;
                    } else if ( res.data.mainphoto4tvp == 'Video' && res.data.mainphoto4 != "" ) {
                        this.model.mainphoto[4].media_url = res.data.mainphoto4;
                    }
                    if ( this.model.mainphoto[5].media_name == null && res.data.mainphoto5tvp == 'Image' && res.data.mainphoto5 != "" ) {
                        this.model.mainphoto[5].media_name = res.data.mainphoto5;
                    } else if ( res.data.mainphoto5tvp == 'Video' && res.data.mainphoto5 != "" ) {
                        this.model.mainphoto[5].media_url = res.data.mainphoto5;
                    }
                    if ( this.model.mainphoto[6].media_name == null && res.data.mainphoto6tvp == 'Image' && res.data.mainphoto6 != "" ) {
                        this.model.mainphoto[6].media_name = res.data.mainphoto6;
                    } else if ( res.data.mainphoto6tvp == 'Video' && res.data.mainphoto6 != "" ) {
                        this.model.mainphoto[6].media_url = res.data.mainphoto6;
                    }
                    console.log( this.model );
                }
                else if(res.type=="expired"){
                    this.router.navigateByUrl('/login') ;
                }                else
                    this._alert.create( res.type, res.message );
            } );
    }
    deleterecord( id ) {
        if ( confirm( 'Are you sure?' ) ) {
            this.isshowform = false;
            this.dbserv.delete( "loupedel", id )
                .subscribe( res => {
                    if ( res.type == "success" ) {
                        /*this.loadpage( this.defaultparam );*/
                        this._alert.create( res.type, res.message );
                    }
                    else if(res.type=="expired"){
                        this.router.navigateByUrl('/login') ;
                    }                    else
                        this._alert.create( res.type, res.message );
                } );
        }
    }
    changevalue( type: string ) {
        this.model.active = type;
    }

    fileChange( $event ) {
        console.log( $event );
        this.uploadedimage = $event.target.files[0];
        this.imagesmodel.media_name = $event.target.files[0];
        if ( this.imagesmodel.media_type == 'Image' ) {
            this.readCoverImageUrl();
        } else {
            this.imagesmodel.media_url = '';
            this.isVideoUpload = true;
            setTimeout( function() {
                var $source = $( '#covervideo' );
                $source[0].src = URL.createObjectURL( $event.target.files[0] );
                $source.parent()[0].load();
            }, 1000 );
        }
    }
    showhideextra( type: any ) {
        // console.log(type);
        this.model.type = type;
        if ( this.model.type == "Product" ) {
            $( ".serviceextra" ).css( "display", 'none' );
            $( ".serviceHide" ).css( "display", 'block' );
        } else {
            $( ".serviceextra" ).css( "display", 'block' );
            $( ".serviceHide" ).css( "display", 'none' );
        }
        this.loadcats();
    }

    showhideextra_popup( modelradio: any ) {
        this.imagesmodel.media_type = modelradio;
        this.imagesmodel.media_name = null;
        this.imagesmodel.media_url = '';
        // if(modelradio=="Video"){
        //  $(".serviceextra_pop").css("display",'none');
        //  $(".serviceHide_pop").css("display",'block');
        // } else {
        //  $(".serviceextra_pop").css("display",'block');
        //  $(".serviceHide_pop").css("display",'none');
        // }
        // this.loadcats();
    }

    clean( obj ) {
        for ( var propName in this.model ) {
            if ( this.model[propName] == null || this.model[propName] == "null" || this.model[propName] == "nul" || this.model[propName] == undefined || this.model[propName] == "undefined" || this.model[propName] == "0000-00-00" ) {
                this.model[propName] = '';
            }
        }
    }
    saverecord() {
        this.clean( this.model );
        let _formData = new FormData();
        _formData.append( "id", this.model.id.toString() );
        _formData.append( "category_id", this.model.category_id.toString() );
        _formData.append( "brand_id", this.model.brand_id.toString() );
        _formData.append( "title", this.model.title );
        _formData.append( "gender", this.model.gender );
        _formData.append( "type", this.model.type );
        _formData.append( "productline", this.model.productline );
        _formData.append( "season", this.model.season );
        _formData.append( "overview", this.model.overview );
        _formData.append( "material", this.model.material );
        _formData.append( "materialrate", this.model.materialrate.toString() );
        _formData.append( "craftsmanship", this.model.craftsmanship );
        _formData.append( "craftsmanshiprate", this.model.craftsmanshiprate.toString() );
        _formData.append( "designnstyle", this.model.designnstyle );
        _formData.append( "designnstylerate", this.model.designnstylerate.toString() );
        _formData.append( "usage", this.model.usage );
        _formData.append( "usagerate", this.model.usagerate.toString() );
        _formData.append( "exclusivity", this.model.exclusivity );
        _formData.append( "exclusivityrate", this.model.exclusivityrate.toString() );
        _formData.append( "conclusions", this.model.conclusions );
        _formData.append( "shortdesc", this.model.shortdesc );
        _formData.append( "country", this.model.country );
        _formData.append( "state", this.model.state );
        _formData.append( "city", this.model.city );
        _formData.append( "zipcode", this.model.zipcode );
        _formData.append( "address1", this.model.address1 );
        _formData.append( "address2", this.model.address2 );
        _formData.append( "storetype", this.model.storetype );
        _formData.append( "phone", this.model.phone );
        _formData.append( "email", this.model.email );
        _formData.append( "website", this.model.website );
        _formData.append( "markers", JSON.stringify( this.markerlist ) );
        _formData.append( "mainphoto", JSON.stringify( this.model.mainphoto ) );
        _formData.append( "coverimagestyle", this.model.coverimagestyle.toString() );
        _formData.append( "service_date", this.model.service_date );
        _formData.append( "active", this.model.active );
        if ( this.model.release_year != 0 && this.model.release_year != null )
            _formData.append( "release_year", this.model.release_year.toString() );
        else
            _formData.append( "release_year", '' );

        //  _formData.append("coverphototvp",this.model.coverphototvp);
        // if(this.model.coverphototvp=='Image')
        // {
        //  if(this.model.coverphotoimage!=null && this.model.coverphotoimage!=''){
        //      _formData.append('coverphotoimage',this.model.coverphotoimage);
        //  }
        // }
        // else if(this.model.coverphototvp=='Video')
        // {
        //  _formData.append("coverphoto",this.model.coverphoto);
        // }
        // _formData.append("mainphoto1tvp",this.model.mainphoto1tvp);
        // if(this.model.mainphoto1tvp=='Image')
        // {
        //  if(this.model.mainphoto1image!=null && this.model.mainphoto1image!=''){
        //      _formData.append('mainphoto1image',this.model.mainphoto1image);
        //  }
        // }
        // else if(this.model.mainphoto1tvp=='Video')
        // {
        //  _formData.append("mainphoto1",this.model.mainphoto1);
        // }

        // _formData.append("mainphoto2tvp",this.model.mainphoto2tvp);
        // if(this.model.mainphoto2tvp=='Image')
        // {
        //  if(this.model.mainphoto2image!=null && this.model.mainphoto2image!='')
        //      _formData.append('mainphoto2image',this.model.mainphoto2image);
        // }
        // else if(this.model.mainphoto2tvp=='Video')
        // {
        //  _formData.append("mainphoto2",this.model.mainphoto2);
        // }

        // _formData.append("mainphoto3tvp",this.model.mainphoto3tvp);
        // if(this.model.mainphoto3tvp=='Image')
        // {
        //  if(this.model.mainphoto3image!=null && this.model.mainphoto3image!='')
        //      _formData.append('mainphoto3image',this.model.mainphoto3image);
        // }
        // else if(this.model.mainphoto3tvp=='Video')
        // {
        //  _formData.append("mainphoto3",this.model.mainphoto3);
        // }
        // _formData.append("mainphoto4tvp",this.model.mainphoto4tvp);
        // if(this.model.mainphoto4tvp=='Image')
        // {
        //  if(this.model.mainphoto4image!=null && this.model.mainphoto4image!='')
        //      _formData.append('mainphoto4image',this.model.mainphoto4image);
        // }
        // else if(this.model.mainphoto4tvp=='Video')
        // {
        //  _formData.append("mainphoto4",this.model.mainphoto4);
        // }
        // _formData.append("mainphoto5tvp",this.model.mainphoto5tvp);
        // if(this.model.mainphoto5tvp=='Image')
        // {
        //  if(this.model.mainphoto5image!=null && this.model.mainphoto5image!='')
        //      _formData.append('mainphoto5image',this.model.mainphoto5image);
        // }
        // else if(this.model.mainphoto5tvp=='Video')
        // {
        //  _formData.append("mainphoto5",this.model.mainphoto5);
        // }
        // _formData.append("mainphoto6tvp",this.model.mainphoto6tvp);
        // if(this.model.mainphoto6tvp=='Image')
        // {
        //  if(this.model.mainphoto6image!=null && this.model.mainphoto6image!='')
        //      _formData.append('mainphoto6image',this.model.mainphoto6image);
        // }
        // else if(this.model.mainphoto6tvp=='Video')
        // {
        //  _formData.append("mainphoto6",this.model.mainphoto6);
        // }
        let mytags: string = '';
        if ( this.model.tags.length > 0 ) {
            for ( let i = 0; i < this.model.tags.length; i++ ) {
                if ( mytags == '' )
                    mytags = '-' + this.model.tags[i].id.toString() + '-';
                else
                    mytags += ',-' + this.model.tags[i].id.toString() + '-';
                _formData.append( "tags", mytags );
            }
        }
        this.dbserv.saveimage( "loupesave", _formData )
            .subscribe( res => {
                if ( res.type == "success" ) {
                    this._alert.create(res.type,res.message);
                    if(this.isUpdateMode){
                        this.router.navigateByUrl('/myaccount/loupe');
                    } else {
                        if (this.model.active == 'Preview') {
                            window.open('/loupe/'+this.model.type.toLowerCase()+'/'+res.data.id,'_blank');
                            this.model.id = res.data.id;
                            // this.router.navigateByUrl('/story/'+res.data.id) ;
                        }else{
                            this.router.navigateByUrl('/myaccount/loupe');
                            this.model = {
                                    id: 0,
                                    user_id: 0,
                                    title: '',
                                    category_id: '',
                                    sub_category_id: '',
                                    brand_id: '',
                                    shortdesc: '',
                                    type: 'Service',
                                    productline: '',
                                    season: '',
                                    overview: '',
                                    material: '',
                                    materialrate: 0,
                                    craftsmanship: '',
                                    craftsmanshiprate: 0,
                                    designnstyle: '',
                                    designnstylerate: 0,
                                    usage: '', usagerate: 0,
                                    exclusivity: '',
                                    exclusivityrate: 0,
                                    conclusions: '',
                                    country: '',
                                    state: '',
                                    city: '',
                                    zipcode: '',
                                    active: "",
                                    address1: "",
                                    address2: "",
                                    storetype: "",
                                    phone: "",
                                    email: "",
                                    website: "",
                                    tags: [],
                                    release_year: 0,
                                    coverimagestyle: "standard",
                                    service_date: "",
                                    mediatitle: "",
                                    mediacredit: "",
                                    mediadesc: "",
                                    gender: 'Both',
                                    mainphoto: [
                                        {
                                            id: 0,
                                            media_type: '',
                                            media_url: '',
                                            media_name: null,
                                            mediatitle: '',
                                            mediacredit: '',
                                            mediadesc: '',
                                            coverimage: true
                                        },
                                        _.cloneDeep( this.imagesmodel ),
                                        _.cloneDeep( this.imagesmodel ),
                                        _.cloneDeep( this.imagesmodel ),
                                        _.cloneDeep( this.imagesmodel ),
                                        _.cloneDeep( this.imagesmodel ),
                                        _.cloneDeep( this.imagesmodel )
                                    ]
                                };
                            this.showSavingData = false;
                        }
                    }
                }
                else if ( res.type == "expired" ) {
                    this.router.navigateByUrl( '/login' );
                }
                this.isshowform = false; this._alert.create( res.type, res.message );
                /*this.loadpage( this.defaultparam );*/
            } );
    }
    addrecord() {
        this.model = {
            id: 0,
            user_id: 0,
            title: '',
            category_id: '',
            sub_category_id: '',
            brand_id: '',
            shortdesc: '',
            type: 'Service',
            productline: '',
            season: '',
            overview: '',
            material: '',
            materialrate: 0,
            craftsmanship: '',
            craftsmanshiprate: 0,
            designnstyle: '',
            designnstylerate: 0,
            usage: '', usagerate: 0,
            exclusivity: '',
            exclusivityrate: 0,
            conclusions: '',
            country: '',
            state: '',
            city: '',
            zipcode: '',
            active: "",
            address1: "",
            address2: "",
            storetype: "",
            phone: "",
            email: "",
            website: "",
            tags: [],
            release_year: 0,
            coverimagestyle: "standard",
            service_date: "",
            mediatitle: "",
            mediacredit: "",
            mediadesc: "",
            gender: 'Both',
            mainphoto: [
                {
                    id: 0,
                    media_type: '',
                    media_url: '',
                    media_name: null,
                    mediatitle: '',
                    mediacredit: '',
                    mediadesc: '',
                    coverimage: true
                },
                _.cloneDeep( this.imagesmodel ),
                _.cloneDeep( this.imagesmodel ),
                _.cloneDeep( this.imagesmodel ),
                _.cloneDeep( this.imagesmodel ),
                _.cloneDeep( this.imagesmodel ),
                _.cloneDeep( this.imagesmodel )
            ]
        };
        this.isshowform = true;
        this.uploadedimage = null;
        this.showhideextra( 'Product' );
    }

    onItemSelect( item: any ) {
        console.log( item );
        console.log( this.model.tags );
    }
    OnItemDeSelect( item: any ) {
        console.log( item );
        console.log( this.model.tags );
    }
    onSelectAll( items: any ) {
        console.log( this.model.tags );
    }
    onDeSelectAll( items: any ) {
        console.log( this.model.tags );
    }
    onDateChanged( event: IMyDateModel ) {
        // event properties are: event.date, event.jsdate, event.formatted and event.epoc
        if ( event.jsdate ) {
            this.model.service_date = event.jsdate.getFullYear() + "-" + event.jsdate.getMonth() + "-" + event.jsdate.getDate();
            console.log( this.model.service_date );
        }
    }

    /*key_down( e ) {
        if ( e.target.value == '' ) {
            this.loadpage( this.defaultparam );
        }
        if ( e.keyCode === 13 ) {
            this.loadpage( this.defaultparam );
        }
    }*/
    productsmakers( id ) {
        this.productid = id;
        // this.loupemarker.showmainproduct(this.productid);
        this.dbserv.getById( "getproductmarkers", this.productid ).subscribe( res1 => {
            if ( res1.type == "success" ) {
                this.markers = [];
                this.markerlist = res1.data;
                for ( let i = 0; i < this.markerlist.length; i++ ) {
                    let item: [number, number] = [this.markerlist[i].xpos, this.markerlist[i].ypos];
                    this.markers.push( item );
                };
                this.context = this.canvas.nativeElement.getContext( "2d" );
                this.draw();
            }
            //          this.lnktimelinemarkers.nativeElement.click();
        } );
    }

    // Copper And Marker Code

    updatemediasettings( type ) {
        // if(type=="Video"){
        //  switch(this.currentuploadtype){
        //      case "cover":
        //          this.model.coverphototvp = type;
        //          this.model.coverphoto = this.videoCoverUrl;
        //          this.model.coverphotoimage = null;
        //          break;
        //      case "1":
        //          this.model.mainphoto1tvp = type;
        //          this.model.mainphoto1 = this.videourl;
        //          this.model.mainphoto1image = null;
        //          break;
        //      case "2":
        //          this.model.mainphoto2tvp = type;
        //          this.model.mainphoto2 = this.videourl;
        //          this.model.mainphoto2image = null;
        //          break;
        //      case "3":
        //          this.model.mainphoto3tvp = type;
        //          this.model.mainphoto3 = this.videourl;
        //          this.model.mainphoto3image = null;
        //          break;
        //      case "4":
        //          this.model.mainphoto4tvp = type;
        //          this.model.mainphoto4 = this.videourl;
        //          this.model.mainphoto4image = null;
        //          break;
        //      case "5":
        //          this.model.mainphoto5tvp = type;
        //          this.model.mainphoto5 = this.videourl;
        //          this.model.mainphoto5image = null;
        //          break;
        //      case "6":
        //          this.model.mainphoto6tvp = type;
        //          this.model.mainphoto6 = this.videourl;
        //          this.model.mainphoto6image = null;
        //          break;
        //  }
        // }
        // else if(type=="Image"){
        //  switch(this.currentuploadtype){
        //      case "cover":
        //          this.model.coverphototvp = type;
        //          this.model.coverphoto = '';
        //          this.model.coverphotoimage = this.uploadedimage;
        //          break;
        //      case "1":
        //          this.model.mainphoto1tvp = type;
        //          this.model.mainphoto1 = '';
        //          this.model.mainphoto1image = this.uploadedimage;
        //          break;
        //      case "2":
        //          this.model.mainphoto2tvp = type;
        //          this.model.mainphoto2 = '';
        //          this.model.mainphoto2image = this.uploadedimage;
        //          break;
        //      case "3":
        //          this.model.mainphoto3tvp = type;
        //          this.model.mainphoto3 = '';
        //          this.model.mainphoto3image = this.uploadedimage;
        //          break;
        //      case "4":
        //          this.model.mainphoto4tvp = type;
        //          this.model.mainphoto4 = '';
        //          this.model.mainphoto4image = this.uploadedimage;
        //          break;
        //      case "5":
        //          this.model.mainphoto5tvp = type;
        //          this.model.mainphoto5 = '';
        //          this.model.mainphoto5image = this.uploadedimage;
        //          break;
        //      case "6":
        //          this.model.mainphoto6tvp = type;
        //          this.model.mainphoto6 = '';
        //          this.model.mainphoto6image = this.uploadedimage;
        //          break;
        //  }
        // }
    }

    showdialog( type, inx ) {
        this.currentmodel = inx;
        this.isVideoUpload = false;
        this.currentuploadtype = type;
        this.uploadedimage = null;
        this.videourl = '';
        this.imagedata = {};
        this.upladmodelTitle = type ? 'Cover' : "Main - " + inx;
        this.imagedata = {};
        this.imagesmodel = {
            id: 0,
            media_type: '',
            media_url: '',
            media_name: null,
            mediatitle: '',
            mediacredit: '',
            mediadesc: '',
            coverimage: false
        };
        let obj = this;
        if ( type || inx == 0 ) {
             $("#covermedia").trigger("reset");
            if ( this.model.mainphoto[inx].media_type == '' || this.model.mainphoto[inx].media_type == null ) {
                this.model.mainphoto[inx].media_type = 'Image';
            }
            this.imagesmodel = _.cloneDeep( this.model.mainphoto[inx] );
            this.imagepreviewurl = '';
            this.videoCoverUrl = '';
            //this.lnktimelinemarkers.nativeElement.click();
            if ( this.imagesmodel.media_type == 'Image' ) {
                setTimeout( function() {
                    obj.homecropper.reset();
                    obj.covercropper.reset();
                }, 1000 );
            } else {
                if ( this.imagesmodel.media_url == '' && this.imagesmodel.media_type == 'Video' ) {
                    this.isVideoUpload = true;
                    this.uploadedimage = this.imagesmodel.media_name;
                    setTimeout( function() {
                        var $source = $( '#uploadedvideo' );
                        $source[0].src = URL.createObjectURL( obj.imagesmodel.media_name );
                        $source.parent()[0].load();
                    }, 500 );
                }
            }
            this.coverimagedialogue.nativeElement.click();
            // this.showhideextra_popup(this.model.mainphoto[0].media_type);
            // this.imagesmodel.coverimage = true;
            // this.modelradio = "Photo_pop";
        } else {
             $("#media").trigger("reset");
            if ( this.model.mainphoto[inx].media_type == '' || this.model.mainphoto[inx].media_type == null ) {
                this.model.mainphoto[inx].media_type = 'Image';
            }
            this.imagesmodel = _.cloneDeep( this.model.mainphoto[inx] );
            if ( this.imagesmodel.media_type == 'Image' ) {
                setTimeout( function() {
                    obj.cropper.reset();
                }, 1000 );
            }
            this.imagedialogue.nativeElement.click();
        }
        console.log( this.imagesmodel );
    }
    readCoverImageUrl() {
        /*if (this.uploadedimage && this.uploadedimage) {
            var reader = new FileReader();
            reader.onload = (event:any) => {
                this.imagepreviewurl = event.target.result;
            }
            reader.readAsDataURL(this.uploadedimage);
            //this.updatemediasettings('Image');
        }*/
        if ( this.uploadedimage && this.uploadedimage ) {
            var reader = new FileReader();
            var image: any = new Image();
            reader.onload = ( event: any ) => {
                image.src = event.target.result;
                this.homecropper.setImage( image );
                this.covercropper.setImage( image );
            }
            reader.onloadend = ( event: any ) => {
                image.src = event.target.result;
                this.homecropper.setImage( image );
                this.covercropper.setImage( image );
            };
            reader.readAsDataURL( this.uploadedimage );
            // reader.readAsDataURL(this.imagesmodel.media_name);
        }
    }

    cropped( bounds: Bounds ) {
        this.croppedHeight = bounds.bottom - bounds.top;
        this.croppedWidth = bounds.right - bounds.left;
    }
    fileChangeListener( $event ) {
        var image: any = new Image();
        var file: File = $event.target.files[0];
        var myReader: FileReader = new FileReader();
        var that = this;
        myReader.onloadend = function( loadEvent: any ) {
            image.src = loadEvent.target.result;
            that.cropper.setImage( image );
        };
        myReader.readAsDataURL( file );
    }

    previewFile( file ) {
        var request = new XMLHttpRequest();
        request.open( 'GET', file, true );
        request.responseType = 'blob';
        var image: any = new Image();
        request.onload = () => {
            var reader = new FileReader();
            reader.readAsDataURL( request.response );
            reader.onload = ( event: any ) => {
                image.src = event.target.result;
                this.cropper.setImage( image );
            };
            reader.onloadend = ( event: any ) => {
                image.src = event.target.result;
                this.cropper.setImage( image );
            };
        };
        request.send();
    }
    readImageUrl() {
        if ( this.uploadedimage && this.uploadedimage ) {
            var reader = new FileReader();
            var image: any = new Image();
            reader.onload = ( event: any ) => {
                image.src = event.target.result;
                this.cropper.setImage( image );
            }
            reader.onloadend = ( event: any ) => {
                image.src = event.target.result;
                this.cropper.setImage( image );
            };
            reader.readAsDataURL( this.uploadedimage );
            //this.updatemediasettings('Image');
        }
    }


    onSymbolChange( $event ) {
        this.uploadedsymbol = $event.target.files[0];
    }
    onFileChange( $event ) {

        console.log( $event );
        this.uploadedimage = $event.target.files[0];
        this.imagesmodel.media_name = $event.target.files[0];
        if ( this.imagesmodel.media_type == 'Image' ) {
            this.readImageUrl();
        } else {
            this.imagesmodel.media_url = '';
            this.isVideoUpload = true;
            setTimeout( function() {
                var $source = $( '#uploadedvideo' );
                $source[0].src = URL.createObjectURL( $event.target.files[0] );
                $source.parent()[0].load();
            }, 1000 );
        }

        // this.uploadedimage = $event.target.files[0];
        // this.readImageUrl();
        //this.saveprofileimage( $event.target.files[0]);
    }
    @HostListener( 'dragover', ['$event'] ) onDragOver( event ) {
        this.dragAreaClass = "droparea";
        event.preventDefault();
    }
    @HostListener( 'dragenter', ['$event'] ) onDragEnter( event ) {
        this.dragAreaClass = "droparea";
        event.preventDefault();
    }
    @HostListener( 'dragend', ['$event'] ) onDragEnd( event ) {
        this.dragAreaClass = "dragarea";
        event.preventDefault();
    }
    @HostListener( 'dragleave', ['$event'] ) onDragLeave( event ) {
        this.dragAreaClass = "dragarea";
        event.preventDefault();
    }
    @HostListener( 'drop', ['$event'] ) onDrop( event ) {
        this.dragAreaClass = "dragarea";
        event.preventDefault();
        event.stopPropagation();
        this.uploadedimage = event.dataTransfer.files[0];
        this.readImageUrl();
        //this.saveprofileimage(event.dataTransfer.files[0]);
    }
    // saveprofileimage(){
    //  if(this.imagedata.image != '' && this.imagedata.image != null){
    //      this.uploadedimage = this.imagedata.image;
    //      this.updatemediasettings('Image');
    //      this.imagedata = {};
    //      this.lnksaveprofilebox.nativeElement.click();
    //      this._alert.create("success","successfully uploaded image");
    //  }
    // }

    savecoverimage() {
        this.loading = true;
        if ( this.imagesmodel.media_type == 'Image'
            && this.homeimagedata.image != ''
            && this.homeimagedata.image != null
            && this.coverimagedata.image != ''
            && this.coverimagedata.image != null
            && this.imagesmodel.coverimage
        ) {
            if ( this.model.coverimagestyle == "standard" ) {
                this.imagesmodel.media_name = this.homeimagedata.image;
                this.canvasDynamicWidth = 1220;
            } else {
                this.imagesmodel.media_name = this.coverimagedata.image;
                this.canvasDynamicWidth = 1280;
            }

            // this.updatemediasettings('Image');
            this.model.mainphoto[this.currentmodel] = _.cloneDeep( this.imagesmodel );
            //this.markerlist = [];
            // document.getElementById('review-cover-media-close').click();
            // this.lnktimelinemarkers.nativeElement.click();
            // setTimeout(function() {
            //  $("body").addClass("modal-open");
            // }, 1000);
        } else {
            this.model.mainphoto[this.currentmodel] = _.cloneDeep( this.imagesmodel );
            // document.getElementById('review-cover-media-close').click();
        }
        let _formData = new FormData();
        _formData.append( "id", this.imagesmodel.id.toString() );
        _formData.append( "media_type", this.imagesmodel.media_type );
        _formData.append( "mediatitle", this.imagesmodel.mediatitle );
        _formData.append( "mediacredit", this.imagesmodel.mediacredit );
        _formData.append( "mediadesc", this.imagesmodel.mediadesc );
        _formData.append( 'media_name', this.imagesmodel.media_name );
        _formData.append( 'media_url', this.imagesmodel.media_url );
        if ( this.imagesmodel.media_name != null && this.imagesmodel.media_name != '' ) {
            _formData.append( 'media_file', this.uploadedimage );
        }
        this.dbserv.saveimage( "savemedia", _formData )
            .subscribe( res => {
                console.log( res );
                if ( res.type == 'success' ) {
                    this.model.mainphoto[this.currentmodel] = res.data;
                    this.model.mainphoto[this.currentmodel].coverimage = _.cloneDeep( this.imagesmodel.coverimage );
                    if ( this.imagesmodel.media_type == 'Image' ) {
                        document.getElementById( 'review-cover-media-close' ).click();
                        this.lnktimelinemarkers.nativeElement.click();
                        //                  if (this.model.id > 0) {
                        //                      this.productsmakers(this.model.id);
                        //                  }
                        setTimeout( function() {
                            $( "body" ).addClass( "modal-open" );
                        }, 1000 );
                    } else {
                        document.getElementById( 'review-cover-media-close' ).click();
                    }
                    this.imagesmodel = {
                        id: 0,
                        media_type: '',
                        media_url: '',
                        media_name: null,
                        mediatitle: '',
                        mediacredit: '',
                        mediadesc: '',
                        coverimage: false
                    };
                }
                this.loading = false;
            } );
        console.log( this.model );
    }
    saveimage() {
        this.loading = true;
        console.log( this.imagesmodel, this.currentmodel );
        if ( this.imagesmodel.media_type == 'Image'
            && this.imagedata.image != ''
            && this.imagedata.image != null
        ) {
            this.imagesmodel.media_name = this.imagedata.image;
            // this.updatemediasettings('Image');
            this.model.mainphoto[this.currentmodel] = _.cloneDeep( this.imagesmodel );
            //this.markerlist = [];
            // document.getElementById('review-media-close').click();
        } else {
            this.model.mainphoto[this.currentmodel] = _.cloneDeep( this.imagesmodel );
            // document.getElementById('review-media-close').click();
        }
        let _formData = new FormData();
        _formData.append( "id", this.imagesmodel.id.toString() );
        _formData.append( "media_type", this.imagesmodel.media_type );
        _formData.append( "mediatitle", this.imagesmodel.mediatitle );
        _formData.append( "mediacredit", this.imagesmodel.mediacredit );
        _formData.append( "mediadesc", this.imagesmodel.mediadesc );
        _formData.append( 'media_name', this.imagesmodel.media_name );
        _formData.append( 'media_url', this.imagesmodel.media_url );
        if ( this.imagesmodel.media_name != null && this.imagesmodel.media_name != '' ) {
            _formData.append( 'media_file', this.uploadedimage );
        }
        this.dbserv.saveimage( "savemedia", _formData )
            .subscribe( res => {
                console.log( res );
                if ( res.type == 'success' ) {
                    this.model.mainphoto[this.currentmodel] = res.data;
                    this.model.mainphoto[this.currentmodel].coverimage = _.cloneDeep( this.imagesmodel.coverimage );
                    if ( this.imagesmodel.media_type == 'Image' ) {
                        document.getElementById( 'review-media-close' ).click();
                    } else {
                        document.getElementById( 'review-media-close' ).click();
                    }
                    this.imagesmodel = {
                        id: 0,
                        media_type: '',
                        media_url: '',
                        media_name: null,
                        mediatitle: '',
                        mediacredit: '',
                        mediadesc: '',
                        coverimage: false
                    };
                }
                this.loading = false;
            } );
        console.log( this.model );
    }

    // Marker Code Start //

    draw() {
        //this.context.clearRect(0,0,300,225);
        //this.context.clearRect(0,0,570,357);
        let coverphotoimage = "";
        this.model.mainphoto.forEach(( obj ) => {
            if ( obj.coverimage && obj.media_type == "Image" ) {
                coverphotoimage = obj.photoimage;
            }
        } );
        if ( coverphotoimage != '' ) {
            // $("#canvasdiv").css("background-image",'url('+coverphotoimage+')');
            for ( let i = 0; i < this.markerlist.length; i++ ) {
                this.context.beginPath();
                var x = this.markerlist[i].xpos; // x coordinate
                var y = this.markerlist[i].ypos; // y coordinate
                var radius = 10; // Arc radius
                var startAngle = 0; // Starting point on circle
                var endAngle = Math.PI * 2; // End point on circle
                var anticlockwise = i % 2 !== 0; // clockwise or anticlockwise
                this.context.arc( x, y, radius, startAngle, endAngle, anticlockwise );
                this.context.fillStyle = this.rectColor;
                this.context.fill();
            }
        }
    }
    tempdraw( xpos: number, ypos: number ) {
        
        this.context.clearRect( 0, 0, this.canvasDynamicWidth, 560 );
        this.context = this.canvas.nativeElement.getContext( "2d" );
        this.context.beginPath();
        var x = xpos; // x coordinate
        var y = ypos; // y coordinate
        var radius = 10; // Arc radius
        var startAngle = 0; // Starting point on circle
        var endAngle = Math.PI * 2; // End point on circle
        var anticlockwise = 1 % 2 !== 0; // clockwise or anticlockwise
        this.context.arc( x, y, radius, startAngle, endAngle, anticlockwise );
        this.context.fillStyle = this.rectColor;
        this.context.fill();
    }
    savemarkerrecord() {
        // $("#marker_form").trigger("reset");
        let newrecord = true;
        this.markerlist.forEach(( obj ) => {
            if ( obj.id == this.marker.id ) {
                obj = _.cloneDeep( this.marker );
                newrecord = false;
            }
        } );
        if ( newrecord ) {
            this.markerlist.push( this.marker );
        }
        let reclist = { recs: this.markerlist, productid: 0 };
        this.marker = { id: 0, title: '', description: '', xpos: '', ypos: '' };
        console.log( this.markerlist );
    }
    markpoint( $event ) {
        if ( this.markerlist.length <= 4 ) {
            this.marker.xpos = $event.offsetX;
            this.marker.ypos = $event.offsetY;
            this.marker.id = this.getindex( $event.offsetX, $event.offsetY );
            this.tempdraw( $event.offsetX, $event.offsetY );
        }
    }
    getindex( offsetX: number, offsetY: number ) {
        /*for(let i=0; i<this.markers.length;i++)
        {
            if(this.markers[i][0]==offsetX && this.markers[i][1]==offsetY)
                return i;
        }
        return this.markers.length;*/

        for ( let i = 0; i < this.markerlist.length; i++ ) {
            if ( this.markerlist[i].xpos == offsetX && this.markerlist[i].ypos == offsetY )
                return i;
        }
        return this.markerlist.length;
    }
    editmarker( index: number ) {
        this.marker.xpos = this.markerlist[index].xpos;
        this.marker.ypos = this.markerlist[index].ypos;
        this.marker.title = this.markerlist[index].title;
        this.marker.description = this.markerlist[index].description;
        this.marker.id = index;
    }
    removeMarker( index: number ) {
        this.markerlist.splice( index, 1 );
        this.context.clearRect( 0, 0, this.canvasDynamicWidth, 560 );
        this.draw();
    }
   /* filtertag() {
        this.filtertagids = [];
        this.tagsfillter.forEach( obj => {
            if ( obj.checked )
                this.filtertagids.push( obj.id );
        } );
        this.loadpage( this.defaultparam );
    }*/
    /*selecalltag( event ) {
        this.filtertagids = [];
        this.tagsfillter.forEach( obj => {
            obj.checked = event.target.checked;
            if ( obj.checked )
                this.filtertagids.push( obj.id );
        } );
        this.loadpage( this.defaultparam );
    }*/
    saveimageclick() {
        this._alert.create( "success", "successfully pin set" );
    }
    ngAfterViewInit() {
        $( ".custo-filter-colap" ).click( function( e ) {
            if ( !$( this ).hasClass( 'custo_filter_onen_close' ) ) {
                $( this ).next( ".utl-filter-box" ).addClass( 'visiblefilter' );
                $( this ).addClass( 'custo_filter_onen_close' );
                e.stopPropagation();
            } else {
                $( ".utl-filter-box" ).removeClass( 'visiblefilter' );
                $( ".custo-filter-colap" ).removeClass( 'custo_filter_onen_close' );
                e.stopPropagation();
            }
        } );

        $( ".utl-filter-box" ).click( function( e ) {
            e.stopPropagation();
        } );

        $( document ).click( function() {
            $( ".utl-filter-box" ).removeClass( 'visiblefilter' );
            $( ".custo-filter-colap" ).removeClass( 'custo_filter_onen_close' );
        } );
    }
    clickfortotalitem() {
        this.filterfield = 'All';
        this.currentlist = 'All';
        this.filtertype = 'All';
        this.defaultparam.status = [];
        this.defaultparam.gender = [];
        this.defaultparam.service = [];
        this.filtercatids = [];
        this.defaultparam.protype = [];
        this.filtertagids = [];
        this.tagsfillter.forEach( obj => {
            obj.checked = false;
        } );
        this.categories1.forEach( obj => {
            obj.checked = false;
        } );

    }
    previewvideo() {
        this.isVideoUpload = false;
        this.uploadedimage = null;
        this.updatemediasettings( 'Video' );
        //this.videopreview = this.sanitizer.bypassSecurityTrustResourceUrl('https://www.youtube.com/embed/' + this.videourl);
        //this.videopreview = 'https://www.youtube.com/embed/' + this.videourl;
    }

    videotoimage( file ) {
        // var file = event.target.files[0];
        var fileReader = new FileReader();
        if ( file.type.match( 'image' ) ) {
            fileReader.onload = function() {
                // var img = document.createElement('img');
                // img.src fileReader.result.toString();
                return fileReader.result.toString();
                // document.getElementsByTagName('div')[0].appendChild(img);
            };
            fileReader.readAsDataURL( file );
        } else {
            fileReader.onload = function() {
                var blob = new Blob( [fileReader.result], { type: file.type } );
                var url = URL.createObjectURL( blob );
                var video = <HTMLVideoElement>document.createElement( 'video' );
                var timeupdate = function() {
                    if ( snapImage() ) {
                        video.removeEventListener( 'timeupdate', timeupdate );
                        video.pause();
                    }
                };
                video.addEventListener( 'loadeddata', function() {
                    if ( snapImage() ) {
                        video.removeEventListener( 'timeupdate', timeupdate );
                    }
                } );
                var snapImage = function() {
                    var canvas = document.createElement( 'canvas' );
                    canvas.width = video.videoWidth;
                    canvas.height = video.videoHeight;
                    canvas.getContext( '2d' ).drawImage( video, 0, 0, canvas.width, canvas.height );
                    var image = canvas.toDataURL();
                    var success = image.length > 100000;
                    if ( success ) {
                        // var img = document.createElement('img');
                        // img.src = image;
                        return image;
                        // document.getElementsByTagName('div')[0].appendChild(img);
                        // URL.revokeObjectURL(url);
                    }
                    return success;
                };
                video.addEventListener( 'timeupdate', timeupdate );
                video.preload = 'metadata';
                video.src = url;
                // Load video in Safari / IE11
                video.muted = true;
                // video.playsInline = true;
                video.play();
            };
            fileReader.readAsArrayBuffer( file );
        }
    }
    youtubeURLtoID( url ) {
        if ( url != null && url != '' ) {
            if ( url.indexOf( "http" ) == 0 ) {
                return url.substring( url.lastIndexOf( "?v=" ) + 3 );
            } else {
                return url;
            }
        }
    }
    
    newtag(){
        if(this.tags != ''){
            let model = {
                tag:this.tags,
                active:'Pending'
            }
            this.dbserv.save("loupetagssave",model).subscribe(res => {
                if(res.type=="success")
                {
                    this._alert.create(res.type,res.message);
                    this.tags = '';
                    this.dbserv.getAll("loupetagslist").subscribe(res => { this.tagslist = res.records;});
                }
                else if(res.type=="expired")
                {
                    this.router.navigateByUrl('/login') ;   
                }
                else
                {
                    this._alert.create(res.type,res.message);
                }
            }); 
        }
    }
    removeMedia(inx){
        this.model.mainphoto[inx] = _.cloneDeep( this.imagesmodel );
    }
}
