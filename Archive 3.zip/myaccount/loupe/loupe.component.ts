import { Component, OnInit, ElementRef, ViewChild,AfterViewChecked } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../services/dbservice.service';
import { AuthenticationService } from '../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser';
import { LoupemarkersComponent } from './loupemarkers/loupemarkers.component';
@Component({
  selector: 'app-loupe',
  templateUrl: './loupe.component.html',
  styleUrls: ['./loupe.component.css']
})
export class LoupeComponent implements OnInit,AfterViewChecked {
    @ViewChild('lnktimelinemarkers') lnktimelinemarkers:ElementRef;
    @ViewChild('loupemarker') loupemarker:LoupemarkersComponent
    @ViewChild('lnktimelinesharebox') lnktimelinesharebox:ElementRef;
/*  @ViewChild('canvas') canvas;*/
    loggedin="No";
    
    mysummary = {Published:0, Workinprogress:0,Trash:0,Saved:0,Total:0};
    wasClicked:boolean = false;
    latitude:any;
    longitude:any;
    visiblefilter = false;
    custo_filter_onen_close = false;
    userid = 0;
    mytotalitems: any;
    mylastpage: number = 1;
    mypage: number = 1;
    mylimit:number = 12;
    websiteroot = '';
    savedtotalitems: any;
    savedlastpage: number = 1;
    savedpage: number = 1;
    savedlimit:number = 12;
    saveditems = [];
    productid = 0;
    params:any = {searchfield:""};
    myitems = [];
    genderfilter = 'Both';
    rootpath = '';
    visittype = '';
    options:any;
    currtime:any;
    activeone = true;
    activetwo = false;
    
    mysharedreviewid = 0;
    mysharedtype = 'Review Product';
    mysharedurl = '';
    mysharedescription = '';
    mysharedtitle = '';
    mysharedimage = '';

    releaseyears = [];
    selectedtype: any = {};
    selectedcats: any = {};
    selectedseasons: any = {};
    selectedreleaseyears: any = {};
    categories:any;
    sortby = '';
    loading = false;
    loading2 = false;

    constructor(private sanitizer:DomSanitizer,private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private cookieService: CookieService) {
        this.rootpath = localStorage.getItem('baseurl');
        this.currtime = Math.random();
        this.websiteroot = localStorage.getItem('basewebsiteurl');
        this.visittype = localStorage.getItem('visittype');
    }
    
    ngOnInit() {
        scroll(0,0);
        this.categories = [];
            this.dbserv.getAll("loupeallcatlist/"+this.visittype).subscribe(res => { 
            this.categories = res;
        });

        if (window.navigator && window.navigator.geolocation) {
            window.navigator.geolocation.getCurrentPosition(
                position => {
                    console.log(position);
                    this.latitude = position.coords.latitude;
                    this.longitude = position.coords.longitude;
                },
                error => {
                    switch (error.code) {
                        case 1:
                            console.log('Permission Denied');
                            break;
                        case 2:
                            console.log('Position Unavailable');
                            break;
                        case 3:
                            console.log('Timeout');
                            break;
                    }
                }
            );
        };

        let currentYear = new Date().getFullYear();
        let yearItems = [];
        for(let i = currentYear; i >= 2000; i--){
            yearItems.push(i);
        }
        this.releaseyears = yearItems;

        this.loadmyrecs(this.mypage);
         $(".custo-filter-colap").click(function(e){
            if(!$(this).hasClass('custo_filter_onen_close')){
                $(this).next(".utl-filter-box").addClass('visiblefilter');
                $(this).addClass('custo_filter_onen_close');
                e.stopPropagation();
            }else{
                $(".utl-filter-box").removeClass('visiblefilter');
                $(".custo-filter-colap").removeClass('custo_filter_onen_close');
                e.stopPropagation();
            }
        });

        $(".utl-filter-box").click(function(e){
            e.stopPropagation();
        });

        $(document).click(function(){
            $(".utl-filter-box").removeClass('visiblefilter');
            $(".custo-filter-colap").removeClass('custo_filter_onen_close');
        });
        	if (this.authserv.isloggedin()) {
			this.loggedin = "Yes";
		}
     
    }
    ngAfterViewChecked()
    {
        /*this.context = this.canvas.nativeElement.getContext("2d");
        console.log(this.context);*/
    }
    showimages(item)
    {
        let images = [];
        if(item.mainphoto1tvp=="Image" && item.mainphoto1)
        {
            let rec = {type:item.mainphoto1tvp,media:item.mainphoto1};
            images.push(rec);
        }
        if(item.mainphoto12tvp=="Image" && item.mainphoto2)
        {
            let rec = {type:item.mainphoto2tvp,media:item.mainphoto2};
            images.push(rec);
        }
        if(item.mainphoto3tvp=="Image" && item.mainphoto3)
        {
            let rec = {type:item.mainphoto3tvp,media:item.mainphoto3};
            images.push(rec);
        }
        if(item.mainphoto4tvp=="Image" && item.mainphoto4)
        {
            let rec = {type:item.mainphoto4tvp,media:item.mainphoto4};
            images.push(rec);
        }
        if(item.mainphoto5tvp=="Image" && item.mainphoto5)
        {
            let rec = {type:item.mainphoto5tvp,media:item.mainphoto5};
            images.push(rec);
        }
        if(item.mainphoto6tvp=="Image" && item.mainphoto6)
        {
            let rec = {type:item.mainphoto6tvp,media:item.mainphoto6};
            images.push(rec);
        }
        let mediastring = '';
        this.currtime = Math.random();
        
        if(images.length>2)
        {
            if(images.length>1)
            {
                mediastring+='<img class="list-opa-one" src="'+this.rootpath+'assets/loupe/'+images[0].media+'?newtime='+this.currtime+'" alt="porduct-img">';
            }
            if(images.length>2)
            {
                mediastring+='<img class="list-opa-two" src="'+this.rootpath+'assets/loupe/'+images[1].media+'?newtime='+this.currtime+'" alt="porduct-img">';
            }
        }
        else
        {
            if(images.length>1)
            {
                mediastring+='<img src="'+this.rootpath+'assets/loupe/'+images[0].media+'?newtime='+this.currtime+'" alt="porduct-img">';
            }
        }
        return mediastring;
        
    }
    throttle = (250 * 3);
    scrollDistance = 1;
    scrollUpDistance = 2;
    onScrollDownMyRecs() {
        //console.log("my");
        if(this.mytotalitems>this.myitems.length){
            this.mypage++;
            this.loadmyrecs(this.mypage);
        }
    }
    loadmyrecs(page:number)
    {
        let srhmodel = {
            selectedtype:this.selectedtype,
            selectedcats:this.selectedcats,
            selectedseasons:this.selectedseasons,
            selectedreleaseyears:this.selectedreleaseyears,
            sortby:this.sortby,
            latitude:this.latitude,
            longitude:this.longitude
        };
        this.currtime = Math.random();
        this.loading = true;
        this.dbserv.post("myloupes/"+this.genderfilter+"/"+page+"/"+this.mylimit,srhmodel).subscribe(res => {
                    if(res.type=="success")
                    {
                        
                        if(page == 1)
                            this.myitems = [];
                if(res.records.total>this.myitems.length)
                this.myitems = [ ...this.myitems, ...res.records.data]
            

                        //this.myitems = res.records.data;
                        this.mypage = res.records.current_page;
                        this.mylastpage = res.records.last_page; 
                        this.mytotalitems = res.records.total;
                        
                        this.dbserv.post("myloupessummary/"+this.genderfilter+"/"+page+"/"+this.mylimit,srhmodel)
                        .subscribe(res => {
                            if(res.type=="success"){
                                this.mysummary = res.records;
                            }
                        });
                    }
                    else if(res.type=="expired")
                    {
                        this.router.navigateByUrl('/login') ;   
                    }
                    else
                        this._alert.create(res.type,res.message); 

                    this.loading = false;
                   
        }); 
    }
    throttleSave = (250 * 3);
    scrollSaveDistance = 1;
    scrollUpSaveDistance = 2;
    onScrollDownSaveRecs() {
        if(this.savedtotalitems>this.saveditems.length){
            this.savedpage++;
            this.loadsavedrecs(this.savedpage);
        }
    }

    loadsavedrecs(page:number)
    {
        let srhmodel = {
            selectedtype:this.selectedtype,
            selectedcats:this.selectedcats,
            selectedseasons:this.selectedseasons,
            selectedreleaseyears:this.selectedreleaseyears,
            sortby:this.sortby
        };
        this.currtime = Math.random();
        this.loading2 = true;
        this.dbserv.post("savedloupes/"+this.genderfilter+"/"+page+"/"+this.savedlimit,srhmodel).subscribe(res => {
                    if(res.type=="success")
                    {
                        // console.log(res.records.data);

                        if(page == 1)
                            this.saveditems = [];
                if(res.records.total>this.saveditems.length)
                this.saveditems = [ ...this.saveditems, ...res.records.data]

                        //this.saveditems = res.records.data;
                        this.savedpage = res.records.current_page;
                        this.savedlastpage = res.records.last_page; 
                        this.savedtotalitems = res.records.total;
                    }
                    else if(res.type=="expired")
                    {
                        this.router.navigateByUrl('/login') ;   
                    }
                    else
                        this._alert.create(res.type,res.message); 

                    this.loading2 = false;
                   
        }); 
    }
    tabcontent(tab:string)
    {
        if(tab=='photo')
        {
            this.activeone = true;
            this.activetwo = false;
            
            $("#tab1").css("display",'block');
            $("#tab2").css("display",'none');
        
            this.selectedtype = {};
            this.selectedcats = {};
            this.selectedseasons = {};
            this.selectedreleaseyears = {};
            this.sortby = "";
            this.loadmyrecs(1);
        }
        else
        {
            this.activeone = false;
            this.activetwo = true;
            
            $("#tab1").css("display",'none');
            $("#tab2").css("display",'block');

            this.selectedtype = {};
            this.selectedcats = {};
            this.selectedseasons = {};
            this.selectedreleaseyears = {};
            this.sortby = "";
            this.loadsavedrecs(1);
        }
    }
/*    likeme(id,type,inx)
    {
        console.log(id,type,inx);
        let params = {loupeid:id,status:type};
        this.dbserv.post("loupelike",params).subscribe(res => {
                                                                if(res.type=="success")
                                                                {
                                                                    if(type=="like")
                                                                    {
                                                                        $("#reclike" + id).css("display","none");
                                                                        $("#recunlike" + id).css("display","block");
                                                                    }
                                                                    else if(type=="unlike")
                                                                    {
                                                                        $("#reclike" + id).css("display","block");
                                                                        $("#recunlike" + id).css("display","none");
                                                                    }
                                                                    // console.log("1",this.saveditems);
                                                                    this.saveditems[inx].liked = res.total;
                                                                    // console.log("2",this.saveditems);
                                                                    // this.loadmyrecs(this.mypage);
                                                                    // this.loadsavedrecs(this.savedpage);
                                                                }

                                                                else if(res.type=="expired")
                                                                {
                                                                    this.router.navigateByUrl('/login') ;   
                                                                }
                                                                else
                                                                    this._alert.create(res.type,res.message);
                                                        });
    }
    saveme(id,type,inx)
    {
        let params = {loupeid:id,status:type};
        this.dbserv.post("loupemysavedlist",params).subscribe(res => {
                                                                if(res.type=="success")
                                                                {
                                                                    if(type=="save")
                                                                    {
                                                                        $("#recsave" + id).css("display","none");
                                                                        $("#recunsave" + id).css("display","block");
                                                                    }
                                                                    else if(type=="unsave")
                                                                    {
                                                                        $("#recsave" + id).css("display","block");
                                                                        $("#recunsave" + id).css("display","none");
                                                                    }
                                                                    // this.loadmyrecs(this.mypage);
                                                                    this.loadsavedrecs(this.savedpage);
//                                                                    this.saveditems[inx].saved = res.total;
                                                                }
                                                                else if(res.type=="expired")
                                                                {
                                                                    this.router.navigateByUrl('/login') ;   
                                                                }
                                                                else
                                                                    this._alert.create(res.type,res.message);
                                                        });
    }*/
    likeme(id,type,inx,arraylist)
    {
        let params = {loupeid:id,status:type};
        this.dbserv.post("loupelike",params).subscribe(res => {
                                                                if(res.type=="success")
                                                                {
                                                                    if(type=="like")
                                                                    {
                                                                        if(arraylist == 'mi'){
                                                                            $("#mreclike" + id).css("display","none");
                                                                            $("#mrecunlike" + id).css("display","block");
                                                                        }else{
                                                                            $("#reclike" + id).css("display","none");
                                                                            $("#recunlike" + id).css("display","block");
                                                                        }
                                                                    }
                                                                    else if(type=="unlike")
                                                                    {
                                                                        if(arraylist == 'mi'){
                                                                            $("#mreclike" + id).css("display","block");
                                                                            $("#mrecunlike" + id).css("display","none");
                                                                        }else{
                                                                            $("#reclike" + id).css("display","block");
                                                                            $("#recunlike" + id).css("display","none");
                                                                        }
                                                                    }
                                                                    // this.loadpage(this.page,false);
                                                                    /*this._alert.create(res.type,res.message+type);*/
                                                                    if(arraylist == 'mi')
                                                                        this.myitems[inx].liked = res.total;
                                                                    if(arraylist == 'sl')
                                                                        this.saveditems[inx].liked = res.total;
                                                                }
                                                                else if(res.type=="expired")
                                                                {
                                                                    this.router.navigateByUrl('/login') ;   
                                                                }
                                                                else
                                                                    this._alert.create(res.type,res.message);
                                                        });
    }
        saveme(id,type,inx,arraylist)
        {
            let params = {loupeid:id,status:type};
            this.dbserv.post("loupemysavedlist",params).subscribe(res => {
                                                                    if(res.type=="success")
                                                                    {
                                                                        if(type=="save")
                                                                        {
/*                                                                          $("#recsave" + id).css("display","none");
                                                                            $("#recunsave" + id).css("display","block");
*/                                                                      if(arraylist == 'mi'){
                                                                            $("#mrecsave" + id).css("display","none");
                                                                            $("#mrecunsave" + id).css("display","block");
                                                                        }else{
                                                                            $("#recsave" + id).css("display","none");
                                                                            $("#recunsave" + id).css("display","block");
                                                                        }

                                                                        }
                                                                        else if(type=="unsave")
                                                                        {
                                                                            if(arraylist == 'mi'){
                                                                                $("#mrecsave" + id).css("display","block");
                                                                                $("#mrecunsave" + id).css("display","none");
                                                                            }else{
                                                                                $("#recsave" + id).css("display","block");
                                                                                $("#recunsave" + id).css("display","none");
                                                                            }
                                                                        }
                                                                        // this.loadpage(this.page,false);
                                                                        if(arraylist == 'mi')
                                                                            this.myitems[inx].saved = res.total;
                                                                        if(arraylist == 'sl')
                                                                            this.saveditems[inx].saved = res.total;
                                                                            this.loadsavedrecs(this.savedpage);
                                                                        /*this._alert.create(res.type,res.message+type);*/
                                                                    }
                                                                    else if(res.type=="expired")
                                                                    {
                                                                        this.router.navigateByUrl('/login') ;   
                                                                    }
                                                                    else
                                                                        this._alert.create(res.type,res.message);
                                                            });
        }
    shareme(currrec,type)
    {
        if(type=="Product")
        {
            this.mysharedtype = 'Review Product';
            this.mysharedurl = this.websiteroot+"loupe/product/"+currrec.id;
        }
        else
        {
            this.mysharedtype = 'Review Service';
            this.mysharedurl = this.websiteroot+"loupe/service/"+currrec.id;
        }
        this.currtime = Math.random();
        
        this.mysharedescription = currrec.title;
        this.mysharedtitle = currrec.shortdesc;
        this.mysharedreviewid = currrec.id;
        let images = [];
        if(currrec.mainphoto1tvp=="Image" && currrec.mainphoto1)
        {
            let rec = {type:currrec.mainphoto1tvp,media:currrec.mainphoto1};
            images.push(rec);
        }
        if(currrec.mainphoto2tvp=="Image" && currrec.mainphoto2)
        {
            let rec = {type:currrec.mainphoto2tvp,media:currrec.mainphoto2};
            images.push(rec);
        }
        if(currrec.mainphoto3tvp=="Image" && currrec.mainphoto3)
        {
            let rec = {type:currrec.mainphoto3tvp,media:currrec.mainphoto3};
            images.push(rec);
        }
        if(currrec.mainphoto4tvp=="Image" && currrec.mainphoto4)
        {
            let rec = {type:currrec.mainphoto4tvp,media:currrec.mainphoto4};
            images.push(rec);
        }
        if(currrec.mainphoto5tvp=="Image" && currrec.mainphoto5)
        {
            let rec = {type:currrec.mainphoto5tvp,media:currrec.mainphoto5};
            images.push(rec);
        }
        if(currrec.mainphoto6tvp=="Image" && currrec.mainphoto6)
        {
            let rec = {type:currrec.mainphoto6tvp,media:currrec.mainphoto6};
            images.push(rec);
        }
        if(images.length>1)
        {
            this.mysharedimage = this.rootpath+'assets/loupe/'+images[0].media+'?newtime='+this.currtime;;
        }
        this.lnktimelinesharebox.nativeElement.click();
        
//      lnktimelinesharebox
    }
    productsmakers(id)
    {
        this.productid = id;
        this.loupemarker.showmainproduct(this.productid);
        this.lnktimelinemarkers.nativeElement.click();  
    }
    filterby()
    {
        console.log('click');
        this.wasClicked = !this.wasClicked;
        if(this.wasClicked)
        {
            console.log('TRUE');
            this.custo_filter_onen_close = true;
            this.visiblefilter = true;
            
        }
        else
        {
            console.log('FALSE');
            this.custo_filter_onen_close = false;   
            this.visiblefilter = false; 
        }

    }

    add3Dots(string, limit)
    {
    if(string != null && string != undefined){
      var dots = "...";
      if(string.length > limit)
      {
        // you can also use substr instead of substring
        string = string.substring(0,limit) + dots;
      }
        return string;
        }
    }
    
    /// Popup marker code
    /*record = {id:0,user_id:0,category_id:0,brand_id:0,shortdesc:'',title:"",type:"",gender:"",productline:"",season:"",overview:"",material:"",materialrate:0,craftsmanship:"",craftsmanshiprate:0,designnstyle:"",designnstylerate:0,usage:"",usagerate:0,exclusivity:"",exclusivityrate:0,conclusions:"",coverphototvp:"",coverphoto:"",mainphoto1tvp:"",mainphoto1:"",mainphoto2tvp:"",mainphoto2:"",mainphoto3tvp:"",mainphoto3:"",mainphoto4tvp:"",mainphoto4:"",mainphoto5tvp:"",mainphoto5:"",mainphoto6tvp:"",mainphoto6:"",created_at:"",updated_at:"",active:"",brand:"",category:"",username:"",image:""};
    model = {id:0,title:'',description:'',xpos:0,ypos:0};
    markerColor:string = "#FF0000";
    context:CanvasRenderingContext2D;
    originalmarkers: number[][] = [];/*[25, 25], [50, 50], [75, 75]
    markers: number[][];
    markerlist = [];
    showmainproduct(id)
    {
        this.productid = id;
        
        this.dbserv.getById("getproductreview/Product",this.productid).subscribe(res => {
                                                    if(res.type=="success"){
                                                        this.record=res.data;
                                                        this.dbserv.getById("getproductmarkers",this.productid).subscribe(res1 => {
                                                            if(res1.type=="success"){
                                                                this.markers = [];
                                                                this.markerlist=res1.data;
                                                                for(let i = 0; i < this.markerlist.length; i++) {
                                                                    let item: [number, number] = [this.markerlist[i].xpos,this.markerlist[i].ypos];
                                                                    this.markers.push(item);
                                                                };
                                                                console.log(this.markers);
                                                            }
                                                            
                                                        }); 
                                                    }
                                                });
        
    }
    saverecord()
    {
        this.markerlist[this.model.id] = this.model;
        let reclist = {recs:this.markerlist,productid:this.productid};
        this.dbserv.post("saveloupemarker",reclist).subscribe(res => {
                                                            this.showmainproduct(this.productid);
                                                            this.model = {id:0,title:'',description:'',xpos:0,ypos:0};
                                                        }); 
    }
    markpoint($event)
    {
        console.log($event);    
    }*/
    street(id){
		$("#ellipsis-"+id).children().toggleClass('fa fa-ellipsis-h fa fa-ellipsis-v');
		$("#street-"+id).toggle();
	}
    //Popup marker code end here..
    youtubeURLtoID( url ) {
        if ( url != null && url != '' ) {
            if ( url.indexOf( "http" ) == 0 ) {
                return url.substring( url.lastIndexOf( "?v=" ) + 3 );
            } else {
                return url;
            }
        }
    }
}
