import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrgdirectoryComponent } from './orgdirectory.component';

describe('OrgdirectoryComponent', () => {
  let component: OrgdirectoryComponent;
  let fixture: ComponentFixture<OrgdirectoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrgdirectoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrgdirectoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
