import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orgdirectory',
  templateUrl: './orgdirectory.component.html',
  styleUrls: ['./orgdirectory.component.css']
})
export class OrgdirectoryComponent implements OnInit {

	options:any;
	constructor() { }
	
	ngOnInit() {
	}
}
