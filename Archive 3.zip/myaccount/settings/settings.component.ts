import { Component, OnInit } from '@angular/core';
import { DbserviceService } from '../services/dbservice.service';
import { AuthenticationService } from '../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import { AlertsService } from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import $ from 'jquery';

@Component( {
    selector: 'app-settings',
    templateUrl: './settings.component.html',
    styleUrls: ['./settings.component.css']
} )
export class SettingsComponent implements OnInit {
    gmodel = { id: 0, maritalstatus: "", occupation: "", birthday: "", country: "", state: "", city: "", zipcode: "", aboutme: "", facebook: "", twitter: "", linkedin: "", instagram: "", pinterest: "", youtube: "", google: "", website: "", gender: "", firstname: "", lastname: "", name: "", email: "",mobilecode:"",mobileno:"",connectiontype:"", };
    record = {id:0,name:"",email:"",usertype:"",verified:"",image:"",updated_at:"",firstname:"",lastname:"",gender:"",maritalstatus:"",occupation:"",birthday:"",mobileno:"",country:"",state:"",city:"",zipcode:"",initials:"",aboutme:"",connectiontype:""};
    wasClicked: boolean = false;
    currentmenu: number = 0;
    on = false;
    options: any;
    visittype = '';
    userid = 0;
    active1 = true;
    active2 = false;
    active3 = false;
    active4 = false;
    active5 = false;

    constructor( private authserv: AuthenticationService, private _alert: AlertsService, private dbserv: DbserviceService, private router: Router, private cookieService: CookieService ) {
        this.visittype = localStorage.getItem( 'visittype' );

    }

    kswitch() {
        this.wasClicked = !this.wasClicked;
        if ( this.wasClicked ) {
            this.on = true;
        }
        else {
            this.on = false;
        }
    }

    tabcontent( tab: string ) {
        if ( tab == 'Details' ) {
            this.active1 = true;
            this.active2 = false;
            this.active3 = false;
            this.active4 = false;
            this.active5 = false;
        }
        else if ( tab == 'Privacy' ) {
            this.active1 = false;
            this.active2 = true;
            this.active3 = false;
            this.active4 = false;
            this.active5 = false;
        }
        else if ( tab == 'Notifications' ) {
            this.active1 = false;
            this.active2 = false;
            this.active3 = true;
            this.active4 = false;
            this.active5 = false;
        }
        else if ( tab == 'Shipping' ) {
            this.active1 = false;
            this.active2 = false;
            this.active3 = false;
            this.active4 = true;
            this.active5 = false;
        }
        else {
            this.active1 = false;
            this.active2 = false;
            this.active3 = false;
            this.active4 = false;
            this.active5 = true;
        }
    }
    ngOnInit() {
        
        if ( this.authserv.isloggedin() ) {
            this.authserv.session().subscribe( res => {
                if ( res.isnew == 'Yes' )
                    this.router.navigate( ['/home'] );
            } );
            this.userid = +this.authserv.getUserId();
            this.gmodel.id = this.userid;
            this.dbserv.getById( "getaboutinto", this.userid ).subscribe( res => {
                this.gmodel = res.data;
                this.gmodel.name = res.user.name;
            } );
            this.dbserv.getById("getuserdetail",this.userid).subscribe(res => {
                if(res.type=="success")
                {
                    this.record = res.data;
                }
                
            });
        }
        else
            this.router.navigate( ["/login"] );
        this.dbserv.getById( "getaboutinto", this.userid ).subscribe( res => {
            this.gmodel = res.data;
            this.gmodel.name = res.user.name;
            this.gmodel.email = res.user.email;
        } );
    }
    savegeneralrec()
    {

        this.dbserv.save("saveaboutinto",this.gmodel).subscribe(res => {
            
                                                           this._alert.create(res.type,res.message);
                                                         });    
    }
}
