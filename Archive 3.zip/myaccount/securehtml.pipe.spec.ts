import { SecureurlPipe } from './securehtml.pipe';

describe('SecurehtmlPipe', () => {
  it('create an instance', () => {
    const pipe = new SecurehtmlPipe();
    expect(pipe).toBeTruthy();
  });
});
