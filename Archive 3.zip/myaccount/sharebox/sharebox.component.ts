import { Component,OnInit,Input} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import { AuthenticationService } from '../../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';

@Component({
  selector: 'app-sharebox',
  templateUrl: './sharebox.component.html',
  styleUrls: ['./sharebox.component.css']
})
export class ShareboxComponent implements OnInit {
	@Input() recordid: string;
	@Input() sharedurl: string;
	@Input() sharedescription: string;
	@Input() sharedtitle: string;
	@Input() sharedimage: string;
	@Input() sharedtype: string;
	rootpath = '';
	currtime:any;
	myusers = [];
	selectedusers:any;
	settings = {};
	shareoption = "Private";
	options:any;
	constructor(private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private cookieService: CookieService) {
		this.rootpath = localStorage.getItem('baseurl');
		this.currtime = Math.random();
		this.selectedusers = [];
		this.settings = { 
						  singleSelection: false, 
						  text:"Select Tags",
						  selectAllText:'Select All',
						  unSelectAllText:'UnSelect All',
						  enableSearchFilter: true,
						  limitSelection:4,
						  enableCheckAll:false,
						  classes:"myclass custom-class"
						};
	}
	ngOnInit() {
		this.dbserv.getAll("pubinboxfriends").subscribe(res => {
														if(res.type=="success")
															this.myusers = res.data;
														else
														{
															//this.router.navigate(['/login']);	  
														}
													});
	}
	shareonsite()
	{
		if(this.shareoption=="Private" || this.shareoption=="Friend")
		{
			let model = {permit:this.shareoption,fromid:this.recordid,type:this.sharedtype};
			this.dbserv.save("timelineshare",model).subscribe(res => { 
										   this._alert.create(res.type,res.message);
										});
		}
		else if(this.shareoption=="Message")
		{
			let idslist = [];
			if(this.selectedusers.length>0)
			{
				for(let i=0;i<this.selectedusers.length;i++)
				{
					idslist[i] = this.selectedusers[i].id;
				}
			}
			
			let model = {fromid:this.recordid,type:this.sharedtype,users:idslist};
			this.dbserv.save("sharemessagetoinbox",model).subscribe(res => { 
										   this._alert.create(res.type,res.message);
										});
		}
			
	}
	onItemSelect(item:any){
        /*console.log(item);*/
        console.log(this.selectedusers);
    }
    OnItemDeSelect(item:any){
        /*console.log(item);*/
        console.log(this.selectedusers);
    }
    onSelectAll(items: any){
        console.log(this.selectedusers);
    }
    onDeSelectAll(items: any){
        console.log(this.selectedusers);
    }
}