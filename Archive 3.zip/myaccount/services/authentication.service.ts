import { Injectable } from '@angular/core';
import { Http, Headers, Response,RequestOptions} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
@Injectable()
export class AuthenticationService {
	serviceBase:string = "";
	public token: string;
	constructor(private http: Http) {
		// set token if saved in local storage
        var currentUser = JSON.parse(localStorage.getItem('currentUser'));
		this.serviceBase = localStorage.getItem('apiurl');
        this.token = currentUser && currentUser.token;	
	}
	private handleError(error: Response | any) {
        console.error(error);
        return Observable.throw(error); // <= B
    }
	adminsession() {
		return this.http.get(this.serviceBase + 'user',this.jwt());
    }
	session() {
		return this.http.get(this.serviceBase + 'user',this.jwt()).map((response: Response) => response.json()).catch(e => {
																	if (e.status === 401) {
																	
																		return Observable.throw('Unauthorized');
																	}
																	// do any other checking for statuses here
																});
    }
	login(email: string, password: string) {
        return this.http.post(this.serviceBase + 'authenticate', JSON.stringify({ email: email, password: password }))
            .map((response: Response) => {
                // login successful if there's a jwt token in the response
				 let user = response.json();
                if (user && user.token) {
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                    localStorage.setItem('currentUser', JSON.stringify(user));
                }
				  
            });
    }
	isloggedin():boolean
	{
		let user = JSON.parse(localStorage.getItem('user'));
		if (user && user.id) {
            return true;
        }
		
		return false;
	}
	getUserId():number
	{
		let user = JSON.parse(localStorage.getItem('user'));
		if (user && user.id) {
            return user.id;
        }
		
		return 0;
	}
	getUserName():string
	{
		let user = JSON.parse(localStorage.getItem('user'));
		if (user && user.name) {
            return user.name;
        }
		return 'guest';
	}
	getUserImage():string
	{
		let user = JSON.parse(localStorage.getItem('user'));
		if (user && user.image) {
            return user.image;
        }
		return 'assets/img/img-def1.png';
	}
	getUserType():string
	{
		let user = JSON.parse(localStorage.getItem('user'));
		if (user && user.usertype) {
            return user.usertype;
        }
		return 'gues';
	}
	gettoken()
	{
		let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser && currentUser.token) {
            return currentUser.token;
        }
		return '';
	}
	private jwt() {
        // create authorization header with jwt token
        let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser && currentUser.token) {
            let headers = new Headers({ 'Authorization': 'Bearer ' + currentUser.token });
            return new RequestOptions({ headers: headers });
        }
    }
    logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
    }

}
