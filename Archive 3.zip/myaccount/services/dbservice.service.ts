import { Injectable } from '@angular/core';
import { Http, Headers, Response,RequestOptions} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'
import $ from 'jquery';
@Injectable()
export class DbserviceService {
	serviceBase:string = "";
	public token: string;
	constructor(private http: Http) {
		// set token if saved in local storage
		var currentUser = JSON.parse(localStorage.getItem('currentUser'));
		this.token = currentUser && currentUser.token;	
		this.serviceBase = localStorage.getItem('apiurl');
	}
	showloader(status)
	{
		if(status)
			$(".myloaderdiv").css('display','block');
		else
			$(".myloaderdiv").css('display','none');
	}
	//Non registered calls
	getdirectAll(callurl:string) {
        return this.http.get(this.serviceBase + callurl).map((response: Response) => response.json());
    }
	getdirectpost(callurl:string, obj: any) {
        return this.http.post(this.serviceBase + callurl, obj).map((response: Response) => response.json());
    }
	getByStringId(callurl:string, id: string) {
        return this.http.get(this.serviceBase + callurl + '/' + id).map((response: Response) => response.json());
    }
	post(callurl:string, obj: any) {
       this.showloader(true);
	   return this.http.post(this.serviceBase + callurl, obj, this.jwt()).map((response: Response) => { this.showloader(false); return response.json(); }).catch(e => {
																	if (e.status === 400 || e.status === 401) {
																		this.showloader(false);
																		return Observable.throw('Unauthorized');
																	}
																	this.showloader(false);
																});
    }
	get(callurl:string) {
		this.showloader(true);
        return this.http.get(this.serviceBase + callurl, this.jwt()).map((response: Response) => { this.showloader(false); return response.json(); }).catch(e => {
																	if (e.status === 400 || e.status === 401) {
																		this.showloader(false);
																		return Observable.throw('Unauthorized');
																	}
																	this.showloader(false);
																});
    }
	saveimage(callurl:string, obj: any) {
        return this.http.post(this.serviceBase + callurl, obj, this.jwtmultypart()).map((response: Response) => {return response.json(); }).catch(e => {
																	if (e.status === 400 || e.status === 401) {
																		localStorage.removeItem('currentUser');
																		/*this.router.navigateByUrl('login') ;*/
																		return Observable.throw('Unauthorized');
																	}
																});
    }

	//registered user calls
	getAll(callurl:string) {
        return this.http.get(this.serviceBase + callurl, this.jwt()).map((response: Response) => response.json());
    }

    getById(callurl:string, id: number) {
        return this.http.get(this.serviceBase + callurl + '/' + id, this.jwt()).map((response: Response) => response.json());
    }
    save(callurl:string, obj: any) {
        return this.http.post(this.serviceBase + callurl, obj, this.jwt()).map((response: Response) => response.json());
    }

    delete(callurl:string, id: number) {
        return this.http.get(this.serviceBase + callurl + '/' + id, this.jwt()).map((response: Response) => response.json());
    }
	private jwtmultypart() {
        // create authorization header with jwt token
        let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser && currentUser.token) {
            let headers = new Headers({ 'Authorization': 'Bearer ' + currentUser.token,"enctype":"multipart/form-data"});
            return new RequestOptions({ headers: headers });
        }
    }
    // private helper methods
	gettoken()
	{
		let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser && currentUser.token) {
            return currentUser.token;
        }
		return '';
	}
    private jwt() {
        // create authorization header with jwt token
        let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser && currentUser.token) {
            let headers = new Headers({ 'Authorization': 'Bearer ' + currentUser.token });
            return new RequestOptions({ headers: headers });
        }
    }
}
