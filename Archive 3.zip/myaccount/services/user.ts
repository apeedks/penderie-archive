export class User {
    id: number;
	name: string;
    email: string;
    usertype: string;
    created_at: string;
	updated_at: string;
}