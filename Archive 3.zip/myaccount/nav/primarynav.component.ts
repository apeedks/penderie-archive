import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationService } from '../../services/authentication.service';
import { TranslateService } from '../../translate';
import {AlertsService} from '@jaspero/ng2-alerts';
import $ from 'jquery';
@Component({
  selector: 'app-primarynav',
  templateUrl: './primarynav.component.html',
  styles: [
  `
		.header-user-info{
		padding-top: 7px;
		float: right;
		}
  `]


})
export class PrimarynavComponent implements OnInit {
	isuserloggedin:boolean = false;
	userid:number = 0;
	userfullname:string='';
	model: any = {};
    loading = false;
	returnUrl: string;
	validation_message = '';
	constructor(private _translate: TranslateService,private route: ActivatedRoute,private router: Router,private authserv: AuthenticationService,private _alert: AlertsService) { }
	
	ngOnInit() {
		this.userid = this.authserv.getUserId();
		if(this.userid>0)
		{
			this.isuserloggedin = true;
			this.userfullname = this.authserv.getUserName();
		}
	}
	login() {
        this.loading = true;
        this.authserv.login(this.model.email, this.model.password)
            .subscribe(
                data => {
                    this.validation_message = 'Oops! Looks like your email or password is incorrect.';
					this.router.navigate(['myaccount']);
                },
                error => {
					this.validation_message = '';
                    //this._alert.create('error',this._translate.instant('Invalid login credentials.'));
                    this.loading = false;
                });
    }
	funcsearchclicked()
	{
		$('body').toggleClass('custo-search-open')
		$('.search-clicker').toggleClass('search-cross')
	}
	logout() {
        this.authserv.logout();
		this.router.navigate(['home']);
    }
}
