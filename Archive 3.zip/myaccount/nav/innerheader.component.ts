import { Component, OnInit, OnDestroy, trigger, state, style, transition, animate, Input, Output, EventEmitter, HostListener, ElementRef, ViewChild  } from '@angular/core';
import {DbserviceService} from '../services/dbservice.service';
import { AuthenticationService } from '../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import {ImageCropperComponent, CropperSettings} from 'ng2-img-cropper';
import $ from 'jquery';
//import { Observable } from "rxjs";
//import { IntervalObservable } from "rxjs/observable/IntervalObservable";
//import 'rxjs/add/operator/takeWhile';

import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/observable/interval';
import 'rxjs/add/operator/takeUntil';

@Component({
  selector: 'app-innerheader',
  templateUrl: './innerheader.component.html',
  styleUrls: ['./innerheader.component.css'],
  animations: [
    trigger('slideInOut', [
      state('in', style({
        transform: 'translate3d(0, 0, 0)'
      })),
      state('out', style({
        transform: 'translate3d(100%, 0, 0)'
      })),
      transition('in => out', animate('400ms ease-in-out')),
      transition('out => in', animate('400ms ease-in-out'))
    ]),
  ]
})
export class InnerheaderComponent implements OnInit,OnDestroy {
	@ViewChild('lnksaveprofilebox') lnksaveprofilebox:ElementRef;
	@ViewChild('lnksavesymbolbox') lnksavesymbolbox:ElementRef;
	imagedata: any;
	imagepreviewurl2:string;
	websiteroot:string;
	cropperSettings: CropperSettings;
	symbol = {backtype1:'',backtype:'',backtype2:'',initial1:'',initial2:'',initial3:'',frontfont:"",frontcolor:"#C0C0C0",background:'',background1:'#C0C0C0',background2:'#C0C0C0'};
	@ViewChild('menulinkexpcoll') menulinkexpcoll:ElementRef;
	@ViewChild('cropper', undefined) cropper:ImageCropperComponent;
	dragAreaClass:string='dragarea';
	uploadedimage:any=null;
	uploadedsymbol:any=null;
	symbolimage = '';
	uploadedimagebtn:boolean=false;
	uploadedsymbolbtn:boolean=false;
	imagepreviewurl:string='';
	menuexpanddown = "collapse show";
	wasClicked = true;
	rootpath = '';
	options:any;
	currtime:any;
	menuState:string = 'in';
	visittype:string = "";
	penderie_user_id:number=0;
	username:string;
	penderie_user_type:string='';
	userid = 0;
	loggedin = false;
	dashleftpannel = false;
	dashdesignpannel = false;
	userfullname:string='';
	usertype = '';
	record = {id:0,name:"",email:"",usertype:"",verified:"",image:"",imagesrc:'',background:"",backtype:"",frontfont:"",frontcolor:"",symbol:"",updated_at:"",firstname:"",lastname:"",gender:"",maritalstatus:"",occupation:"",birthday:"",mobileno:"",country:"",state:"",city:"",zipcode:"",initials:"",aboutme:"",connectiontype:""};
	rootnode;
	currentnode:any;
	notifications:any;
	noticount:number = 0;
	destroy$: Subject<boolean> = new Subject<boolean>();
	url:string="";
	constructor(private authserv: AuthenticationService,private _alert: AlertsService,private dbserv:DbserviceService,private route:ActivatedRoute,private router: Router,private cookieService: CookieService) {
		this.visittype = localStorage.getItem('visittype');
		this.currtime = Math.random();
		this.rootpath = localStorage.getItem('baseurl');
		this.websiteroot = localStorage.getItem('basewebsiteurl');
		this.menuexpanddown = localStorage.getItem('menuexpanddown');
		this.url = router.url;
		// console.log(this.url);
		switch(router.url)
		{
			case "/myaccount/timeline":
				this.menuexpanddown = "collapse hide";
				localStorage.setItem('menuexpanddown',this.menuexpanddown);
				break;
			default:
				this.menuexpanddown = "collapse show";
				localStorage.setItem('menuexpanddown',this.menuexpanddown);
				break;
			
		}
		this.cropperSettings = new CropperSettings();
        this.cropperSettings.width = 600;
        this.cropperSettings.height = 600;
        this.cropperSettings.croppedWidth = 600;
        this.cropperSettings.croppedHeight = 600;
        this.cropperSettings.canvasWidth = 420;
		this.cropperSettings.noFileInput = true;
        this.cropperSettings.canvasHeight = 300;
        this.cropperSettings.touchRadius = 20;
		this.cropperSettings.rounded = true;
     	this.cropperSettings.keepAspect = true;
        this.imagedata = {};
		
		this.penderie_user_id = +this.cookieService.get('penderie_user_id');
		this.penderie_user_type = this.cookieService.get('penderie_user_type');
	}
	cropped($event)
	{
		/*this.imagepreviewurl = this.imagedata.image;
		this.imagepreviewurl2 = this.imagedata.image;*/
	}
	savesymbol()
	{
		this.currtime = Math.random();
		this.rootpath = localStorage.getItem('baseurl');
		this.uploadedsymbolbtn = true;
		if(this.symbol.backtype == null)
			this.symbol.backtype = '';
		if(this.symbol.frontfont == null)
			this.symbol.frontfont = '';
		let _formData = new FormData();
		_formData.append("backtype",this.symbol.backtype.toString());
		_formData.append("initial1",this.symbol.initial1.toString());
		_formData.append("initial2",this.symbol.initial2.toString());
		_formData.append("initial3",this.symbol.initial3.toString());
		_formData.append("frontfont",this.symbol.frontfont.toString());
		_formData.append("frontcolor",this.symbol.frontcolor.toString());
		switch(this.symbol.backtype)
		{
			case "imgdefault":
				_formData.append("background",'#C0C0C0');
				break;
			case "imgdefault":
				_formData.append("background",'#C0C0C0');
				break;
			case "textcustom":
				_formData.append("background",this.symbol.background2);
				break;
			case "imagecustom":
				_formData.append("background",this.symbol.background1);
				break;
		}
		
		if(this.uploadedsymbol!=null && this.uploadedsymbol.name!='')
		{
			_formData.append('image',this.uploadedsymbol, this.uploadedsymbol.name);
		}
		
		this.dbserv.saveimage("usersymbolimage",_formData).subscribe(res => {
															this.uploadedsymbolbtn = false;
															this.currtime = Math.random();
															this.loadmainrec();
															this.lnksavesymbolbox.nativeElement.click();
															this._alert.create(res.type,res.message);
														});
	}
	backcolorchange($event)
	{
		/*console.log($event.target);*/
	}
	changebacktype(type)
	{
		this.symbol.backtype = type;
		if(type=='textdefault' || type=='imgdefault')
			this.symbol.background = '#C0C0C0';
	}
	toggleMenu() {
    	this.menuState = this.menuState === 'out' ? 'in' : 'out';
  	}
	logout() {
        this.authserv.logout();
		this.router.navigate(['/login']);
    }
	ngOnInit() {
		this.loadmainrec();
		this.route.params.subscribe(params => {
			this.username = params['username'];
		});
	}
	loadmainrec()
	{
		this.currtime = Math.random();
		this.route.params.subscribe(params => {
			this.username = params['username'];
			if (this.username != undefined) {
				this.dbserv.getByStringId("getuserdetailbyname",this.username)
					.subscribe(res => {
					if(res.type=="success"){
						this.record=res.data;
						if(this.record.imagesrc!=''){
							let imageurl = this.websiteroot+"assets/profiles/"+this.record.imagesrc;
							this.previewFile(imageurl);
						}
						this.userid = +this.record.id;
						this.usertype = this.record.usertype;
						let initial = this.record.initials;
						if(initial!=''){
							let initialarray = initial.split('-');
							if(initialarray.length>0)
								this.symbol.initial1 = initialarray[0];
							if(initialarray.length>1)
								this.symbol.initial2 = initialarray[1];
							if(initialarray.length>2)
								this.symbol.initial3 = initialarray[2];
						}
						this.symbolimage = this.record.symbol;
						this.symbol.background = this.record.background;
						this.symbol.backtype = this.record.backtype;
						if(this.record.backtype == null || this.record.backtype == ''){
							this.symbol.backtype = 'textdefault';
						}
						if(this.symbol.backtype=="imgdefault" || this.symbol.backtype=="imagecustom")
						{
							this.symbol.backtype1 = this.symbol.backtype;
							this.symbol.background1 = this.symbol.background;
							if(this.symbol.background1==null || this.symbol.background1=='')
								this.symbol.background1 = '#C0C0C0';
						}
						if(this.symbol.backtype=="textdefault" || this.symbol.backtype=="textcustom")
						{
							this.symbol.backtype2 = this.symbol.backtype;
							this.symbol.background2 = this.symbol.background;
							if(this.symbol.background2==null || this.symbol.background2=='')
								this.symbol.background2 = '#C0C0C0';
						}
						this.symbol.frontfont = this.record.frontfont;
						this.symbol.frontcolor = this.record.frontcolor;
						if(this.symbol.frontcolor==null || this.symbol.frontcolor=='')
							this.symbol.frontcolor = '#C0C0C0';
						this.imagepreviewurl = this.record.image;
					}
				});
			}else{
				if(this.authserv.isloggedin()){
					this.loggedin = true;
					this.userid = +this.authserv.getUserId();
					this.usertype = this.authserv.getUserType();
					this.userfullname = this.authserv.getUserName();
					this.dbserv.getById("getuserdetail",this.userid)
						.subscribe(res => {
							if(res.type=="success"){
								this.record = res.data;
								if(this.record.imagesrc!='')
								{
									let imageurl = this.websiteroot+"assets/profiles/"+this.record.imagesrc;
									this.previewFile(imageurl);
								}
								let initial = this.record.initials;
								if(initial != '' && initial != null){
									let initialarray = initial.split('-');
									if(initialarray.length>0)
										this.symbol.initial1 = initialarray[0];
									if(initialarray.length>1)
										this.symbol.initial2 = initialarray[1];
									if(initialarray.length>2)
										this.symbol.initial3 = initialarray[2];
								}
								this.symbolimage = this.record.symbol;
								this.symbol.background = this.record.background;
								this.symbol.backtype = this.record.backtype;
								if(this.record.backtype == null || this.record.backtype == ''){
									this.symbol.backtype = 'textdefault';
								}
								if(this.symbol.backtype=="imgdefault" || this.symbol.backtype=="imagecustom")
								{
									this.symbol.backtype1 = this.symbol.backtype;
									this.symbol.background1 = this.symbol.background;
									if(this.symbol.background1==null || this.symbol.background1=='')
										this.symbol.background1 = '#C0C0C0';
								}
								if(this.symbol.backtype=="textdefault" || this.symbol.backtype=="textcustom")
								{
									this.symbol.backtype2 = this.symbol.backtype;
									this.symbol.background2 = this.symbol.background;
									if(this.symbol.background2==null || this.symbol.background2=='')
										this.symbol.background2 = '#C0C0C0';
								}
								this.symbol.frontfont = this.record.frontfont;
								this.symbol.frontcolor = this.record.frontcolor;
								if(this.symbol.frontcolor==null || this.symbol.frontcolor=='')
									this.symbol.frontcolor = '#C0C0C0';
								this.imagepreviewurl = this.record.image;
							}
							else
								this.router.navigateByUrl('/login');
						});
						// get our data every subsequent 5 seconds
				    Observable.interval(5000).takeUntil(this.destroy$).subscribe(val => {
				    	this.dbserv.getAll("mynotifications").subscribe(res => {
							if(res.type=="success"){
								this.notifications = res.data;
								this.noticount = res.count;
							}
						},error => {
							// console.log(error);
							this.authserv.logout();
							this.router.navigate(['/login']);
							// this._alert.create('error',this._translate.instant('Invalid login credentials.'));
						});
				    });
				}
			}
		});
	}
	menuexpandcollapse()
	{
		if(this.menuexpanddown == "collapse hide")
		{
			this.menuexpanddown = "collapse show";
			localStorage.setItem('menuexpanddown',this.menuexpanddown);
			this.router.navigateByUrl('/myaccount');
		}
		else
		{
			/*this.menulinkexpcoll.nativeElement.click();*/
			this.menuexpanddown = "collapse hide";
			localStorage.setItem('menuexpanddown',this.menuexpanddown);
			this.router.navigateByUrl('/myaccount/timeline');
			
		}
		// $('html, body').animate({
  //       	scrollTop: $("#innerHeadScrol").offset().top - 95
  //   	},2000);
	}
	switchtopgender(type:string)
	{
		this.cookieService.set('visittype',type);
		localStorage.setItem('visittype',type);

		setTimeout((router: Router) => {
			document.location.reload();
			//this.router.navigate(['home']);
		}, 500);
		
	}
	rotateLeft()
	{
		this.wasClicked = !this.wasClicked;
		if(this.wasClicked)
		{
			this.dashleftpannel = true;
			this.dashdesignpannel = true;
		}
		else
		{
			this.dashleftpannel = false;
			this.dashdesignpannel = false;
		}
	}
	
	switchsections(type:string)
	{
		this.cookieService.set('sectiontheme',type);
		switch(type)
		{
			case "Fine Material":
				this.router.navigate(['fine-material']);
				break;
			case "Superiar Craftmanship":
				this.router.navigate(['superiar-craftmanship']);
				break;
			case "Art of Styling":
				this.router.navigate(['art-of-styling']);
				break;
			case "Balanced Living":
				this.router.navigate(['balanced-living']);
				break;
		}
	}
	previewFile(file) {
		var request = new XMLHttpRequest();
		request.open('GET', file, true);
		request.responseType = 'blob';
		var image:any = new Image();
		request.onload = () => {
			var reader = new FileReader();
			reader.readAsDataURL(request.response);
			reader.onload = (event:any) => {
				image.src = event.target.result; 
				this.cropper.setImage(image);
			};
			reader.onloadend = (event:any) => {
				image.src = event.target.result; 
				this.cropper.setImage(image);
			};
		};
		request.send();
	}
	readImageUrl() {
	  if (this.uploadedimage && this.uploadedimage) {
		var reader = new FileReader();
		var image:any = new Image();
		reader.onload = (event:any) => {
		   image.src = event.target.result; 
			this.cropper.setImage(image);
		}
		reader.onloadend = (event:any) => {
           image.src = event.target.result; 
			this.cropper.setImage(image);
        };
		reader.readAsDataURL(this.uploadedimage);
	  }
	}
	
	onSymbolChange($event){
		this.uploadedsymbol = $event.target.files[0];
	}
	onFileChange($event){
	   this.uploadedimage = $event.target.files[0];
	   this.readImageUrl();
	   //this.saveprofileimage( $event.target.files[0]);
	}
	@HostListener('dragover', ['$event']) onDragOver(event) {
        this.dragAreaClass = "droparea";
        event.preventDefault();
    }
	@HostListener('dragenter', ['$event']) onDragEnter(event) {
		this.dragAreaClass = "droparea";
		event.preventDefault();
	}
	@HostListener('dragend', ['$event']) onDragEnd(event) {
		this.dragAreaClass = "dragarea";
		event.preventDefault();
	}
	@HostListener('dragleave', ['$event']) onDragLeave(event) {
		this.dragAreaClass = "dragarea";
		event.preventDefault();
	}
	@HostListener('drop', ['$event']) onDrop(event) {   
		this.dragAreaClass = "dragarea";           
		event.preventDefault();
		event.stopPropagation();
		this.uploadedimage = event.dataTransfer.files[0];
		this.readImageUrl();
		//this.saveprofileimage(event.dataTransfer.files[0]);
	}
	saveprofileimage(){
		this.currtime = Math.random();
		this.uploadedimagebtn = true;
		if(this.imagedata.image!=null)
		{
			let _formData = new FormData();
			_formData.append("id",this.userid.toString());
			_formData.append('image',this.imagedata.image);
			if (this.uploadedimage && this.uploadedimage) {
				_formData.append('imagesrc',this.uploadedimage, this.uploadedimage.name);
			}
			this.dbserv.saveimage("userprofileimage",_formData).subscribe(res => {
															this.uploadedimagebtn = false;
															this.lnksaveprofilebox.nativeElement.click();
															this.loadmainrec();
															this._alert.create(res.type,res.message);
														}); 
		}
		else
		{
			this._alert.create('error','Please, select an image first.');
			this.uploadedimagebtn = false;
		}
	}
	ngOnDestroy() {
	    this.destroy$.next(true);
	    // Now let's also unsubscribe from the subject itself:
    	this.destroy$.unsubscribe();
	}
	  ngAfterViewInit() {
	      $('html, body').animate({
	          scrollTop: $("#innerHeadScrol").offset().top - 95
	      }, 2000);
	  }
}
