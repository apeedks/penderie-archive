import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-innerfooter',
  templateUrl: './innerfooter.component.html',
  styleUrls: ['./innerfooter.component.css']
})
export class InnerfooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
	
}
