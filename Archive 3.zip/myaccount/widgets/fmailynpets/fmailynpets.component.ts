import { Component, OnInit, trigger, state, style, transition, animate, ElementRef, ViewChild  } from '@angular/core';
import {DbserviceService} from '../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { AuthenticationService } from '../../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import $ from 'jquery';
@Component({
  selector: 'app-myaccountfmailynpets',
  templateUrl: './fmailynpets.component.html',
  styleUrls: ['./fmailynpets.component.css']
})
export class FmailynpetsComponent implements OnInit {
		@ViewChild('postmodalcancel') postmodalcancel:ElementRef;
	model = {id:0,userid:0,title:'',relation:'',detail:""};
	public items:Object;
	sourcelist:any;
	userid = 0;
	constructor(private authserv: AuthenticationService,private _alert: AlertsService,private dbserv:DbserviceService,private router: Router) { }
	
	ngOnInit() {
	  	if(this.authserv.isloggedin())
		{
			this.userid = +this.authserv.getUserId();
			this.loadpage();
			this.dbserv.getAll("sourcebytype/relationships").subscribe(res => {this.sourcelist = res;});
		}
		else
			this.router.navigate(["/login"]);
	}
	loadpage()
	{
		this.dbserv.getAll("memefamilynpets/"+this.userid).subscribe(res => {this.items = res;}); 
	}
	deleterecord(id)
	{

        if(confirm ('Are you sure you want to delete this Family and Pets'))
        {
    
            this.dbserv.delete("memefamilynpetsdelte", id).subscribe(res => { this._alert.create(res.type,res.message);this.loadpage();});
        }
	}
	saverecord()
	{
		this.model.userid = this.userid;
		this.dbserv.save("memefamilynpetssave",this.model).subscribe(res => { 
																   this._alert.create(res.type,res.message);
																   if(res.type=="success")
																   {
																		this.model = {id:0,userid:0,title:'',relation:'',detail:""};
																		this.loadpage();
																		$( "#cancel" ).trigger( "click" );																	
																		this.postmodalcancel.nativeElement.click();
																		//$('#about-familynpets').hide();
																		//$('.modal-backdrop').hide();
																   }
																});
	}
	addrecord()
	{
	    $("#pets").trigger("reset");   
		this.model = {id:0,userid:0,title:'',relation:'',detail:""};
	}
    editrecord(id)
    {  
            this.dbserv.getById("memefamilynpetssingle", id).subscribe(res => { 
                this.model = res.data;

            });
    }
}
