import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FmailynpetsComponent } from './fmailynpets.component';

describe('FmailynpetsComponent', () => {
  let component: FmailynpetsComponent;
  let fixture: ComponentFixture<FmailynpetsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FmailynpetsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FmailynpetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
