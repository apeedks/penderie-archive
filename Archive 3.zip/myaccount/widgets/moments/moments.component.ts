import { Component, OnInit, trigger, state, style, transition, animate, ElementRef, ViewChild  } from '@angular/core';
import {DbserviceService} from '../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { AuthenticationService } from '../../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import $ from 'jquery';
@Component({
  selector: 'app-myaccountmoments',
  templateUrl: './moments.component.html',
  styleUrls: ['./moments.component.css']
})
export class MomentsComponent implements OnInit {
	@ViewChild('postmodalcancel') postmodalcancel:ElementRef;
	model = {id:0,userid:0,title:'',detail:'',year:""};
	public items:Object;
	sourcelist:any;
	userid = 0;
	yearddl = [];
	constructor(private authserv: AuthenticationService,private _alert: AlertsService,private dbserv:DbserviceService,private router: Router) { 
		for (var i = 1980; i <= 2017; i++) {
		   this.yearddl.push(i);
		}
	}
	
	ngOnInit() {
	  	if(this.authserv.isloggedin())
		{
			this.userid = +this.authserv.getUserId();
			this.loadpage();
		}
		else
			this.router.navigate(["/login"]);
	}
	loadpage()
	{
		this.dbserv.getAll("memmoments/"+this.userid).subscribe(res => {this.items = res;}); 
	}
	deleterecord(id)
	{
	    if(confirm ('Are you sure you want to delete this Member'))
        {
		    this.dbserv.delete("mememomentsdelete", id).subscribe(res => {
		    this._alert.create(res.type,res.message);
		    this.loadpage();
		    this.model = {id:0,userid:0,title:'',detail:'',year:""};
		    });
        }
	}
	saverecord()
	{
		this.model.userid = this.userid;
		this.dbserv.save("memmomentssave",this.model).subscribe(res => { 
															   this._alert.create(res.type,res.message);
															   if(res.type=="success")
															   {
																	this.model = {id:0,userid:0,title:'',detail:'',year:""};
																	this.loadpage();
																	$( "#cancel" ).trigger( "click" );
																	this.postmodalcancel.nativeElement.click();
																	// $('#about-moments').hide();
																	// $('.modal-backdrop').hide();
															   }
															});
	}
	addrecord()
	{
	    $("#moment").trigger("reset");
		this.model = {id:0,userid:0,title:'',detail:'',year:""};
	}
    editrecord(id)
    {  
            this.dbserv.getById("memmomentssingle", id).subscribe(res => { 
                this.model = res.data;
            });
    }
}