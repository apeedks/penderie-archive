import { Component, OnInit, trigger, state, style, transition, animate, ElementRef, ViewChild  } from '@angular/core';
import {DbserviceService} from '../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { AuthenticationService } from '../../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import $ from 'jquery';

@Component({
  selector: 'app-myaccountplace',
  templateUrl: './place.component.html',
  styleUrls: ['./place.component.css']
})
export class PlaceComponent implements OnInit {
	@ViewChild('postmodalcancel') postmodalcancel:ElementRef;
	model = {country:"",state:"",city:"",userid:0};
	public items:Object;
	sourcelist:any;
	userid = 0;
	countrylist:any;
	statelist:any;
	citylist:any;
	constructor(private authserv: AuthenticationService,private _alert: AlertsService,private dbserv:DbserviceService,private router: Router) { 
		
	}
	
	ngOnInit() {
	  	if(this.authserv.isloggedin())
		{
			this.userid = +this.authserv.getUserId();
			this.loadpage();
			this.dbserv.getAll("sourcebytype/fieldofstudy").subscribe(res => {this.sourcelist = res;});
			this.dbserv.getAll("countries").subscribe(res => {this.countrylist = res;});
		}
		else
			this.router.navigate(["/login"]);
	}
	loadpage()
	{
		this.dbserv.getAll("list-member-places/").subscribe(res => {this.items = res.data;}); 
	}
	states()
	{
		this.dbserv.getAll("states/" + this.model.country).subscribe(res => {this.statelist = res;});
		this.citylist = [];
		this.model.city = '';
		//this.statelist = [];
		this.model.state = '';
	}
	cities()
	{
		this.dbserv.getAll("cities/" + this.model.country + "/" + this.model.state).subscribe(res => {this.citylist = res;
		this.citylist.push({city:"Other"});});
	}
	deleterecord(id)
	{  if(confirm ('Are you sure you want to delete this Place'))
		{
			this.dbserv.delete("delete-member-places", id).subscribe(res => { this._alert.create(res.type,res.message);this.loadpage();this.model = {country:"",state:"",city:"",userid:0};});
		}
	}
	saverecord()
	{
	    
	        this.model.userid = this.userid;
	        this.dbserv.save("member-places",this.model).subscribe(res => { 
																  // this._alert.create(res.type,res.message);
																   if(res.type=="success")
																   {
																		this.model = {country:"",state:"",city:"",userid:0};
																		$( "#cancel" ).trigger( "click" );
																		this.postmodalcancel.nativeElement.click();
																		this.loadpage();
																		this._alert.create(res.type,res.message);
																		//$('#about-educations').hide();
																		 //window.close();
																		//$('#about-educations').css({'visibility':'hidden'});
																		//$('.modal-backdrop').hide();
																		
																   }
																});
	    }
	
	addrecord()
	{
        $("#about-place_1").trigger("reset");	      
        this.model = {country:"",state:"",city:"",userid:0};
	}
    editrecord(id)
    {  
            this.dbserv.getById("list-member-places", id).subscribe(res => { 
            this.model = res.data[0];
            this.dbserv.getAll("states/" + this.model.country).subscribe(res => {this.statelist = res;});
            this.dbserv.getAll("cities/" + this.model.country + "/" + this.model.state).subscribe(res => {this.citylist = res;});
            this.cities()
            });
    }
}
