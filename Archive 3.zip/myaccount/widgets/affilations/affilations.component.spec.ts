import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AffilationsComponent } from './affilations.component';

describe('AffilationsComponent', () => {
  let component: AffilationsComponent;
  let fixture: ComponentFixture<AffilationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AffilationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AffilationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
