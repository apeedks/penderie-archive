import { Component, OnInit, trigger, state, style, transition, animate, ElementRef, ViewChild } from '@angular/core';
import {DbserviceService} from '../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { AuthenticationService } from '../../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import $ from 'jquery';
@Component({
  selector: 'app-myaccounteducations',
  templateUrl: './educations.component.html',
  styleUrls: ['./educations.component.css']
})
export class EducationsComponent implements OnInit {
	@ViewChild('postmodalcancel') postmodalcancel:ElementRef;
	model = {id:0,userid:0,degree:'',institution:'',country:"",state:"",city:"",yearfrom:"",yearto:"",fieldofstudy:""};
	public items:Object;
	sourcelist:any;
	userid = 0;
	countrylist:any;
	statelist:any;
	citylist:any;
	yearddl = [];
	constructor(private authserv: AuthenticationService,private _alert: AlertsService,private dbserv:DbserviceService,private router: Router) { 
		for (var i = 1980; i <= 2017; i++) {
		   this.yearddl.push(i);
		}
	}
	
	ngOnInit() {
	  	if(this.authserv.isloggedin())
		{
			this.userid = +this.authserv.getUserId();
			this.loadpage();
			this.dbserv.getAll("sourcebytype/fieldofstudy").subscribe(res => {this.sourcelist = res;});
			this.dbserv.getAll("countries").subscribe(res => {this.countrylist = res;});
		}
		else
			this.router.navigate(["/login"]);
	}
	loadpage()
	{
		this.dbserv.getAll("memeducations/"+this.userid).subscribe(res => {this.items = res;}); 
	}
	states()
	{
		this.dbserv.getAll("states/" + this.model.country).subscribe(res => {this.statelist = res;});
		this.citylist = [];
		this.model.city = '';
		//this.statelist = [];
		this.model.state = '';
	}
	cities()
	{
		this.dbserv.getAll("cities/" + this.model.country + "/" + this.model.state).subscribe(res => {this.citylist = res;});
	}
	deleterecord(id)
	{  if(confirm ('Are you sure you want to delete this Education'))
		{
			this.dbserv.delete("memeducationsdelte", id).subscribe(res => { this._alert.create(res.type,res.message);this.loadpage();this.model = {id:0,userid:0,degree:'',institution:'',country:"",state:"",city:"",yearfrom:"",yearto:"",fieldofstudy:""};});
		}
	}
	saverecord()
	{
	    
	    if(!(this.model.yearfrom != '' && this.model.yearto != '' && this.model.yearfrom > this.model.yearto)){
	        this.model.userid = this.userid;
	        this.dbserv.save("memeducationssave",this.model).subscribe(res => { 
																  // this._alert.create(res.type,res.message);
																   if(res.type=="success")
																   {
																		this.model = {id:0,userid:0,degree:'',institution:'',country:"",state:"",city:"",yearfrom:"",yearto:"",fieldofstudy:""};
																		$( "#cancel" ).trigger( "click" );
																		this.postmodalcancel.nativeElement.click();
																		this.loadpage();
																		this._alert.create(res.type,res.message);
																		//$('#about-educations').hide();
																		 //window.close();
																		//$('#about-educations').css({'visibility':'hidden'});
																		//$('.modal-backdrop').hide();
																		
																   }
																});
	    }
	}
	addrecord()
	{
	    $("#education").trigger("reset");         
		this.model = {id:0,userid:0,degree:'',institution:'',country:"",state:"",city:"",yearfrom:"",yearto:"",fieldofstudy:""};
	}
    editrecord(id)
    {  
            this.dbserv.getById("memeducationssingle", id).subscribe(res => { 
                this.model = res.data;
                this.dbserv.getAll("states/" + this.model.country).subscribe(res => {this.statelist = res;});
                this.dbserv.getAll("cities/" + this.model.country + "/" + this.model.state).subscribe(res => {this.citylist = res;});
                this.cities()
            });
    }
}
