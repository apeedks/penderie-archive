import { Component, OnInit, trigger, state, style, transition, animate, ElementRef, ViewChild  } from '@angular/core';
import {DbserviceService} from '../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { AuthenticationService } from '../../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import $ from 'jquery';
@Component({
  selector: 'app-myaccountaspirations',
  templateUrl: './aspirations.component.html',
  styleUrls: ['./aspirations.component.css']
})
export class AspirationsComponent implements OnInit {
	@ViewChild('postmodalcancel') postmodalcancel:ElementRef;
	model = {id:0,userid:0,type:'',detail:''};
	public items:Object;
	mylist:any;
	userid = 0;
	constructor(private authserv: AuthenticationService,private _alert: AlertsService,private dbserv:DbserviceService,private router: Router) { }
	
	ngOnInit() {
	  	if(this.authserv.isloggedin())
		{
			this.userid = +this.authserv.getUserId();
			this.loadpage();
			this.dbserv.getAll("sourcebytype/aspirations").subscribe(res => {this.mylist = res;});
		}
		else
			this.router.navigate(["/login"]);
	}
	loadpage()
	{
		this.dbserv.getAll("memaspirations/"+this.userid).subscribe(res => {this.items = res;}); 
	}
	deleterecord(id)
	{
	    if(confirm ('Are you sure you want to delete this Aspiration'))
		{
			this.dbserv.delete("memaspirationsdelte", id).subscribe(res => { this._alert.create(res.type,res.message);this.loadpage();});
		}
	}
	saverecord()
	{
		this.model.userid = this.userid;
		this.dbserv.save("memaspirationssave",this.model).subscribe(res => { 
																   this._alert.create(res.type,res.message);
																   if(res.type=="success")
																   {
																		this.loadpage();
																		//$('#about-aspiration').hide();
																		//$('.modal-backdrop').hide();
																		$( "#cancel" ).trigger( "click" );
																		this.postmodalcancel.nativeElement.click();
																		this.model = {id:0,userid:0,type:'',detail:''};
																   }
																});
	}
	addrecord()
	{
	    $("#about-aspiration_rest").trigger("reset");
		this.model = {id:0,userid:0,type:'',detail:''};
	}
    editrecord(id)
    {  
            this.dbserv.getById("memaspirationssingle", id).subscribe(res => { 
                this.model = res.data;
            });
    }
}
