import { Component, OnInit, trigger, state, style, transition, animate, ElementRef, ViewChild  } from '@angular/core';
import {DbserviceService} from '../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { AuthenticationService } from '../../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import $ from 'jquery';

@Component({
  selector: 'app-myaccounthobbies',
  templateUrl: './hobbies.component.html',
  styleUrls: ['./hobbies.component.css']
})
export class HobbiesComponent implements OnInit {
	@ViewChild('postmodalcancel') postmodalcancel:ElementRef;
	model = {id:0,userid:0,title:'',detail:''};
	public items:Object;
	sourcelist:any;
	userid = 0;
	constructor(private authserv: AuthenticationService,private _alert: AlertsService,private dbserv:DbserviceService,private router: Router) { }
	
	ngOnInit() {
	  	if(this.authserv.isloggedin())
		{
			this.userid = +this.authserv.getUserId();
			this.loadpage();
		}
		else
			this.router.navigate(["/login"]);
	}
	loadpage()
	{
		this.dbserv.getAll("memhobbies/"+this.userid).subscribe(res => {this.items = res;}); 
	}
	deleterecord(id)
	{
	    if(confirm ('Are u sure want to delete a hobbies'))
        {
	            this.dbserv.delete("memhobbiesdelete", id).subscribe(res => { this._alert.create(res.type,res.message);this.loadpage();});
        }
	}
	saverecord()
	{
		this.model.userid = this.userid;
		this.dbserv.save("memhobbiessave",this.model).subscribe(res => { 
															   this._alert.create(res.type,res.message);
															   if(res.type=="success")
															   {
																	this.loadpage();this.model = {id:0,userid:0,title:'',detail:''};
																	this.loadpage();
																	$( "#cancel" ).trigger( "click" );																	
																	this.postmodalcancel.nativeElement.click();
																	//$('#about-hobbies').hide();
																	//$('.modal-backdrop').hide();
															   }
															});
	}
	addrecord()
	{
	    $("#hobbies").trigger("reset");
		this.model = {id:0,userid:0,title:'',detail:''};
	}
    editrecord(id)
    {  
            this.dbserv.getById("memhobbiessingle", id).subscribe(res => { 
            this.model = res.data;
            });
    }
}
