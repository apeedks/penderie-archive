import { Component, OnInit, trigger, state, style, transition, animate , ElementRef, ViewChild } from '@angular/core';
import {DbserviceService} from '../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { AuthenticationService } from '../../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import {IMyDpOptions,IMyDateModel} from 'mydatepicker';
import $ from 'jquery';
@Component({
  selector: 'app-myaccountawards',
  templateUrl: './awards.component.html',
  styleUrls: ['./awards.component.css']
})
export class AwardsComponent implements OnInit {
		@ViewChild('postmodalcancel') postmodalcancel:ElementRef;
	model = {id:0,userid:0,title:'',institute:'',date:"",detail:""};
	public items:Object;
	sourcelist:any;
	userid = 0;
	disableSince:any = {};
	// date
	public myDatePickerOptions: IMyDpOptions = {
				// other options...
				dateFormat: 'mm/dd/yyyy',
				editableDateField:false,
				openSelectorTopOfInput: false
		};
	model2: any = { date: { year: 2018, month: 10, day: 9 } };


	constructor(private authserv: AuthenticationService,private _alert: AlertsService,private dbserv:DbserviceService,private router: Router) {
	    let today = new Date();
        this.disableSince = { year: today.getFullYear(), month: today.getMonth() + 1, day: today.getDate() };
        this.myDatePickerOptions.disableSince = this.disableSince;
        let date = new Date();
	}
	
	onDateChanged(event: IMyDateModel) {
				// event properties are: event.date, event.jsdate, event.formatted and event.epoc
		if(event.jsdate)
		{
			 this.model.date = event.jsdate.getFullYear() + "-" + (event.jsdate.getMonth() + 1 ) + "-" + event.jsdate.getDate();
			console.log(this.model.date);

		}
	}

	ngOnInit() {
	  	if(this.authserv.isloggedin())
		{
			this.userid = +this.authserv.getUserId();
			this.loadpage();
			this.dbserv.getAll("sourcebytype/relationships").subscribe(res => {this.sourcelist = res;});
            let dob:string = this.model.date;
            if(dob && dob!='')
            {
                let db_date = new Date(dob);
                this.model2 = { date: { year: +(db_date.getFullYear()), month: +(db_date.getMonth()+1), day: +(db_date.getDate()) } };
                
                //console.log(this.model2);
            }
		}
		else
			this.router.navigate(["/login"]);
	}
	loadpage()
	{
		this.dbserv.getAll("memawards/"+this.userid).subscribe(res => {this.items = res;}); 
	}
	deleterecord(id)
	{
	    if(confirm ('Are you sure you want to delete this Awards'))
        {
    
	            this.dbserv.delete("memawardsdelete", id).subscribe(res => { this._alert.create(res.type,res.message);this.loadpage();});
        }
	}
	saverecord()
	{
		this.model.userid = this.userid;
		this.dbserv.save("memawardssave",this.model).subscribe(res => { 
															   this._alert.create(res.type,res.message);
															   if(res.type=="success")
															   {
																	this.model = {id:0,userid:0,title:'',institute:'',date:"",detail:""};
																	this.model2= null;
																	this.loadpage();
																	$( "#cancel" ).trigger( "click" );
																	this.postmodalcancel.nativeElement.click();
																	//$('#about-awards').hide();
																	//$('.modal-backdrop').hide();
															   }
														   });
	}
	addrecord()
	{
		this.model2= null;
		 $("#awards").trigger("reset");   
		this.model = {id:0,userid:0,title:'',institute:'',date:"",detail:""};
	}
    editrecord(id)
    {  
            this.dbserv.getById("memawardssingle", id).subscribe(res => { 
                this.model = res.data;

            });
    }
}
