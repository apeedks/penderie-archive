import { Component, OnInit, trigger, state, style, transition, animate, ElementRef, ViewChild  } from '@angular/core';
import {DbserviceService} from '../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { AuthenticationService } from '../../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import $ from 'jquery';

@Component({
  selector: 'app-mylanguageplace',
  templateUrl: './language.component.html',
  styleUrls: ['./language.component.css']
})
export class LanguageComponent implements OnInit {
	@ViewChild('postmodalcancel') postmodalcancel:ElementRef;
	model = {id:0,language:"",userid:0};
	public items:Object;
	sourcelist:any;
	
	userid = 0;
	constructor(private authserv: AuthenticationService,private _alert: AlertsService,private dbserv:DbserviceService,private router: Router) { 
		
	}
	
	ngOnInit() {
	  	if(this.authserv.isloggedin())
		{
			this.userid = +this.authserv.getUserId();
			this.loadpage();
	         this.dbserv.getAll("sourcebytype/language").subscribe(res => {
	               this.sourcelist = res;
	               this.sourcelist.push({title:"Other"});});
		}
		else
			this.router.navigate(["/login"]);
	}
	loadpage()
	{
		this.dbserv.getAll("list-member-languages/").subscribe(res => {this.items = res.data;}); 
	}
	
	deleterecord(id)
	{  if(confirm ('Are you sure you want to delete this language'))
		{
			this.dbserv.delete("delete-member-languages", id).subscribe(res => { this._alert.create(res.type,res.message);this.loadpage();this.model = {id:0,language:"",userid:0};});
		}
	}
	   editrecord(id)
	    {  
	            this.dbserv.getById("list-member-languages", id).subscribe(res => { 
	                this.model = res.data[0];
	            });
	    }
	saverecord()
	{
	    
	        this.model.userid = this.userid;
	        this.dbserv.save("member-languages",this.model).subscribe(res => { 
																  // this._alert.create(res.type,res.message);
																   if(res.type=="success")
																   {
																		this.model = {id:0,language:"",userid:0};
																		$( "#cancel" ).trigger( "click" );
																		this.postmodalcancel.nativeElement.click();
																		this.loadpage();
																		this._alert.create(res.type,res.message);
																		//$('#about-educations').hide();
																		 //window.close();
																		//$('#about-educations').css({'visibility':'hidden'});
																		//$('.modal-backdrop').hide();
																		
																   }
																});
	    }
	
	addrecord()
	{
        $("#language_1").trigger("reset");	      
        this.model = {id:0,language:"",userid:0};
	}
}
