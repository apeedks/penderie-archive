import { Component, OnInit, trigger, state, style, transition, animate, ElementRef, ViewChild  } from '@angular/core';
import {DbserviceService} from '../../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { AuthenticationService } from '../../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import $ from 'jquery';
@Component({
  selector: 'app-myaccountprofessions',
  templateUrl: './professions.component.html',
  styleUrls: ['./professions.component.css']
})
export class ProfessionsComponent implements OnInit {
	@ViewChild('postmodalcancel') postmodalcancel:ElementRef;
	model = {id:0,userid:0,title:'',organizatoin:'',country:"",state:"",city:"",yearfrom:"",yearto:"",details:""};
	public items:Object;
	userid = 0;
	countrylist:any;
	statelist:any;
	citylist:any;
	yearddl = [];
	constructor(private authserv: AuthenticationService,private _alert: AlertsService,private dbserv:DbserviceService,private router: Router) { 
		for (var i = 1980; i <= 2017; i++) {
		   this.yearddl.push(i);
		}
	}
	
	ngOnInit() {
	  	if(this.authserv.isloggedin())
		{
			this.userid = +this.authserv.getUserId();
			this.loadpage();
			this.dbserv.getAll("countries").subscribe(res => {this.countrylist = res;});
		}
		else
			this.router.navigate(["/login"]);
	}
	loadpage()
	{
		this.dbserv.getAll("memprofessions/"+this.userid).subscribe(res => {this.items = res;}); 
	}
	states()
	{
		this.dbserv.getAll("states/" + this.model.country).subscribe(res => {this.statelist = res;});
		this.citylist = [];
		this.model.city = '';
		// this.statelist = [];
		this.model.state = '';
	}
	cities()
	{
		this.dbserv.getAll("cities/" + this.model.country + "/" + this.model.state).subscribe(res => {this.citylist = res;});
	}
	deleterecord(id)
	{if(confirm ('Are you sure you want to delete this Profession'))
		{
			this.dbserv.delete("memprofessionsdelete", id).subscribe(res => { this._alert.create(res.type,res.message);this.loadpage();this.model = {id:0,userid:0,title:'',organizatoin:'',country:"",state:"",city:"",yearfrom:"",yearto:"",details:""};});
		}
	}
	saverecord()
	{
	    if(!(this.model.yearfrom != '' && this.model.yearto != '' && this.model.yearfrom > this.model.yearto)){
		this.model.userid = this.userid;
		this.dbserv.save("memprofessionssave",this.model).subscribe(res => { 
																	this._alert.create(res.type,res.message);
																   if(res.type=="success")
																   {
																		this.model = {id:0,userid:0,title:'',organizatoin:'',country:"",state:"",city:"",yearfrom:"",yearto:"",details:""};
																		this.loadpage();
																		// $('#about-professions').hide();
																		// $('.modal-backdrop').hide();
																		$( "#cancel" ).trigger( "click" );																	
																		this.postmodalcancel.nativeElement.click();
																   }
																});
	    }
	}
	addrecord()
	{
	    
		this.model = {id:0,userid:0,title:'',organizatoin:'',country:"",state:"",city:"",yearfrom:"",yearto:"",details:""};
	}
    editrecord(id)
    {  
            this.dbserv.getById("memprofessionssingle", id).subscribe(res => { 
                this.model = res.data;
                this.dbserv.getAll("states/" + this.model.country).subscribe(res => {this.statelist = res;});
                this.dbserv.getAll("cities/" + this.model.country + "/" + this.model.state).subscribe(res => {this.citylist = res;});
                this.cities()
            });
    }
}
