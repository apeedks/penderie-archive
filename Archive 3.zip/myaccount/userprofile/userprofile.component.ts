import { Component, OnInit, trigger, state, style, transition, animate } from '@angular/core';
import {DbserviceService} from '../services/dbservice.service';
import { AuthenticationService } from '../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit {
	record = {id:0,name:"",email:"",usertype:"",verified:"",image:"",updated_at:"",firstname:"",lastname:"",gender:"",maritalstatus:"",occupation:"",birthday:"",mobileno:"",country:"",state:"",city:"",zipcode:"",initials:"",aboutme:"",connectiontype:"", facebook: "",twitter: "",linkedin:"",instagram: "",pinterest: "",youtube: "",google: "",website: ""};
	affiliations = [];
	educations = [];
	familynpets = [];
	hobbies = [];
	awards = [];
	moments = [];
	professions = [];
	languages = [];
	aspirations = [];
	places = [];
	username:string = '';
	userid = 0;
	options:any;
	constructor(private cookieService:CookieService,private dbserv:DbserviceService,private authserv: AuthenticationService,private _alert: AlertsService,private route: ActivatedRoute,private router: Router) { 
		this.route.params.subscribe(params => {
		    this.username = params['username']; // (+) converts string 'id' to a number
			this.dbserv.getByStringId("getuserdetailbyname",this.username)
			.subscribe(res => {
				if(res.type=="success")
				{
					this.record=res.data;
					this.userid = this.record.id;
					this.dbserv.getAll("memaffilations/"+this.userid).subscribe(res => {this.affiliations = res;}); 
					this.dbserv.getAll("memeducations/"+this.userid).subscribe(res => {this.educations = res;});
					this.dbserv.getAll("memefamilynpets/"+this.userid).subscribe(res => {this.familynpets = res;});
					this.dbserv.getAll("memhobbies/"+this.userid).subscribe(res => {this.hobbies = res;});
					
					this.dbserv.getAll("memaspirations/"+this.userid).subscribe(res => {this.aspirations = res;});
					this.dbserv.getAll("memawards/"+this.userid).subscribe(res => {this.awards = res;});
					this.dbserv.getAll("memmoments/"+this.userid).subscribe(res => {this.moments = res;}); 
					this.dbserv.getAll("memprofessions/"+this.userid).subscribe(res => {this.professions = res;}); 
					this.dbserv.getAll("memgeneral/"+this.userid+"/languages").subscribe(res => {this.languages = res;});
					this.dbserv.getAll("memgeneral/"+this.userid+"/places").subscribe(res => {this.places = res;});
				}
			});
		});
		
	}
	
	ngOnInit() {
		let checklogginUserData = localStorage.getItem('user');
		if(checklogginUserData){
			let checklogginUserJSONData = JSON.parse(checklogginUserData);
			if(checklogginUserJSONData.usertype=="Member"){
				if(this.authserv.isloggedin()){
					this.authserv.session().subscribe(res => {
						if(res.isnew=='Yes')
							this.router.navigate(['/home']);
					});
				}
			}
		}
	}

}
