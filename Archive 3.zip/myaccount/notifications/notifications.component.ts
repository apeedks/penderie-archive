import { Component, OnInit } from '@angular/core';
import {DbserviceService} from '../services/dbservice.service';
import { AuthenticationService } from '../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';
@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {
	wasClicked:boolean = false;
	custo_filter_onen_close = false;
	visiblefilter = false;

	options:any;
	lastpage: number;
	totalitems: any;
	page: number = 1;
	limit:number = 3;
	items = [];
	params:any = {};
	userid = 0;
	constructor(private authserv: AuthenticationService,private _alert: AlertsService,private dbserv:DbserviceService,private router: Router,private cookieService: CookieService)  { }
	ngOnInit() {
		if(this.authserv.isloggedin())
		{
			this.userid = +this.authserv.getUserId();
			this.loadrecs();
		}
	}
	showmorerecs()
	{
		this.page = this.page + 1;
		this.dbserv.post("memnotifications/"+this.page+"/"+this.limit,this.params).subscribe(res => {
		   this.items = [ ...this.items, ...res.records.data];
		   this.page = res.records.current_page;
		   this.lastpage = res.records.last_page;
		   this.totalitems = res.records.total;
		});
	}
	loadrecs()
	{
		/*this.params.searchfield = this.searchfield;*/
		this.dbserv.post("memnotifications/"+this.page+"/"+this.limit,this.params).subscribe(res => {this.items = res.records.data; this.page = res.records.current_page;this.lastpage = res.records.last_page; this.totalitems = res.records.total;});
	}
	filterby()
	{
		this.wasClicked = !this.wasClicked;
		if(this.wasClicked)
		{
			this.custo_filter_onen_close = true;
			this.visiblefilter = true;

		}
		else
		{
			this.custo_filter_onen_close = false;
			this.visiblefilter = false;
		}

	}
}
