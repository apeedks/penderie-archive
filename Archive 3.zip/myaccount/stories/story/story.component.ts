import { Component, OnInit, ElementRef, ViewChild, HostListener } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import { AuthenticationService } from '../../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import {ImageCropperComponent, CropperSettings, Bounds} from 'ng2-img-cropper';
import $ from 'jquery';
@Component({
  selector: 'app-story',
  templateUrl: './story.component.html',
  styleUrls: ['./story.component.css']
})
export class StoryComponent implements OnInit {
	model = {id:0, title: '',category_id:0,image:null,imagetitle:'',tags:[],gender:"",theme:"",description:"",credits:"",agree:false,active:"",shortdesc:""};
	rootpath:string;
	currtime:any;
	uploadedimage = null;
	tags:any = '';
	tagslist:any = [];
	settings = {};
	options:any;

	// for image uploader
	@ViewChild('lnksaveprofilebox') lnksaveprofilebox:ElementRef;
	imagedata:any;
    cropperSettings:CropperSettings;
    croppedWidth:number;
    croppedHeight:number;
    dragAreaClass:string='dragarea';
	uploadedsymbol:any=null;
	symbolimage = '';
	uploadedimagebtn:boolean=false;
	uploadedsymbolbtn:boolean=false;
	imagepreviewurl:string='';
	categories: any;
	isUpdateMode:boolean=false;
    @ViewChild('cropper', undefined) cropper:ImageCropperComponent;



	constructor(private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private cookieService: CookieService) {
		
		this.route.params.subscribe(params => {
			if(params['id'])
			{
				this.isUpdateMode = true;
			    this.model.id = +params['id'];
			    this.dbserv.getById("storiesdetpub",this.model.id).subscribe(res => {
					if(res.type=="success")
					{
						this.model = res.data;
						this.model.agree = false;
						this.loadddl();
					}else{
						this.router.navigateByUrl('/myaccount/stories') ;	
					}
				});
			}
		});

		this.settings = { 
		  singleSelection: false, 
		  text:"Select Tags",
		  selectAllText:'Select All',
		  unSelectAllText:'UnSelect All',
		  enableSearchFilter: true,
		  limitSelection:10,
		  enableCheckAll:false,
		  classes:"myclass custom-class"
		};  
		this.dbserv.getAll("storytagslist").subscribe(res => { this.tagslist = res.records;});
				    // for image 
		this.rootpath = localStorage.getItem('baseurl');

	   	this.cropperSettings = new CropperSettings();
        this.cropperSettings.width = 1920;
		this.cropperSettings.height = 1280;
		this.cropperSettings.croppedWidth = 1920;
		this.cropperSettings.croppedHeight = 1280;
		this.cropperSettings.canvasWidth = 420;
		this.cropperSettings.noFileInput = true;
		this.cropperSettings.canvasHeight = 300;
		this.cropperSettings.touchRadius = 20;
		this.cropperSettings.rounded = false;
		this.cropperSettings.keepAspect = true;
		this.imagedata = {};


	}



// for image
	  cropped(bounds:Bounds) {
    this.croppedHeight =bounds.bottom-bounds.top;
    this.croppedWidth = bounds.right-bounds.left;
  }
  
  fileChangeListener($event) {
    var image:any = new Image();
    var file:File = $event.target.files[0];
    var myReader:FileReader = new FileReader();
    var that = this;
    myReader.onloadend = function (loadEvent:any) {
        image.src = loadEvent.target.result;
        that.cropper.setImage(image);

    };

    myReader.readAsDataURL(file);
    }

    	previewFile(file) {
		console.log(file);
		var request = new XMLHttpRequest();
		request.open('GET', file, true);
		request.responseType = 'blob';
		var image:any = new Image();
		request.onload = () => {
			var reader = new FileReader();
			reader.readAsDataURL(request.response);
			reader.onload = (event:any) => {
				image.src = event.target.result; 
				this.cropper.setImage(image);
			};
			reader.onloadend = (event:any) => {
				image.src = event.target.result; 
				this.cropper.setImage(image);
			};
		};
		request.send();
	}
	readImageUrl() {
	  if (this.uploadedimage && this.uploadedimage) {
		var reader = new FileReader();
		var image:any = new Image();
		reader.onload = (event:any) => {
		   image.src = event.target.result; 
			this.cropper.setImage(image);
		}
		reader.onloadend = (event:any) => {
           image.src = event.target.result; 
			this.cropper.setImage(image);
        };
		reader.readAsDataURL(this.uploadedimage);
	  }
	}


	onSymbolChange($event){
		this.uploadedsymbol = $event.target.files[0];
	}
	onFileChange($event){
	   this.uploadedimage = $event.target.files[0];
	   this.readImageUrl();
	   //this.saveprofileimage( $event.target.files[0]);
	}
	@HostListener('dragover', ['$event']) onDragOver(event) {
        this.dragAreaClass = "droparea";
        event.preventDefault();
    }
	@HostListener('dragenter', ['$event']) onDragEnter(event) {
		this.dragAreaClass = "droparea";
		event.preventDefault();
	}
	@HostListener('dragend', ['$event']) onDragEnd(event) {
		this.dragAreaClass = "dragarea";
		event.preventDefault();
	}
	@HostListener('dragleave', ['$event']) onDragLeave(event) {
		this.dragAreaClass = "dragarea";
		event.preventDefault();
	}
	@HostListener('drop', ['$event']) onDrop(event) {   
		this.dragAreaClass = "dragarea";           
		event.preventDefault();
		event.stopPropagation();
		this.uploadedimage = event.dataTransfer.files[0];
		this.readImageUrl();
		//this.saveprofileimage(event.dataTransfer.files[0]);
	}



	saveprofileimage(){
		this.lnksaveprofilebox.nativeElement.click();
	}


 // *************************************************************


	
	ngOnInit() {
	    scroll(0,0);
		if(this.authserv.isloggedin())
		{
			this.authserv.session().subscribe(res => {
							if(res.isnew=='Yes')
								this.router.navigate(['/home']);
						});
			
		}
		this.loadddl();
	}
	fileChange($event){
		console.log($event.target.files[0]);
		this.uploadedimage = $event.target.files[0];
	}
	hideform()
	{
		this.cropper.reset();
		this.uploadedimagebtn = false;
	}
	saverecord()
	{
		
		this.uploadedimagebtn = true;
		let _formData = new FormData();
		_formData.append("id",this.model.id.toString());
		_formData.append("title",this.model.title);
		_formData.append("category_id",this.model.category_id.toString());
		_formData.append("gender",this.model.gender);
        _formData.append("shortdesc",this.model.shortdesc);
		// _formData.append("tags",this.model.tags);
		_formData.append("description",this.model.description);
		
		let mytags:string = '';
		if(this.model.tags.length>0)
		{
			for(let i=0;i<this.model.tags.length;i++)
			{
				if(mytags=='')
					mytags = '-'+this.model.tags[i].id.toString()+'-';
				else
					mytags += ',-'+this.model.tags[i].id.toString()+'-';
				_formData.append("tags",mytags);
			}
		}
		
		_formData.append("theme",this.model.theme);
		_formData.append("imagetitle",this.model.imagetitle);
		_formData.append("credits",this.model.credits);
		if (this.model.active == 'Preview') {
			_formData.append("active",'Saved');
		}
		else{
			_formData.append("active",this.model.active);
		}

		// Image 
		if(this.imagedata.image != undefined){
			if(this.uploadedimage!=null && this.uploadedimage.name!='')
			{
				_formData.append('image',this.uploadedimage, this.uploadedimage.name);
				_formData.append('imagesrc',this.uploadedimage, this.uploadedimage.name);
			}
			if(this.imagedata.image != '' && this.imagedata.image != null)
			{
				_formData.append('image',this.imagedata.image);
			}
		}
		// *****************

		this.dbserv.saveimage("storiessave",_formData).subscribe(res => {
				if(res.type=="success")
				{
					this._alert.create(res.type,res.message);
					if(this.isUpdateMode){
						this.router.navigateByUrl('/myaccount/stories') ;
					} else {
						if (this.model.active == 'Preview') {
							window.open('/story/'+res.data.id,'_blank');
							this.model.id = res.data.id;
							// this.router.navigateByUrl('/story/'+res.data.id) ;
						}else{
							this.router.navigateByUrl('/myaccount/stories') ;
							this.model = {id:0, title: '',category_id:0,image:null,imagetitle:'',tags:[],gender:"",theme:"",description:"",credits:"",agree:false,active:"",shortdesc:""};
							/*this.loadpage(this.defaultparam);
							this.isshowform = false;*/
							 this.uploadedimagebtn = false;
							  this.imagedata={};
							this.uploadedimage=null;
							this.cropper.reset();
						}
					}
				}
				else if(res.type=="expired")
				{
					this.router.navigateByUrl('/login') ;	
				}
				else{
					this._alert.create(res.type,res.message);
				}
							
				this.uploadedimagebtn = false;
		}); 
		
	}
	add3Dots(string, limit)
	{
	if(string != null && string != undefined){
	  var dots = "...";
	  if(string.length > limit)
	  {
	    // you can also use substr instead of substring
	    string = string.substring(0,limit) + dots;
	  }
	    return string;
	    }
	}
    savestory(active){
        this.model.active = active;
        // this.saverecord(); 
    }
    loadddl()
	{
		this.categories = [];
		if(this.model.gender != ''){
			this.dbserv.getAll("storycatlist/"+this.model.theme+'/'+this.model.gender)
			.subscribe(res => {
				this.categories = res;
			});
		}
	}
	onItemSelect(item:any){
		console.log(item);
		console.log(this.model.tags);
	}
	OnItemDeSelect(item:any){
		console.log(item);
		console.log(this.model.tags);
	}
	onSelectAll(items: any){
		console.log(this.model.tags);
	}
	onDeSelectAll(items: any){
		console.log(this.model.tags);
	}
	newtag(){
		if(this.tags != ''){
			let model = {
				tag:this.tags,
				active:'Pending'
			}
			this.dbserv.save("storytagssave",model).subscribe(res => {
				if(res.type=="success")
				{
					this.tags = '';
					this.dbserv.getAll("storytagslist").subscribe(res => { this.tagslist = res.records;});
					this._alert.create(res.type,res.message);
				}
				else if(res.type=="expired")
				{
					this.router.navigateByUrl('/login') ;	
				}
				else
				{
					this._alert.create(res.type,res.message);
				}
			}); 
		}
	}
}
