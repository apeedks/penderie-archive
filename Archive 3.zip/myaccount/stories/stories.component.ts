import { Component, OnInit, HostListener, ElementRef, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../services/dbservice.service';
import { AuthenticationService } from '../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';
import * as _ from 'lodash';

@Component({
  selector: 'app-stories',
  templateUrl: './stories.component.html',
  styleUrls: ['./stories.component.css']
})
export class StoriesComponent implements OnInit {
	@ViewChild('lnktimelinesharebox') lnktimelinesharebox:ElementRef;
	wasClicked:boolean = false;
	totalitems: any;
	wasClicked1:boolean = false;
	custo_filter_onen_close = false;
	visiblefilter = false;
	custo_filter_onen_close1 = false;
	visiblefilter1 = false;
	userid = 0;
	categories: any;
	mytotalitems: any;
	mylastpage: number = 1;
	mypage: number = 1;
	loading = false;
	mylimit:number = 12;
	visittype = '';
    params:any = {searchfield:"",sortfield:'latest',filtercat:[]};
    paramssave:any = {searchfield:"",sortfield:'latest',filtercat:[]};
	genderfilter = 'Both';
	myitems = [];
	websiteroot = '';
	savedtotalitems: any;
	savedlastpage: number = 1;
	savedpage: number = 1;
	savedlimit:number = 12;
	saveditems = [];
	filters:any = {thetrueluxury:[],finematerial:[],superiorcraftsmanship:[],artofstyling:[],balancedliving:[]};
	filters1:any = {thetrueluxury:[],finematerial:[],superiorcraftsmanship:[],artofstyling:[],balancedliving:[]};
	rootpath = '';
	options:any;
	currtime:any;
	thetrueluxury:any;
	finematerial:any;
	superiorcraftsmanship:any;
	artofstyling:any;
	balancedliving:any;
	thetrueluxury1:any;
    finematerial1:any;
    superiorcraftsmanship1:any;
    artofstyling1:any;
    balancedliving1:any;
	mysharedstoryid: number =1;
	loaded:boolean = false;
	mysharedtype = 'Story';
	mysharedurl = '';
	mysharedescription = '';
	mysharedtitle = '';
	mysharedimage = '';
	loggedin="No";
	mysummary = {Published:0, Uploaded:0,Trash:0,Draft:0,Workinprogress:0,Total:0};
	constructor(private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private cookieService: CookieService) {
		this.rootpath = localStorage.getItem('baseurl');
		this.websiteroot = localStorage.getItem('basewebsiteurl');
		this.visittype = localStorage.getItem('visittype');
	}
	
	ngOnInit() {
	 scroll(0,0);
	this.loadddl();
		if(this.authserv.isloggedin())
		{
			this.authserv.session().subscribe(res => {
							if(res.isnew=='Yes')
								this.router.navigate(['/home']);
						});
			this.loadmyrecs(this.mypage); 
		}
		              $(".custo-filter-colap").click(function(e){
            if(!$(this).hasClass('custo_filter_onen_close')){
                $(".utl-filter-box").addClass('visiblefilter');
                $(".custo-filter-colap").addClass('custo_filter_onen_close');
                e.stopPropagation();
            }else{
                $(".utl-filter-box").removeClass('visiblefilter');
                $(".custo-filter-colap").removeClass('custo_filter_onen_close');
                e.stopPropagation();
            }
        });

        $(".utl-filter-box").click(function(e){
            e.stopPropagation();
        });

        $(document).click(function(){
            $(".utl-filter-box").removeClass('visiblefilter');
            $(".custo-filter-colap").removeClass('custo_filter_onen_close');
            // self.filterby();
		});
				if (this.authserv.isloggedin()) {
			this.loggedin = "Yes";
		}
	}
	
	loadmyrecs(page:number)
	{
	if(page == 1)
			this.myitems = [];
		this.currtime = Math.random();
		let cararray = [];
		this.filters.thetrueluxury.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.filters.finematerial.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.filters.superiorcraftsmanship.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.filters.artofstyling.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.filters.balancedliving.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.params.filtercat = cararray;
		
		/*this.params.searchfield = this.searchfield;*/
		this.currtime = Math.random();
		this.dbserv.post("mystories/"+this.genderfilter+"/"+page+"/"+this.mylimit,this.params)
		.subscribe(res => {
			if(res.type=="success")
			{
				if(page == 1)
					this.myitems = [];
				this.myitems = [ ...this.myitems, ...res.records.data]
				this.mypage = res.records.current_page;
				this.mylastpage = res.records.last_page; 
				this.totalitems = res.total;
				this.mytotalitems = res.records.total;
				this.dbserv.post("mystoriessummary/"+this.genderfilter+"/"+page+"/"+this.mylimit,this.params)
					.subscribe(res => {
						if(res.type=="success"){
							this.mysummary = res.records;
						}
					});
			}
			else if(res.type=="expired")
			{
				this.router.navigateByUrl('/login') ;	
			}
			else
				this._alert.create(res.type,res.message); 
		   
	}); 
	}
	loadsavedrecs(page:number)
	{
	console.log(this.filters1);
		if(page == 1)
			this.saveditems = [];
		this.currtime = Math.random();
		let cararray1 = [];
		this.filters1.thetrueluxury.forEach(obj=>{
			if(obj.checked)
				cararray1.push(obj.id);
		})
		this.filters1.finematerial.forEach(obj=>{
			if(obj.checked)
				cararray1.push(obj.id);
		})
		this.filters1.superiorcraftsmanship.forEach(obj=>{
			if(obj.checked)
				cararray1.push(obj.id);
		})
		this.filters1.artofstyling.forEach(obj=>{
			if(obj.checked)
				cararray1.push(obj.id);
		})
		this.filters1.balancedliving.forEach(obj=>{
			if(obj.checked)
				cararray1.push(obj.id);
		})
		
		this.paramssave.filtercat = cararray1;
		this.currtime = Math.random();
		this.dbserv.post("savedstories/"+this.genderfilter+"/"+page+"/"+this.savedlimit,this.paramssave).subscribe(res => {
																					if(res.type=="success")
																					{
																						this.saveditems = [ ...this.saveditems, ...res.records.data]
																						this.savedpage = res.records.current_page;
																						this.savedlastpage = res.records.last_page; 
																						this.savedtotalitems = res.records.total;
																						this.loaded = true;
																					}
																					else if(res.type=="expired")
																					{
																						this.router.navigateByUrl('/login') ;	
																					}
																					else
																						this._alert.create(res.type,res.message); 
																				   
																		}); 
	}
		sortswitch()
	{
		this.myitems = [];
		this.loadmyrecs(1);
	}
		sortswitch1()
	{
		this.saveditems = [];
		this.loadsavedrecs(1);
	}
	likeme(id,type,inx)
	{
		let params = {story_id:id,status:type};
		this.dbserv.post("storieslike",params)
			.subscribe(res => {
				if(res.type=="success")
				{
					if(type=="like")
					{
						$("#reclike" + id).css("display","none");
						$("#recunlike" + id).css("display","block");
					}
					else if(type=="unlike")
					{
						$("#reclike" + id).css("display","block");
						$("#recunlike" + id).css("display","none");
					}
					this.saveditems[inx].liked = res.total;
				}
				else if(res.type=="expired")
				{
					this.router.navigateByUrl('/login') ;	
				}
				else
					this._alert.create(res.type,res.message);
		});
	}
	saveme(id,type,inx)
	{
		let params = {story_id:id,status:type};
		
		this.dbserv.post("storiesmysavedlist",params)
			.subscribe(res => {
				if(res.type=="success")
				{
					if(type=="save")
					{
						$("#recsave" + id).css("display","none");
						$("#recunsave" + id).css("display","block");
					}
					else if(type=="unsave")
					{
						$("#recsave" + id).css("display","block");
						$("#recunsave" + id).css("display","none");
					}
					this.saveditems[inx].saved = res.total;
					this.loadsavedrecs(this.savedpage);
				}
				else if(res.type=="expired")
				{
					this.router.navigateByUrl('/login') ;	
				}
				else
					this._alert.create(res.type,res.message);
		});
	}
	shareme(currrec)
	{
		this.currtime = Math.random();
		this.mysharedurl = this.websiteroot+"story/"+currrec.id;
		this.mysharedescription = currrec.title;
		this.mysharedtitle = currrec.shortdesc;
		this.mysharedstoryid = currrec.id;
		this.mysharedimage = this.rootpath+'assets/stories/'+currrec.image+'?newtime='+this.currtime;
		this.lnktimelinesharebox.nativeElement.click();
	}
	filterby()
	{
		this.wasClicked = !this.wasClicked;
		if(this.wasClicked)
		{
			this.custo_filter_onen_close = true;
			this.visiblefilter = true;
			
		}
		else
		{
			this.custo_filter_onen_close = false;	
			this.visiblefilter = false;	
		}

	}
	filterby1()
	{
		this.wasClicked1 = !this.wasClicked1;
		if(this.wasClicked1)
		{
			this.custo_filter_onen_close1 = true;
			this.visiblefilter1 = true;
			
		}
		else
		{
			this.custo_filter_onen_close1 = false;	
			this.visiblefilter1 = false;	
		}

	}
	
	addnewstory()
	{
		this.userid = this.authserv.getUserId();
		if(this.userid>0)
		{
			this.router.navigate(['/myaccount/poststory']);
		}	
	}
	switchtabs(tab)
	{
		switch(tab)
		{
			case "1":
				this.myitems = [];
				this.loadmyrecs(this.mypage);
				break;
			case "2":
				this.saveditems = [];
				this.loadsavedrecs(this.savedpage);
				break;
		}
		$(".tabheadings").removeClass("active");
		$("#headtab"+ tab).addClass("active");
		$(".tab_prefcontentjquery").removeClass("activeitem");
		$(".tab_prefcontentjquery").addClass("inactiveitem");
		$("#tab"+ tab).removeClass("inactiveitem");
		$("#tab"+ tab).addClass("activeitem");
	}
	
		selecfillter(event:any, id:any = ''){
		// console.log(event);
		if(id == '' || id == 0 || id == null || id == undefined){
			switch (event.target.value) {
				case "thetrueluxury":
					this.filters.thetrueluxury.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "finematerial":
					this.filters.finematerial.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "superiorcraftsmanship":
					this.filters.superiorcraftsmanship.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "artofstyling":
					this.filters.artofstyling.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "balancedliving":
					this.filters.balancedliving.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
			}
			this.myitems = [];
			this.loadmyrecs(1);
		}
	}
	selecrmethod()
	{	this.myitems = [];
		this.loadmyrecs(1);
	}
	
	selecfillter1(event:any, id:any = ''){
		if(id == '' || id == 0 || id == null || id == undefined){
			switch (event.target.value) {
				case "thetrueluxury":
					this.filters1.thetrueluxury.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "finematerial":
					this.filters1.finematerial.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "superiorcraftsmanship":
					this.filters1.superiorcraftsmanship.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "artofstyling":
					this.filters1.artofstyling.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "balancedliving":
					this.filters1.balancedliving.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
			}
			
			this.saveditems = [];
			this.loadsavedrecs(1);
		}
	}
	selecrmethod1()
	{
		this.saveditems = [];
		this.loadsavedrecs(1);
	}
	
	loadddl()
	{
		this.categories = [];
		this.dbserv.getAll("storycatlist/-/"+this.visittype).subscribe(res => { this.categories = res;});
		this.dbserv.getAll("storycatlist/The True Luxury/"+this.visittype)
		.subscribe(res => { 
			this.filters.thetrueluxury = _.cloneDeep(res);
			this.filters1.thetrueluxury = _.cloneDeep(res);
		});
		this.dbserv.getAll("storycatlist/Fine Material/"+this.visittype)
		.subscribe(res => { 
			this.filters.finematerial = _.cloneDeep(res);
			this.filters1.finematerial = _.cloneDeep(res);
		});
		this.dbserv.getAll("storycatlist/Superior Craftsmanship/"+this.visittype)
		.subscribe(res => { 
			this.filters.superiorcraftsmanship = _.cloneDeep(res);
			this.filters1.superiorcraftsmanship = _.cloneDeep(res);
		});
		this.dbserv.getAll("storycatlist/Art of Styling/"+this.visittype)
		.subscribe(res => { 
			this.filters.artofstyling = _.cloneDeep(res);
			this.filters1.artofstyling = _.cloneDeep(res);
		});
		this.dbserv.getAll("storycatlist/Balanced Living/"+this.visittype)
		.subscribe(res => { 
			this.filters.balancedliving = _.cloneDeep(res);
			this.filters1.balancedliving = _.cloneDeep(res);
		});
			//this.filters1 = _.cloneDeep(this.filters);
	}
	datecompare(date:any)
	{
		let oneDay = 24*60*60*1000; // hours*minutes*seconds*milliseconds
		let firstDate = new Date();
		let secondDate = new Date(date);
		return Math.round(Math.abs((firstDate.getTime() - secondDate.getTime())/(oneDay)));
	}
	add3Dots(string, limit)
	{
	if(string != null && string != undefined){
	  var dots = "...";
	  if(string.length > limit)
	  {
	    // you can also use substr instead of substring
	    string = string.substring(0,limit) + dots;
	  }
	    return string;
	    }
	}
      selectAll(event:any){
      this.thetrueluxury = event.target.checked;
      this.finematerial = event.target.checked;
      this.superiorcraftsmanship = event.target.checked;
      this.artofstyling = event.target.checked;
      this.balancedliving = event.target.checked;
      event.target.value = 'thetrueluxury';
      this.selecfillter(event);
      event.target.value = 'finematerial';
      this.selecfillter(event);
      event.target.value = 'superiorcraftsmanship';
      this.selecfillter(event);
      event.target.value = 'artofstyling';
      this.selecfillter(event);
      event.target.value = 'balancedliving';
      this.selecfillter(event);
    this.myitems = [];
    this.loadmyrecs(this.mypage);
  }
      selectAll1(event:any){
          this.thetrueluxury1 = event.target.checked;
          this.finematerial1 = event.target.checked;
          this.superiorcraftsmanship1 = event.target.checked;
          this.artofstyling1 = event.target.checked;
          this.balancedliving1 = event.target.checked;
          event.target.value = 'thetrueluxury';
          this.selecfillter1(event);
          event.target.value = 'finematerial';
          this.selecfillter1(event);
          event.target.value = 'superiorcraftsmanship';
          this.selecfillter1(event);
          event.target.value = 'artofstyling';
          this.selecfillter1(event);
          event.target.value = 'balancedliving';
          this.selecfillter1(event);
        this.saveditems = [];
        this.loadsavedrecs(this.savedpage);
      }  
  	removeme(id,type)
	{
		let params = {story_id:id,status:type};
		this.dbserv.post("storiesmysavedlist",params).subscribe(res => {
																		this._alert.create(res.type,res.message);
																		this.loadsavedrecs(1);
														});
														
	}
	opensharebox(id)
	{
		this.lnktimelinesharebox.nativeElement.click();
	}
	street(id){
		$("#ellipsis-"+id).children().toggleClass('fa fa-ellipsis-h fa fa-ellipsis-v');
		$("#street-"+id).toggle();
	}	
	throttle = (250 * 3);
    scrollDistance = 1;
    scrollUpDistance = 2;
    onScrollDownMyRecs() {
        //console.log("my");
        if(this.mytotalitems>this.myitems.length){
            this.mypage++;
            this.loadmyrecs(this.mypage);
        }
    }
    throttleSave = (250 * 3);
    scrollSaveDistance = 1;
    scrollUpSaveDistance = 2;
    onScrollDownSaveRecs() {
        if(this.savedtotalitems>this.saveditems.length){
            this.savedpage++;
            this.loadsavedrecs(this.savedpage);
        }
    }
}
