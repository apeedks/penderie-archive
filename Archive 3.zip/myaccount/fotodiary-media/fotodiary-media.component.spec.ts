import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FotodiaryMediaComponent } from './fotodiary-media.component';

describe('FotodiaryMediaComponent', () => {
  let component: FotodiaryMediaComponent;
  let fixture: ComponentFixture<FotodiaryMediaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FotodiaryMediaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FotodiaryMediaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
