import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-memguestbook',
  templateUrl: './memguestbook.component.html',
  styleUrls: ['./memguestbook.component.css']
})
export class MemguestbookComponent implements OnInit {
	wasClicked:boolean = false;
	custo_filter_onen_close = false;
	visiblefilter = false;
	
	constructor() { }
	
	ngOnInit() {
	}
	
	filterby()
	{
		this.wasClicked = !this.wasClicked;
		if(this.wasClicked)
		{
			this.custo_filter_onen_close = true;
			this.visiblefilter = true;
			
		}
		else
		{
			this.custo_filter_onen_close = false;	
			this.visiblefilter = false;	
		}
	
	}

}
