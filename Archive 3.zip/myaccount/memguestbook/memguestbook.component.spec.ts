import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MemguestbookComponent } from './memguestbook.component';

describe('MemguestbookComponent', () => {
  let component: MemguestbookComponent;
  let fixture: ComponentFixture<MemguestbookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MemguestbookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MemguestbookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
