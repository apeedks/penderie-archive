import { Component, OnInit, Input, Output, EventEmitter, HostListener } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-preference',
  templateUrl: './preference.component.html',
  styleUrls: ['./preference.component.css']
})
export class PreferenceComponent implements OnInit {
	options:any;
	preflistdefault:string = '';
	prefcatlist = [];
	preftypelist = [];
    gender =[];
	selectedprefs = [];
	userid:number;
	constructor(private route: ActivatedRoute,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private auth:AuthenticationService,private cookieService: CookieService) {
		
	}
	getselectedprefs()
	{
	}
	saveprefs()
	{
		this.selectedprefs = [];
		for(let x in this.prefcatlist) {
			if(this.prefcatlist[x].checked)
				this.selectedprefs.push({c:this.prefcatlist[x].id});
			if(this.prefcatlist[x].items)
				for(let y in this.prefcatlist[x].items) {
					if(this.prefcatlist[x].items[y].checked)
						this.selectedprefs.push({b:this.prefcatlist[x].items[y].id});
				}
		}	
		if(this.selectedprefs.length<1 && this.selectedprefs.length>3)
		{
			this._alert.create('error','You must select alteast 1 and atmost 3 Luxury Brands.');
			return false;
		}
		else
		{
			let model = {prefs:this.selectedprefs,type:'Luxury Brands'}
			this.dbserv.save("savefrontcatsbrandstypesprefs",model).subscribe(res => {
														this._alert.create(res.type,res.message);
													});	
		}
		
		this.selectedprefs = [];
		for(let x in this.preftypelist) {
			if(this.preftypelist[x].checked)
				this.selectedprefs.push({c:this.preftypelist[x].id});
			if(this.preftypelist[x].items)
				for(let y in this.preftypelist[x].items) {
					if(this.preftypelist[x].items[y].checked)
						this.selectedprefs.push({b:this.preftypelist[x].items[y].id});
				}
		}	
		if(this.selectedprefs.length<1 && this.selectedprefs.length>3)
		{
			this._alert.create('error','You must select alteast 1 and atmost 3 Luxury Brands.');
			return false;
		}
		else
		{
			let model = {prefs:this.selectedprefs,type:'Material'}
			this.dbserv.save("savefrontcatsbrandstypesprefs",model).subscribe(res => {
														this._alert.create(res.type,res.message);
													});	
		}
	}
	prefcontent(tab)
	{
		$(".tab_prefcontentjquery").removeClass("active");
		$("#prefmytab"+ tab).addClass("active");
		$(".preftabheaders").removeClass("active");
		$("#preftabhead"+ tab).addClass("active");
	}
	ngOnInit() {
	    scroll(0,0);
//	    $('html, body').animate({
//            scrollTop: $("#collapseExample").offset().top - 70
//        });
		this.userid = this.auth.getUserId();
		if(this.userid>0)
		{
			let tvp:string = this.cookieService.get('visittype');
            this.dbserv.getAll("getuserdetail/"+this.userid)
                .subscribe(data => {
                    if(data.type=="success")
                    {
                        this.dbserv.getAll("prefcatsbrands/"+data.data.gender).subscribe(res => {
                            if(res.type=="success")
                            {
                                this.prefcatlist = res.data;
                            }
                            else if(res.type=="expired")
                            {
                                this.router.navigateByUrl('/login') ;   
                            }
                            else
                                this._alert.create(res.type,res.message);
                        });
                        this.dbserv.getAll("prefcatstypes/"+data.data.gender).subscribe(res => {
                            if(res.type=="success")
                            {
                                this.preftypelist = res.data;
                            }
                            else if(res.type=="expired")
                            {
                                this.router.navigateByUrl('/login') ;   
                            }
                            else
                                this._alert.create(res.type,res.message);
                        });
                    }
                });
		}
		else
		{
			this.router.navigate(['login']);	
		}
	}

}
