import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fotodiary-albums',
  templateUrl: './fotodiary-albums.component.html',
  styleUrls: ['./fotodiary-albums.component.css']
})
export class FotodiaryAlbumsComponent implements OnInit {
	wasClicked:boolean = false;
	custo_filter_onen_close = false;
	visiblefilter = false;
	
	constructor() { }
	
	ngOnInit() {
	}
	
	filterby()
	{
		this.wasClicked = !this.wasClicked;
		if(this.wasClicked)
		{
			this.custo_filter_onen_close = true;
			this.visiblefilter = true;
			
		}
		else
		{
			this.custo_filter_onen_close = false;	
			this.visiblefilter = false;	
		}
	
	}

}
