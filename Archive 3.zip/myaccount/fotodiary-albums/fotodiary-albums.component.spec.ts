import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FotodiaryAlbumsComponent } from './fotodiary-albums.component';

describe('FotodiaryAlbumsComponent', () => {
  let component: FotodiaryAlbumsComponent;
  let fixture: ComponentFixture<FotodiaryAlbumsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FotodiaryAlbumsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FotodiaryAlbumsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
