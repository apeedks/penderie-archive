import { Component, OnInit, trigger, state, style, transition, animate } from '@angular/core';
import {DbserviceService} from '../services/dbservice.service';
import { AuthenticationService } from '../services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import {IMyDpOptions,IMyDateModel} from 'mydatepicker';
import $ from 'jquery';
@Component({
  selector: 'app-myabout',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
    countryArray = [
                    {
                        countryCode:"GB",
                        pattern:"GIR[ ]?0AA|((AB|AL|B|BA|BB|BD|BH|BL|BN|BR|BS|BT|CA|CB|CF|CH|CM|CO|CR|CT|CV|CW|DA|DD|DE|DG|DH|DL|DN|DT|DY|E|EC|EH|EN|EX|FK|FY|G|GL|GY|GU|HA|HD|HG|HP|HR|HS|HU|HX|IG|IM|IP|IV|JE|KA|KT|KW|KY|L|LA|LD|LE|LL|LN|LS|LU|M|ME|MK|ML|N|NE|NG|NN|NP|NR|NW|OL|OX|PA|PE|PH|PL|PO|PR|RG|RH|RM|S|SA|SE|SG|SK|SL|SM|SN|SO|SP|SR|SS|ST|SW|SY|TA|TD|TF|TN|TQ|TR|TS|TW|UB|W|WA|WC|WD|WF|WN|WR|WS|WV|YO|ZE)(\\d[\\dA-Z]?[ ]?\\d[ABD-HJLN-UW-Z]{2}))|BFPO[ ]?\\d{1,4}"
                    },
                    {
                        countryCode:"JE",
                        pattern:"JE\\d[\\dA-Z]?[ ]?\\d[ABD-HJLN-UW-Z]{2}"
                    },
                    {
                        countryCode:"GG",
                        pattern:"GY\\d[\\dA-Z]?[ ]?\\d[ABD-HJLN-UW-Z]{2}"
                    },
                    {
                        countryCode:"IM",
                        pattern:"IM\\d[\\dA-Z]?[ ]?\\d[ABD-HJLN-UW-Z]{2}"
                    },
                    {
                        countryCode:"US",
                        pattern:"\\d{5}([ \\-]\\d{4})?"
                    },
                    {
                        countryCode:"CA",
                        pattern:"[ABCEGHJKLMNPRSTVXY]\\d[ABCEGHJ-NPRSTV-Z][ ]?\\d[ABCEGHJ-NPRSTV-Z]\\d"
                    },
                    {
                        countryCode:"DE",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"JP",
                        pattern:"\\d{3}-\\d{4}"
                    },
                    {
                        countryCode:"FR",
                        pattern:"\\d{2}[ ]?\\d{3}"
                    },
                    {
                        countryCode:"AU",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"IT",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"CH",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"AT",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"ES",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"NL",
                        pattern:"\\d{4}[ ]?[A-Z]{2}"
                    },
                    {
                        countryCode:"BE",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"DK",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"SE",
                        pattern:"\\d{3}[ ]?\\d{2}"
                    },
                    {
                        countryCode:"NO",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"BR",
                        pattern:"\\d{5}[\\-]?\\d{3}"
                    },
                    {
                        countryCode:"PT",
                        pattern:"\\d{4}([\\-]\\d{3})?"
                    },
                    {
                        countryCode:"FI",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"AX",
                        pattern:"22\\d{3}"
                    },
                    {
                        countryCode:"KR",
                        pattern:"\\d{3}[\\-]\\d{3}"
                    },
                    {
                        countryCode:"CN",
                        pattern:"\\d{6}"
                    },
                    {
                        countryCode:"TW",
                        pattern:"\\d{3}(\\d{2})?"
                    },
                    {
                        countryCode:"SG",
                        pattern:"\\d{6}"
                    },
                    {
                        countryCode:"DZ",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"AD",
                        pattern:"AD\\d{3}"
                    },
                    {
                        countryCode:"AR",
                        pattern:"([A-HJ-NP-Z])?\\d{4}([A-Z]{3})?"
                    },
                    {
                        countryCode:"AM",
                        pattern:"(37)?\\d{4}"
                    },
                    {
                        countryCode:"AZ",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"BH",
                        pattern:"((1[0-2]|[2-9])\\d{2})?"
                    },
                    {
                        countryCode:"BD",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"BB",
                        pattern:"(BB\\d{5})?"
                    },
                    {
                        countryCode:"BY",
                        pattern:"\\d{6}"
                    },
                    {
                        countryCode:"BM",
                        pattern:"[A-Z]{2}[ ]?[A-Z0-9]{2}"
                    },
                    {
                        countryCode:"BA",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"IO",
                        pattern:"BBND 1ZZ"
                    },
                    {
                        countryCode:"BN",
                        pattern:"[A-Z]{2}[ ]?\\d{4}"
                    },
                    {
                        countryCode:"BG",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"KH",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"CV",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"CL",
                        pattern:"\\d{7}"
                    },
                    {
                        countryCode:"CR",
                        pattern:"\\d{4,5}|\\d{3}-\\d{4}"
                    },
                    {
                        countryCode:"HR",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"CY",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"CZ",
                        pattern:"\\d{3}[ ]?\\d{2}"
                    },
                    {
                        countryCode:"DO",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"EC",
                        pattern:"([A-Z]\\d{4}[A-Z]|(?:[A-Z]{2})?\\d{6})?"
                    },
                    {
                        countryCode:"EG",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"EE",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"FO",
                        pattern:"\\d{3}"
                    },
                    {
                        countryCode:"GE",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"GR",
                        pattern:"\\d{3}[ ]?\\d{2}"
                    },
                    {
                        countryCode:"GL",
                        pattern:"39\\d{2}"
                    },
                    {
                        countryCode:"GT",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"HT",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"HN",
                        pattern:"(?:\\d{5})?"
                    },
                    {
                        countryCode:"HU",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"IS",
                        pattern:"\\d{3}"
                    },
                    {
                        countryCode:"IN",
                        pattern:"\\d{6}"
                    },
                    {
                        countryCode:"ID",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"IL",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"JO",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"KZ",
                        pattern:"\\d{6}"
                    },
                    {
                        countryCode:"KE",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"KW",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"LA",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"LV",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"LB",
                        pattern:"(\\d{4}([ ]?\\d{4})?)?"
                    },
                    {
                        countryCode:"LI",
                        pattern:"(948[5-9])|(949[0-7])"
                    },
                    {
                        countryCode:"LT",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"LU",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"MK",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"MY",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"MV",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"MT",
                        pattern:"[A-Z]{3}[ ]?\\d{2,4}"
                    },
                    {
                        countryCode:"MU",
                        pattern:"(\\d{3}[A-Z]{2}\\d{3})?"
                    },
                    {
                        countryCode:"MX",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"MD",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"MC",
                        pattern:"980\\d{2}"
                    },
                    {
                        countryCode:"MA",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"NP",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"NZ",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"NI",
                        pattern:"((\\d{4}-)?\\d{3}-\\d{3}(-\\d{1})?)?"
                    },
                    {
                        countryCode:"NG",
                        pattern:"(\\d{6})?"
                    },
                    {
                        countryCode:"OM",
                        pattern:"(PC )?\\d{3}"
                    },
                    {
                        countryCode:"PK",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"PY",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"PH",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"PL",
                        pattern:"\\d{2}-\\d{3}"
                    },
                    {
                        countryCode:"PR",
                        pattern:"00[679]\\d{2}([ \\-]\\d{4})?"
                    },
                    {
                        countryCode:"RO",
                        pattern:"\\d{6}"
                    },
                    {
                        countryCode:"RU",
                        pattern:"\\d{6}"
                    },
                    {
                        countryCode:"SM",
                        pattern:"4789\\d"
                    },
                    {
                        countryCode:"SA",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"SN",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"SK",
                        pattern:"\\d{3}[ ]?\\d{2}"
                    },
                    {
                        countryCode:"SI",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"ZA",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"LK",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"TJ",
                        pattern:"\\d{6}"
                    },
                    {
                        countryCode:"TH",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"TN",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"TR",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"TM",
                        pattern:"\\d{6}"
                    },
                    {
                        countryCode:"UA",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"UY",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"UZ",
                        pattern:"\\d{6}"
                    },
                    {
                        countryCode:"VA",
                        pattern:"00120"
                    },
                    {
                        countryCode:"VE",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"ZM",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"AS",
                        pattern:"96799"
                    },
                    {
                        countryCode:"CC",
                        pattern:"6799"
                    },
                    {
                        countryCode:"CK",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"RS",
                        pattern:"\\d{6}"
                    },
                    {
                        countryCode:"ME",
                        pattern:"8\\d{4}"
                    },
                    {
                        countryCode:"CS",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"YU",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"CX",
                        pattern:"6798"
                    },
                    {
                        countryCode:"ET",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"FK",
                        pattern:"FIQQ 1ZZ"
                    },
                    {
                        countryCode:"NF",
                        pattern:"2899"
                    },
                    {
                        countryCode:"FM",
                        pattern:"(9694[1-4])([ \\-]\\d{4})?"
                    },
                    {
                        countryCode:"GF",
                        pattern:"9[78]3\\d{2}"
                    },
                    {
                        countryCode:"GN",
                        pattern:"\\d{3}"
                    },
                    {
                        countryCode:"GP",
                        pattern:"9[78][01]\\d{2}"
                    },
                    {
                        countryCode:"GS",
                        pattern:"SIQQ 1ZZ"
                    },
                    {
                        countryCode:"GU",
                        pattern:"969[123]\\d([ \\-]\\d{4})?"
                    },
                    {
                        countryCode:"GW",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"HM",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"IQ",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"KG",
                        pattern:"\\d{6}"
                    },
                    {
                        countryCode:"LR",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"LS",
                        pattern:"\\d{3}"
                    },
                    {
                        countryCode:"MG",
                        pattern:"\\d{3}"
                    },
                    {
                        countryCode:"MH",
                        pattern:"969[67]\\d([ \\-]\\d{4})?"
                    },
                    {
                        countryCode:"MN",
                        pattern:"\\d{6}"
                    },
                    {
                        countryCode:"MP",
                        pattern:"9695[012]([ \\-]\\d{4})?"
                    },
                    {
                        countryCode:"MQ",
                        pattern:"9[78]2\\d{2}"
                    },
                    {
                        countryCode:"NC",
                        pattern:"988\\d{2}"
                    },
                    {
                        countryCode:"NE",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"VI",
                        pattern:"008(([0-4]\\d)|(5[01]))([ \\-]\\d{4})?"
                    },
                    {
                        countryCode:"PF",
                        pattern:"987\\d{2}"
                    },
                    {
                        countryCode:"PG",
                        pattern:"\\d{3}"
                    },
                    {
                        countryCode:"PM",
                        pattern:"9[78]5\\d{2}"
                    },
                    {
                        countryCode:"PN",
                        pattern:"PCRN 1ZZ"
                    },
                    {
                        countryCode:"PW",
                        pattern:"96940"
                    },
                    {
                        countryCode:"RE",
                        pattern:"9[78]4\\d{2}"
                    },
                    {
                        countryCode:"SH",
                        pattern:"(ASCN|STHL) 1ZZ"
                    },
                    {
                        countryCode:"SJ",
                        pattern:"\\d{4}"
                    },
                    {
                        countryCode:"SO",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"SZ",
                        pattern:"[HLMS]\\d{3}"
                    },
                    {
                        countryCode:"TC",
                        pattern:"TKCA 1ZZ"
                    },
                    {
                        countryCode:"WF",
                        pattern:"986\\d{2}"
                    },
                    {
                        countryCode:"XK",
                        pattern:"\\d{5}"
                    },
                    {
                        countryCode:"YT",
                        pattern:"976\\d{2}"
                    }
                ];
    zippattern="";
	gmodel = {id:0, maritalstatus: "",occupation: "",birthday:"",country: "",state: "",city: "",zipcode: "",aboutme: "", facebook: "",twitter: "",linkedin:"",instagram: "",pinterest: "",youtube: "",google: "",website: "", gender:"",firstname:"",lastname:"",name:""};
	record = {id:0,name:"",email:"",usertype:"",verified:"",image:"",updated_at:"",firstname:"",lastname:"",gender:"",maritalstatus:"",occupation:"",birthday:"",mobileno:"",country:"",state:"",city:"",zipcode:"",initials:"",aboutme:"",connectiontype:""};
	socailmodel = {id:0, facebook: "",twitter: "",linkedin:"",instagram: "",pinterest: "",youtube: "",google: "",website: ""};
	modelother = {id:0,userid:0, type: "",title: ""};
	languagelist:any;
	options:any;
	tabfirst = true;
	tabsecond = false;
	activeone = true;
	activetwo = false;
	countrylist:any;
	languages = [];
	places = [];
	countWebPresense = 0;
	isallowed = true;
	followerstep:boolean = true;
	disableSince:any = {};
	webpresence_facebook = [];
	public myDatePickerOptions: IMyDpOptions = {
        // other options...
	    editableDateField:false,
        dateFormat: 'mm/dd/yyyy',
    };
	model2: any = { date: { year: 2018, month: 10, day: 9 } };
	statelist:any;
	citylist:any;
	userid=0;
	constructor(private authserv: AuthenticationService,private _alert: AlertsService,private dbserv:DbserviceService,private router: Router,private cookieService: CookieService) 
	{ 
		// let date = new Date();
		// this.model2.date.year = date.getFullYear();
		// this.model2.date.month = date.getMonth();
		// this.model2.date.day = date.getDate();
		let today = new Date();
		this.disableSince = { year: today.getFullYear(), month: today.getMonth() + 1, day: today.getDate() };
		this.myDatePickerOptions.disableSince = this.disableSince;
		let date = new Date();
		// this.gmodel.birthday = this.model2.date.year + "-" + (this.model2.date.month+1) + "-" + this.model2.date.day;
	}
	onDateChanged(event: IMyDateModel) {
        // event properties are: event.date, event.jsdate, event.formatted and event.epoc
		if(event.jsdate)
		{
			this.gmodel.birthday = event.jsdate.getFullYear() + "-" + event.jsdate.getMonth() + "-" + event.jsdate.getDate();
			console.log(this.gmodel.birthday);
		}
    }
	states()
	{
		this.dbserv.getAll("states/" + this.gmodel.country).subscribe(res => {this.statelist = res;this.cities();});
	      this.citylist = [];
	        /*this.gmodel.city = '';*/
	        //this.statelist = [];
	       /* this.gmodel.state = '';*/
		
//		this.citylist = [];
//		this.gmodel.city = '';
//		this.statelist = [];
//		this.gmodel.state = '';
        let pattern = this.countryArray.find(x => x.countryCode === this.gmodel.country);
        console.log(pattern);
        if(pattern != undefined)
            this.zippattern = pattern.pattern;
        else
            this.zippattern = "";
	}
	cities()
	{
		this.dbserv.getAll("cities/" + this.gmodel.country + "/" + this.gmodel.state).subscribe(res => {
		    this.citylist = res;
		    this.citylist.push({city:"Other"});
		});
	}
	savegeneralrec()
	{
		this.dbserv.save("saveaboutinto",this.gmodel).subscribe(res => {
			
														   this._alert.create(res.type,res.message);
														 });	
	}
	savewebpresence()
	{
		this.dbserv.save("savesocialinfo",this.socailmodel).subscribe(res => {
														   this._alert.create(res.type,res.message);
														 });	
	}
	ngOnInit() {
		if(this.authserv.isloggedin())
		{
			this.authserv.session().subscribe(res => {
							if(res.isnew=='Yes')
								this.router.navigate(['/home']);
						});
			this.userid = +this.authserv.getUserId();
			this.gmodel.id = this.userid;
			this.dbserv.getAll("countries").subscribe(res => {this.countrylist = res;});
			this.dbserv.getById("getaboutinto",this.userid).subscribe(res => {
				this.gmodel = res.data;
				this.gmodel.name = res.user.name;
				let dob:string = this.gmodel.birthday;
				if(dob && dob!='')
				{
					let db_date = new Date(dob);
					this.model2 = { date: { year: +(db_date.getFullYear()), month: +(db_date.getMonth()+1), day: +(db_date.getDate()) } };
					
					//console.log(this.model2);
				}
				
				this.states();
			});
			 this.dbserv.getById("getuserdetail",this.userid).subscribe(res => {
		            if(res.type=="success")
		            {
		                this.record = res.data;
		            }
		            
		        });
			this.dbserv.getById("getsocialinfo",this.userid).subscribe(res => {this.socailmodel = res.data;});
			
			this.dbserv.getAll("sourcebytype/language").subscribe(res => {this.languagelist = res;});
			
			this.loadlanguages();
			this.loadplaces();
		}
		else
			this.router.navigate(["/login"]);
	}
	ngAfterViewInit(){
		/* $('html, body').animate({
         	scrollTop: $("#collapseExample").offset().top - 70
    	});*/
	}
	loadlanguages()
	{
		this.dbserv.getAll("memgeneral/"+this.userid+"/languages").subscribe(res => {this.languages = res;});
	}
	savelanguage()
	{	
		this.modelother.userid = this.userid;
		this.modelother.type = 'languages';
		this.dbserv.save("memgeneralsave",this.modelother).subscribe(res => { 
																	   this._alert.create(res.type,res.message);
																	   if(res.type=="success")
																	   {
																			this.modelother = {id:0,userid:0,type:"",title:""};
																			this.loadlanguages();
																	   }
																	});
	}
	loadplaces()
	{
		this.dbserv.getAll("memgeneral/"+this.userid+"/places").subscribe(res => {this.places = res;});	
	}
	saveplaces()
	{
		this.modelother.userid = this.userid;
		this.modelother.type = 'places';
		this.dbserv.save("memgeneralsave",this.modelother).subscribe(res => { 
																	   this._alert.create(res.type,res.message);
																	   if(res.type=="success")
																	   {
																			this.modelother = {id:0,userid:0,type:"",title:""};
																			this.loadplaces();
																	   }
																	});

	}
	deletememgen(id,type)
	{
		
		this.dbserv.delete("memgeneraldelete", id).subscribe(res => { 
															 this._alert.create(res.type,res.message);
															 if(type=='languages')
															 	this.loadlanguages();
															 else
																this.loadplaces();
														});
		
	}
	tabcontent(tab:string)
	{
		if(tab=='photo')
		{
			this.activeone = true;
			this.activetwo = false;
			this.tabfirst = true;
			this.tabsecond = false;
		}
		else
		{
			this.activeone = false;
			this.activetwo = true;
			this.tabfirst = false;
			this.tabsecond = true;
		}
	}
	
	checkWebPres()
	{
		this.countWebPresense = 0;
		if(this.socailmodel.facebook !== ''){
			this.countWebPresense++;
		}

		if(this.socailmodel.twitter !== ''){
			this.countWebPresense++;
		}

		if(this.socailmodel.linkedin !== ''){
			this.countWebPresense++;
		}

		if(this.socailmodel.instagram !== ''){
			this.countWebPresense++;
		}

		if(this.socailmodel.pinterest !== ''){
			this.countWebPresense++;
		}

		if(this.socailmodel.youtube !== ''){
			this.countWebPresense++;
		}

		if(this.socailmodel.google !== ''){
			this.countWebPresense++;
		}

		if(this.socailmodel.website !== ''){
			this.countWebPresense++;
		}
		
		if(this.countWebPresense >= 3){
			this.isallowed = true;
		}else {
			this.isallowed = false;
		}
	}
	matchregex()
    {
	    this.webpresence_facebook = (this.socailmodel.facebook.match("https://www.facebook.com/"));
	    
    }
	
}
