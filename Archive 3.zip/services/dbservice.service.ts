import { Injectable } from '@angular/core';
import { Http, Headers, Response,RequestOptions} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import $ from 'jquery';
import 'rxjs/add/operator/map';
@Injectable()
export class DbserviceService {
	serviceBase:string = "";
	public token: string;
	constructor(private http: Http) {
		// set token if saved in local storage
		var currentUser = JSON.parse(localStorage.getItem('currentUser'));
		this.token = currentUser && currentUser.token;	
		this.serviceBase = localStorage.getItem('apiurl');
	}
	showloader(status)
	{
		if(status)
			$(".myloaderdiv").css('display','block');
		else
			$(".myloaderdiv").css('display','none');
	}
	//Non registered calls
	getdirectAll(callurl:string) {
         this.showloader(true);
		return this.http.get(this.serviceBase + callurl).map((response: Response) => { this.showloader(false); return response.json(); }).catch(e => {
																	if (e.status === 400 || e.status === 401) {
																		this.showloader(false);
																		return Observable.throw('Unauthorized');
																	}
																	this.showloader(false);
																});
    }
	getdirectpost(callurl:string, obj: any) {
         this.showloader(true);
		return this.http.post(this.serviceBase + callurl, obj).map((response: Response) => { this.showloader(false); return response.json(); }).catch(e => {
																	if (e.status === 400 || e.status === 401) {
																		this.showloader(false);
																		return Observable.throw('Unauthorized');
																	}
																	this.showloader(false);
																});
    }
	getByStringId(callurl:string, id: string) {
		 this.showloader(true);
        return this.http.get(this.serviceBase + callurl + '/' + id).map((response: Response) => response.json());
    }
	saveimage(callurl:string, obj: any) {
		 this.showloader(true);
        return this.http.post(this.serviceBase + callurl, obj, this.jwtmultypart()).map((response: Response) => { this.showloader(false); return response.json(); }).catch(e => {
																	if (e.status === 400 || e.status === 401) {
																		this.showloader(false);
																		return Observable.throw('Unauthorized');
																	}
																	this.showloader(false);
																});
    }
    //Ajay Parmar
    sendEmailMulti(callurl:string, obj: any) {
		 this.showloader(true);
        return this.http.post(this.serviceBase + callurl, obj, this.jwtmultypart()).map((response: Response) => { this.showloader(false); return response.json(); }).catch(e => {
																	if (e.status === 400 || e.status === 401) {
																		this.showloader(false);
																		return Observable.throw('Unauthorized');
																	}
																	this.showloader(false);
																});
    }
	post(callurl:string, obj: any) {
       this.showloader(true);
	   return this.http.post(this.serviceBase + callurl, obj, this.jwt()).map((response: Response) => { this.showloader(false); return response.json(); }).catch(e => {
																	if (e.status === 400 || e.status === 401) {
																		this.showloader(false);
																		return Observable.throw('Unauthorized');
																	}
																	this.showloader(false);
																});
    }
	//registered user calls
	getAll(callurl:string, needTOShowLoader:boolean = true) {
		if(needTOShowLoader){
			this.showloader(true);
		}
        return this.http.get(this.serviceBase + callurl, this.jwt()).map((response: Response) => { this.showloader(false); return response.json(); }).catch(e => {
			if (e.status === 400 || e.status === 401) {
				this.showloader(false);
				return Observable.throw('Unauthorized');
			}
			this.showloader(false);
		});
    }
	get(callurl:string) {
		this.showloader(true);
        return this.http.get(this.serviceBase + callurl, this.jwt()).map((response: Response) => { this.showloader(false); return response.json(); }).catch(e => {
																	if (e.status === 400 || e.status === 401) {
																		this.showloader(false);
																		return Observable.throw('Unauthorized');
																	}
																	this.showloader(false);
																});
    }

    getById(callurl:string, id: number) {
		this.showloader(true);
        return this.http.get(this.serviceBase + callurl + '/' + id, this.jwt()).map((response: Response) => { this.showloader(false); return response.json(); }).catch(e => {
																	if (e.status === 400 || e.status === 401) {
																		this.showloader(false);
																		return Observable.throw('Unauthorized');
																	}
																	this.showloader(false);
																});
    }
    save(callurl:string, obj: any) {
		 this.showloader(true);
        return this.http.post(this.serviceBase + callurl, obj, this.jwt()).map((response: Response) => { this.showloader(false); return response.json(); }).catch(e => {
																	if (e.status === 400 || e.status === 401) {
																		this.showloader(false);
																		return Observable.throw('Unauthorized');
																	}
																	this.showloader(false);
																});
    }

    delete(callurl:string, id: number) {
		 this.showloader(true);
        return this.http.get(this.serviceBase + callurl + '/' + id, this.jwt()).map((response: Response) => { this.showloader(false); return response.json(); }).catch(e => {
																	if (e.status === 400 || e.status === 401) {
																		this.showloader(false);
																		return Observable.throw('Unauthorized');
																	}
																	this.showloader(false);
																});
    }

    // private helper methods
	gettoken()
	{
		let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser && currentUser.token) {
            return currentUser.token;
        }
		return '';
	}
	private jwtmultypart() {
        // create authorization header with jwt token
        let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser && currentUser.token) {
            let headers = new Headers({ 'Authorization': 'Bearer ' + currentUser.token,"enctype":"multipart/form-data"});
            return new RequestOptions({ headers: headers });
        }
    }
    private jwt() {
        // create authorization header with jwt token
        let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser && currentUser.token) {
            let headers = new Headers({ 'Authorization': 'Bearer ' + currentUser.token });
            return new RequestOptions({ headers: headers });
        }
    }
}
