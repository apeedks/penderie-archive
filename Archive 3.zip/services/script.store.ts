interface Scripts {
    name: string;
    src: string;
}  
export const ScriptStore: Scripts[] = [
    {name: 'modernizr', src: '../../modernizr.custom.79639.js'},
    {name: 'cond', src: '../../jquery.ba-cond.min.js'},
	{name: 'slitslider', src: '../../jquery.slitslider.js'}
];