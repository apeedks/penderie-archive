import { Injectable } from '@angular/core';
import { Http, Headers, Response,RequestOptions} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { CookieService } from 'ngx-cookie-service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { TranslateService } from '../translate';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
@Injectable()
export class AuthenticationService {
	serviceBase:string = "";
  public token: string;
  headers: Headers;
  options: RequestOptions;
  validation_message = '';

	constructor(private http: Http, private cookieService:CookieService,private _alert: AlertsService,private _translate: TranslateService) {
		// set token if saved in local storage
        var currentUser = JSON.parse(localStorage.getItem('currentUser'));
		this.serviceBase = localStorage.getItem('apiurl');
        this.token = currentUser && currentUser.token;	
    this.headers = new Headers({ 'Content-Type': 'application/json', 
                                  'Accept': 'q=0.8;application/json;q=0.9' });
    this.options = new RequestOptions({ headers: this.headers });
	}
	private handleError(error: Response | any) {
        console.error(error);
        return Observable.throw(error); // <= B
    }
	adminsession() {
		return this.http.get(this.serviceBase + 'user',this.jwt());
  }
	
	session() {
		return this.http.get(this.serviceBase + 'user',this.jwt())
		.map((response: Response) => response.json())
		.catch(e => {
			// console.log('session',e);
			if (e.status === 400) {
				return Observable.throw('Bad Request');
			}
			if (e.status === 401) {
				return Observable.throw('Unauthorized');
			}
			// do any other checking for statuses here
		});
  }
	sessionreq()
	{
		return this.session().subscribe(response => {
			let user = response;
			console.log("session",user);
			this.cookieService.set('penderie_user_id',user.id);
			this.cookieService.set('penderie_contact_user_id',user.id,new Date().getTime() + (1000 * 1),'/');
			this.cookieService.set('penderie_user_type',user.usertype);
			if (user.usertype =='Member') {
				localStorage.setItem('user', JSON.stringify(user));
				return true;
			}
			else
			{
				localStorage.removeItem('currentUser');
				localStorage.removeItem('user');
				return false;
			}
		});
	}
	loginwithsocialid(socialid: string) {
		if(socialid != '' && socialid != undefined){
      return this.http.post(this.serviceBase + 'authfrontsocial', JSON.stringify({ socialid: socialid}))
			.map((response: Response) => {
				return response.json();
				// login successful if there's a jwt token in the response
				// let user = response.json();
				// console.log('checkSDpo',user);
				// if (user && user.token) {
				// 	// store user details and jwt token in local storage to keep user logged in between page refreshes
				// 	localStorage.setItem('currentUser', JSON.stringify(user));
				// 	this.sessionreq();
				// }
			});
		}
  }
	login(email: string, password: string) {
    return this.http.post(this.serviceBase + 'authfront', JSON.stringify({ email: email, password: password })).map((response: Response) => {
      // login successful if there's a jwt token in the response
      let user = response.json();
      console.log(user);
      if(user.type == "error"){
		  this.validation_message = user.message;
        //this._alert.create('error',this._translate.instant('Oops! Looks like your email or password is incorrect.'));
      }else{
        if (user && user.token) {
          localStorage.setItem('currentUser', JSON.stringify(user));
          this.sessionreq();
		}
		this.validation_message = '';
      }
    });
  }
  forgotusername(email: string){
    return this.http.post(this.serviceBase + 'forget-member-username', JSON.stringify({ memberEmail: email}), this.options)
            .map((response: Response) => {
              return response.json();
            });
  }
  forgotpassword(email: string){
    return this.http.post(this.serviceBase + 'forget-member-password', JSON.stringify({ memberEmail: email}), this.options)
            .map((response: Response) => {
              return response.json();
            });
  }
	isloggedin():boolean
	{
		let user = JSON.parse(localStorage.getItem('user'));
		if (user && user.id) {
      return true;
    }
		return false;
	}
	getUserId():number
	{
		let user = JSON.parse(localStorage.getItem('user'));
		if (user && user.id) {
      return user.id;
    }
		return 0;
	}
	getUserName():string
	{
		let user = JSON.parse(localStorage.getItem('user'));
		if (user && user.name) {
      return user.name;
    }
		return 'guest';
	}
	getUserImage():string
	{
		let user = JSON.parse(localStorage.getItem('user'));
		if (user && user.image) {
      return user.image;
    }
		return 'assets/img/img-def1.png';
	}
	getUserType():string
	{
		let user = JSON.parse(localStorage.getItem('user'));
		if (user && user.usertype) {
            return user.usertype;
        }
		return 'gues';
	}
	private jwt() {
        // create authorization header with jwt token
        let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser && currentUser.token) {
            let headers = new Headers({ 'Authorization': 'Bearer ' + currentUser.token });
            return new RequestOptions({ headers: headers });
        }
    }
    logout() {
        localStorage.removeItem('currentUser');
		localStorage.removeItem('user');
    }

}
