import { Component, OnInit, ElementRef, ViewChild} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../services/dbservice.service';
import { AuthenticationService } from '../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';

@Component({
  selector: 'app-stories',
  templateUrl: './stories.component.html',
  styleUrls: ['./stories.component.css']
})
export class StoriesComponent implements OnInit {
	@ViewChild('lnktimelinesharebox') lnktimelinesharebox:ElementRef;
	model = {sortfield:'latest',searchfield:'',filtercat:[],tag:''};
	userid = 0;
	saveditems = [];
	loggedin="No";
	visiblefilter = false;
	custo_filter_onen_close = false;
	visittype = '';
	theme:string = 'All';
	rootpath = '';
	websiteroot = '';
	currtime:any;
	storieslist:any;
	myitems = [];
	myslider = [];
	options:any;
	pageSize: number;
	totalitems: any;
	page: number = 1;
	last_page: number =1;
	mysharedstoryid: number =1;
	mysharedtype = 'Story';
	mysharedurl = '';
	mysharedescription = '';
	mysharedtitle = '';
	mysharedimage = '';
	categories: any;
	loaded:boolean = false;
	thetrueluxury:any;
	finematerial:any;
	superiorcraftsmanship:any;
	artofstyling:any;
	balancedliving:any;
	loading = false;
	filters:any = {thetrueluxury:[],finematerial:[],superiorcraftsmanship:[],artofstyling:[],balancedliving:[]};
	category:any = '';
  	categorytitle:any = '';
  	tag:any = '';
	constructor(private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private cookieService: CookieService) { 
		this.rootpath = localStorage.getItem('baseurl');
		this.visittype = localStorage.getItem('visittype');
		this.websiteroot = localStorage.getItem('basewebsiteurl');
		
	}
		loadddl()
	{
		this.categories = [];
		this.dbserv.getAll("storycatlist/-/"+this.visittype).
		subscribe(res => { 
			this.categories = res;
			if(this.category != '' && this.category != null)
				this.categorytitle = this.categories.find(x=>x.id == this.category).title;
			else
				this.categorytitle = '';
		});
		this.dbserv.getAll("storycatlist/The True Luxury/"+this.visittype)
		.subscribe(res => { 
			this.filters.thetrueluxury = res;
		});
		this.dbserv.getAll("storycatlist/Fine Material/"+this.visittype)
		.subscribe(res => { 
			this.filters.finematerial = res;
		});
		this.dbserv.getAll("storycatlist/Superior Craftsmanship/"+this.visittype)
		.subscribe(res => { 
			this.filters.superiorcraftsmanship = res;
		});
		this.dbserv.getAll("storycatlist/Art of Styling/"+this.visittype)
		.subscribe(res => { 
			this.filters.artofstyling = res;
		});
		this.dbserv.getAll("storycatlist/Balanced Living/"+this.visittype)
		.subscribe(res => { 
			this.filters.balancedliving = res;
		});
	}
	ngOnInit() {
		this.categorytitle = '';
		this.route.queryParamMap.subscribe(params => {
			if(params.keys.length > 0){
				this.category = params.get('category');
				this.model.tag = params.get('tag');
				console.log(params,params.keys.length);
				this.dbserv.getAll("storieswidget/"+this.visittype+"/"+this.theme).subscribe(res => {this.storieslist = res;});	
				this.loadpage(1,true);
				this.loadddl();
				this.dbserv.post("publicstoriesslider/"+this.visittype+"/"+this.theme+"/"+this.page+"/20",this.model)
				.subscribe(res => {
					this.myslider = res.data;
				});
				scroll(0,0);
			}
		});
		this.route.params.subscribe(params => {
		    this.theme = params['theme'];//params['theme']; // (+) converts string 'id' to a number
			if(!this.theme)
				this.theme = 'All';
			this.dbserv.getAll("storieswidget/"+this.visittype+"/"+this.theme).subscribe(res => {this.storieslist = res;});	
			this.loadpage(1,true);
			this.loadddl();
			this.dbserv.post("publicstoriesslider/"+this.visittype+"/"+this.theme+"/"+this.page+"/20",this.model)
			.subscribe(res => {
				this.myslider = res.data;
			});
			scroll(0,0);
		});
				$(".custo-filter-colap").click(function(e){
			if(!$(this).hasClass('custo_filter_onen_close')){
		    	$(".utl-filter-box").addClass('visiblefilter');
		    	$(".custo-filter-colap").addClass('custo_filter_onen_close');
		    	e.stopPropagation();
		    }else{
		    	$(".utl-filter-box").removeClass('visiblefilter');
		    	$(".custo-filter-colap").removeClass('custo_filter_onen_close');
		    	e.stopPropagation();
		    }
		});

		$(".utl-filter-box").click(function(e){
		    e.stopPropagation();
		});

		$(document).click(function(){
		    $(".utl-filter-box").removeClass('visiblefilter');
		    $(".custo-filter-colap").removeClass('custo_filter_onen_close');
		    // self.filterby();
		});
				if (this.authserv.isloggedin()) {
			this.loggedin = "Yes";
		}
		// this.loadddl();
		//this.theme = res['theme'];
		// this.dbserv.getAll("storieswidget/"+this.visittype+"/"+this.theme).subscribe(res => {this.storieslist = res;});	
		// this.loadpage(this.page,false);
	}
	filterswitch()
	{
		$('html, body').animate({
        	scrollTop: $("#scrollUp").offset().top - 95
    	}, 2000);
    	
		this.myitems = [];
		this.loadpage(1,false);
	}
	
	sortswitch()
	{
		this.myitems = [];
		this.loadpage(1,false);
	}
	loadpage(cpage,status)
	{
		if(cpage == 1)
			this.myitems = [];
		this.currtime = Math.random();
		this.loading = true;
		let cararray = [];
		this.filters.thetrueluxury.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.filters.finematerial.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.filters.superiorcraftsmanship.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.filters.artofstyling.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		this.filters.balancedliving.forEach(obj=>{
			if(obj.checked)
				cararray.push(obj.id);
		})
		if(cararray.length == 0){
			if(this.category != '' && this.category != null)
				cararray.push(this.category);
		}
		this.model.filtercat = cararray;
		
		this.currtime = Math.random();
		this.dbserv.post("publicstories/"+this.visittype+"/"+this.theme+"/"+cpage+"/2",this.model)
		.subscribe(res => {
			if(cpage == 1)
				this.myitems = [];
			if(res.total>this.myitems.length)
				this.myitems = [ ...this.myitems, ...res.data]
			this.loaded = true;
			//if(status)
				//this.myitems = res.data;
			//else
				// this.myitems = [ ...this.myitems, ...res.data]
				
			this.page = res.current_page; 
			this.totalitems = res.total;
			this.pageSize = res.per_page;
			this.last_page = res.last_page;
			this.loading = false;
		}); 
	}
	likeme(id,type,inx,arraylist)
	{
		let params = {story_id:id,status:type};
		this.dbserv.post("storieslike",params).subscribe(res => {
																if(res.type=="success")
																{
																	if(type=="like")
																	{
																	    if(arraylist == 'mi'){
																	        $("#mreclike" + id).css("display","none");
	                                                                        $("#mrecunlike" + id).css("display","block");
																	    }else{
    																		$("#reclike" + id).css("display","none");
    																		$("#recunlike" + id).css("display","block");
																	    }
																	}
																	else if(type=="unlike")
																	{
																	    if(arraylist == 'mi'){
																	        $("#mreclike" + id).css("display","block");
	                                                                        $("#mrecunlike" + id).css("display","none");
																	    }else{
    																		$("#reclike" + id).css("display","block");
    																		$("#recunlike" + id).css("display","none");
																	    }
																	}
																	// this.loadpage(this.page,false);
																	/*this._alert.create(res.type,res.message+type);*/
																	if(arraylist == 'mi')
																		this.myitems[inx].liked = res.total;
																	if(arraylist == 'sl')
																		this.storieslist[inx].liked = res.total;
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/login') ;	
																}
																else
																	this._alert.create(res.type,res.message);
														});
	}
		saveme(id,type,inx,arraylist)
		{
			let params = {story_id:id,status:type};
			this.dbserv.post("storiesmysavedlist",params).subscribe(res => {
																	if(res.type=="success")
																	{
																		if(type=="save")
																		{
/*																			$("#recsave" + id).css("display","none");
																			$("#recunsave" + id).css("display","block");
*/                                                                      if(arraylist == 'mi'){
                                                                            $("#mrecsave" + id).css("display","none");
                                                                            $("#mrecunsave" + id).css("display","block");
                                                                        }else{
                                                                            $("#recsave" + id).css("display","none");
                                                                            $("#recunsave" + id).css("display","block");
                                                                        }

																		}
																		else if(type=="unsave")
																		{
																		    if(arraylist == 'mi'){
	                                                                            $("#mrecsave" + id).css("display","block");
	                                                                            $("#mrecunsave" + id).css("display","none");
	                                                                        }else{
	                                                                            $("#recsave" + id).css("display","block");
	                                                                            $("#recunsave" + id).css("display","none");
	                                                                        }
																		}
																		// this.loadpage(this.page,false);
																		if(arraylist == 'mi')
	                                                                        this.myitems[inx].saved = res.total;
	                                                                    if(arraylist == 'sl')
	                                                                        this.storieslist[inx].saved = res.total;
																		/*this._alert.create(res.type,res.message+type);*/
																	}
																	else if(res.type=="expired")
																	{
																		this.router.navigateByUrl('/login') ;	
																	}
																	else
																		this._alert.create(res.type,res.message);
															});
		}
	shareme(currrec)
	{
		this.currtime = Math.random();
		this.mysharedurl = this.websiteroot+"story/"+currrec.id;
		this.mysharedescription = currrec.title;
		this.mysharedtitle = currrec.shortdesc;
		this.mysharedstoryid = currrec.id;
		this.mysharedimage = this.rootpath+'assets/stories/'+currrec.image+'?newtime='+this.currtime;
		this.lnktimelinesharebox.nativeElement.click();
		
//		lnktimelinesharebox
	}
	/*shareme(id)
	{
		let params = {story_id:id};
		this.dbserv.post("storiesshareme",params).subscribe(res => {
																if(res.type=="success")
																{
																	this._alert.create(res.type,res.message);
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/login') ;	
																}
																else
																	this._alert.create(res.type,res.message);
														});
	}*/
	addnewstory()
	{
		this.userid = this.authserv.getUserId();
		if(this.userid>0)
		{
			this.router.navigate(['/myaccount/poststory']);
		}
		else
			this.router.navigate(['/login']);
	}
	filterby()
	{
		this.visiblefilter = !this.visiblefilter;
		if(this.visiblefilter)
		{
			this.custo_filter_onen_close = true;
		}
		else
		{
			this.custo_filter_onen_close = false;	
		}
	}
	selecfillter(event:any, id:any = ''){
		// console.log(event);
		if(id == '' || id == 0 || id == null || id == undefined){
			switch (event.target.value) {
				case "thetrueluxury":
					this.filters.thetrueluxury.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "finematerial":
					this.filters.finematerial.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "superiorcraftsmanship":
					this.filters.superiorcraftsmanship.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "artofstyling":
					this.filters.artofstyling.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
				case "balancedliving":
					this.filters.balancedliving.forEach(obj=>{
						obj.checked = event.target.checked;
					})
					break;
			}
			this.myitems = [];
			this.loadpage(1,true);
		}
	}
	selecrmethod()
	{	this.myitems = [];
		this.loadpage(1,true);
	}

	key_down(e) {
		console.log(e);
		if(e.target.value == '')
		{
			this.loadpage(1,true);
		}
    		if(e.keyCode === 13) {
      				this.filterswitch();
    	}
  	}
  	add3Dots(string, limit)
	{
	  var dots = "...";
	  if(string.length > limit)
	  {
	    // you can also use substr instead of substring
	    string = string.substring(0,limit) + dots;
	  }
	    return string;
	}
	
	throttle = 1780;
  scrollDistance = 1;
  scrollUpDistance = 2;
	onScrollDown() {
		if(this.totalitems>this.myitems.length){
			this.page++
			this.loadpage(this.page,true);
		}
  }
    selectAll(event:any){
    	this.thetrueluxury = event.target.checked;
    	this.finematerial = event.target.checked;
    	this.superiorcraftsmanship = event.target.checked;
    	this.artofstyling = event.target.checked;
    	this.balancedliving = event.target.checked;
    	event.target.value = 'thetrueluxury';
    	this.selecfillter(event);
    	event.target.value = 'finematerial';
    	this.selecfillter(event);
    	event.target.value = 'superiorcraftsmanship';
    	this.selecfillter(event);
    	event.target.value = 'artofstyling';
    	this.selecfillter(event);
    	event.target.value = 'balancedliving';
    	this.selecfillter(event);
		this.myitems = [];
		this.loadpage(1,true);
	}
	street(id){
		$("#ellipsis-"+id).children().toggleClass('fa fa-ellipsis-h fa fa-ellipsis-v');
		$("#street-"+id).toggle();
	}
}
