import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StorydetComponent } from './storydet.component';

describe('StorydetComponent', () => {
  let component: StorydetComponent;
  let fixture: ComponentFixture<StorydetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StorydetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StorydetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
