import { Component, OnInit, ElementRef, ViewChild} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../../services/dbservice.service';
import { AuthenticationService } from '../../services/authentication.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';

@Component({
  selector: 'app-storydet',
  templateUrl: './storydet.component.html',
  styleUrls: ['./storydet.component.css']
})
export class StorydetComponent implements OnInit {
	@ViewChild('lnktimelinesharebox') lnktimelinesharebox:ElementRef;
	record = {id:0,category_id:0,user_id:0,title:"",credits:"",shortdesc:"",gender:"",tag:'',imagetitle:"",image:"",description:"",theme:"",featured:"",tags:[],created_at:"",updated_at:"",viewed:"",active:"",name:"",username:"",userimage:"",category:"",loggedin:'No',liked:'',saved:'',likedbyme:'',savedbyme:''};
	storieslist:any;
	
	stroyid = 0;
	loggedin="No";
	pageurl = '';
	visittype = '';
	rootpath = '';
    tagslist:any;
	websiteroot = '';
	currtime:any;
	userid = 0;
	userimage = '';
	comment = '';
	options:any;
	pageSize: number;
	totalitems:number;
	last_page:number = 1;
	page: number = 1;
	limit:number = 5;
	public items = [];
	mysharedstoryid: number =1;
	mysharedtype = 'Story';
	mysharedurl = '';
	mysharedescription = '';
	mysharedtitle = '';
	mysharedimage = '';
	constructor(private route: ActivatedRoute,private authserv: AuthenticationService,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private cookieService: CookieService) { 
		this.rootpath = localStorage.getItem('baseurl');
		this.visittype = localStorage.getItem('visittype');
		this.websiteroot = localStorage.getItem('basewebsiteurl');
		if(this.authserv.isloggedin())
		{
			this.userid = +this.authserv.getUserId();
			this.userimage = this.authserv.getUserImage();
		}
	}
	loadcomments(pageno,status)
	{	
		this.currtime = Math.random();
		this.dbserv.getAll("publicstorycomments/"+this.record.id+"/"+pageno+"/"+this.limit).subscribe(res => {
																			if(status)
																				this.items = res.records.data;
																			else
																				this.items = [ ...this.items, ...res.records.data]
																			this.page = res.records.current_page; 
																			this.totalitems = res.records.total;
																			this.pageSize = res.records.per_page;
																			this.last_page = res.records.last_page;
																			this.userid = +res.userid;
																		}); 	
	}
	savecomment($event)
	{
		if($event.keyCode == 13) 
		{
			if($event.target.value!="")
			{
				let commmodel = {storyid:this.record.id,comment:$event.target.value};
				this.dbserv.save("storysavecomment",commmodel).subscribe(res => {
																				if(res.type=="success")
																			   {
																					this.comment = '';
																					this.loadcomments(1,true);
																			   }
																			   else
																			   		this._alert.create(res.type,res.message);	
																		});
			}
			else
			{
				this._alert.create('error','Please, enter the comment.');	
			}
		}
	}
	savecommentreply($event,commid)
	{
		if($event.keyCode == 13) 
		{
			if($event.target.value!="")
			{
				let commmodel = {storyid:this.record.id,commentid:commid,reply:$event.target.value};
				this.dbserv.save("savecommentreply",commmodel).subscribe(res => {
																				if(res.type=="success")
																			   {
																					this.comment = '';
																					$event.target.value = '';
																					this.loadcomments(1,true);
																			   }
																			   else
																			   		this._alert.create(res.type,res.message);	
																		});
			}
			else
			{
				this._alert.create('error','Please, enter the comment.');	
			}
		}
	}
	likeme(id,type,inx='')
	{
		let params = {story_id:id,status:type};
		this.dbserv.post("storieslike",params).subscribe(res => {
																if(res.type=="success")
																{
																	if(type=="like")
																	{
																		$("#reclike" + id).css("display","none");
																		$("#recunlike" + id).css("display","block");
																	}
																	else if(type=="unlike")
																	{
																		$("#reclike" + id).css("display","block");
																		$("#recunlike" + id).css("display","none");
																	}
																	// this.loadpage();
																	if(inx != '')
																	{
																	  this.storieslist[inx].liked = res.total;
																	  }
																	  else{
																		  this.record.liked = res.total;
																	  }
																	
																	/*this._alert.create(res.type,res.message+type);*/
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/login') ;	
																}
																else
																	this._alert.create(res.type,res.message);
														});
	}
	saveme(id,type,inx='')
	{
		let params = {story_id:id,status:type};
		this.dbserv.post("storiesmysavedlist",params).subscribe(res => {
																if(res.type=="success")
																{
																	if(type=="save")
																	{
																		$("#recsave" + id).css("display","none");
																		$("#recunsave" + id).css("display","block");
																	}
																	else if(type=="unsave")
																	{
																		$("#recsave" + id).css("display","block");
																		$("#recunsave" + id).css("display","none");
																	}
																	// this.loadpage
																	if(inx != '')
																	{
																	  this.storieslist[inx].saved = res.total;
																	  }
																	  else{
																		  this.record.saved = res.total;
																	  }
																	/*this._alert.create(res.type,res.message+type);*/
																}
																else if(res.type=="expired")
																{
																	this.router.navigateByUrl('/login') ;	
																}
																else
																	this._alert.create(res.type,res.message);
														});
	}
	opensharebox(id)
	{
		this.lnktimelinesharebox.nativeElement.click();
	}
	loadpage()
	{
		this.currtime = Math.random();
		this.dbserv.getById("storiesdetpub",this.stroyid).subscribe(res => {
																		if(res.type=="success")
																		{
																			this.record = res.data;
																			this.loadcomments(1,true);
																			this.mysharedstoryid = this.record.id;
																			this.mysharedescription = this.record.shortdesc;
																			this.mysharedtitle = this.record.title;
																			this.mysharedimage = this.rootpath+'assets/stories/' + this.record.image+'?random+\='+this.currtime;
																			this.mysharedurl = this.websiteroot+"story/"+ this.record.id;
																			this.dbserv.getById("story/increase-view",this.stroyid).subscribe(res => {});
																		}else{
																			this.router.navigateByUrl('/stories') ;	
																		}
																	});
	}
	ngOnInit() {
        this.dbserv.getAll("storieswidget/"+this.visittype+"/All").subscribe(res => {this.tagslist = res;});
		this.dbserv.getAll("storieswidget/"+this.visittype+"/All").subscribe(res => {this.storieslist = res;});	
		this.route.params.subscribe(params => {
		    this.stroyid = params['stroyid'];
			this.loadpage();
		});
		scroll(0,0);
		if (this.authserv.isloggedin()) {
			this.loggedin = "Yes";
		}
	}
        add3Dots(string, limit)
    {
      var dots = "...";
      if(string.length > limit)
      {
        // you can also use substr instead of substring
        string = string.substring(0,limit) + dots;
      }
        return string;
    }
    tagswitch(tg)
    {
        this.record.tag = tg;
//        this.items = [];
        this.loadpage();
    }
        sortswitch()
    {
        $('html, body').animate({
            scrollTop: $("#scrollUp").offset().top - 95
        }, 2000);
        this.items = [];
        this.loadpage();
	}
		shareme(currrec)
	{
		this.currtime = Math.random();
		this.mysharedurl = this.websiteroot+"story/"+currrec.id;
		this.mysharedescription = currrec.title;
		this.mysharedtitle = currrec.shortdesc;
		this.mysharedstoryid = currrec.id;
		this.mysharedimage = this.rootpath+'assets/stories/'+currrec.image+'?newtime='+this.currtime;
		this.lnktimelinesharebox.nativeElement.click();
		
//		lnktimelinesharebox
	}    
		street(id){
		$("#ellipsis-"+id).children().toggleClass('fa fa-ellipsis-h fa fa-ellipsis-v');
		$("#street-"+id).toggle();
	}
}
