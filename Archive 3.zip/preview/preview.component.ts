import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../services/dbservice.service';
import { Meta,Title} from '@angular/platform-browser';
import {PlatformLocation } from '@angular/common';
import $ from 'jquery';

@Component({
  selector: 'app-preview',
  templateUrl: './preview.component.html',
  styleUrls: ['./preview.component.css']
})
export class PreviewComponent implements OnInit {
  pageid:string;
  pageurl:string;
  basepageurl:string;
  record = {
		id:0,
		contents_tabs_id:0,
		content_section: '',
		title: '',
		content:"",
		content_type:'',
		sortorder:0
	};
  sections = [{
		id:0,
		contents_tabs_id:0,
		section_type: 'content',
		title: '',
		content:"",
		content_type:'',
		sortorder:0
	}];
	sections_heading = [{
		id:0,
		title:'',
		content_section:'',
		contents_tabs_id:0,
		sortorder:0,
		sections:this.sections
	}]
  tabs = [{
		id:0,
		contents_id:0,
		template:0,
		content_type: 'template',
		content_section: '',
		title: '',
		content:"",
		sortorder:0,
		sections_heading:this.sections_heading
	}];
  model = {
  	id:0,
  	title: '',
  	content: "",
  	image: "",
  	metatitle: "",
  	metakeyword: "",
  	metadescr: "",
  	summary:'',
  	content_type:'',
  	tabs:this.tabs
  };
  headerimage:string='';
  h2itemsarray = [];
  constructor(private dbserv:DbserviceService,private route: ActivatedRoute,private router: Router,private meta: Meta, private titleService: Title,private platformLocation: PlatformLocation) { }
	
  getimage(img)
  {
	return  'assets/pageheaders/'+ img;
  }
  getRoute(event) {
		var goRoute = event.target.getAttribute('data-link')
		// alert(goRoute);
		if(goRoute != '#'){
			this.router.navigate([goRoute]);
		}
	}
	slug(str) {
	    var $slug = '';
	    var trimmed = $.trim(str);
	    $slug = trimmed.replace(/[^a-z0-9-]/gi, '-').
	    replace(/-+/g, '-').
	    replace(/^-|-$/g, '');
	    return $slug.toLowerCase();
	}
  ngOnInit() {
	  this.pageurl = (this.platformLocation as any).location.href;
	  this.basepageurl =  localStorage.getItem("baseurl");
	  this.route.params.subscribe(params => {
		  this.pageid = params['pageid']; // (+) converts string 'id' to a number
			this.dbserv.getByStringId("getcontentpreview",this.pageid)
				.subscribe(res => {
					if(res.type=="success")
						// res.data.content = res.data.content.replace(/href/g,"data-link");
						// var h2items = [];
						// h2items = res.data.content.split("<h2>");
						// this.h2itemsarray = [];
						// h2items.forEach((val)=>{
						// 	if(val.indexOf("</h2>") != -1){
						// 		let h3items = val.split("<h3>");
						// 		let h3itemsarray = [];
						// 		h3items.forEach((valh3)=>{
						// 			if(valh3.indexOf("</h3>") != -1){
						// 				let h3txt = valh3.substring(0,valh3.indexOf("</h3>"));
						// 				let h3content = valh3.substring(valh3.indexOf("</h3>"));
						// 				h3itemsarray.push({title:h3txt,slug:this.slug(h3txt),content:h3content});
						// 			}
						// 		});
						// 		let h2txt = val.substring(0,val.indexOf("</h2>"));
						// 		let h2content = val.substring(val.indexOf("</h2>"));
						// 		res.data.content = res.data.content.replace("<h2>"+h2txt+"</h2>", "<h2 id=\""+this.slug(h2txt)+"\">"+h2txt+"</h2>");
						// 		this.h2itemsarray.push({title:h2txt,slug:this.slug(h2txt),items:h3itemsarray,content:h2content});
						// 	}
						// });
						// console.log(this.h2itemsarray);
						this.model=res.data;
						this.headerimage = this.basepageurl + "/assets/pageheaders/" + this.model.image;
						this.meta.addTag({ name: 'keywords', content: this.model.metakeyword });
						this.meta.addTag({ name: 'description', content: this.model.metadescr });
						this.meta.addTag({ property: 'og:title', content: this.model.metakeyword });
						this.meta.addTag({ property: 'og:description', content: this.model.metadescr });
						this.meta.addTag({ property: 'og:image', content: this.headerimage });
						this.meta.addTag({ property: 'og:url', content: this.pageurl });
						this.titleService.setTitle(this.model.metatitle);
  					scroll(0,0);
				});
		});
  }

  scrollUp(id){
		$('html, body').animate({
    		scrollTop: $("#section"+id).offset().top - 104
  		}, 2000);
	}
}
