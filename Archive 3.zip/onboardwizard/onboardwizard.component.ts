import { Component, OnInit, trigger, state, style, transition, animate, Input, Output, EventEmitter, HostListener, ElementRef, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {DbserviceService} from '../services/dbservice.service';
import {AlertsService} from '@jaspero/ng2-alerts';
import { CookieService } from 'ngx-cookie-service';
import $ from 'jquery';
import { AuthenticationService } from '../services/authentication.service';
import {ImageCropperComponent, CropperSettings} from 'ng2-img-cropper';
@Component({
  selector: 'app-onboardwizard',
  templateUrl: './onboardwizard.component.html',
  styleUrls: ['./onboardwizard.component.css']
})
export class OnboardwizardComponent implements OnInit {
	conmodel = {connectiontype:'Connections',personality:'', facebook: "",twitter: "",linkedin:"",instagram: "",pinterest: "",youtube: "",google: "",website: "",gender:""};
	currentmenu:number = 0;
	aboutme:string='';
	dragAreaClass:string='dragarea';
	tabfirst = true;
	tabsecond = false;
	activeone = true;
	activetwo = false;
	connectionWebPresense = 0;
	clubdefault:string = '';
	preflistdefault:string = '';
	prefcatlist = [];
	preftypelist = [];
	selectedprefs = [];
	uploadedimage:any=null;
	uploadedimagebtn:boolean=false;
	imagepreviewurl:string='';
	userid:number;
	pointlist:any;
	errors = [];
	clubslist = [];
	grouplist = [];
	forumlist = [];
	options:any;
	genderselection = 0;
	gender:string="";
	currentpreviousestep:number = 1;
	currentnextstep:number = 2;
	currentstep:number = 1;
	totalsearchsteps:number = 5;
	totalpoints:number = 0;
	
	isprofilephotouploaded = false;
	isaboutfilled = false;
	ispreferencefilled = false;
	isclubselected = false;
	isnetworkchosen = false;
	issharenannourcechosen = false;
	
	imagedata: any;
	imagepreviewurl2:string;
	websiteroot:string;
	cropperSettings: CropperSettings;
	symbol = {backtype1:'',backtype:'',backtype2:'',initial1:'',initial2:'',initial3:'',frontfont:"",frontcolor:"#C0C0C0",background:'',background1:'#C0C0C0',background2:'#C0C0C0'};
	@ViewChild('lnksaveprofilebox') lnksaveprofilebox:ElementRef;
	@ViewChild('cropper', undefined) cropper:ImageCropperComponent;
	
	uploadedsymbol:any=null;
	symbolimage = '';
	uploadedsymbolbtn:boolean=false;
	rootpath = '';
	skipwizardc:boolean = false;

	constructor(private route: ActivatedRoute,private router: Router,private _alert: AlertsService,private dbserv:DbserviceService,private auth:AuthenticationService,private cookieService: CookieService) {
		this.rootpath = localStorage.getItem('baseurl');
		this.cropperSettings = new CropperSettings();
        this.cropperSettings.width = 600;
        this.cropperSettings.height = 600;
        this.cropperSettings.croppedWidth = 600;
        this.cropperSettings.croppedHeight = 600;
        this.cropperSettings.canvasWidth = 420;
		this.cropperSettings.noFileInput = true;
        this.cropperSettings.canvasHeight = 300;
        this.cropperSettings.touchRadius = 92;
		this.cropperSettings.rounded = true;
     	this.cropperSettings.keepAspect = true;
        this.imagedata = {};
	}
	cropped($event)
	{
		/*this.imagepreviewurl = this.imagedata.image;
		this.imagepreviewurl2 = this.imagedata.image;*/
	}
	stepback()
	{
		// if(this.connectionWebPresense == 1){
			if(this.currentpreviousestep == 4)
				this.currentpreviousestep = 3;
		// }
		this.movetostep(this.currentpreviousestep);
		scroll(0,0);
	}
	skipwizard()
	{
		this.skipwizardc = true;
		this.movetostep(this.currentnextstep);
		scroll(0,0);
	}
	saveaboutme()
	{
		if(this.aboutme!=null && this.aboutme!='')
		{
			this.userid = this.auth.getUserId();
			let _formData = new FormData();
			_formData.append("userid",this.userid.toString());
			_formData.append("aboutme",this.aboutme);
			this.dbserv.saveimage("userprofileaboutme",_formData).subscribe(res => {
															this._alert.create(res.type,res.message);
															this.isaboutfilled = true;
															this.getporfilepoints();
														}); 	
		}
	}
	changepersonality(type)
	{
		$(".personality").removeClass("active");
		$("#lnk"+type).addClass("active");
		this.conmodel.personality = type;	
	}
	saveconnections()
	{
		this.dbserv.save("updateconnectiontype",this.conmodel).subscribe(res => {
													this.isnetworkchosen = true;
													this.getporfilepoints();
												}); 	
	}
	switchconnections(type)
	{
		this.isnetworkchosen = false;
		this.conmodel.connectiontype = type;
		this.dbserv.save("updateconnectiontype",this.conmodel).subscribe(res => {
													this.isnetworkchosen = true;
													this.getporfilepoints();
												}); 	
	}
	
	nextwizard()
	{
		if(this.currentstep==1)
		{
			this.saveaboutme();
		}
		// if(this.connectionWebPresense == 1){
			if(this.currentnextstep == 4)
				this.currentnextstep = 5;
		// }
		this.movetostep(this.currentnextstep);
		scroll(0,0);
	}
	movetostep(stepid:number)
	{
		if(stepid>this.totalsearchsteps)
		{
			this.userid = this.auth.getUserId();
			this.updatepoint(this.currentstep);
			let model = {isnew:'No',user:this.userid}
			this.dbserv.save("updateisnew",model).subscribe(res => {
													this._alert.create(res.type,res.message);
													this.router.navigate(['/home']);
												});
		}
		else
		{
			this.updatepoint(this.currentstep);
			if(stepid>3)
			{
				this.getselectedclubs();
			}
			else if(stepid>2)
			{
				this.getselectedprefs();
			}
			
			if(stepid>1 && stepid<=this.totalsearchsteps)
			{
				this.currentpreviousestep = stepid-1;
				this.currentnextstep = stepid+1;	
				this.currentstep = stepid;	
				$('#stepbackbutton').css("display",'block');
				
			}
			else if(stepid>this.totalsearchsteps)
			{
				this.currentpreviousestep = this.totalsearchsteps-1;
				this.currentnextstep = this.totalsearchsteps;
				this.currentstep =this.totalsearchsteps;alert('2-'+stepid);
			}
			else
			{
				this.currentpreviousestep = 1;
				this.currentnextstep = 2;
				this.currentstep = 1;	
				$('#stepbackbutton').css("display",'none');
			}	
			$('.new-tabs-opt-outer').css("display",'none');
			$('#step' + this.currentstep).css("display",'block');
			if(this.currentstep == 3)
				this.clubcontent(this.clubdefault);
			if(this.currentstep == 2)
				this.prefcontent("1");
			
			switch(this.currentstep)
			{
				case 1:
					$('#abouttab').addClass("active");
					$('#preftab').removeClass("active");
					$('#clubtab').removeClass("active");
					$('#networktab').removeClass("active");
					$('#sharenannourcetab').removeClass("active");
					break;
				case 2:
					$('#abouttab').addClass("active");
					$('#preftab').addClass("active");
					$('#clubtab').removeClass("active");
					$('#networktab').removeClass("active");
					$('#sharenannourcetab').removeClass("active");
					break;
				case 3:
					$('#abouttab').addClass("active");
					$('#preftab').addClass("active");
					$('#clubtab').addClass("active");
					$('#networktab').removeClass("active");
					$('#sharenannourcetab').removeClass("active");
					break;
				case 4:
					$('#abouttab').addClass("active");
					$('#preftab').addClass("active");
					$('#clubtab').addClass("active");
					$('#networktab').addClass("active");
					$('#sharenannourcetab').removeClass("active");
					break;
				case 5:
					$('#abouttab').addClass("active");
					$('#preftab').addClass("active");
					$('#clubtab').addClass("active");
					$('#networktab').addClass("active");
					$('#sharenannourcetab').addClass("active");
					break;
			}
		}
		// console.log('step',this.currentstep);
	}
	updatepoint(step)
	{
		if(this.isprofilephotouploaded || this.isaboutfilled)
		{
			let pntmodel = {stepid:step,points:this.pointlist[step-1].point};
			this.dbserv.save("saveonboardpoints",pntmodel).subscribe(res => {
															this.getporfilepoints();
														});	
		}
		if(this.ispreferencefilled)
		{
			let pntmodel = {stepid:step,points:this.pointlist[step-1].point};
			this.dbserv.save("saveonboardpoints",pntmodel).subscribe(res => {
															this.getporfilepoints();
														});	
		}
		if(this.isclubselected)
		{
			let pntmodel = {stepid:step,points:this.pointlist[step-1].point};
			this.dbserv.save("saveonboardpoints",pntmodel).subscribe(res => {
															this.getporfilepoints();
														});	
		}
		if(this.isnetworkchosen)
		{
			let pntmodel = {stepid:step,points:this.pointlist[step-1].point};
			this.dbserv.save("saveonboardpoints",pntmodel).subscribe(res => {
															this.getporfilepoints();
														});	
		}
		if(this.issharenannourcechosen)
		{
			let pntmodel = {stepid:step,points:this.pointlist[step-1].point};
			this.dbserv.save("saveonboardpoints",pntmodel).subscribe(res => {
															this.getporfilepoints();
														});	
		}
	}
	getselectedprefs()
	{
		this.selectedprefs = [];
		for(let x in this.prefcatlist) {
			if(this.prefcatlist[x].checked)
				this.selectedprefs.push({c:this.prefcatlist[x].id});
			if(this.prefcatlist[x].items)
				for(let y in this.prefcatlist[x].items) {
					if(this.prefcatlist[x].items[y].checked)
						this.selectedprefs.push({b:this.prefcatlist[x].items[y].id});
				}
		}	
		if(this.selectedprefs.length<1 && this.selectedprefs.length>3)
		{
			this._alert.create('error','You must select alteast 1 and atmost 3 Luxury Brands.');
			return false;
		}
		else
		{
			let model = {prefs:this.selectedprefs,type:'Luxury Brands'}
			this.dbserv.save("savefrontcatsbrandstypesprefs",model).subscribe(res => {
														//this._alert.create(res.type,res.message);
													});	
		}
		
		this.selectedprefs = [];
		for(let x in this.preftypelist) {
			if(this.preftypelist[x].checked)
				this.selectedprefs.push({c:this.preftypelist[x].id});
			if(this.preftypelist[x].items)
				for(let y in this.preftypelist[x].items) {
					if(this.preftypelist[x].items[y].checked && this.skipwizardc === false)
						this.selectedprefs.push({b:this.preftypelist[x].items[y].id});
				}
		}	
		this.skipwizardc = !this.skipwizardc;
		if(this.selectedprefs.length<1 && this.selectedprefs.length>3)
		{
			this._alert.create('error','You must select alteast 1 and atmost 3 Luxury Brands.');
			return false;
		}
		else
		{
			let model = {prefs:this.selectedprefs,type:'Material'}
			this.dbserv.save("savefrontcatsbrandstypesprefs",model).subscribe(res => {
														//this._alert.create(res.type,res.message);
													});	
		}
	}
	getselectedclubs()
	{
		this.grouplist = [];
		this.forumlist = [];
		this.isclubselected = false;
		for(let x in this.clubslist) {
			if(this.clubslist[x]) {
				for(let y in this.clubslist[x].items) {
					if(this.clubslist[x].items[y].checked)
						this.grouplist.push(this.clubslist[x].items[y].id);
					if(this.clubslist[x].items[y].items)
						for(let z in this.clubslist[x].items[y].items) {
							if(this.clubslist[x].items[y].items[z].checked)
								this.forumlist.push(this.clubslist[x].items[y].items[z].id);
						}
				}
			}
		}	
		if(this.grouplist.length<1 && this.grouplist.length>3)
		{
			this._alert.create('error','You must select alteast 1 and atmost 3 groups.');
			return false;
		}
		else
		{
			this.userid = this.auth.getUserId();
			let model = {user:this.userid,groups:this.grouplist,forums:this.forumlist}
			this.dbserv.save("saveclubprefs",model).subscribe(res => {
														this._alert.create(res.type,res.message);
													});	
			this.isclubselected = true;
			this.getporfilepoints();
		}
	}
	
	readImageUrl() {
	  if (this.uploadedimage && this.uploadedimage) {
		var reader = new FileReader();
		var image:any = new Image();
		reader.onload = (event:any) => {
		   image.src = event.target.result; 
			this.cropper.setImage(image);
		}
		reader.onloadend = (event:any) => {
           image.src = event.target.result; 
			this.cropper.setImage(image);
        };
		reader.readAsDataURL(this.uploadedimage);
	  }
	}
	onFileChange($event){
	   this.uploadedimage = $event.target.files[0];
	   this.readImageUrl();
	   //this.saveprofileimage( $event.target.files[0]);
	}
	@HostListener('dragover', ['$event']) onDragOver(event) {
        this.dragAreaClass = "droparea";
        event.preventDefault();
    }
	@HostListener('dragenter', ['$event']) onDragEnter(event) {
		this.dragAreaClass = "droparea";
		event.preventDefault();
	}
	@HostListener('dragend', ['$event']) onDragEnd(event) {
		this.dragAreaClass = "dragarea";
		event.preventDefault();
	}
	@HostListener('dragleave', ['$event']) onDragLeave(event) {
		this.dragAreaClass = "dragarea";
		event.preventDefault();
	}
	@HostListener('drop', ['$event']) onDrop(event) {   
		this.dragAreaClass = "dragarea";           
		event.preventDefault();
		event.stopPropagation();
		this.uploadedimage = event.dataTransfer.files[0];
		this.readImageUrl();
		//this.saveprofileimage(event.dataTransfer.files[0]);
	}
	saveprofileimage(){
	 	this.uploadedimagebtn = true;
		if(this.imagedata.image!=null && this.uploadedimage!=null && this.uploadedimage.name!='')
		{
			console.log(this.uploadedimage);
			let _formData = new FormData();
			_formData.append("id",this.userid.toString());
			_formData.append('image',this.uploadedimage, this.uploadedimage.name);
			_formData.append('image',this.imagedata.image);
			if (this.uploadedimage && this.uploadedimage) {
				_formData.append('imagesrc',this.uploadedimage, this.uploadedimage.name);
			}
			this.dbserv.saveimage("userprofileimage",_formData).subscribe(res => {
				this.uploadedimagebtn = false;
				this.isprofilephotouploaded = true;
				this.dbserv.getById("getuserdetail",this.auth.getUserId()).subscribe(ures => {
					console.log("connectiontype ="+ures);
					if(ures.type=="success")
					{
						 this.imagepreviewurl = ures.data.image;
						// console.log("imagepreviewurl=",this.imagepreviewurl);
					}

				});
				this.lnksaveprofilebox.nativeElement.click();
				this.getporfilepoints();
				this._alert.create(res.type,res.message);
			}); 
		}
		else
		{
			this._alert.create('error','Please, select an image first.');
			this.uploadedimagebtn = false;
		}
	}
	
	ngOnInit() {
		this.userid = this.auth.getUserId();
		if(this.userid>0)
		{
			let tvp:string = this.cookieService.get('visittype');
			if(tvp=="")
				tvp = 'Women';
			this.getporfilepoints();
			console.log(this.imagepreviewurl);
			this.imagepreviewurl = this.auth.getUserImage();
			this.dbserv.getAll("clubs/" + tvp).subscribe(res => {this.clubslist = res;this.clubdefault = this.clubslist[0].id.toString();});
			 this.dbserv.getById("getuserdetail",this.userid).subscribe(res => {
	                if(res.type=="success")
	                {
	                    this.gender = res.data.gender;
	                    /*if(this.gender == "Men")
                        {
                            this.imagepreviewurl = 'assets/img/original.jpg';
                        }
                        if(this.gender == "Women")
                        {
                            this.imagepreviewurl = 'assets/img/img-def1.png';
                        }*/
	                }
	            });
			 
			this.dbserv.getAll("getuserdetail/"+this.userid)
                .subscribe(data => {
                    if(data.type=="success")
                    {
                        this.dbserv.getAll("prefcatsbrands/"+data.data.gender).subscribe(res => {
                            if(res.type=="success")
                            {
                                this.prefcatlist = res.data;
                            }
                            else if(res.type=="expired")
                            {
                                this.router.navigateByUrl('/login') ;   
                            }
                            else
                                this._alert.create(res.type,res.message);
                        });
                        this.dbserv.getAll("prefcatstypes/"+data.data.gender).subscribe(res => {
                            if(res.type=="success")
                            {
                                this.preftypelist = res.data;
                            }
                            else if(res.type=="expired")
                            {
                                this.router.navigateByUrl('/login') ;   
                            }
                            else
                                this._alert.create(res.type,res.message);
                        });
                    }
                });
			this.dbserv.getById("getuserdetail",this.auth.getUserId()).subscribe(ures => {
				console.log("connectiontype =",ures);
				if(ures.type=="success")
				{
						this.conmodel.connectiontype = ures.data.connectiontype;
						this.conmodel.gender = ures.data.gender;
						if(ures.data.gender == "Men" && ures.data.image == '')
						{
						    this.imagepreviewurl = 'assets/img/original.jpg';
						}
						if(ures.data.gender == "Women" && ures.data.image == '')
                        {
						    this.imagepreviewurl = 'assets/img/img-def1.png';
                        }
						console.log(this.imagepreviewurl);
						
					if(this.conmodel.connectiontype=="Follower Only")
					{
						this.currentstep = 2;
						this.currentnextstep = 2;
						this.movetostep(this.currentnextstep);
						scroll(0,0);
						this.connectionWebPresense = 1;
						console.log("value of count"+this.connectionWebPresense);
					}
					
				}

			});
		}
		else
		{
			this.router.navigate(['login']);	
		}
		window.scroll(0,0);
	}
	getporfilepoints()
	{
		this.dbserv.getAll("profilepoints").subscribe(res => {
														  
														    this.pointlist = res;
															this.totalpoints = 0;
															this.totalpoints += +this.pointlist[0].point;
															this.totalpoints += +this.pointlist[1].point;
															this.totalpoints += +this.pointlist[2].point;
															this.totalpoints += +this.pointlist[3].point;
															this.totalpoints += +this.pointlist[4].point;
												});	
	}
	tabcontent(tab:string)
	{
		if(tab=='photo')
		{
			this.activeone = true;
			this.activetwo = false;
			this.tabfirst = true;
			this.tabsecond = false;
		}
		else
		{
			this.activeone = false;
			this.activetwo = true;
			this.tabfirst = false;
			this.tabsecond = true;
		}
	}
	prefcontent(tab)
	{
		$(".tab_prefcontentjquery").removeClass("activeitem");
		$(".tab_prefcontentjquery").addClass("inactiveitem");
		$("#prefmytab"+ tab).removeClass("inactiveitem");
		$("#prefmytab"+ tab).addClass("activeitem");
		$(".preftabheaders").removeClass("active");
		$("#preftabhead"+ tab).addClass("active");
	}
	clubcontent(tab)
	{
		$(".tab_contentjquery").removeClass("activeitem");
		$(".tab_contentjquery").addClass("inactiveitem");
		$("#mytab"+ tab).removeClass("inactiveitem");
		$("#mytab"+ tab).addClass("activeitem");
		$(".tabheaders").removeClass("active");
		$("#tabhead"+ tab).addClass("active");
	}	
}
