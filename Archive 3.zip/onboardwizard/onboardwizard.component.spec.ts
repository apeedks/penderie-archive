import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnboardwizardComponent } from './onboardwizard.component';

describe('OnboardwizardComponent', () => {
  let component: OnboardwizardComponent;
  let fixture: ComponentFixture<OnboardwizardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnboardwizardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnboardwizardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
